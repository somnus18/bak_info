/**
 * 处理增量文件，并进行加密
 *
 */

var fs = require('fs'),
    path = require('path'),
    grunt = require('grunt'),
    zip = require('jszip'),
    maps = require('./maps.config'),
    baseDir = process.cwd(),
    projectCode = '.',
    WORKDIR = '/upgrade/',
    updateDir = '.',
    destFiles = new Array();

// 获取主进程文件传递过来的参数，设置打包环境基地址
var argv = process.argv.slice(2);
if((index=argv.indexOf('-basedir')) != -1) {
    var value = argv[index+1];
    baseDir = value || '.';
    process.chdir(baseDir || '.');
}
if((index=argv.indexOf('-projectCode')) != -1) {
    var value = argv[index+1];
    projectCode = value || '.';
}
if((index=argv.indexOf('-updateDir')) != -1) {
    var value = argv[index+1];
    updateDir = value || '.';
}

WORKDIR = projectCode + WORKDIR;

// 读取默认配置信息
var filelist = path.join(baseDir, updateDir, 'filelist'),
    filepath = fs.readFileSync(filelist, 'utf8').replace(/[A-Z]{1}\s{7}/g, '').replace('/\n$/ig', '').split('\n'),
    preMaps = maps.preMaps,
    maps = maps.maps,
    preMapsList = new Array();

// 读取自定义映射配置信息
var customMapsFile = './' + projectCode + '/upgrade/customMaps.config';
if(!!fs.existsSync(customMapsFile)) {
    // 此处有坑，留心发现！
    var customMaps = require('../' + projectCode + '/upgrade/customMaps.config');
    for(var i in customMaps.preMaps) {
        preMaps.push(customMaps.preMaps[i]);
    }
    for(var j in customMaps.maps) {
        maps.push(customMaps.maps[j]);
    }
    // TODO: 最好对合并后的映射配置，进行一个去重
}

// 预映射准备
var tmpList = new Array();
filepath.forEach(function(srcfile) {
    for(var i in preMaps) {
        if(srcfile.search(preMaps[i]['reg']) != -1) {
            tmpList = fs.readdirSync(projectCode + '/' + preMaps[i]['path']);
            for(var j in tmpList) {
                if(path.extname(tmpList[j])==preMaps[i]['ext']) {
                    fs.appendFileSync(path.join(baseDir, updateDir, 'filelist'), preMaps[i]['path']+tmpList[j]+'\n');
                    preMapsList.push(tmpList[j]);
                }
            }
        }
    }
});

Array.prototype.push.apply(filepath, preMapsList);

// 计算出真实拷贝的文件
var filelist = path.join(baseDir, updateDir, 'filelist'),
    filepath = fs.readFileSync(filelist, 'utf8').replace(/[A-Z]{1}\s{7}/g, '').replace('/\n$/ig', '').split('\n');
filepath.forEach(function(srcfile) {
    for(var i in maps) {
        if(srcfile.search(maps[i]['src']) != -1) {
            var destFile = srcfile.replace(maps[i]['src'], maps[i]['dest']);
            if(destFiles.indexOf(destFile)==-1) {
                destFiles.push(destFile);
                console.log(destFile + '****************');
            }
        }
    }
});

// 拷贝文件
destFiles.forEach(function(file) {
    var srcFile = './' + projectCode + '/dist/' + file,
        destFile = './' + WORKDIR + '/update_code/' + file;
        reg = /\.(css|js|html|png|jpg|gif|jpeg|json|less|md)$/ig;
    if(!reg.test(file)) {
        srcFile = srcFile + '/';
    }
    if(grunt.file.isDir(srcFile)) {
        grunt.file.mkdir(path.join(distPath, srcFile));
    } else {
        if(grunt.file.exists(srcFile)) {
            grunt.file.copy(srcFile, destFile);
        }
    }
});

// 解压manifest_rsa.zip
var input = fs.readFileSync(updateDir + '/manifest_rsa.zip', 'binary'),
    zip = new zip(input),
    files = zip.files,
    filenames = Object.getOwnPropertyNames(files);
filenames.forEach(function(filename) {
    var content = zip.file(filename).asBinary();
    fs.writeFileSync(baseDir + '/' + updateDir + '/manifest.json', content, 'binary');
});
