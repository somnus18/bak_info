/**
 * 工具类
 *
 */

var crypto = require('crypto');

// 工具类
var Utils = {
    // md5加密
    md5: function(data) {
        return crypto.createHash('md5').update(data).digest('hex').toLowerCase();
    },

    // 生成json文件
    getUpdateJson: function(v, t, url, md5, module) {
        var json = ',"' + v + '": {"lastVersion": "' + t + '","md5": "' + md5 + '","modulesName": "' + module + '","updateUrl": "' + url + '"}';
        return json;
    }
};

module.exports = Utils;
