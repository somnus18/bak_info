/**
 * 生成各个版本增量包
 *
 */

var fs = require('fs'),
    path = require('path'),
    grunt = require('grunt'),
    ursa = require('ursa'),
    glob = require('glob'),
    crypto = require('crypto'),
    rimraf = require('rimraf'),
    Zip = require('jszip'),
    Utils = require('./Utils.js'),
    key = require('./key.config'),
    baseDir = process.cwd(),
    projectCode = '.',
    updateDir = '.',
    updateFrom = '0000',
    updateTo = '0000',
    env = 'test',
    envlist = '',
    module = '',
    buildNumber = '',
    TEMP_PATH = './temp',
    TEMP_PACKAGE_PATH = './temp_zip',
    outputFolder = 'output',
    belong = '',
    productUrl = '',
    productTestUrl = '',
    testUrl = '',
    packageConfig = {},
    md5Map = {},
    ursaKey = ursa.createPrivateKey('-----BEGIN RSA PRIVATE KEY-----\n'+
'MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAPAdBTvu2wwE1sqf\n'+
'NV345l4g2zus+AZ1XyjCtq7U7H1rlrGsnadqTd0NCIP1m39R+RyRmGoViEObPFg6\n'+
'CRgOag/h9Mx6ojBjh7Sbj5YNMXoR/vi0RbZJ43BRWoG1woP4MYTH1BNpaM4u77Aj\n'+
'Dh/iBG66ujbuhJy3I0l+InrbkLfZAgMBAAECgYEA2+hYQNmzeEB+T7icceJhadgB\n'+
'sZfq2E9qxbP/CAQuS3fb3gHPqeKsSUWEhQbOUT9MPaQCyTXLRM/J5qvQZF3fN8KA\n'+
'OxJUXxu8iy2qb2XPv/9/1dZf0i2uCDivjaCc8/PviXMZs0a0P4HDHsHHffn6vcYI\n'+
'iEnhCf2eMMIdV3nZxeECQQD4jr4qKMVVMtOme11COJgBnlHVv6CmTLeTGv8rz4LM\n'+
'zeBSJJfMVjfLpHf8Ivo4mVdx7VBlbNIVi7jwBVPLE4CtAkEA902M6tJ8BahnEX6o\n'+
'P1p6W2A2ChA6leE7wWnrtzDjiCG9nNExUFHhdCE5EceV8nfLIcX9XE/t6voEyVJU\n'+
'5pD9XQJBAJqBEJBgW5nESHA6SxQ43bRT14bI4XG+SnZ0151CFop8hy5IdNud1H0P\n'+
'tU3T6Dp6hzLYU5tYc5bVDZaVmSqo6tkCQFzNJDFGVTYGUM8W2WoUuM+rVfwGxQVT\n'+
'ZQoahlLTLL778lxzf+7lGxZqFTFf1RwM6hQ9aOsIL3663aryk1uGUx0CQAp0fGJM\n'+
'/Y5Ic+rrZA46kV5+BtXJulkIRTVBTMW1vv714iCk6selXIzQo2sU0gD0BUVlx8V1\n'+
'yoKileuksRbuU5k=\n'+
'-----END RSA PRIVATE KEY-----');

// 获取主进程文件传递过来的参数，设置打包环境参数
var argv = process.argv.slice(2);
if((index=argv.indexOf('-basedir')) != -1) {
    var value = argv[index+1];
    baseDir = value || '.';
}
if((index=argv.indexOf('-projectCode')) != -1) {
    var value = argv[index+1];
    projectCode = value || '.';
}
if((index=argv.indexOf('-updateDir')) != -1) {
    var value = argv[index+1];
    updateDir = value || '.';
}
if((index=argv.indexOf('-updateFrom')) != -1) {
    var value = argv[index+1];
    updateFrom = value || '0000';
    updateTo = updateFrom * 1 + 1 + '';
}
if((index=argv.indexOf('-env')) != -1) {
    var value = argv[index+1];
    env = value || 'test';
}
if((index=argv.indexOf('-envlist')) != -1) {
    var value = argv[index+1];
    envlist = value || '';
}
if((index=argv.indexOf('-module')) != -1) {
    var value = argv[index+1];
    module = value || '';
}
if((index=argv.indexOf('-output')) != -1) {
    var value = argv[index+1];
    outputFolder = value || 'output';
}
if((index=argv.indexOf('-productUrl')) != -1) {
    var value = argv[index+1];
    productUrl = value || '';
}
if((index=argv.indexOf('-productTestUrl')) != -1) {
    var value = argv[index+1];
    productTestUrl = value || '';
}
if((index=argv.indexOf('-testUrl')) != -1) {
    var value = argv[index+1];
    testUrl = value || '';
}
if((index=argv.indexOf('-belong')) != -1) {
    var value = argv[index+1];
    belong = value || '';
}
if((index=argv.indexOf('-buildNumber')) != -1) {
    var value = argv[index+1];
    buildNumber = value || new Date().valueOf();
}

// 私钥加密，默认用普惠的
if(key[belong]!=undefined) {
    console.log('使用自定义私钥加密md5：' + key[belong]);
    ursaKey = ursa.createPrivateKey(key[belong]);
}

// 设置默认工作目录为源代码下upgrade文件夹
process.chdir(baseDir + '/' + projectCode + '/upgrade/' || '.');

// 升级操作类
var Upgrade = {

    // 备份资源包
    dobak: function(v) {
        var srcfiles = glob.sync('**/*', {
            cwd: baseDir + '/' + projectCode + '/upgrade/update/' + v
        });
        var tmpFolder = baseDir + '/' + projectCode + '/upgrade/update/';
        srcfiles.forEach(function(srcfile) {
            var filepath = path.join('update', v, srcfile);
            if(grunt.file.isDir(filepath)) {
                grunt.file.mkdir(path.join(tmpFolder, 'baktemp', srcfile));
            } else {
                grunt.file.copy(filepath, path.join(tmpFolder, 'baktemp', srcfile));
            }
        });
    },

    // 还原备份的资源包
    restore: function(v) {
        var srcfiles = glob.sync('**/*', {
            cwd: baseDir + '/' + projectCode + '/upgrade/update/baktemp'
        });
        try {
            rimraf.sync(baseDir + '/' + projectCode + '/upgrade/update/' + v);
        } catch(e) {
            error(e);
        }
        var folder = baseDir + '/' + projectCode + '/upgrade/update/';
        srcfiles.forEach(function(srcfile) {
            var filepath = path.join(baseDir + '/' + projectCode + '/upgrade/update', 'baktemp', srcfile);
            if(grunt.file.isDir(filepath)) {
                grunt.file.mkdir(path.join(folder, v, srcfile));
            } else {
                grunt.file.copy(filepath, path.join(folder, v, srcfile));
            }
        });
        try {
            rimraf.sync(baseDir + '/' + projectCode + '/upgrade/update/baktemp');
        } catch(e) {
            error(e);
        }
    },

    // 输出全量包
    outputPkgName: function() {
        var pkgName = fs.readFileSync(baseDir + '/' + projectCode + '/upgrade/pkgName.txt', 'binary');
        grunt.file.copy(baseDir + '/' + projectCode + '/output/' + pkgName, baseDir + '/' + projectCode + '/upgrade/update/' + updateFrom + '/0000-' + updateFrom + '_' + buildNumber + '.zip');
        // 拷贝全量包，供multijob使用
        grunt.file.copy(baseDir + '/' + projectCode + '/output/' + pkgName, baseDir + '/' + outputFolder + '/' + module + '.zip');
    },

    // 升级预备
    preUpgrade: function() {
        grunt.file.mkdir(TEMP_PATH);
        grunt.file.mkdir(TEMP_PACKAGE_PATH + '/' + updateTo);
    },

    // 解压打包模块的历史增量包，添加本次增量修改的文件，形成各个版本的新增量包
    unzip: function() {
        var zipList = glob.sync(baseDir + '/' + projectCode + '/upgrade/update/' + updateFrom + '/*');
        zipList.forEach(function(zipfile) {
            // 去掉buildNumber
            zipfile = Upgrade.reduceBuildNumber(zipfile);
            if(zipfile.indexOf('-' + updateFrom + '.zip')==-1) {
                return;
            }
            var input = fs.readFileSync(zipfile, 'binary'),
                zipname = path.basename(zipfile, '.zip');
            var zip = new Zip(input),
                files = zip.files,
                filenames = Object.getOwnPropertyNames(files),
                i = 0;
            filenames.forEach(function(filename) {
                var filepath = path.join(TEMP_PATH, zipname, filename),
                    fileObj = files[filename];
                if(filename.slice(-1) === '/') {
                    grunt.file.mkdir(filepath);
                } else {
                    var fileDir = path.dirname(filepath);
                    grunt.file.mkdir(fileDir);
                    var content = zip.file(filename).asBinary();
                    fs.writeFileSync(filepath, content, 'binary');
                }
            });
            Upgrade.copyUpgradeFiles(zipname);
            Upgrade.zip(zipname);
        });
        Upgrade.copyUpgradeFiles(updateFrom + '-' + updateFrom);
        Upgrade.zip(updateFrom + '-' + updateFrom);
    },

    // 拷贝升级文件到临时文件，并将update_code下的文件拷贝覆盖。同时将加密好的manifest.json拷贝到各个目录
    copyUpgradeFiles: function(dest) {
        if(!fs.existsSync(TEMP_PATH + dest)) {
            grunt.file.mkdir(TEMP_PATH + '/' + dest);
        }
        var srcfiles = glob.sync('**/*', {
            cwd: 'update_code'
        });
        grunt.file.copy(baseDir + '/' + updateDir + '/manifest.json', path.join(TEMP_PATH, dest, 'manifest.json'));
        srcfiles.forEach(function(srcfile) {
            var filepath = path.join('update_code', srcfile);
            if(grunt.file.isDir(filepath)) {
                grunt.file.mkdir(path.join(TEMP_PATH, dest, srcfile));
            } else {
                grunt.file.copy(filepath, path.join(TEMP_PATH, dest, srcfile));
                grunt.file.copy(baseDir + '/' + updateDir + '/manifest.json', path.join(TEMP_PATH, dest, 'manifest.json'));
            }
        });
    },

    // 压缩文件
    zip: function(folder) {
        var files = glob.sync('**/*', {
            cwd: TEMP_PATH + '/' + folder
        });
        var zip = new Zip(),
            toFolder = path.join(TEMP_PACKAGE_PATH, updateTo);
        files.forEach(function(filepath) {
            if(grunt.file.isDir(path.join(TEMP_PATH, folder, filepath))) {
                zip.folder(filepath);
            } else {
                var input = fs.readFileSync(path.join(TEMP_PATH, folder, filepath), 'binary');
                zip.file(filepath, input, {
                    binary: true
                });
            }
        });
        var distfilename = path.basename(folder).replace(/-.+/, '-' + updateTo) + '_' + buildNumber + '.zip',
            distfile = path.join(TEMP_PACKAGE_PATH, updateTo, distfilename);
        var output = zip.generate({
            base64: false,
            compression: 'DEFLATE'
        });
        md5Map[distfilename] = Utils.md5(output);
        fs.writeFileSync(distfile, output, 'binary');
        rimraf.sync('./output/' + updateTo);
    },

    // 处理升级配置文件
    upgradeConfig: function() {
        if(fs.existsSync(baseDir + '/' + projectCode + '/upgrade/update/' + updateFrom + '/packages.json')) {
            packageConfig = require(baseDir + '/' + projectCode + '/upgrade/update/' + updateFrom + '/packages.json');
        }
        for(var key in packageConfig) {
            var filename = packageConfig[key].zip,
                fns = filename.replace(/.zip/ig, '').split('-'),
                fnsArr = fns[1].split('_');
            // 将build号去除
            fns[1] = fnsArr.length>1 ? fnsArr[0] : fns[1];
            packageConfig[key] = {
                zip: fns[0] + '-' + (fns[1] * 1 + 1) + '_' + buildNumber + '.zip',
                md5: md5Map[fns[0] + '-' + (fns[1] * 1 + 1) + '_' + buildNumber + '.zip'],
                to: fns[1] * 1 + 1 + ''
            };
        }
        // 最新的增量包加密
        packageConfig[updateFrom] = {
            zip: updateFrom + '-' + updateTo + '_' + buildNumber + '.zip',
            md5: md5Map[updateFrom + '-' + updateTo + '_' + buildNumber + '.zip'],
            to: updateTo
        };
        // 全量包加密
        packageConfig['0000'] = {
            zip: '0000-' + updateTo + '_' + buildNumber + '.zip',
            md5: md5Map['0000-' + updateTo + '_' + buildNumber + '.zip'],
            to: updateTo
        };
        fs.writeFileSync(path.join(TEMP_PACKAGE_PATH, updateTo, 'packages.json'), JSON.stringify(packageConfig), 'UTF-8');
    },

    // 生成json文件
    createJson: function(e) {
        env = (e==undefined ? '' + (env + '').split('_')[0] : e);
        var json = {
                flag: '1',
                env: env
            },
            updateJson = '',
            updateUrl = ((env.toLowerCase()=='product' || (env.toLowerCase()=='production')) ? productUrl + module + 'html' : (env.toLowerCase()=='prd_test' ? productTestUrl + module + 'html' : testUrl + module + 'html'));
        for(var key in packageConfig) {
            var from = key,
                filename = packageConfig[key].zip,
                to_version = packageConfig[key].to,
                md5 = packageConfig[key].md5,
                dest = './update/' + to_version;
            console.log(from + '+++++' + to_version + '+++++' + filename + '+++++' + md5 + '+++++' + ursaKey.privateEncrypt(md5, 'utf8', 'base64'));
            updateJson += Utils.getUpdateJson(from, to_version, updateUrl + '/' + to_version + '/' + filename, ursaKey.privateEncrypt(md5, 'utf8', 'base64'), module);
        }
        if(!fs.existsSync(dest)) {
            fs.mkdirSync(dest);
        }
        json.data = JSON.parse('{' + updateJson.slice(1) + '}');
        if(e==undefined) {
            fs.writeFileSync(dest + '/' + module + '.json', JSON.stringify(json));
            fs.writeFileSync(dest + '/packages.json', JSON.stringify(packageConfig));
        } else {
            fs.writeFileSync(dest + '/' + module + '_' + e + '.json', JSON.stringify(json));
        }
    },


    // 升级包打zip包
    zipPackage: function() {
        var outputName = module + '_' + updateTo + '_' + env + '_' + grunt.template.today('yyyymmddHHMM') + '.zip',
            zip = new Zip(),
            files = glob.sync('**/*', {
                cwd: TEMP_PACKAGE_PATH
            }),
            tempfiles = glob.sync('**/*', {
                cwd: TEMP_PACKAGE_PATH
            });
        tempfiles.forEach(function(srcfile) {
            var filepath = path.join(TEMP_PACKAGE_PATH, srcfile);
            if(grunt.file.isDir(filepath)) {
                grunt.file.mkdir(path.join('update', srcfile));
            } else {
                grunt.file.copy(filepath, path.join('update', srcfile));
            }
        });
        files.forEach(function(filepath) {
            if(grunt.file.isDir(path.join(TEMP_PACKAGE_PATH, filepath))) {
                zip.folder(filepath);
            } else {
                var input = fs.readFileSync(path.join(TEMP_PACKAGE_PATH, filepath), 'binary');
                zip.file(filepath, input, {
                    binary: true
                });
            }
        });
        var output = zip.generate({
            base64: false,
            compression: 'DEFLATE'
        });
        if(!fs.existsSync('output')) {
            grunt.file.mkdir('output');
        }
        fs.writeFileSync('output/' + outputName, output, 'binary');
    },


    // 清理项目环境
    clean: function() {
        try {
            rimraf.sync(TEMP_PATH);
            rimraf.sync(TEMP_PACKAGE_PATH);
        } catch (e) {
            error(e);
        }
    },

    // 去掉buildNumber号
    reduceBuildNumber: function(zipfile) {
        var zipArr = zipfile.split('/'),
            filename = zipArr[zipArr.length-1],
            newFileArr = filename.split('_'),
            newFilename = (newFileArr.length>1 ? newFileArr[0] + '.zip' : newFileArr[0]);
        zipArr.pop();
        newFilename = zipArr.join('/') + '/' + newFilename;
        if(zipfile != newFilename) {
            grunt.file.copy(zipfile, newFilename);
        }
        return newFilename;
    },

    // 如果资源包版本号重复，则先删除之前的版本号
    deleteRepeat: function(version) {
        var folder = baseDir + '/' + projectCode + '/upgrade/update/' + version,
            output = baseDir + '/' + outputFolder + '/' + version;
        if(!!fs.existsSync(folder)) {
            try {
                rimraf.sync(folder);
            } catch(e) {
                error(e);
            }
        }
        if(!!fs.existsSync(output)) {
            try {
                rimraf.sync(output);
            } catch(e) {
                error(e);
            }
        }
    },

    // 生成所有环境的JSON文件
    createAllJson: function() {
        var envList = envlist.split(',');
        // var envList = new Array('TEST', 'PRD_TEST', 'PRODUCT');
        if((env.toLowerCase()=='product') || (env.toLowerCase()=='production')) {
            envList.pop(1);
            envList.push(env.toUpperCase());
        }
        for(var i in envList) {
            Upgrade.createJson(envList[i]);
        }
    }
};


(function() {
    Upgrade.dobak(updateFrom);
    Upgrade.deleteRepeat(updateTo);
    Upgrade.outputPkgName();
    Upgrade.preUpgrade();
    Upgrade.unzip();
    Upgrade.upgradeConfig();
    Upgrade.zipPackage();
    Upgrade.createJson();
    Upgrade.createAllJson();
    Upgrade.clean();
    Upgrade.restore(updateFrom);
})();
