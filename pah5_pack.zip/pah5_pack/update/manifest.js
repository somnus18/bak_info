/**
 * 对全量包文件进行MD5加密
 *
 */

var fs = require('fs'),
    crypto = require('crypto'),
    glob = require('glob'),
    path = require('path'),
    grunt = require('grunt'),
    zip = require('jszip'),
    Utils = require('./Utils.js'),
    md5All = {},
    baseDir = process.cwd(),
    projectCode = '.',
    updateDir = '.';


// 获取主进程文件传递过来的参数，设置打包环境基地址
var argv = process.argv.slice(2);
if((index=argv.indexOf('-basedir')) != -1) {
    var value = argv[index+1];
    baseDir = value || '.';
    process.chdir(baseDir || '.');
}
if((index=argv.indexOf('-projectCode')) != -1) {
    var value = argv[index+1];
    projectCode = value || '.';
}
if((index=argv.indexOf('-updateDir')) != -1) {
    var value = argv[index+1];
    updateDir = value || '.';
}

// 需要md5加密的目标文件目录
var distFolder = baseDir + '/' + projectCode + '/dist/';

// 获取目标文件目录下所有文件
var sourceFiles = glob.sync('**/*', {
    cwd: distFolder
});

// 遍历文件夹对文件进行加密
sourceFiles.forEach(function(sourceFile) {
    var source = path.join(distFolder, sourceFile);
    if(!grunt.file.isDir(source)) {
        var data = fs.readFileSync(source, 'binary'),
            key = source.split('dist/')[1];
        // css、js文件夹及html格式文件才进行md5加密且不能是map格式文件
        if((/^(css|js)/g.test(key.split('/')[0]) || /html$/g.test(key)) && !/map$/g.test(key)){
            md5All[key] = Utils.md5(data);
            console.log(key + '---：' + md5All[key]);
        }
    }
});

// 写入manifest.json文件，并进行压缩
var zip = new zip();
zip.file('manifest.json', JSON.stringify(md5All), {
    binary: true
});
var output = zip.generate({
    base64: false,
    compression: 'DEFLATE'
});
fs.writeFileSync(baseDir+'/'+updateDir+'/manifest.zip', output, 'binary');
