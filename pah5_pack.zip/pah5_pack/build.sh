#!/bin/bash
##
# 增量打包过程控制脚本
#
##

# 构建开始
echo '==== 构建开始 ===='
# ./build.sh TEST ro 30100001 http://git-ma.paic.com.cn/papc/ro_h5.git master db8082ae1187553db779cf41e85713aa8669d485 gulp http://test1-puhui-web.pingan.com.cn:10180/manager/stg/papc/package/resource/ http://test1-puhui-web.pingan.com.cn:10180/manager/stg/papc/cfs-ss/prd_test/ http://git-ma.paic.com.cn/xxx/jenkins_job/raw/master/papc/ papc N 100,110 64


# 设置构建参数
echo '==== [START] 设置构建参数'
## 环境参数，test（测试环境） prd_test（预发布环境） product（生成环境）
ENVIRONMENT="$1"
## 模块名
MODULE="$2"
## 增量包版本变量
CONFIGFROMVER="$3"
## 代码仓库地址
REPOSITORIES="$4"
## 代码分支
BRANCH="$5"
## 增量包起始版本
UPDATEFROM="$6"
## 构建gulp路径
GULP_COMMAND="$7"
## 正式环境地址
PRODUCT_URL="$8"
## 预发布环境地址
PRODUCT_TEST_URL="$9"
## 测试环境地址
TEST_URL="${10}"
## 项目归属
PROJECT_BELONG="${11}"
## 如果是测试环境时，是否上传到gitlab。取值Y表示上传，N表示不上传
IS_UPLOAD="${12}"
## 环境列表
ENVLIST=${13}
## Jenkins构建号
buildNumber=${14}
## 上传到指定版本号的文件夹下
VERSION_LIST="${15}"
## 打包工作空间基地址
BASEDIR=`pwd`
## 增量构建工具项目文件夹
UPDATE='update'
## 增量包产物地址
OUTPUT='output'
## H5项目源码文件夹
# PROJECTCODE=${MODULE}_${BRANCH}_H5
PROJECTCODE='project_src'
## 增量包上传文件夹
JENKINS_JOB='upload'
## 增量包上传目录
UPLOADFOLDER=${PROJECT_BELONG}/${MODULE}html/
## 增量包JSON上传目录
UPLOADJSONFOLDER=${PROJECT_BELONG}/updateH5/
## gitlab项目地址
GITLAB_URL='http://git-ma.paic.com.cn/papc/jenkins_job.git'
## gitlab账号
GITLAB_ACCOUNT='paph059'
## gitlab密码
GITLAB_PASSWORD='059phios'
echo '==== [END] 设置构建参数'


# 检出版本库信息到工作空间，根据环境切换分支
echo -e '==== [START] 检出版本库信息到工作空间，并切换到 \033[32m'${BRANCH}'\033[0m 分支'
if [ ! -d ${PROJECTCODE} ]
    then
    git clone -b ${BRANCH} ${REPOSITORIES} ${PROJECTCODE}
else
    cd ${PROJECTCODE}
    git checkout ${BRANCH}
    git pull
    cd ${BASEDIR}
fi
echo -e '==== [END] 检出版本库信息到工作空间，并切换到 \033[32m'${BRANCH}'\033[0m 分支'


# 构建全量包
echo '==== [START] 构建全量包'
cd ${PROJECTCODE}
${GULP_COMMAND} build -env ${ENVIRONMENT} -chdir ${PROJECTCODE} -mod ${MODULE}
cd ${BASEDIR}
echo '==== [END] 构建全量包'


# 生成manifest加密包
echo '==== [START] 生成RSA加密包'
node ${BASEDIR}/${UPDATE}/manifest.js -basedir ${BASEDIR} -projectCode ${PROJECTCODE} -updateDir ${UPDATE}
java -jar ${BASEDIR}/${UPDATE}/ManifestRSAUtils.jar -signature -source=${BASEDIR}/${UPDATE}/manifest.zip -output=${BASEDIR}/${UPDATE}/manifest_rsa.zip -privateKey=9274497037578780109772165779418977599659692962538854771424375728534498139684574963977980255089636848504125527402063538635994726902543727940853031342877048228281793470553704390135556366426058617118070299154521901757880986323964186095184576213069825603514266505993743689508523195691471131557830702269269577729 -modulus=111241345598792187418400151662844351198553678200202951163037941456984883707999265998210997799745521621598622746952605807391505566803076189249576338784431410161012041778144294557511560779410745782302679867290472368657989185469943399782969260933431872810872967691988895582054535490907866746507114689860515367673 -manifest=auto
echo '==== [END] 生成RSA加密包'


# 校验manifest加密包
echo '==== [START] 校验RSA加密包'
java -jar ${BASEDIR}/${UPDATE}/ManifestRSAUtils.jar -verify -source=${BASEDIR}/${UPDATE}/manifest_rsa.zip -publicKey=65537 -modulus=111241345598792187418400151662844351198553678200202951163037941456984883707999265998210997799745521621598622746952605807391505566803076189249576338784431410161012041778144294557511560779410745782302679867290472368657989185469943399782969260933431872810872967691988895582054535490907866746507114689860515367673
echo '==== [END] 校验RSA加密包'


# 生成增量文件列表
echo '==== [START] 生成增量文件列表'
cd ${PROJECTCODE}
git diff --name-only ${UPDATEFROM} HEAD www > ${BASEDIR}/${UPDATE}/filelist
git diff --name-only ${UPDATEFROM} HEAD templates >> ${BASEDIR}/${UPDATE}/filelist
cd ${BASEDIR}
echo '==== [END] 生成增量文件列表'


# 文件映射，移动增量文件到增量工作空间
echo '==== [START] 文件映射并处理增量文件'
node ${BASEDIR}/${UPDATE}/filelist.js -basedir ${BASEDIR} -projectCode ${PROJECTCODE} -updateDir ${UPDATE}
echo '==== [END] 文件映射并处理增量文件'


# 构建增量包和json配置文件
echo '==== [START] 构建增量包和配置文件'
echo "node ${BASEDIR}/${UPDATE}/upgrade.js -basedir ${BASEDIR} -projectCode ${PROJECTCODE} -updateDir ${UPDATE} -updateFrom ${CONFIGFROMVER} -env ${ENVIRONMENT} -envlist ${ENVLIST} -module ${MODULE} -belong ${PROJECT_BELONG} -output ${OUTPUT} -productUrl ${PRODUCT_URL} -productTestUrl ${PRODUCT_TEST_URL} -testUrl ${TEST_URL} -buildNumber ${buildNumber}"
node ${BASEDIR}/${UPDATE}/upgrade.js -basedir ${BASEDIR} -projectCode ${PROJECTCODE} -updateDir ${UPDATE} -updateFrom ${CONFIGFROMVER} -env ${ENVIRONMENT} -envlist ${ENVLIST} -module ${MODULE} -belong ${PROJECT_BELONG} -output ${OUTPUT} -productUrl ${PRODUCT_URL} -productTestUrl ${PRODUCT_TEST_URL} -testUrl ${TEST_URL} -buildNumber ${buildNumber}
echo '==== [END] 构建增量包和配置文件'

# 拷贝增量包到output目录
echo '==== [START] 拷贝增量包到output目录'
if [ ! -d ${OUTPUT} ]
    then
    mkdir ${OUTPUT}
fi
cp -rf ${PROJECTCODE}/upgrade/update/ ${OUTPUT}/
echo '==== [END] 拷贝增量包到output目录'

# 如果非生产环境，则上传增量包到git服务器
echo '==== [START] 如果非生产环境，则上传增量包到git服务器'
if [ ${ENVIRONMENT} == 'TEST' ]
    then
    echo -e '当前为 \033[32m'${ENVIRONMENT}'\033[0m 环境，开始上传资源包！'
    # 判断上传开关是否打开
    if [ ${IS_UPLOAD} == 'N' ]
        then
        echo -e '\033[31m 当前上传开关关闭，终止上传资源！ \033[0m'
    else
        echo -e '\033[32m 当前上传开关打开，开始上传资源！ \033[0m'
        # 检出jenkins项目
        if [ ! -d ${JENKINS_JOB} ]
            then
            git clone ${GITLAB_URL} ${JENKINS_JOB}
        else
            cd ${JENKINS_JOB}
            git pull
            cd ${BASEDIR}
        fi
        let CONFIGTOVER=${CONFIGFROMVER}*1+1
        # 创建资源包上传文件夹
        cd ${JENKINS_JOB}
        if [ ! -d ${UPLOADFOLDER} ]
            then
            mkdir -p ${UPLOADFOLDER}
        fi
        cd ${BASEDIR}
        # 判断之前是否已经上传过此次打包版本号的资源，是的话清理掉
        CP_SOURCE="${PROJECTCODE}/upgrade/update/${CONFIGTOVER}/"
        CP_TARGET="${JENKINS_JOB}/${UPLOADFOLDER}/${CONFIGTOVER}/"
        if [ -d ${CP_TARGET} ]
            then
            cd ${CP_TARGET}
            filelist=`ls .`
            for file in ${filelist}
            do
                git rm ${file}
            done
            cd ${BASEDIR}
        fi
        # 拷贝资源包到上传的文件夹
        cp -rf ${CP_SOURCE} ${CP_TARGET}
        # 拷贝JSON到各个版本号下的文件夹
        VERSION_ARR=(${VERSION_LIST//+/ })
        for version in ${VERSION_ARR[@]}
        do
            UPLOAD_WITH_VERSION="${UPLOADJSONFOLDER}/${version}/"
            # 创建JSON文件上传文件夹
            cd ${JENKINS_JOB}
            if [ ! -d ${UPLOAD_WITH_VERSION} ]
                then
                mkdir -p ${UPLOAD_WITH_VERSION}
            fi
            cd ${BASEDIR}
            CP_JSON_SOURCE="${PROJECTCODE}/upgrade/update/${CONFIGTOVER}/${MODULE}.json"
            CP_JSON_TARGET="${JENKINS_JOB}/${UPLOAD_WITH_VERSION}/"
            cp -rf ${CP_JSON_SOURCE} ${CP_JSON_TARGET}
        done
        # 提交到gitlab
        cd ${JENKINS_JOB}
        git add *
        git commit -a -m "提交${MODULE}模块${CONFIGTOVER}资源"
        git push origin master:master
    fi
else
    echo -e '当前为 \033[32m'${ENVIRONMENT}'\033[0m 环境，不需要上传！'
fi
echo '==== [END] 如果非生产环境，则上传增量包到git服务器'

# 构建结束
echo '==== 构建结束 ===='
