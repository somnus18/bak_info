#!/bin/bash
##
# 清理打包空间
#
##
echo '开始清理打包空间...'
rm -rf output project_src upload update/filelist update/manifest.json update/manifest.zip update/manifest_rsa.zip
echo '清理打包空间成功！'
