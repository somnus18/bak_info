# 基于vue+vue-router+vuex+zepto
打包构建：node webpack + babel( 支持es6语法 )

### 请确保已经正确安装了如下工具包:
1. node.jsv4+
2. npm
3. webpack

### 安装

```
npm i
```

### 开发环境编译及服务启动并开启热部署模式

```
npm run stg1-app // 爱行销app测试STG1
npm run stg1-m // 移动端测试STG1
```
```
npm run stg2-app // 爱行销app测试STG2
npm run stg2-m // 移动端测试STG2
```
```
npm run prd-app // 爱行销app生产
npm run prd-m // 移动端生产
```

压缩本地包

```
npm run zip-app-stg1 // 爱行销app测试STG1环境压缩包
npm run zip-m-stg1 // 移动端测试STG1环境压缩包
```
```
npm run zip-app-stg2 // 爱行销app测试STG2环境压缩包
npm run zip-m-stg2 // 移动端测试STG2环境压缩包
```
```
npm run zip-app-prd // 爱行销app生产环境压缩包
npm run zip-m-prd // 移动端生产环境压缩包
```

### 编码要求

1. 注意编码规范，变量名、文件名使用驼峰写法，注意名称的语义化等
2. 使用es6语法
3. 避免冗余代码，复用较多的需要抽出来
4. `尽量少用第三方组件（除非比较复杂的组件）`
5. 尽量不用js原生方法操作dom(如document.body等)

### 目录结构
<pre>
├── build                   // Webpack 配置文件
├── config                  // Webpack 配置文件
├── dist                    // 项目build目录
├── output-app              // 按揭二期爱行销app项目输出zip文件
├── output-m                // 按揭二期中介端项目输出zip文件
├── static                  // 静态文件css和js库目录
├── src                     // 源码目录
│   ├── assets              // css js 和图片资源
│   ├── common              // 各种公共方法
│   ├── components          // 各种vue组件
│   ├── filters             // 过滤器
│   ├── app                 // 爱行销app项目入口
│   │   ├── common             // 按揭二期爱行销公共方法
│   │   ├── views              // 各种页面
│   │   ├── App.vue            // vue入口
│   │   ├── main.js            // Webpack 预编译入口
│   │   ├── routes.js          // 各种路由
│   │   └── routes-map.js      // 各种路由页面配置
│   └── m                 // 移动端项目入口
│       ├── common             // 按揭二期中介端公共方法
│       ├── views              // 各种页面
│       ├── App.vue            // vue入口
│       ├── main.js            // Webpack 预编译入口
│       ├── routes.js          // 各种路由
│       └── routes-map.js      // 各种路由页面配置
├── .babelrc                // babel配置文件
├── .eslintignore           // js规则校验忽略文件
├── .eslintrc               // js规则校验文件
├── .gitignore              // 忽略文件
├── gulpfile.js             // gulp配置文件
├── index.html              // 项目入口文件
├── README.md               // 项目描述
└── package.json            // 项目配置文件
</pre>


## 补充 picker选择器

#### 非联动picker

```
import mPicker from 'src/components/picker/index';
```

```
<m-picker :slots='slots' :isPicker='isPicker'
    :indexText='indexText'
    :datakey='datakey'
    @confirm='pickerConfirm' @cancel='pickerCancel'>
</m-picker>
```



###### API

| 参数 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| slots | slot 对象数组 | Array | [] |
| valueKey | 当 values 为对象数组时，作为文本显示在 Picker 中的对应字段的字段名,业务需求默认’v’ | String | ‘v' |
| indexText | 选择器名称 | String | ‘请选择' |
| datakey  | 数据对象的key，选择器确定后confrim第二个参数，原本带出 | String | ‘’ |
| @confirm | 确定事件，默认两个参数，第一个是选择的对象数组，第二个是datakey | event |  |
| @cancel | 取消选择器，自行隐藏组件 | event  |  |


<br>

#### 日期选择器(年月日)

```
import mAreaPicker from 'src/components/picker/area-picker.vue';
```
```
<m-date-picker :isPicker='isDatePicker' :datakey='dateDatakey'
    @confirm='datePickerConfirm' @cancel="datePickerCancel">

</m-date-picker>
```
###### API

| 参数 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| indexText | 选择器名称 | String | ‘请选择日期' |
| datakey  | 数据对象的key，选择器确定后confrim第二个参数，原本带出 | String | '' |
| @confirm | 确定事件，默认两个参数，第一个是选择的数组[2017,01,01]，第二个是datakey | event |  |
| @cancel | 取消选择器，自行隐藏组件 | event  |  |

<br>
### 城市选择器

```
import mAreaPicker from 'src/components/picker/area-picker.vue';
```

```
<m-area-picker :isPicker='isAreaPicker' isZone :datakey='areaDataKey'
    @confirm='areaPickerConfirm' @cancel="areaPickerCancel">
</m-area-picker>
```

###### API

| 参数 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| indexText | 选择器名称 | String | ‘请选择地区' |
| datakey  | 数据对象的key，选择器确定后confrim第二个参数，原本带出 | String | '' |
| isZone  | 只需省市，不需要区 | Boolean | false |
| @confirm | 1、确定事件，默认两个参数，第一个是选择的数组[2017,01,01]，第二个是datakey;<br> 2、当`isZone: true`,不需要区，但第三个参数会把区带出，自行操作 | event |  |
| @cancel | 取消选择器，自行隐藏组件 | event  |  |


例子可以查看 create/sell_info.vue等

