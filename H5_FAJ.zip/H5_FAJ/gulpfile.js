var gulp = require('gulp');
var gutil = require('gulp-util');
var chalk = require('chalk');
var fs = require('fs');
var rimraf = require('gulp-rimraf');
var runSequence = require('run-sequence');
var zip = require('gulp-zip');

var pkg = require('./package.json');
var BUILD_TIMESTAMP = gutil.date(new Date(), "yyyymmddHHMMss");
pkg.build = BUILD_TIMESTAMP;

// 设置默认工作目录为./
process.chdir("./");

// 获取env
var argv = process.argv.slice(2);
var env = "DEVELOPMENT",
    envIndex;
(function () {
    if ((envIndex = argv.indexOf("-env")) != -1) {
        var envValue = argv[envIndex + 1];
        var envs = ["DEVELOPMENT", "STG1", "STG2", "STG3", "PRODUCTION"];
        if (envValue && envs.indexOf(envValue) != -1) {
            env = envValue;
        }
    }
})();

gutil.log(
    'Working directory :',
    chalk.magenta(__dirname)
);

var paths = {
    dest: "./dist",
    output_app: "./output-app",
    output_m: "./output-m"
}

/*
 * 清空目标工程目录
 */
gulp.task('clean', function () {
    return gulp.src(paths.dest + '/*', {read: false})
        .pipe(rimraf({force: true}));
});

/*
 * 打包zip
 */
gulp.task('zip-app', function () {
    return gulp.src(paths.dest + '/**/*')
        .pipe(zip(pkg.name + "_app_v_" + pkg.version.replace(/\./g, "_") + "_" + env.toLowerCase() + "_" + BUILD_TIMESTAMP + '.zip'))
        .pipe(gulp.dest(paths.output_app));
});

/*
 * 打包zip
 */
gulp.task('zip-m', function () {
    return gulp.src(paths.dest + '/**/*')
        .pipe(zip(pkg.name + "_m_v_" + pkg.version.replace(/\./g, "_") + "_" + env.toLowerCase() + "_" + BUILD_TIMESTAMP + '.zip'))
        .pipe(gulp.dest(paths.output_m));
});

/*
 * 清空工程无需访问的目录, 生产和测试需删除data目录
 */
gulp.task('cleanDist', function () {
    return gulp.src([
  //      paths.dest + '/static/data'
    ], {read: false})
        .pipe(rimraf({force: true}));
});

/*
 * 用于jenkins自动构建打包
 */
gulp.task('build-app', function (callback) {
    var args = [
        'cleanDist',
        'zip-app',
        function (error) {
            if (error) {
                console.log(error.message);
            } else {
                console.log('RELEASE FINISHED SUCCESSFULLY');
            }
            callback(error);
        }
    ];

    if (env === 'DEVELOPMENT') {
        args.shift();
    }

    runSequence.apply(this, args);

});

/*
 * 用于jenkins自动构建打包
 */
gulp.task('build-m', function (callback) {
    var args = [
        'cleanDist',
        'zip-m',
        function (error) {
            if (error) {
                console.log(error.message);
            } else {
                console.log('RELEASE FINISHED SUCCESSFULLY');
            }
            callback(error);
        }
    ];

    if (env === 'DEVELOPMENT') {
        args.shift();
    }

    runSequence.apply(this, args);
});
