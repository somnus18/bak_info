var argvs = process.argv,
    // webpack配置页面环境
    conf_env,
    // 构建环境
    build_env = (argvs[2] && argvs[2].replace('-', '')) || 'production',
    // 爱行销还是手机移动端
    project_env = (argvs[3] && argvs[3].replace('-', '')) || 'app';

process.env.NODE_ENV = build_env;
switch (build_env) {
    case 'development':
        conf_env = 'prod';
        break;
    case 'stg1':
    case 'stg2':
    case 'stg3':
    case 'production':
        conf_env = 'prod';
        break;
    default :
        build_env = 'production';
        conf_env = 'prod';
        break;
}

module.exports = {
    project_env: project_env,
    conf_env: conf_env,
    build_env: build_env
}
