// http://eslint.org/docs/user-guide/configuring

module.exports = {
    root: true,
    parser: 'babel-eslint',
    parserOptions: {
        sourceType: 'module'
    },
    env: {
        browser: true,
        'es6': true
    },
    // https://github.com/feross/standard/blob/master/RULES.md#javascript-standard-style
    extends: 'standard',
    // required to lint *.vue files
    plugins: [
        'html'
    ],
    // http://eslint.org/docs/user-guide/configuring#specifying-globals
    globals: {
        'Vue': true,
        'describe': true,
        'it': true,
        'expect': true,
        '_App': true,
        'C': true,
        '$': true,
        '$$': true,
        'wx': true,
        'eventHub': true,
        'vm': true
    },
    /**
     * add your custom rules here
     *
     * off或者0，不启用这个规则
     * warn或者1，出现问题会有警告
     * error或者2，出现问题会报错
     * never参数：不能带末尾的逗号,
     * always参数：必须带末尾的逗号,
     * always-multiline：多行模式必须带逗号,单行模式不能带逗号
     */
    'rules': {
        // 数组和对象键值对最后一个逗号,
        'comma-dangle': [2, 'never'],
        // 条件语句的条件中不允许出现赋值运算符
        'no-cond-assign': 2,
        // 禁止在条件中使用常量表达式 if(true) if(1)
        'no-constant-condition': 2,
        // 正则表达式中不允许出现控制字符
        'no-control-regex': 2,
        // 对象中不允许出现重复的键
        'no-dupe-keys': 2,
        // 函数参数禁止重名
        'no-dupe-args': 2,
        // 正则表达式中不允许出现空的字符组
        'no-empty-character-class': 2,
        // 在try catch语句中不允许重新分配异常变量
        'no-ex-assign': 2,
        // 不允许出现不必要的布尔值转换
        'no-extra-boolean-cast': 2,
        // 不允许出现不必要的圆括号
        'no-extra-parens': 2,
        // 不允许出现不必要的分号
        'no-extra-semi': 2,
        'no-func-assign': 2, //不允许重新分配函数声明
        'no-inner-declarations': ['error', 'functions'], //不允许在嵌套代码块里声明函数
        'no-invalid-regexp': 2, //不允许在RegExp构造函数里出现无效的正则表达式
        'no-irregular-whitespace': 2, //不允许出现不规则的空格
        'no-negated-in-lhs': 2, //不允许在in表达式语句中对最左边的运算数使用取反操作
        'no-obj-calls': 2, //不允许把全局对象属性当做函数来调用
        'no-regex-spaces': 2, //正则表达式中不允许出现多个连续空格
        'quote-props': 0, //对象中的属性名是否需要用引号引起来
        'no-sparse-arrays': 2, //数组中不允许出现空位置
        'no-unreachable': 2, //在return，throw，continue，break语句后不允许出现不可能到达的语句
        // 禁止和NaN作比较,推荐使用isNaN方法
        'use-isnan': 2,
        'valid-typeof': ['error', {
            'requireStringLiterals': true
        }], //在使用typeof表达式比较的时候强制使用有效的字符串
        'default-case': 0, // 在switch语句中需要有default语句
        'eqeqeq': ['error', 'smart'], // 比较的时候使用严格等于
        'no-alert': 1, //不允许使用alert，confirm，prompt语句
        'no-caller': 2, //不允许使用arguments.callee和arguments.caller属性
        'no-div-regex': 2, //不能使用看起来像除法的正则表达式
        'no-else-return': 0, //如果if语句有return，else里的return不用放在else里
        'no-labels': ['error', {
            'allowLoop': true,
            'allowSwitch': false
        }], //不允许标签语句
        'no-eq-null': 2, //不允许对null用==或者!=
        'no-eval': 2, //不允许使用eval()
        'no-extend-native': 0, //允许扩展原生对象
        'no-extra-bind': 2, //不允许不必要的函数绑定
        'no-fallthrough': 2, //不允许switch按顺序全部执行所有case
        'no-floating-decimal': 2, //不允许浮点数缺失数字
        'no-implied-eval': 2, //不允许使用隐式eval()
        'no-iterator': 2, //不允许使用__iterator__属性
        'no-lone-blocks': 2, //不允许不必要的嵌套代码块
        'no-loop-func': 2, //不允许在循环语句中进行函数声明
        'no-multi-spaces': 2, //不允许出现多余的空格
        'no-multi-str': 2, //不允许用\来让字符串换行
        'no-global-assign': 2, //不允许重新分配原生对象
        'no-new': 2, //不允许new一个实例后不赋值或者不比较
        'no-new-func': 2, //不允许使用new Function
        'no-new-wrappers': 2, //不允许使用new String，Number和Boolean对象
        'no-octal': 2, //不允许使用八进制字面值
        'no-octal-escape': 2, //不允许使用八进制转义序列
        'no-param-reassign': 0, //不允许重新分配函数参数
        'no-proto': 2, //不允许使用__proto__属性
        'no-redeclare': 2, //不允许变量重复声明
        'no-return-assign': 2, //不允许在return语句中使用分配语句
        'no-script-url': 2, //不允许使用javascript:void(0)
        'no-self-compare': 2, //不允许自己和自己比较
        'no-sequences': 2, //不允许使用逗号表达式
        'no-throw-literal': 2, //不允许抛出字面量错误 throw 'error'
        'no-unused-expressions': 0, //不允许无用的表达式
        'no-void': 2, //不允许void操作符
        'no-warning-comments': [1, {'terms': ['todo', 'fixme', 'any other term']}], //不允许警告备注
        'no-with': 2, //不允许使用with语句
        'vars-on-top': 0, //var必须放在作用域顶部
        'wrap-iife': [2, 'any'], //立即执行表达式的括号风格
        'yoda': [2, 'never', {'exceptRange': true}], //不允许在if条件中使用yoda条件
        'strict': [2, 'function'], //使用严格模式
        'no-catch-shadow': 2, //不允许try catch语句接受的err变量与外部变量重名
        'no-delete-var': 2, //不允许使用delete操作符
        'no-label-var': 2, //不允许标签和变量同名
        'no-shadow': 2, //外部作用域中的变量不能与它所包含的作用域中的变量或参数同名
        'no-shadow-restricted-names': 2, //js关键字和保留字不能作为函数名或者变量名
        'no-undef': 2, //不允许未声明的变量
        'no-undef-init': 2, //不允许初始化变量时给变量赋值undefined
        'no-undefined': 0, //不允许把undefined当做标识符使用
        'no-unused-vars': [2, {'vars': 'all', 'args': 'after-used'}], //不允许有声明后未使用的变量或者参数
        'no-use-before-define': [2, 'nofunc'], //不允许在未定义之前就使用变量
        // 语句强制分号结尾
        'semi': [2, 'always'],
        // 不允许出现空的代码块
        'no-empty': 2,
        // 圈复杂度
        'complexity': 0,
        // 是否校验缩进格式
        'indent': 0,
        'brace-style': [2, '1tbs', { 'allowSingleLine': false}], //大括号风格
        'camelcase': [2, {'properties': 'never'}], //强制驼峰命名规则
        'comma-style': [2, 'last'], //逗号风格
        'consistent-this': [0, 'self'], //当获取当前环境的this是用一样的风格
        'eol-last': 2, //文件以换行符结束
        'func-names': 0, //函数表达式必须有名字
        'func-style': 0, //函数风格，规定只能使用函数声明或者函数表达式
        'key-spacing': [2, {'beforeColon': false, 'afterColon': true}], //对象字面量中冒号的前后空格
        'max-nested-callbacks': 0, //回调嵌套深度
        'new-cap': [2, {'newIsCap': true, 'capIsNew': false}], //构造函数名字首字母要大写
        'new-parens': 2, //new时构造函数必须有小括号
        'newline-after-var': 0, //变量声明后必须空一行
        'no-array-constructor': 2, //不允许使用数组构造器
        'no-mixed-spaces-and-tabs': 0, //不允许混用tab和空格 [2, 'smart-tabs']
        'no-multiple-empty-lines': [2, {'max': 2}], //空行最多不能超过两行
        'no-nested-ternary': 0, //不允许使用嵌套的三目运算符
        'no-new-object': 2, //禁止使用new Object()
        'fun-call-spacing': 0, //函数调用时，函数名与()之间不能有空格
        'no-ternary': 0, //不允许使用三目运算符
        'no-trailing-spaces': 2, //一行最后不允许有空格
        // 使用let和const代替var
        'no-var': 2,
        // 对象的属性名强制使用单引号
        'quotes': [2, 'single'],
        // 连续声明
        'one-var': ['error', {var: 'always', let: 'always', const: 'never'}],
        // 禁止使用new require
        'no-new-require': 2,
        'space-before-function-paren': ['error', {'anonymous': 'always', 'named': 'never', 'asyncArrow': 'always'}],
        'no-tabs': 0,
        'no-useless-escape': 0,
        // 箭头函数前后都需有空格
        'arrow-spacing': [2, {'before': false, 'after': true}],
        // allow paren-less arrow functions
        'arrow-parens': 0,
        radix: 0,//使用parseInt时强制使用基数来指定是十进制还是其他进制
        // allow async-await
        'generator-star-spacing': 0,
        // 生产不允许出现console语句
        // 'no-console': process.env.NODE_ENV === 'production' ? 2 : 0,
        // allow debugger during development
        'no-debugger': process.env.NODE_ENV === 'production' ? 2 : 0
    }
}
