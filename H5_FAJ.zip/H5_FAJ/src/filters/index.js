import Vue from 'vue';

export default {
    init: function () {
        /**
         * 获取性别
         * @params '0'
         * @return '女'
         */
        Vue.filter('gender', (value)=> {
            return (value + '') === 'F' ? '女' : '男';
        });
        /**
         * 获取城市名称
         */
        Vue.filter('getCName', (value)=> {
            return value ? value.split('/')[1] : '';
        });
    }
};
