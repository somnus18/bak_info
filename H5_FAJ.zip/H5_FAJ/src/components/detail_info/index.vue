<template>
    <div v-if="isShow" class="detail-container layer">
        <div class="close" @click="close"></div>
        <div class="detail" @click=''>
            <h3 class="tit">补件具体信息</h3>
            <div class="content">
                {{evidences[ekey]['evidenceContent']}}
            </div>
        </div>
    </div>
</template>

<script type="text/ecmascript-6">
    export default {
        name: 'detail-order',
        props: ['isShow', 'evidences', 'ekey'],
        data() {
            return {
            };
        },
        methods: {
            close() {
                this.$parent.isShowDelOrder = false;
            }
        }
    };
</script>

<style scoped lang="scss">
    .detail-container{
        z-index: 999;
        .close{
            position: absolute;
            top: 20%;
            left: 50%;
            width: .5rem;
            height: .5rem;
            margin-left: -0.25rem;
            background: url('../../assets/images/m/icons/icon_closepopup@2x.png');
            background-size: 100%;
        }
        .detail{
            width: 84%;
            height: auto;
            position: absolute;
            top: 30%;
            left: 50%;
            margin-left: -42%;
            text-align: left;
            background-color: white;
            border: 1px solid #fff;
            border-radius: .1rem;
            .tit{
                padding: .35rem;
                font-size: 16px;
                color: #9b9b9b;
                background-color: #e9e9e9;
                border: 1px solid #e9e9e9;
                border-top-right-radius: .1rem;
                border-top-left-radius:  .1rem;
            }
            .content {
                padding: .35rem;
                font-size: 16px;
                text-indent: 2em;
            }
        }
    }
</style>
