<template>
    <div class="show-card">
        <dl class="row" v-for="item in itemArr">
            <dt class="row-name">{{item.name}}</dt>
            <dd class="row-value">{{item.value}}</dd>
        </dl>
    </div>
</template>
<script type="text/ecmascript-6">
    export default {
        data() {
            return {};
        },
        props: ['itemArr']
    };
</script>
<style scoped>
    .show-card{
        padding:.2rem .3rem;
        border-bottom: solid 1px #f0f0f0;
        background: #fff;
    }
    .row{
        padding:.16rem 0;
        overflow: hidden;
    }
    .row-name{
        float: left;
        color:#666;
    }
    .row-value{float: right;color:#333;}
</style>
