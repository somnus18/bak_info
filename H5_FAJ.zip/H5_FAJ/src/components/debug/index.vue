<template>
    <div>
        <div class="debug-container" v-show="toggle">
            <a class="debug-btn" @click="refresh">refresh</a>
            <a class="debug-btn" @click="interface">interface</a>
            <a class="debug-btn" @click="back">back</a>
            <a class="debug-btn" @click="clear">clear</a>
            <p class="debug-v">当前url: {{currUrl}}</p>

            <div class="debug-text" v-for="item in debugs" :style="{color:item.type == 'log'?'#8FDAFF': item.type == 'warn' ? '#f5cf79' : '#FF8F8F'}">
                [{{item.type == 'log'?'DEBUG': item.type == 'warn' ? 'WARN' : 'ERROR'}}]: {{item.text}}
            </div>
        </div>
        <div class="debug-btn-test" @click="toggle=!toggle">debug</div>
    </div>
</template>

<script type="text/ecmascript-6">
    export default {
        name: 'debug',
        mounted() {
            for (let key in C.debug) {
                eventHub.$on('debug-' + key, this.handlerLog);
            }
        },
        data() {
            return {
                currUrl: location.href,
                toggle: false,
                debugs: []
            };
        },
        methods: {
            refresh() {
                location.reload();
            },
            interface() {
                this.toggle = !this.toggle;
                C.Native.forwardWebView = C.Native.forwardWebView || function (opt) {
                        C.Native.forward(opt);
                    };
                C.Native.forwardWebView({
                    url: 'index.html#/interface'
                });
            },
            back() {
                this.toggle = !this.toggle;
                this.$router.go('-1');
            },
            clear() {
                this.debugs = [];
            },
            handlerLog(obj) {
                let text = C.Utils.paramToString(obj.text);
                switch (obj.type) {
                    case 'clear':
                        this.debugs = [];
                        this.toggle = false;
                        this.currUrl = location.href;
                        break;
                    case 'log':
                    case 'warn':
                    case 'error':
                        this.debugs.push({
                            text: text,
                            type: obj.type
                        });
                        console[obj.type](text);
                        break;

                }
            }
        }
    };
</script>

<style>
    .debug-container {
        position: absolute;
        top: 0px;
        left: 0px;
        padding: 5px;
        height: 450px;
        overflow-y: auto;
        background-color: rgba(0, 0, 0, 0.8);
        width: 100%;
        z-index: 999999
    }

    .debug-container > div {
        border-bottom: dotted 1px #666;
    }

    .debug-container .debug-v {
        color: #fff;
        font-size: 16px;
        padding: 5px;
    }

    .debug-container .debug-btn {
        min-width: 80px;
        border-radius: 4px;
        font-size: 18px;
        line-height: 40px;
        height: 40px;
        border: none;
        padding: 0 10px;
        margin-bottom: 10px;
        display: inline-block;
        background-color: #07c756;
        color: #fff;
        text-align: center;
    }

    .debug-container .debug-text {
        font-size: 0.32rem;
    }

    .debug-btn-test {
        position: fixed;
        left: 0.4rem;
        bottom: 1rem;
        width: 1rem;
        height: 1rem;
        line-height: 1rem;
        background: rgba(0, 0, 0, 0.2);
        text-align: center;
        border-radius: 50%;
        color: #f60;
        z-index: 999999;
    }
</style>
