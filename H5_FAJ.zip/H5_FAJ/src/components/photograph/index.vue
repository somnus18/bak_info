<template>
	<div>
		<div class="box">
			<div class="title" @click='showPhoto'>
				<span class="left">{{item.title}}</span>
				<i class="icon-down" :class='[photoMainShow ? "rotate_180" : "rotate_0" ]' ></i>
			</div>
			<transition name="fade">
				<div class="main" v-show='photoMainShow'>
					<!-- h5图片上传 -->
					<upload-image-h5 :imgList='item.imgList'
					:notRemoveIcon='notRemoveIcon'
					:isShowAddBtn='isShowAddBtn'
					:orderId='orderId'
					:kbType='item.kbType'
					:page='page'
					:maxLength='maxLength'></upload-image-h5>
					<!-- Native图片上传 -->
					<upload-image-native :imgList='item.imgList'
					:canShowBigImg='canShowBigImg'
					:notRemoveIcon='notRemoveIcon'
					:isShowAddBtn='isShowAddBtn'
					:maxLength='maxLength'
                    :page="page"
                    :orderId="orderId"
                    :collateralId="collateralId"
                    :kbType="item.kbType">
					</upload-image-native>
				</div>
			</transition>
		</div>
	</div>
</template>

<script type='text/ecmascript-6'>
import uploadImageH5 from 'components/upload/multiple-image-h5';
import uploadImageNative from 'components/upload/multiple-image';
export default {
	name: 'pending-photo',
	props: {
		notRemoveIcon: { // 渠道APP 有初始化图片是没有删除的icon
			type: Boolean, // true无删除icon图标  false有删除icon图标
			default: false
		},
		canShowBigImg: { // 是否可以点击预览
			type: Boolean, // true可以预览  false不可以预览
			default: false
		},
		isShowAddBtn: { // 显示/隐藏 上传按钮
			type: Boolean,
			default: false
		},
		maxLength: {
			type: Number,
			default: 40
		},
		item: {
			type: Object
		},
		isPhotoMain: {
			type: Boolean,
			default: false
		},
		imgList: {
			type: Object
		},
        page: {
            type: String
        },
        orderId: {
            type: String
        },
        collateralId: {
            type: String
        },
        kbType: {
            type: String
        }
	},
	data() {
	    return {
	    	photoShow: true
	    };
	},
	computed: {
		photoMainShow() {
			let Bool;
			if (!this.isPhotoMain && !this.photoShow) {
				Bool = true;
			} else if (this.isPhotoMain && this.photoShow) {
				Bool = true;
			} else {
				Bool = false;
			}
			return Bool;
		}
	},
	components: {
		uploadImageH5,
		uploadImageNative
	},
	methods: {
		showPhoto() {
			this.photoShow = !this.photoShow;
		},
		clickEvent() {
			this.$emit('submit');
		},
		uploadImg(imgBase64, fileName) {
			this.$emit('uploadImg', imgBase64, fileName, this.item.kbType);
		}
	}
};
</script>

<style scoped lang="scss">
.box {
	background: #fff;
	margin-top: .1rem;
	.title{
		padding: .4rem .3rem;
		position:relative;
		font-size: .28rem;
		color: #333;
		.icon-down{
			position: absolute;
		    top: 50%;
		    margin-top: -.15rem;
		    right: .3rem;
		    width: .3rem;
		    height: .4rem;
        	background: url('icon_arrow_r_gray@3x.png') center center no-repeat;
		    background-size: .3rem auto;
		    transition-duration: 200ms;
		}
	}
	.main{
		padding: .1rem;
		padding-bottom: 0;
		background: #fbf9f9;
		.upload-image{
			padding-top: .4rem;
			padding-bottom: .1rem;
		}
	}
	.rotate_0{
	    transform: rotate(0deg);
	    -ms-transform: rotate(0deg);
	    -moz-transform: rotate(0deg);
	    -webkit-transform: rotate(0deg);
	    -o-transform: rotate(0deg);
	}
	.rotate_180{
	    transform: rotate(180deg);
	    -ms-transform: rotate(180deg);
	    -moz-transform: rotate(180deg);
	    -webkit-transform: rotate(180deg);
	    -o-transform: rotate(180deg);
	}
	.fade-enter-active, .fade-leave-active {
	  transition: all .2s;
	}
	.fade-enter, .fade-leave-active {
	  opacity:0
	}
}
.bt-bottom {
    margin:.2rem 0 0 0;
    padding:.3rem 0;
    width: 100%;
    line-height: .8rem;
    text-align: center;
    background:#fff;
    border-top: 1px solid #ddd;
    .btn{
    	border: 1px solid #dd5310;
    }
}
</style>
