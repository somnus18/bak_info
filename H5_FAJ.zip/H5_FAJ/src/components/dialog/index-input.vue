<template>
    <div class="dialog">
        <div class="dialog-pop" :style="popStyle">
            <div class="close" @click="$parent.isShow = false"></div>
            <div class="content">
                <h2>录入人手机号</h2>
                <div class="input-content">
                    <input v-model="number" type="tel" class="tel" maxlength="11" placeholder="请填写录入人手机号"><i
                    class="empty-input-icon" v-if="number" @click="number = ''"></i>
                </div>
            </div>
            <div class="btns">
                <div class="btn-fixed-right btn" @click="ok">确认</div>
            </div>
        </div>
        <div class="layer" @click="$parent.isShow = false"></div>
    </div>
</template>
<script type="text/ecmascript-6">
    export default {
        name: 'dialog',
        data() {
            return {
                number: '',
                showStatus: ''
            };
        },
        created() {
            this.number = this.mobile;
        },
        computed: {
            popStyle() {
                let $app = document.getElementById('app');
                $app.style.overflow = this.isShow === true ? 'hidden' : '';
                return {'margin-top': 0};
            }
        },
        props: {
            mobile: {
                type: [String, Number],
                default: ''
            },
            isShow: {
                type: Boolean,
                default: false
            }
        },
        destroyed: function () {
            document.getElementById('app').style.overflow = '';
        },
        methods: {
            ok() {
                this.$emit('ok', this.number);
            }
        }
    };
</script>
<style scoped lang="scss">
    .dialog {

    .layer {
        z-index: 1009;
    }

    .close {
        position: absolute;
        top: -1rem;
        left: 50%;
        width: .5rem;
        height: .5rem;
        margin-left: -0.25rem;
        background: url('../../assets/images/m/icons/icon_closepopup@2x.png');
        background-size: 100%;
    }

    .dialog-pop {
        position: absolute;
        width: 84%;
        height: auto;
        background: #fff;
        text-align: center;
        border-radius: .1rem;
        top: 30%;
        left: 8%;
        z-index: 1010;

    .content {
        margin-top: .4rem;

    h2 {
        font-size: .3rem;
        color: #999;
        margin-bottom: .6rem;
    }

    .input-content {
        position: relative;

    input.tel {
        padding: .2rem .3rem;
        width: 5.1rem;
        height: .88rem;
        line-height: .4rem;
        color: #333;
        font-size: .34rem;
        background: #f0f0f0;
    }

    .empty-input-icon {
        position: absolute;
        top: .23rem;
        right: .8rem;
        display: inline-block;
        width: .42rem;
        height: .42rem;
        background: url("../../assets/images/m/icons/icon_sign_delete@2x.png") center no-repeat;
        background-size: 100%;
    }

    }
    }
    .btns {
        width: 64%;
        height: .76rem;
        line-height: .76rem;
        font-size: .3rem;
        margin: .8rem auto .6rem;

    .btn {
        width: 100%;
        height: .76rem;
        line-height: .76rem;
    }

    }
    }
    }
</style>
