<template>
    <div class="dialog" v-show="dialog.isShowDialog">
        <div class="dialog-pop">
            <div class="close" @click="closeX" v-if="dialog.isShowClose"></div>
            <div class="content">
                <h2 :class="dialog.titleIcon" v-show="dialog.title">{{dialog.title}}</h2>
                <span class="link" v-show='dialog.link'>{{dialog.link}}</span>
                <span class="txt" v-show="dialog.content" v-html="dialog.content"></span>
            </div>
            <div class="btns" :style="btnWidth">
                <div class="btn-fixed-left btn btn-white" @click="cancel" v-show="dialog.cancelText">{{dialog.cancelText}}</div>
                <div class="btn-fixed-right btn" @click="ok" v-show="dialog.okText">{{dialog.okText}}
                </div>
            </div>
        </div>
        <div class="layer" @click="close"></div>
    </div>
</template>
<script type="text/ecmascript-6">
    import * as types from 'src/app/vuex/mutation-types';

    export default {
        name: 'dialog',
        computed: {
            dialog() {
                return this.$store.state.dialog.data;
            },
            /**
             * 一个按钮是,btns的宽度设置为64%
             * @returns {string|string|*|string|boolean|{width: string}}
             */
            btnWidth() {
                 if ((this.$store.state.dialog.data.cancelText || this.$store.state.dialog.data.okText) && !(this.$store.state.dialog.data.cancelText && this.$store.state.dialog.data.okText)) {
                     return { width: '64%' };
                 } else {
                     return { width: '80%' };
                 }
            }
        },
        methods: {
            cancel() {
                if (this.dialog.isCancelCloseDialog) {
                    this.$store.commit(types.SET_DIALOG, {isShowDialog: false});
                }
                if (this.dialog.cancel) {
                    this.dialog.cancel(this.$store);
                }
            },
            ok() {
                if (this.dialog.isOkCloseDialog) {
                    this.$store.commit(types.SET_DIALOG, {isShowDialog: false});
                }
                if (this.dialog.ok) {
                    this.dialog.ok(this.$store);
                }
            },
            closeX() {
                if (this.dialog.isXCloseDialog) {
                    this.$store.commit(types.SET_DIALOG, {isShowDialog: false});
                }
                if (this.dialog.closeX) {
                    this.dialog.closeX(this.$store);
                }
            },
            close() {
                if (this.dialog.onlyBtn) return;
                this.$store.commit(types.SET_DIALOG, {isShowDialog: false});
            }
        }
    };
</script>
<style scoped lang="scss">
    .dialog {
        .layer {
            z-index: 1009;
        }
        .close{
            position: absolute;
            top: -35%;
            left: 50%;
            width: .6rem;
            height: .6rem;
            margin-left: -.3rem;
            background: url('../../assets/images/m/icons/icon_closepopup@2x.png');
            background-size: 100%;
        }
        .dialog-pop {
            position: fixed;
            width: 84%;
            height: auto;
            margin-left: -42%;
            margin-top: -30%;
            background: #fff;
            text-align: center;
            border-radius: .1rem;
            top: 50%;
            left: 50%;
            z-index: 1010;
            .content {
                margin-top: .7rem;
                h2 {
                    font-size: .42rem;
                    color: #333;
                    padding-bottom: .3rem;
                }
                .link{
                    color: #26a2ff;
                    text-decoration: underline;
                }
                .txt {
                    display: block;
                    font-size: .3rem;
                    color: #333;
                    padding: 0 .64rem;
                    margin-top: .3rem;
                    max-height: 4rem;
                    overflow: auto;
                    line-height: .44rem;
                    text-align: left;

                }
                .pass:before,.fail:before,.warn:before,.warn-native:before{
                    width: .58rem;
                    height: .58rem;
                    content: '';
                    margin-top: -.1rem;
                    display: inline-block;
                    margin-right: .2rem;
                    vertical-align: middle;
                }
                .pass:before{
                    background: url(./icon_pass@2x.png) no-repeat;
                    background-size: 100%;
                }
                .fail:before{
                    background: url(./icon_fail@2x.png) no-repeat;
                    background-size: 100%;
                }
                .warn:before{
                    background: url(./icon_warn@2x.png) no-repeat;
                    background-size: 100%;
                }
                .warn-native:before{
                    background: url(./icon_warning_blue@2x.png) no-repeat;
                    background-size: 100%;
                }
            }
            .btns {
                display: -webkit-box;
                width: 100%;
                height: .76rem;
                line-height: .76rem;
                font-size: .3rem;
                margin: .8rem auto .6rem;
                .btn{
                    width: 100%;
                    height: .76rem;
                    line-height: .76rem;
                    border-radius: .38rem !important;
                }
                .btn-fixed-left {
                    -webkit-box-flex: 1;
                    margin-right: .2rem;
                }
                .btn-fixed-right {
                    -webkit-box-flex: 1;
                }
            }
        }
    }
</style>
