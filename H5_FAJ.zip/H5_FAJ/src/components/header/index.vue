<template>
    <header>
        <div class="navbar" v-if="!isNative" v-show="header.isShowHeader" :class="[header.fixed ? 'fixed': '']">
            <div @click="handlerLeftBtn" :style="{visibility: header.isBack ? '' : 'hidden'}"><span :class="leftIcon"></span>{{header.leftText}}</div>
            <div class="title" @click="handlerTitleBtn"><span :class="header.titleIcon" v-show="header.titleIcon"></span>{{header.titleIcon ? '' : header.title}}</div>
            <div @click="handlerRightBtn"><span :class="header.rightIcon"></span>{{header.rightIcon ? '' : header.rightText}}</div>
        </div>
        <div v-if="header.fixed" class="header-placeholder"></div>
    </header>
</template>

<script type='text/ecmascript-6'>
    export default {
        name: 'header',
        data() {
            return {
                isNative: C.Utils.App.IS_NATIVE
            };
        },
        computed: {
            header() {
                return this.$store.state.header.data;
            },
            leftIcon() {
                return this.$store.getters.leftIcon;
            },
            rightIcon() {
                return this.$store.getters.rightIcon;
            }
        },
        methods: {
            handlerLeftBtn() {
                if (!this.header.isBack) return;
                if (this.header.leftCallback) {
                    this.header.leftCallback();
                } else {
                    this.$router.go(-1);
                }
            },
            handlerRightBtn() {
                if (this.header.rightText || this.header.rightIcon) {
                    this.header.rightCallback && this.header.rightCallback();
                }
            },
            handlerTitleBtn() {
                C.Constant.DEBUG_MODE && this.header.titleCallback && this.header.titleCallback();
            }
        }
    };
</script>

<style scoped lang="scss">
    .header-placeholder{
        height: 1rem;
    }
    .navbar{
        height: 1rem;
        background: #f15b23;
        display: -webkit-box;
        &.fixed {
             position: fixed;
             top: 0;
             left: 0;
             right: 0;
             z-index: 100;
         }
        .title{
            line-height: 1rem;
            text-align: center;
            -webkit-box-flex:1;
            font-size: .32rem;
            color:#fff;
        }
        div{
            &:first-child, &:last-child{
                position: relative;
                width: 1.5rem;
                height: 1rem;
                line-height: 1rem;
                text-align: center;
             }
            &:last-child{
                color: #fff;
             }
        }
        .logo{
            display: inline-block;
            vertical-align: middle;
            width: 3.08rem;
            height: .4rem;
            background: url(../../assets/images/m/img_home_logo@2x.png) no-repeat;
            background-size: 100%;
        }
        .back{
            display: inline-block;
            position: absolute;
            width: .27rem;
            height: .36rem;
            left: .3rem;
            top: .32rem;
            background: url(icon_back@2x.png) no-repeat;
            background-size: 70%;
        }
        .close{
            display: inline-block;
            width: .52rem;
            height: .52rem;
            vertical-align: middle;
            margin-right: -.5rem;
            background: url(./icon_closescreen@2x.png) no-repeat;
            background-size: 100%;
        }
        .user{
            display: inline-block;
            width: .72rem;
            height: .72rem;
            background: url(icon_account@2x.png) no-repeat;
            background-size: 100%;
            margin: .13rem .3rem .3rem -.2rem;
        }
    }
</style>
