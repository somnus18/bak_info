<template>
    <section>
        <m-picker :slots='slots' :datakey='datakey' :valueKey='valueKey' :isPicker='isPicker' :indexText='indexText'
                  @confirm='pickerConfirm' @cancel='pickerCancel' @change="onValuesChange" @initChange='initChange'>
        </m-picker>
    </section>
</template>

<script>
    import mPicker from './index';
    export default {
        name: 'address-picker',
        components: {
            mPicker
        },
        props: {
            isPicker: {
                type: Boolean,
                default: false
            },
            datakey: {
                type: [String, Object],
                default: ''
            },
            defaultDate: { // 二期需求，日期选择器选中项
                type: [String, Array],
                default: ''
            }
        },
        data () {
            return {
                indexText: '请选择日期',
                valueKey: '',
                oldValue: '',
                slots: [],
                year: '',
                month: '',
                _picker: '',
                ArrVla: '',
                day: ''
            };
        },
        created() {
            this.initDate();
        },
        watch: {
            isPicker() {
                let val = this.defaultDate, _val;
                if (val) {
                    _val = val.split('-');
                    this._picker.setSlotValue(0, _val[0] * 1 + '年');
                    this._picker.setSlotValue(1, _val[1] * 1 + '月');
                    this._picker.setSlotValue(2, _val[2] * 1 + '日');
                } else {
                    this._picker.setSlotValue(0, this.year + '年');
                    this._picker.setSlotValue(1, this.month + 1 + '月');
                    this._picker.setSlotValue(2, this.day + 1 + '日');
                }
            }
        },
        methods: {
            initDate() {
                let now = new Date();
                this.year = now.getFullYear();
                this.month = now.getMonth();
                this.day = now.getDate() - 1;
                this.oldValue = parseInt(this.year) + parseInt(this.month);
                this.slots = [
                    {defaultIndex: this.year - 1900, values: this.createArray(1900, 2099, '年')},
                    {defaultIndex: this.month, values: this.createArray(1, 12, '月')},
                    {defaultIndex: this.day, values: this.createArray(1, 31, '日')}
                ];
            },
            initChange(picker) {
                this._picker = picker;
            },
            createArray(min, max, t = "") {
                let newArray = [];
                for (let i = min; i <= max; i++) {
                    newArray.push(i + t);
                }
                return newArray;
            },
            pickerCancel() {
                this.$emit('cancel');
            },
            pickerConfirm(value, key, picker) {
                let _value = [
                parseInt(value[0]) + '',
                (parseInt(value[1]) < 10 ? '0' + parseInt(value[1]) : parseInt(value[1])) + '',
                (parseInt(value[2]) < 10 ? '0' + parseInt(value[2]) : parseInt(value[2])) + ''];
                picker.setSlotValue(0, _value[0] + '年');
                picker.setSlotValue(1, _value[1] + '月');
                picker.setSlotValue(2, _value[2] + '日');
                this._picker = picker;
                this.$emit('confirm', _value, key, picker);
            },
            getDaysInMonth(year, month){
                month = parseInt(month, 10);
                let temp = new Date(year, month, 0), newArray = [];
                for (let i = 1; i <= temp.getDate(); i++) {
                    newArray.push(i + '日');
                }
                return newArray;
            },
            onValuesChange(values, picker) {
                this._picker = picker;
                if (this.oldValue && (this.oldValue !== parseInt(values[0]) + parseInt(values[1]))) {
                    picker.setSlotValues(2, this.getDaysInMonth(parseInt(values[0]), parseInt(values[1])));
                };
                this.oldValue = parseInt(values[0]) + parseInt(values[1]);
            }
        }
    };
</script>

<style scoped>
</style>
