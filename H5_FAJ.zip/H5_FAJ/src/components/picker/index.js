import Picker from './picker.vue';
export default Picker;
