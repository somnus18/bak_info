<template>
  <section v-show='isWatchPicker' @touchmove.prevent>
    <div  class="layer" v-show='isLayer' @click="cancel"></div>
    <div class="picker" :class="{ 'picker-3d': rotateEffect}">
      <div class="picker-toolbar" v-if="showToolbar">
        <button class="left" @click="cancel">取消</button>
        <span>{{indexText}}</span>
        <button class="right" @click="confirm">确定</button>
      </div>
      <div class="picker-items">
        <picker-slot v-for="(slot,index) in slots" :key="index && slot.valueKey"  :valueKey='valueKey' :values="slot.values || []" :text-align="slot.textAlign || 'center'" :visible-item-count="visibleItemCount" :class-name="slot.className" :flex="slot.flex || '1'" v-model="values[slot.valueIndex]" :rotate-effect="rotateEffect" :divider="slot.divider" :content="slot.content"></picker-slot>
        <div class="picker-center-highlight"></div>
      </div>
    </div>
  </section>
</template>

<script>
  import PickerSlot from './picker-slot.vue';
  export default {
    name: 'mt-picker',

    componentName: 'picker',

    props: {
      slots: {
        type: Array
      },
      showToolbar: {
        type: Boolean,
        default: true
      },
      indexText: {
        type: String,
        default: '请选择'
      },
      isPicker: {
        type: Boolean,
        default: false
      },
      visibleItemCount: {
        type: Number,
        default: 5
      },
      rotateEffect: {
        type: Boolean,
        default: false
      },
      valueKey: {
        type: String,
        default: 'v'
      },
      datakey: {}
    },
    data() {
      return {
        isWatchPicker: false,
        isLayer: false
      }
    },
    created() {
      this.$on('slotValueChange', this.slotValueChange);
      var slots = this.slots || [];
      this.values = [];
      var values = this.values;
      var valueIndexCount = 0;
      slots.forEach(function(slot) {
        if (!slot.divider) {
          slot.valueIndex = valueIndexCount++;
          values[slot.valueIndex] = (slot.values || [])[slot.defaultIndex || 0];
        }
      });
      setTimeout(()=> {
        this.initChange();
      }, 100)
    },

    methods: {
      initChange() {
        this.$emit('initChange', this);
      },
      slotValueChange() {
        this.$emit('change', this.values, this);
      },
      cancel() {
        this.$emit('cancel');
      },
      confirm() {
        if (this.values['undefined']) {
          this.$emit('confirm', this.values['undefined'], this.datakey, this);
        } else {
          this.$emit('confirm', this.values, this.datakey, this);
        }
      },
      getSlot(slotIndex) {
        var slots = this.slots || [];
        var count = 0;
        var target;
        var children = this.$children;

        slots.forEach(function(slot, index) {
          if (!slot.divider) {
            if (slotIndex === count) {
              target = children[index];
            }
            count++;
          }
        });
        return target;
      },
      getSlotValue(index) {
        var slot = this.getSlot(index);
        if (slot) {
          return slot.value;
        }
        return null;
      },
      setSlotValue(index, value) {
        var slot = this.getSlot(index);
        if (slot) {
          slot.currentValue = value;
        }
      },
      getSlotValues(index) {
        var slot = this.getSlot(index);
        if (slot) {
          return slot.mutatingValues;
        }
        return null;
      },
      setSlotValues(index, values) {
        var slot = this.getSlot(index);
        if (slot) {
          slot.mutatingValues = values;
        }
      },
      getValues() {
        return this.values;
      },
      setValues(values) {
        var slotCount = this.slotCount;
        values = values || [];
        if (slotCount !== values.length) {
          throw new Error('values length is not equal slot count.');
        }
        values.forEach((value, index) => {
          this.setSlotValue(index, value);
        });
      }
    },

    computed: {
      // values() {
      //   var slots = this.slots || [];
      //   var values = [];
      //   slots.forEach(function(slot) {
      //     if (!slot.divider) values.push(slot.values);
      //   });
      //   return values;
      // },
      slotCount() {
        var slots = this.slots || [];
        var result = 0;
        slots.forEach(function(slot) {
          if (!slot.divider) result++;
        });
        return result;
      }
    },
    watch: {
      isPicker(val) {
        this.isLayer = !this.isLayer;
        this.isWatchPicker = val;
        if (val) {
          document.querySelector('body').style.overflow = 'hidden';
        } else {
          document.querySelector('body').style.overflow = 'auto';
        }
      }
    },
    components: {
      PickerSlot
    }
  };
</script>
<style>
  .picker {
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    overflow: hidden;
    background: #fff;
    border-top: 1px solid #f0f0f0;
    z-index: 999;
  }
  .picker-items {
    display: -webkit-box;
    display: -ms-flexbox;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -ms-flex-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    padding: 0;
    text-align: right;
    font-size: 24px;
    position: relative;
  }

  .picker-center-highlight {
    height: 36px;
    box-sizing: border-box;
    position: absolute;
    left: 0;
    width: 100%;
    top: 50%;
    margin-top: -18px;
    pointer-events: none
  }

  .picker-center-highlight:before,
  .picker-center-highlight:after {
    content: '';
    position: absolute;
    height: 1px;
    width: 100%;
    background-color: #eaeaea;
    display: block;
    z-index: 15;
    -webkit-transform: scaleY(.5);
    transform: scaleY(0.5);
  }

  .picker-center-highlight:before {
    left: 0;
    top: 0;
    bottom: auto;
    right: auto;
  }

  .picker-center-highlight:after {
    left: 0;
    bottom: 0;
    right: auto;
    top: auto;
  }
  button{
  -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    border-radius: 4px;
    border: 0;
    box-sizing: border-box;
    color: inherit;
    display: block;
    height: .8rem;
  font-size: .28rem;
    outline: 0;
    overflow: hidden;
    position: relative;
    text-align: center;
  color: #fff;
}
.picker-toolbar{
  position: relative;
  height: 40px;
  border-bottom: 1px solid #e6e6e6;
}
.picker-toolbar button{
  padding-right: .4rem;
  background: none;
  color: #333;
  display: inline-block;
}
.picker-toolbar button.left{
  position: absolute;
  top: 0;
  left: 0;
  padding-left: .4rem;
  padding-left: .4rem;
  color: #f15b21;
}
.picker-toolbar button.right{
  position: absolute;
  top: 0;
  right: 0;
  padding-left: .4rem;
  padding-right: .4rem;
  color: #f15b21;
}
.picker-toolbar span{
  display: block;
  width: 70%;
  text-align: center;
  margin: 0 auto;
  height: .8rem;
  line-height: .8rem;
  color: #666;
}
.layer{
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    overflow: hidden;
    background: rgba(0, 0, 0, .5);
    z-index: 100;
}
</style>
