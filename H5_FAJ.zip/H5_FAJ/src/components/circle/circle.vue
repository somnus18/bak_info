<template>
    <div class="circle" :style="circleSize">
        <div class="circle_left" :style="styleLeftClip">
            <div class="left" :style="[styleLeftClip,transformL]"></div>
        </div>
        <div class="circle_right" :style="styleRightClip">
            <div class="right" :style="[styleRightClip,transformR]"></div>
        </div>
        <div class="mask" :style="styleMask"><span>{{msg}}</span>%</div>
    </div>
</template>
<style lang="scss" rel="stylesheet/scss">
    .circle {
        width: 100%;
        height: 100%;
        display: inline-block;
        position: relative;
        border-radius: 50%;
        background: #0cc;
        .circle_left, .circle_right {
            width: 100%;
            height: 100%;
            position: absolute;
            top: 0;
            left: 0;
        }
        .left, .right {
            width: 100%;
            height: 100%;
            background: #00aacc;
            border-radius: 50%;
            position: absolute;
            top: 0;
            left: 0;
            transition: all .5s linear;
        }
        .circle_right, .right {
            clip: rect(0, auto, auto, 25px);
        }
        .circle_left, .left {
            clip: rect(0, 25px, auto, 0);
        }
        .mask {
            width: 80%;
            height: 80%;
            border-radius: 50%;
            background: #FFF;
            position: absolute;
            text-align: center;
            font-weight: bold;
            color: #00aacc;
            top: 0;
            right: 0;
            left: 0;
            bottom: 0;
            margin: auto;
        }
    }

</style>
<script>
    export default{
        props: {
            size: {
                type: Number,
                default: 50
            },
            per: {
                type: Number,
                default: 70
            }
        },
        data() {
            return {
                msg: 0,
                num: 0,
                rotateL: 0,
                rotateR: 0
            };
        },
        computed: {
            circleSize() {
                return {
                    width: `${this.size}px`,
                    height: `${this.size}px`
                };
            },
            styleLeftClip() {
                let size = this.size / 2;
                return {
                    clip: `rect(0, ${size}px, auto, 0)`
                };
            },
            styleRightClip() {
                let size = this.size / 2;
                return {
                    clip: `rect(0, auto, auto, ${size}px)`
                };
            },
            styleMask() {
                let lineHeight = this.size * 0.8;
                return {
                    'line-height': `${lineHeight}px`,
                    'font-size': `${lineHeight / 2.8}px`
                };
            },
            transformL() {
                return {
                    transform: `rotate(${this.rotateL}deg)`
                };
            },
            transformR() {
                return {
                    transform: `rotate(${this.rotateR}deg)`
                };
            }
        },
        components: {},
        mounted() {
            this.$nextTick(()=> {
                this.msg = this.per;
                setTimeout(()=> {
                    let num = this.per * 3.6;
                    if (num <= 180) {
                        this.rotateR = num;
                    } else {
                        this.rotateR = 180;
                        setTimeout(()=> {
                            this.rotateL = num - 180;
                        }, 490);
                    }
                }, 0);
            });
        }
    };
</script>
