<template>
  <div class="order-card" @click="goDetail">
      <div class="card-top">
      	<span class="kb-num">{{item.barcode}}</span>
      	<span class="fr">{{arrToObj()[item.interviewType]}}</span>
      </div>
      <div class="card-btm">
          <div class="text-row clear">
              <span class="fl">{{item.clientName}}</span>
              <span class="fr">{{item.signDate}}&nbsp&nbsp&nbsp&nbsp{{item.signBeginTime}}-{{item.signEndTime}}</span>
          </div>
      </div>
    </div>
  </div>
</template>
<script type="text/ecmascript-6">
    export default {
        data() {
            return { };
        },
        props: ['item'],
        methods: {
            goDetail() {
                this.$emit('goDetail');
            },
            arrToObj() {
                return C.Constant['1'];
            }
        }
    };
</script>
<style scoped lang='scss'>
	.order-card{padding:0 5px;margin-top: .2rem;background: #fff;}
    .card-top{padding:.2rem .3rem .15rem;line-height: .4rem;border-bottom: solid 1px #ccc;}
    .card-btm{padding:.2rem .3rem;}
    .text-row{padding:.1rem 0;clear: both;}
    .text-row *{line-height: .5rem;}
</style>
