## loading组件，调用方式。

#### 加载loading
显示loading

```
C.UI.loading();
```
显示loading(带文案)

```
C.UI.loading('登录中...');
```
#### 去掉loading
```
C.UI.stopLoading();
```