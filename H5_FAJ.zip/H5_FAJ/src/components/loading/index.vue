<template>
    <div class="loading" v-show="loading.isShow" v-if="!isNative">
        <div class="layer"></div>
        <div class="loading-pop">
            <div class="content">
                <i class="loading-icon"></i>
                <span class="txt">{{loading.msg || '加载中...'}}</span>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        name: 'loading',
        data() {
            return {
                isNative: C.Utils.App.IS_NATIVE,
                styleObj: {
                    width: window.innerWidth + 'px',
                    height: window.innerHeight + 'px'
                }
            };
        },
        computed: {
            loading() {
                return this.$store.state.loading.data;
            }
        }
    };
</script>
<style scoped lang="scss">
    .loading {
        .layer {
            z-index: 99999;
        }
        .loading-pop {
            position: fixed;
            width: 5.4rem;
            height: .8rem;
            line-height: .8rem;
            margin-left: -2.7rem;
            margin-top: -.4rem;
            text-align: center;
            top: 50%;
            left: 50%;
            z-index: 99999;
            .loading-icon {
                font-style: normal;
                display: inline-block;
                width: 1rem;
                height: 1rem;
                background: url('loading.gif') 50% no-repeat;
                -webkit-background-size: 100%;
                background-size: 100%;
                vertical-align: middle;
                margin-top: -.05rem;
                /*
                -webkit-animation: loading 1.2s linear infinite;
                -moz-animation: loading 1.2s linear infinite;
                animation: loading 1.2s linear infinite;
                */
            }
            .content .txt {
                color: #fff;
                font-size: .3rem;
                margin-left: .24rem;
            }
        }
    }
    /*
    @keyframes loading {
        0% { -webkit-transform: rotateZ(0deg); }
        100% { -webkit-transform: rotateZ(360deg); }
    }
    @-webkit-keyframes loading {
        0% { -webkit-transform: rotateZ(0deg); }
        100% { -webkit-transform: rotateZ(360deg); }
    }
    */
</style>
