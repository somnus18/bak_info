<template>
    <div class="item-card" @click="goDetail">
    	<span class="grey">{{textName}}</span>
    	<span class="fr" :class="[!disabled ? 'ft-yellow' : 'ft-bule', !disabled ? 'hasRight' : '']">{{value}}</span>
        <i class="icon-arrow-r" v-if="!disabled"></i>
    </div>
</template>
<script type="text/ecmascript-6">
    export default {
        data() {
            return {};
        },
        props: {
            textName: {
                type: String,
                default: ''
            },
            value: {
                type: String,
                default: ''
            },
            disabled: {
                type: Boolean,
                default: false // 未审核
            }
        },
        methods: {
        	goDetail() {
                if (this.disabled) return;
        		this.$emit('goDetail');
        	}
        }
    };
</script>
<style scoped>
    .item-card {
        position: relative;
    }

    .grey {
        color: #666
    }

    .hasRight {
        margin-right: .8rem;
        _display: inline-block;
    }

    .icon-arrow-r {
        position: absolute;
        top: 50%;
        right: .3rem;
        margin-top: -8px;
        padding: 8px;
        background: url('../assets/images/app/icons/icon_arrow_r@3x.png') center center/100% auto no-repeat;
        -webkit-background-size: 7px auto;
        background-size: 7px auto;
    }
</style>
