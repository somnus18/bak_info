<template>
    <div ref="scrollView" :style="[wrapperStyle, marginTop]" :class="wrapperClass">
        <div :style="scrollerStyle" :class="scrollerClass">
            <div class="bottom-load" v-if="opt.isRefresh" v-show="topLoad">
                <i class="icon"><img src="./bottomLoad.png" height="20" width="20"></i>下拉刷新
            </div>
            <div class="bottom-load Loading" v-if="opt.isRefresh" v-show="topLoading">
                <i class="icon"><img src="./Loading.gif" height="24" width="24"></i>正在加载...
            </div>
            <slot></slot>
            <div class="bottom-load scroller-bottom" v-if="opt.isLoadMore" v-show="isMoreData && !bottomLoading">
                <i class="icon"><img src="./topLoad.png" height="24" width="24"></i>上拉刷新
            </div>
            <div class="bottom-load Loading" v-if="opt.isLoadMore" v-show="bottomLoading">
                <i class="icon"><img src="./Loading.gif" height="24" width="24"></i>正在加载...
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: 'scroll-view',
        props: {
            opt: {
                type: Object,
                default () {
                    return {}
                }
            },
            isMoreData: {
                type: Boolean
            },
            options: {
                type: Object,
                default () {
                    return {}
                }
            },
            wrapperClass: {
                type: Object,
                default () {
                    return {}
                }
            },
            wrapperStyle: {
                type: Object,
                default () {
                    return {}
                }
            },
            scrollerClass: {
                type: Object,
                default () {
                    return {}
                }
            },
            scrollerStyle: {
                type: Object,
                default () {
                    return {}
                }
            }
        },
        data() {
            return {
                topLoading: false,
                bottomLoading: false,
                topLoad: false,
                bottomLoad: false,
                distY: null,
                marginTop: !C.Utils.App.IS_NATIVE ? {
                    'margin-top': '0.5rem'
                } : {}
            }
        },
        methods: {
            _registPullEvents () {
                const {iscroll} = this;
                iscroll.on('scrollStart', ()=> {
                    this.distY = iscroll.distY;
                    if (this.distY > 10) {
                        // 不使用刷新功能
                        if (!this.opt.isRefresh) return;
                        this.topLoad = true;
                        this.topLoading = false;
                        this.bottomLoading = false;
                        this.bottomLoad = false;
                    } else if (this.distY < 0) {
                        // 不使用加载更多功能
                        this.$parent.noMore = '';
                        if (!this.opt.isLoadMore) return;
                        if (!this.isMoreData) {
                            this.bottomLoading = false;
                            this.$parent.noMore = '没有更多数据了';
                            return;
                        }
                        this.bottomLoad = true;
                        this.bottomLoading = false;
                        this.topLoad = false;
                        this.topLoading = false;
                    }
                });

                iscroll.on('mousemove', function (e) {
                    e.preventDefault();
                }, false);

                iscroll.on('scrollEnd', ()=> {
                    if (iscroll.y <= iscroll.maxScrollY) {
                        if (!this.isMoreData) return;
                        this.$emit('pullUp', iscroll);
                        this.bottomLoading = true;
                        this.bottomLoad = false;
                        this.topLoading = false;
                        this.topLoad = false;
                    } else if (iscroll.y >= 0) {
                        if (iscroll.distY > 100 || iscroll.y > 100) {
                            // debugger;
                            // 不使用刷新功能
                            if (!this.opt.isRefresh) return;
                            this.$emit('pullDown', iscroll);
                            this.topLoading = true;
                        } else {
                            this.topLoading = false;
                        }
                        this.topLoad = false;
                        this.bottomLoading = false;
                        this.bottomLoad = false;
                    }
                });
            },
            scrollToElement () {
                this.$nextTick(() => this.iscroll.scrollToElement.apply(this.iscroll, arguments))
            },
            scrollBy () {
                this.$nextTick(() => this.iscroll.scrollBy.apply(this.iscroll, arguments))
            },
            scrollTo () {
                this.$nextTick(() => this.iscroll.scrollTo.apply(this.iscroll, arguments))
            },
            refresh () {
                this.$nextTick(() => this.iscroll.refresh.apply(this.iscroll, arguments))
            }
        },
        beforeDestroy () {
            this.iscroll && this.iscroll.destroy()
            this.iscroll = null
        },
        mounted () {
            const events = [
                'beforeScrollStart',
                'scrollCancel',
                'scrollStart',
                'scrollEnd',
                'scroll',
                'flick',
                'zoomStart',
                'zoomEnd'
            ]

            setTimeout(() => {
                this.$refs.scrollView.scrollTop = 100;
                try {
                    location.hash && this.iscroll.scrollToElement(location.hash, 0)
                }
                catch (e) {
                }
            }, 0);

            this.$nextTick(() => {
                const IScroll = Vue._IScroll;
                this.iscroll = new IScroll(this.$refs.scrollView, $.extend({
                    probeType: 3,//probeType：1对性能没有影响。在滚动事件被触发时，滚动轴是不是忙着做它的东西。probeType：2总执行滚动，除了势头，反弹过程中的事件。这类似于原生的onscroll事件。probeType：3发出的滚动事件与到的像素精度。注意，滚动被迫requestAnimationFrame（即：useTransition：假）。
                    scrollbars: true,//有滚动条
                    mouseWheel: false,//允许滑轮滚动
                    fadeScrollbars: true,//滚动时显示滚动条，默认影藏，并且是淡出淡入效果
                    bounce: true,//边界反弹
                    interactiveScrollbars: true,//滚动条可以拖动
                    shrinkScrollbars: 'scale',// 当滚动边界之外的滚动条是由少量的收缩。'clip' or 'scale'.
                    click: true,// 允许点击事件
                    keyBindings: false,//允许使用按键控制
                    momentum: true,// 允许有惯性滑动
                    tap: true
                }, this.options));
                events.forEach(event => {
                    this.iscroll.on(event, () => this.$emit(event, this.iscroll))
                });
                this._registPullEvents();
            })
        }
    }
</script>
<style scoped>
    .bottom-load {
        transition: 0.4s all ease-in-out;
    }

    .bottom-load, .index .bottom-load {
        background: rgba(247, 247, 247, 0) !important;
    }

    .bottom-load .icon {
        position: relative;
        top: 3px;
        left: -2px;
    }

    .bottom-load.Loading .icon {
        top: 5px;
        left: -4px;
    }

    .bottom-load {
        height: .96rem;
        line-height: .96rem;
        text-align: center;
        background: rgba(247, 247, 247, 0) !important;
        font-size: .28rem;
        color: #666;
    }
</style>
