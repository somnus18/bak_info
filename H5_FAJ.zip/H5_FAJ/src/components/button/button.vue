<template>
    <div :class="handleClass" @click="clickEvent">{{text}}</div>
</template>
<script>
    export default{
        props: {
            canClick: {
                type: Boolean,
                default: true
            },
            text: {
                type: String,
                default: '提交'
            }
        },
        data() {
            return {};
        },
        computed: {
            handleClass() {
                let className = 'btn';
                if (!this.canClick) {
                    className = 'btn-disabled';
                }
                return className;
            }
        },
        methods: {
            clickEvent() {
                if (this.canClick) {
                    this.$emit('click-button');
                }
            }
        },
        components: {}
    };
</script>
