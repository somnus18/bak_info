<template>
    <div class="input-tel-content">
        <span class="input-name">{{textName}}</span>
        <div class="input-able" v-if="!disabled">
            <input
                :placeholder="placeholder[0]"
                :maxlength="maxlength[0]"
                @input="updateValue($event.target.value, 0)"
                @change="changeValue($event.target.value, 0)"
                @blur="blurHandler($event.target, 0)"
                :type="type[0]"
                class="input-text input-area-code"
                :value="value ? value.split('-')[0] : '' || defaultValue"
                ref="input0"
            />
            <div class="input-icon area-code" @click="clear(0)">
                <span v-if="value && (value.split('-')[0] || value.split('-')[0] === 0) || defaultValue"></span>
            </div>
            <span style="padding-right: .1rem;">-</span>
            <input
                :placeholder="placeholder[1]"
                :maxlength="maxlength[1]"
                @input="updateValue($event.target.value, 1)"
                @change="changeValue($event.target.value, 1)"
                @blur="blurHandler($event.target, 1)"
                :type="type[1]"
                class="input-text"
                :value="value ? value.split('-')[1] : ''"
                ref="input1"
            />
            <div class="input-icon" @click="clear(1)">
                <span v-if="value && (value.split('-')[1] || value.split('-')[1] === 0)"></span>
            </div>
        </div>
        <div class="input-text-content" v-else>
            <span>{{value}}</span>
            <slot></slot>
        </div>
    </div>
</template>
<script type="text/ecmascript-6">
    export default {
        name: 'input-tel',
        props: {
            value: {
                default: ''
            },
            textName: {
                type: String,
                default: '单位电话'
            },
            disabled: {
                type: Boolean,
                default: false
            },
            placeholder: {
                type: Array,
                default: function () {
                    return ['区号', '电话号码'];
                }
            },
            maxlength: {
                type: Array,
                default: function () {
                    return [4, 8];
                }
            },
            type: {
                type: Array,
                default: function () {
                    return ['tel', 'tel'];
                }
            }
        },
        data() {
            return {
                defaultValue: ''
            };
        },
        mounted() {
            this.$nextTick(()=> {
                !this.value && this.md5();
                this.cityCode = (C.Utils.data(C.DK.HOUSE_CITY) || '').split('/')[0];
            });
        },
        methods: {
            updateValue(value, type) {
                value = this.inputValue(value, type);
                this.$emit('input', $.trim(value), $.trim(this.value));
            },
            changeValue(value, type) {
                value = this.inputValue(value, type);
                this.$emit('change', $.trim(value));
            },
            blurHandler() {
                this.$emit('blur-value', $.trim(this.value));
            },
            clear(type) {
                // 这里不能直接this.value='',Input事件会监听之前输入的内容,需要手动调用input事件清空value值
                let value = this.getValue(type);
                this.defaultValue = '';
                this.$emit('input', value === '-' ? '' : value);
                setTimeout(()=> {
                    this.$emit('blur-value');
                }, 500);
            },
            getValue(type) {
                return this.value ? ((!~~type ? '-' : '') + this.value.split('-')[ type ^ 1 ] + (~~type ? '-' : '')) : '';
            },
            inputValue(value, type) {
                if (~~type === 0) {
                    value = value + '-' + this.$refs.input1.value;
                } else {
                    value = this.$refs.input0.value + '-' + value;
                }
                return value;
            },
            md5() {
                $.ajax({
                    url: C.Api('MD5', 'json'),
                    type: 'get',
                    success: (res)=> {
                        C.UI.stopLoading();
                        if ((C.Utils.data(C.DK.MD5) || {}).cMd5 !== res.cMd5 || !C.Utils.data(C.Constant.DK.CHINA_JSON_DEV)) {
                            C.Utils.data(C.DK.MD5, res);
                            this.getCityJsonDev();
                        } else {
                            let data = C.Utils.data(C.Constant.DK.CHINA_JSON_DEV) || {tel: []};
                            // 房产所在地城市的区号 todo
                            this.defaultValue = data.tel[this.cityCode];
                        }
                    }
                });
            },
            getCityJsonDev() {
                $.ajax({
                    url: C.Api('GET_CHINA_JSON_DEV', 'json'),
                    type: 'get',
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            let data = res.data;
                            C.Utils.data(C.Constant.DK.CHINA_JSON_DEV, data);
                            // 房产所在地城市的区号 todo
                            this.defaultValue = data.tel[this.cityCode];
                        }
                    }
                });
            }
        }
    };
</script>
<style scoped lang="scss">

    .input-tel-content {
        min-height: 0.98rem;
        border-bottom: 1px solid #ddd;
        position: relative;
        display: -webkit-box;
        display: flex;
        -webkit-box-align: center;
        align-items: center;
        width: 100%;
        padding-left: 0.3rem !important;
        background: white;
        .input-able, .input-text-content{
            flex: 1;
            display: -webkit-flex;
            display: flex;
            align-items: center;
            justify-content: flex-end;
        }

        .input-name {
            -webkit-box-flex: 1;
            flex: 1;
            padding-top: 0.04rem;
            width: 3rem;
            font-size: 0.32rem;
            line-height: 0.4rem;
            color: #666;
        }

        .input-text {
            width: 1.5rem;
            display: -webkit-box;
            -webkit-box-flex: 1;
            flex: 1;
            text-align: right;
            -webkit-box-pack: end;
            justify-content: flex-end;
            padding-top: 1px;
            font-size: 0.3rem;
            line-height: 0.4rem;
            height: 0.98rem;
            border-radius: 0;
            &.input-area-code {
                 -webkit-box-flex: .5;
                 flex: .5;
             }
            &.area-code {
                -webkit-box-flex: .3;
                flex: .3;
            }

        }
        .input-icon {
            display: inline-block;
            display: -webkit-flex;
            -webkit-box-align: center;
            align-items: center;
            width: 0.72rem;
            height: 100%;

            span {
                width: 0.4rem;
                height: 0.4rem;
                margin-left: .1rem;
                margin-right: .3rem;
                line-height: .3rem;
                padding: .16rem;
                background: url('icon_del@3x.png') center center/100% auto no-repeat;
                -webkit-background-size: 7px auto;
                background-size: 7px auto;
            }

            &.area-code {
                width: 0.65rem;
                span {
                    margin-right: 0;
                }
            }
        }
        .input-text-content {
            -webkit-box-flex: 1;
            flex: 1;
            display: -webkit-box;
            display: flex;
            padding: 0.16rem 0.4rem 0.12rem 0;
            line-height: 0.4rem;
            -webkit-box-align: center;
            align-items: center;
            -webkit-box-pack: end;
            justify-content: flex-end;
            span {
                color: #333;
            }
        }
    }
</style>
