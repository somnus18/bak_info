<template>
    <div :class="[inputClassHandler,noBorder?'':'bd',topBorder?'tb':'']" :style="{'min-height': height + 'rem'}">
        <slot name="name-icon"></slot>
        <span class="input-name" :class="isflex1?'flex1':''" v-if="textName">{{textName}}</span>
        <slot name="name-front"></slot>
        <input
            v-if="!disabled && type!='select'"
            :placeholder="placeholder"
            :maxlength="maxlength"
            class="input-text js_input"
            :type="type"
            @focus="focusevent"
            @input="updateValue($event.target.value)"
            @change="changeValue($event.target.value)"
            @blur="blurHandler($event.target)"
            :value="value">
        <div
            v-if="!disabled && type=='select'"
            :placeholder="placeholder"
            class="input-text no-focus js_select"
            @click="select">
            <span :class="[!value?'unselect':'','select-value']">{{msg}}</span>
            <input style="display: none" type="text" :value="value">
        </div>
        <div class="input-icon">
            <span @click="clear" v-if="!nodel && type!='select' && !disabled && (value || value === 0)"></span>
            <span @click="select" v-if="type =='select'"></span>
        </div>

        <div class="input-text-content" v-if="disabled" :style="{'text-align':textAlign}">
            <span>{{value}}</span>
            <slot></slot>
        </div>
    </div>
</template>
<style lang="scss" scoped rel="stylesheet/scss">
    @import "../../assets/css/func";

    .no-focus {
        -webkit-user-select: none;
    }

    .unselect {
        color: #bcbbbc;
    }

    .input-disable, .input-normal, .input-select {
        position: relative;
        display: flex;
        display: -webkit-flex;
        display: -ms-flexbox;
        align-items: center;
        width: 100%;
        padding-left: p2r(15) !important;
        background: white;
        & .input-name {
            flex: 0.9;
            padding-top: p2r(2);
            width: p2r(150);
            font-size: p2r(16);
            line-height: p2r(20);
            color: #666;
        }
        & .input-text {
            //这里不设置width,会导致安卓部分机型的Input框宽度超出屏幕
            width: p2r(150);
            display: -webkit-flex;
            display: flex;
            flex: 1;
            text-align: right;
            justify-content: flex-end;
            padding-top: 1px;
            font-size: p2r(15);
            line-height: p2r(20);
            height: p2r(49);
            border-radius: 0;
        }
        & .input-text-content {
            flex: 1;
            display: -webkit-flex;
            display: flex;
            padding: p2r(8) p2r(20) p2r(6) 0;
            line-height: p2r(20);
            align-items: center;
            justify-content: flex-end;
        }
    }

    .input-normal, .input-select {
        & .input-icon {
            display: inline-block;
            display: -webkit-flex;
            align-items: center;
            width: p2r(36);
            height: 100%;
            span {
                right: 0;
                width: p2r(20);
                height: p2r(20);
                margin-left: .1rem;
                margin-right: .3rem;
                line-height: .3rem;
            }
        }
        & .input-text-content {
            span {
                height: p2r(30);
            }
        }
    }

    .input-disable {
        & .input-text-content {
            span {
                color: #333;
            }
        }
    }

    .bd {
        border-bottom: 1px solid #ddd;
    }

    .tb {
        border-top: 1px solid #ddd;
    }

    .orange {
        .select-value {
            font-size: .38rem;
            color: orangered;
        }
        .input-text-content {
            span {
                font-size: .38rem;
                color: orangered;
            }
        }
    }

    .input-select {
        .select-value {
            line-height: p2r(50);
            max-width: p2r(180);
            display: block;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            -webkit-text-overflow: ellipsis;
        }
        & .input-icon {
            span {
                padding: .16rem;
                background: url('icon_arrow_r@3x.png') center center/100% auto no-repeat;
                -webkit-background-size: 7px auto;
                background-size: 7px auto;
            }
        }

    }

    .input-normal {
        & .input-icon {
            span {
                padding: .16rem;
                background: url('icon_del@3x.png') center center/100% auto no-repeat;
                -webkit-background-size: 7px auto;
                background-size: 7px auto;
            }
        }
    }

    .js_div {
        display: inline-block;
        padding: 5px;
    }

    .js_img {
        margin-left: -1.3rem;
    }

    .flex1 {
        flex: 1 !important;
    }
</style>
<script>
    export default{
        name: 'e-input',
        props: {
            value: {
                default: ''
            },
            textName: {
                type: String,
                default: ''
            },
            type: {
                type: String,
                default: 'text'
            },
            disabled: {
                type: Boolean,
                default: false
            },
            placeholder: {
                type: String,
                default: '请选择'
            },
            rule: {
                type: String,
                default: ''
            },
            classLeft: {
                type: Boolean,
                default: false
            },
            hasState: {
                type: Boolean,
                default: false
            },
            maxlength: {
                type: [String, Number],
                default: '50'
            },
            noBorder: {
                type: Boolean,
                default: false
            },
            nodel: {
                type: Boolean,
                default: false
            },
            setHeight: {
                type: Boolean,
                default: false
            },
            topBorder: {
                type: Boolean,
                default: false
            },
            isflex1: {
                type: Boolean,
                default: false
            },
            right: {
                type: Boolean,
                default: false
            }
        },
        data() {
            return {};
        },
        computed: {
            height() {
                return this.setHeight ? '0.7' : this.noBorder ? '0.7' : '0.98';
            },
            msg() {
                if (this.value) {
                    return this.value;
                } else {
                    return this.placeholder;
                }
            },
            show() {
                return !this.disabled;
            },
            inputClassHandler() {
                let disabled = this.disabled, type = this.type;
                if (disabled) {
                    return 'input-disable';
                } else {
                    if (type === 'select') {
                        return 'input-select';
                    } else {
                        return 'input-normal';
                    }
                }
            },
            textAlign() {
                return this.right ? 'right' : 'left';
            }

        },
        mounted() {
        },
        components: {},
        methods: {
            focusevent() {
                this.$emit('focusE');
            },
            updateValue(value) {
                this.$emit('input', $.trim(value), $.trim(this.value));
            },
            changeValue(value) {
                this.$emit('change', $.trim(value));
            },
            blurHandler() {
                this.$emit('blur-value', $.trim(this.value));
            },
            select() {
                // 这里调用IOS选取方法,再调用input事件传值
                this.$emit('select-input');
            },
            clear() {
                // 这里不能直接this.value='',Input事件会监听之前输入的内容,需要手动调用input事件清空value值
                this.$emit('input', '');
                setTimeout(()=> {
                    this.$emit('blur-value');
                }, 500);
            }
        }
    };
</script>
