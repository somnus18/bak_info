<template>
    <div class="input-upper-content" :style="{height: value ||  value == '0' ? '1.3rem':''}">
        <div class="content">
            <span class="input-name">{{textName}}</span>
            <div class="input-able" v-if="!disabled">
                <input
                    :placeholder="placeholder"
                    :maxlength="maxlength"
                    @input="updateValue($event.target.value)"
                    @change="changeValue($event.target.value)"
                    @blur="blurHandler($event.target)"
                    :type="type"
                    class="input-text"
                    :value="value"
                />
                <div class="input-icon" @click="clear()">
                    <span v-if="value || value === 0"></span>
                </div>
            </div>
            <div class="input-text-content" v-else>
                <span>{{value}}</span>
            </div>
        </div>
        <span class="upper-money">{{value && (unit === 'Y' ? value : toY(value, 6)) | numUpper}}</span>
    </div>
</template>
<script type="text/ecmascript-6">
    export default {
        name: 'input-upper',
        props: {
            value: {
                default: ''
            },
            textName: {
                type: String,
                default: '金额'
            },
            disabled: {
                type: Boolean,
                default: false
            },
            placeholder: {
                type: String,
                default: '请填写'
            },
            maxlength: {
                type: [String, Number],
                default: '13'
            },
            type: {
                type: String,
                default: 'text'
            },
            unit: { // 金额单位
                default: 'Y' // Y: 元, W: 万元
            }
        },
        filters: {
            numUpper(val) {
                return C.Utils.parseUpperNumberMoney(val);
            }
        },
        data() {
            return {};
        },
        methods: {
            updateValue(value) {
                this.$emit('input', $.trim(value), $.trim(this.value));
            },
            changeValue(value) {
                this.$emit('change', $.trim(value));
            },
            blurHandler() {
                this.$emit('blur-value', $.trim(this.value));
            },
            clear() {
                // 这里不能直接this.value='',Input事件会监听之前输入的内容,需要手动调用input事件清空value值
                this.$emit('input', '');
                setTimeout(()=> {
                    this.$emit('blur-value');
                }, 500);
            },
            toY(val, pre) {
                return C.Utils.toY(val, pre);
            }
        }
    };
</script>
<style scoped lang="scss">

    .input-upper-content {
        position: relative;
        background: #fff;
        border-bottom: 1px solid #ddd;
        .content{
            position: relative;
            min-height: 0.98rem;
            display: -webkit-box;
            display: flex;
            -webkit-box-align: center;
            align-items: center;
            width: 100%;
            padding-left: 0.3rem !important;
            background: white;
        }
        .input-able, .input-text-content{
            flex: 1;
            display: -webkit-flex;
            display: flex;
            align-items: center;
            justify-content: flex-end;
        }

        .input-name {
            -webkit-box-flex: 1;
            flex: 1;
            padding-top: 0.04rem;
            width: 3rem;
            font-size: 0.32rem;
            line-height: 0.4rem;
            color: #666;
        }

        .input-text {
            width: 1.5rem;
            display: -webkit-box;
            -webkit-box-flex: 1;
            flex: 1;
            text-align: right;
            -webkit-box-pack: end;
            justify-content: flex-end;
            padding-top: 1px;
            font-size: 0.3rem;
            line-height: 0.4rem;
            height: 0.98rem;
            border-radius: 0;
        }
        .input-icon {
            display: inline-block;
            display: -webkit-flex;
            -webkit-box-align: center;
            align-items: center;
            width: 0.72rem;
            height: 100%;

            span {
                width: 0.4rem;
                height: 0.4rem;
                margin-left: .1rem;
                margin-right: .3rem;
                line-height: .3rem;
                padding: .16rem;
                background: url('icon_del@3x.png') center center/100% auto no-repeat;
                -webkit-background-size: 7px auto;
                background-size: 7px auto;
            }
        }
        .input-text-content {
            -webkit-box-flex: 1;
            flex: 1;
            display: -webkit-box;
            display: flex;
            padding: 0.16rem 0.4rem 0.12rem 0;
            line-height: 0.4rem;
            -webkit-box-align: center;
            align-items: center;
            -webkit-box-pack: end;
            justify-content: flex-end;
            span {
                color: #333;
            }
        }
        .upper-money{
            position: absolute;
            right: .3rem;
            bottom: .15rem;
            font-size: .25rem;
            color: #999;
            text-align: right;
        }
    }
</style>
