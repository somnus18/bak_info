<template>
    <section class=partner-guarantor-detail>
        <div class=title>身份信息</div>
        <m-input :noBorder=true v-model=C34[info.globalType] :textName="'证件类型'" :disabled=true></m-input>
        <m-input :noBorder=true v-model=C2[info.country] :textName="'国家和地区'" :disabled=true></m-input>
        <m-input :noBorder=true v-model=info.clientName :textName="'姓名'" :disabled=true></m-input>
        <m-input :noBorder=true v-model=info.globalId :textName="'证件号码'" :disabled=true></m-input>
        <m-input :noBorder=true v-model=A9[info.sex] :textName="'性别'" :disabled=true></m-input>
        <m-input :noBorder=true v-model=info.birthDate :textName="'出生日期'" :disabled=true></m-input>
        <!-- 与借款人关系为配偶或其他时,不需要下边框 -->
        <m-input :noBorder="info.mainBorrowerRelation == C15_10 || C15_2 == info.mainBorrowerRelation" v-model=C15[info.mainBorrowerRelation] :textName="'与主借款人关系'" :disabled=true></m-input>
        <!-- 与借款人关系为其他时,显示且设置height的 -->
        <m-input class="input-name-flex-9" :setHeight="info.mainBorrowerRelation == C15_10" v-model=info.mainBorrowerRelationOther v-show="info.mainBorrowerRelation == C15_10" :textName="'与主借款人关系-其他'" :disabled=true></m-input>
        <!-- 与借款人关系为配偶时, 设置height的-->
        <m-input v-model=C5[info.maritalStatus] :setHeight="info.mainBorrowerRelation == C15_2" :disabled="isToView || C15_2 === info.mainBorrowerRelation" :textName="'婚姻状况'" @select-input="pickerEvent('maritalStatus', '婚姻状况', 'C5')" :placeholder="'请选择'" :type="'select'"></m-input>
        <m-input v-model=C3[info.education] :disabled="isToView" :textName="'教育程度'" @select-input="pickerEvent('education', '教育程度', 'C3')" :placeholder="'请选择'" :type="'select'"></m-input>
        <m-input v-model=info.censusAddress :disabled="isToView" :textName="'户籍地'" :placeholder="'请填写'" :type="'text'" :maxlength="42"></m-input>
        <m-input v-model=A7[info.localSocialFlag] :disabled="isToView" :textName="'有无当地社保'" @select-input="pickerEvent('localSocialFlag', '有无当地社保', 'A7')" :placeholder="'请选择'" :type="'select'"></m-input>
        <m-input v-model=info.localYear :disabled="isToView" :textName="'本地居住年限(年)'" :placeholder="'不满1年计1年'" :type="'tel'" :maxlength="3"></m-input>
        <div class=title>家庭信息</div>
        <div class="input-tip-content input-name-flex-8">
            <m-input class="m-input" v-model=info.familyHouseNum :disabled="isToView" :textName="'家庭拥有住房套数'" :placeholder="'请填写'" :type="'tel'" :maxlength="3"></m-input>
            <span class="tip"><i></i>夫妻双方及未成年子女名下拥有产权的住房套数总和</span>
        </div>
        <m-input v-model=A7[info.localHouseFlag] :disabled="isToView || isLocalHouseShow" :textName="'有无本地房产'" @select-input="pickerEvent('localHouseFlag', '有无本地房产', 'A7')" :placeholder="'请选择'" :type="'select'"></m-input>
        <m-input v-model=homeSpecificAddress :disabled="isToView" :textName="'居住城市'" @select-input="pickerAreaEvent('home')" :placeholder=homeSpecificAddressDefault :type="'select'"></m-input>
        <m-input v-model=info.homeAddress :disabled="isToView" :textName="'详细地址'" :placeholder="'请填写'" :type="'text'" :maxlength="85"></m-input>
        <m-upper v-model=info.familyMonthCashOut :disabled="isToView" :textName="'家庭月支出(元)'" :placeholder="'请填写'" :type="'text'" :maxlength="13"></m-upper>
        <div class=title>工作信息</div>
        <m-input v-model=info.companyName :disabled="isToView" :textName="'单位名称'" :placeholder="'请填写'" :type="'text'" :maxlength="42"></m-input>
        <m-input v-model=info.deptName :disabled="isToView" :textName="'部门'" :placeholder="'请填写'" :type="'text'" :maxlength="42"></m-input>
        <m-input class="input-name-flex-8" v-model=info.clientJobyears :disabled="isToView" :textName="'现单位工作年限(年)'" :placeholder="'请填写'" :type="'tel'" :maxlength="3"></m-input>
        <m-input v-model=companySpecificAddress :disabled="isToView" @select-input="pickerAreaEvent('company')" :textName="'工作单位城市'" :placeholder=companySpecificAddressDefault :type="'select'"></m-input>
        <m-input v-model=info.companyAddress :disabled="isToView" :textName="'详细地址'" :placeholder="'请填写'" :type="'text'" :maxlength="85"></m-input>
        <m-upper v-model=info.monthIncome :disabled="isToView" :textName="'税后月收入(元)'" :placeholder="'可提供材料所有收入'" :type="'text'" :maxlength="13"></m-upper>
        <m-upper class="input-name-flex-10" v-if=isPartnerDetail v-model=info.socProPaybase :disabled="isToView" :textName="'社保/公积金缴费基数(元)'" :placeholder="'根据社保/公积金显示'" :type="'text'" :maxlength="13"></m-upper>
        <div class=title>联系方式</div>
        <m-tel v-model=info.companyTelephone :disabled="isToView"></m-tel>
        <div class="input-tip-content">
            <m-input class="m-input" v-model=info.mobile :disabled="isToView" :textName="'手机号码'" :placeholder="'请填写'" :type="'tel'" :maxlength="11"></m-input>
            <span class="tip"><i></i>请填写本人实名认证的手机号，以便在线征信授权</span>
        </div>
        <footer class=footer-bottom v-show="isShowBtn">
            <div class=btn @click=save>{{btnName || '保存'}}</div>
        </footer>

        <m-picker :slots='slots' :isPicker='isPicker' :indexText='indexText'
                  :datakey='dataKey' :valueKey="'v'"
                  @confirm='pickerConfirm' @cancel='pickerCancel'>
        </m-picker>
        <m-area-picker :isPicker='isAreaPicker' :datakey='areaDataKey'
                       @confirm='areaPickerConfirm' @cancel="areaPickerCancel">
        </m-area-picker>
    </section>
</template>
<script type=text/ecmascript-6>
    import mPicker from 'src/components/picker/index';
    import mAreaPicker from 'src/components/picker/area-picker.vue';
    import mInput from 'src/components/cell/cell';
    import mTel from 'src/components/cell/tel';
    import mUpper from 'src/components/cell/upper';

    export default {
        name: 'common-personal-detail',
        props: {
            info: {
                type: Object
            },
            isToView: {
                type: Boolean,
                default: false
            },
            btnName: {
                type: String
            },
            isShowBtn: {
                type: Boolean,
                default: true
            }
        },
        data() {
            return {
                isPicker: false, // 普通选择器显示或隐藏
                isAreaPicker: false, // 地区选择器显示或隐藏
                indexText: '选择器', // 选择器名称
                dataKey: '', // 选择器结果赋值到对象的key值
                dateDataKey: '',
                areaDataKey: '',
                slots: [],
                C34: C.Constant['34'],
                C2: C.Constant['2'],
                A9: C.Constant['A9'],
                C15: C.Constant['15'],
                C5: C.Constant['5'],
                C3: C.Constant['3'],
                A7: C.Constant['A7'],
                C4: C.Constant['4'],
                C15_2: C.Constant['15_2'],
                C15_10: C.Constant['15_10'],
                isLocalHouseShow: false,
                // 是否为共同借款人详情
                isPartnerDetail: true
            };
        },
        created() {
            this.slots = [{values: []}];
        },
        mounted() {
            this.isPartnerDetail = /^\/(apply|checkApply)\/partner/.test(this.$route.fullPath);
        },
        computed: {
            homeSpecificAddress() {
                return this.info.homeCounty ? this.homeSpecificAddressDefault : '';
            },
            homeSpecificAddressDefault() {
                return C.Utils.getAreaName(this.info.homeProvince) + C.Utils.getAreaName(this.info.homeCity) + C.Utils.getAreaName(this.info.homeCounty);
            },
            companySpecificAddress() {
                return this.info.companyCounty ? this.companySpecificAddressDefault : '';
            },
            companySpecificAddressDefault() {
                return C.Utils.getAreaName(this.info.companyProvince) + C.Utils.getAreaName(this.info.companyCity) + C.Utils.getAreaName(this.info.companyCounty);
            }
        },
        watch: {
            'info.mainBorrowerRelation': function () {
                this.info.maritalStatus = this.C15_2 === this.info.mainBorrowerRelation ? C.Constant['5_1'] : this.info.maritalStatus;
            },
            'info.familyHouseNum': function (value) {
                if (value === '0' || value === 0) {
                    this.isLocalHouseShow = true;
                    this.$parent.info.localHouseFlag = C.Constant.A7_0;
                } else {
                    this.isLocalHouseShow = false;
                }
            }
        },
        methods: {
            pickerEvent(key, text, slot) {
                this.dataKey = key;
                this.indexText = text;
                this.slots = [{values: C.Utils.objToArr(this[slot])}];
                this.selectHide();
                this.isPicker = true;
            },
            pickerAreaEvent(key) {
                this.areaDataKey = key;
                this.selectHide();
                this.isAreaPicker = true;
            },
            selectHide() {
                this.isPicker = false;
                this.isAreaPicker = false;
            },
            pickerConfirm(value, key) {
                this.$parent.info[key] = value.k;
                this.isPicker = false;
            },
            pickerCancel() {
                this.isPicker = false;
            },
            areaPickerCancel() {
                this.isAreaPicker = false;
            },
            areaPickerConfirm(value, key) {
                let code = value.k.split('-'),
                    name = value.v.split('-');
                this.info[key + 'Province'] = code[0] + '/' + name[0];
                this.info[key + 'City'] = code[1] + '/' + name[1];
                this.info[key + 'County'] = code[2] + '/' + name[2];
                this.isAreaPicker = false;
            },
            validator() {
                let msg = '',
                    info = this.info,
                    companyTelephoneResult = C.Validator.tel(info.companyTelephone),
                    mobileResult = C.Validator.MobileNo(info.mobile);

                if (info.localYear && !C.Utils.isInteger(info.localYear)) {
                    msg = '本地居住年限请输入整数';
                } else if (info.localYear && !C.Utils.checkAmountRange(info.localYear, 3)()) {
                    msg = '本地居住年限' + C.HT['3_1'];
                } else if (info.familyHouseNum && !C.Utils.isInteger(info.familyHouseNum)) {
                    msg = '家庭拥有住房套数请输入整数';
                } else if (info.familyHouseNum && !C.Utils.checkAmountRange(info.familyHouseNum, 4)()) {
                    msg = '家庭拥有住房套数' + C.HT['4'];
                } else if (info.familyMonthCashOut && !C.Utils.amountFormat(info.familyMonthCashOut)) {
                    msg = '家庭月支出(元)格式不对';
                } else if (info.familyMonthCashOut && !C.Utils.checkAmountRange(info.familyMonthCashOut)()) {
                    msg = '家庭月支出(元)' + C.HT['1'];
                } else if (info.clientJobyears && !C.Utils.isInteger(info.clientJobyears)) {
                    msg = '现单位工作年限请输入整数';
                } else if (info.clientJobyears && !C.Utils.checkAmountRange(info.clientJobyears, 3)()) {
                    msg = '现单位工作年限' + C.HT['3_1'];
                } else if (info.monthIncome && !C.Utils.amountFormat(info.monthIncome)) {
                    msg = '税后月收入(元)格式不对';
                } else if (!this.isPartnerDetail && !C.Utils.isEmpty(info.monthIncome) && this.info.monthIncome <= 0) {
                    msg = '税后月收入(元)需大于0';
                } else if (!C.Utils.isEmpty(info.monthIncome) && !C.Utils.checkAmountRange(this.info.monthIncome, null, 'gEToEL')()) {
                    msg = '税后月收入(元)' + C.HT['1'];
                } else if (info.socProPaybase && !C.Utils.amountFormat(info.socProPaybase)) {
                    msg = '社保/公积金缴费基数(元)格式不对';
                } else if (info.socProPaybase && !C.Utils.checkAmountRange(info.socProPaybase)()) {
                    msg = '社保/公积金缴费基数(元)' + C.HT['1'];
                } else if (info.companyTelephone && !companyTelephoneResult.result) {
                    msg = '单位电话格式不对'; // companyTelephoneResult.error;
                } else if (info.mobile && !mobileResult.result) {
                    msg = mobileResult.error;
                }
                return msg;
            },
            validatorAction() {
                let flag = true, validator = this.validator();
                if (validator) {
                    C.Native.tip(validator);
                    flag = false;
                }
                return flag;
            },
            save() {
                let validator = this.validator();
                if (validator) {
                    C.Native.tip(validator);
                    return;
                }
                if (!this.isPartnerDetail) {
                    delete this.info.socProPaybase;
                }
                this.$emit('save', this.info);
            }
        },
        components: {
            mPicker,
            mInput,
            mAreaPicker,
            mTel,
            mUpper
        }
    };
</script>
<style scoped lang=scss>
    .partner-guarantor-detail{
        .title{
            height: 0.5rem;
            line-height: 0.5rem;
            font-size: .26rem;
            background: #e9e9e9;
            color: #999;
            padding-left: .3rem;
        }
        .m-input{
            border: none !important;
        }
        .footer-bottom{
            padding: .2rem 0;
            margin-top: .15rem;
            text-align: center;
            background: #fff;
            border-top: 1px solid #e9e9e9;
            .btn {
                height: .84rem;
                line-height: .84rem;
                margin: 0 auto;
                border-radius: .42rem;
            }
        }
        .input-tip-content{
            position: relative;
            height: 1.3rem;
            background: #fff;
            border-bottom: 1px solid #ddd;
            .tip{
                position: absolute;
                left: .3rem;
                bottom: .13rem;
                font-size: .24rem;
                color: #999;
                i{
                    display: inline-block;
                    width: .15rem;
                    height: .15rem;
                    background: url(../../assets/images/m/icons/icon_-@2x.png) no-repeat;
                    background-size: 100%;
                    margin-right: .1rem;
                }
            }
        }
        .m-input{
            border-bottom: none !important;
        }
    }
</style>
