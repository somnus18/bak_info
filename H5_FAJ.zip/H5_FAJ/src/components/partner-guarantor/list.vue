<template>
    <section class="partner-guarantor-list">
        <div class="list">
            <header @click="goDetail">
                <span class="title fl">{{item.clientName}}</span><span class="fr icon_arrow"></span>
            </header>
            <ul>
                <li>
                    <span class="title fl">性别</span><span class="fr">{{A9[item.sex]}}</span>
                </li>
                <li>
                    <span class="title fl">与借款人关系</span><span class="fr">{{C15[item.mainBorrowerRelation]}}</span>
                </li>
                <li>
                    <span class="title fl">证件类型</span><span class="fr">{{C34[item.globalType]}}</span>
                </li>
                <li>
                    <span class="title">证件号码</span><span class="fr text">{{item.globalId}}</span>
                </li>
            </ul>
        </div>
    </section>
</template>
<script type="text/ecmascript-6">
    export default {
        name: 'common-personal-list',
        props: ['item'],
        data() {
            return {
                // 性别
                A9: C.Constant.A9,
                // 与借款人关系
                C15: C.Constant['15'],
                // 证件类型
                C34: C.Constant['34']
            };
        },
        created() {
        },
        mounted() {
        },
        computed: {},
        methods: {
            goDetail() {
                this.$emit('goDetail');
            }
        }
    };
</script>
<style scoped lang="scss">
    .partner-guarantor-list{
        background: #fff;
        margin-top: .1rem;
        border-top: 1px solid #ccc;;
        border-bottom: 1px solid #ccc;
        header{
            height: 1.15rem;
            line-height: 1.15rem;
            padding: 0 .3rem;
            border-bottom: 1px solid #ccc;
            .title{
                display: inline-block;
                color: #333;
                font-size: .36rem;
                max-width: 85%;
                text-overflow: ellipsis;
                overflow: hidden;
                white-space: nowrap;
            }
            .icon_arrow{
                width: 0.4rem;
                height: 0.4rem;
                line-height: .3rem;
                margin: 0.375rem 0;
                background: url(../../assets/images/app/icons/icon_arrow_r@3x.png) right center no-repeat;
                background-size: auto .27rem;
            }
        }
        ul{
            background: #f8f8f8;
            padding: .2rem .3rem;
            clear:both;
            li{
                width: 100%;
                height: .8rem;
                line-height: .8rem;
                font-size: .32rem;
                clear:both;
                .title{
                    color: #666;
                }
                .fr{
                    color: #333;
                }
                .text{
                    display: inline-block;
                    max-width: 75%;
                    text-overflow: ellipsis;
                    overflow: hidden;
                    white-space: nowrap;
                }
            }
        }

    }
</style>
