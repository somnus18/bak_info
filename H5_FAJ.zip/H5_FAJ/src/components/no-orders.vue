<template>
    <div class="no-orders">
        <span>{{msg}}</span>
    </div>
</template>
<script type="text/ecmascript-6">
    export default {
        name: 'no-order',
        props: {
            msg: {
                type: String,
                default: '您暂时还没有订单!'
            }
        },
        data() {
            return {};
        },
        created() {
        },
        mounted() {
        },
        computed: {},
        methods: {
            render() {
            }
        }
    };
</script>
<style scoped lang="scss">
    .no-orders {
        position: absolute;
        left: 0;
        right: 0;
        top: 30%;
        text-align: center;
        span{
            color: #999;
            font-size: .32rem;
            display: inline-block;
            margin: 0 auto;
            text-align: center;
        }
    }
</style>
