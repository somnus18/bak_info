<template>
    <div :class="[sta?'':'d','button']" @click="clickEvent">{{msg}}</div>
</template>
<style lang="scss" rel="stylesheet/scss">
    .button {
        display: inline-block;
        width: 1.5rem;
        border-radius: 5px;
        font-size: .26rem;
        color: #26a2ff;
        cursor: pointer;
        background: white;
        border: 1px solid #26a2ff;
        text-align: center;
    }

    .d {
        background: #26a2ff;
        color: white;
    }
</style>
<script>
    export default{
        name: 'xg-button',
        props: {
            buttonText: {
                type: String,
                default: '发送短信'
            },
            time: {
                type: Number,
                default: 60
            },
            status: {
                type: Boolean,
                default: true
            },
            toClick: {
                flag: false
            }
        },
        data() {
            return {
                sta: true,
                msg: true,
                timeout: ''
            };
        },
        created() {
            this.msg = this.buttonText;
        },
        watch: {
            toClick: {
                handler(curval) {
                    if (curval.flag) {
                        this.clickEvent();
                    }
                },
                deep: true
            }
        },
        methods: {
            clickEvent() {
                let time = this.time;
                if (this.sta === true) {
                    if (time > 0) {
                        this.sta = false;
                        this.$emit('click-button');
                        this.countDown(time);
                    }
                }
            },
            countDown(time) {
                --time;
                if (time > 0) {
                    this.msg = `重发(${time})S`;
                    this.timeout = setTimeout(()=> {
                        this.countDown(time);
                    }, 1000);
                } else {
                    this.msg = '重发短信';
                    this.toClick.flag = false;
                    this.sta = true;
                }
            }
        },
        components: {},
        destroyed() {
            // 清除定时器
            clearTimeout(this.timeout);
        }
    };
</script>
