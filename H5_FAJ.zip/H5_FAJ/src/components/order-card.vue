<template>
    <div class="apply-module">
        <div class="order-card" @click="flag&&goDetail()" :class="['order-content',moveClass?'moved':'']"
             @touchstart="handleTouchStart($event,canMove)"
             @touchmove="handleTouchMove($event,canMove)"
             @touchend="handleTouchEnd($event,canMove)">
            <div class="card-main">
                <div class="card-top">
                    <span class="kb-num">{{item.barcode}}</span>
                    <span class="fr">{{arrToObj2()[item.loanVariety]}}</span>
                </div>
                <div class="card-btm">
                    <div class="text-row clear">
                        <span class="fl c3">{{item.clientName}}</span>
                        <span class="fr" :class="[colorStatus,{'mid-state':!showBankStatus}]">{{arrToObj()[item.orderStatus]}}</span>
                    </div>
                    <div class="text-row clear">
                        <span class="fl">{{item.mobile || '-'}}</span>
                        <span class="fr" v-if="showBankStatus">{{A43[item.bankStatus]}}</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="order-copy" v-if="isCopy">
            <div @click="copy(item, $event)">复制<br>订单</div>
        </div>
        <div class="order-del">
            <div @click="del(item, $event)">取消<br>订单</div>
        </div>
    </div>
</template>
<script type="text/ecmascript-6">
    export default {
        data() {
            return {
                A43: C.Constant['43'],
                width: 1.3,
                startX: 0,
                startY: 0,
                space: 0,
                endY: 0,
                canScroll: true,
                isMoved: false,
                moveClass: false,
                type: '',
                flag: true
            };
        },
        computed: {
            colorStatus() {
                switch (this.item.orderStatus) {
                    // 已放款 颜色为#1f85e6
                    case C.Constant.A1_8:
                        return {blue: true};
                    // 取消订单、拒绝 颜色为#333
                    case C.Constant.A1_9:
                    case C.Constant.A1_10:
                        return {gary: true};
                    default :
                        return {orange: true};
                }
            }
        },
        watch: {
            isMoved(val, oldVal) {
                if (oldVal === true) {
                    setTimeout(()=> {
                        this.moveClass = val;
                    }, 200);
                } else {
                    this.moveClass = val;
                }
            }
        },
        created() {
        },
        props: ['item', 'index', 'canMove', 'showBankStatus', 'isCopy'],
        methods: {
            goDetail() {
                this.$emit('goDetail');
            },
            arrToObj() {
                return C.Constant.A1;
            },
            arrToObj2() {
                return C.Constant.A2;
            },
            // 删除操作
            del(item, e) {
                // 状态大于C.Constant.A1_1的订单不能取消
                if (item.orderStatus > C.Constant.A1_1) {
                    C.Native.tip('该订单无法取消');
                    return;
                }
                this.$emit('delete', item, e);
            },
            // 复制订单
            copy(item) {
                // 提交创建订单时,将orderId已sourceOrderId传递给后端(后端根据sourceOrderId是否有效,进行复制订单操作)。
                C.Native.forward({
                    url: 'index.html#create/index?orderId=' + item.orderId
                });
            },
            handleTouchStart(event, canMove) {
                this.flag = true;
                if (!canMove) return;
                this.timeStart = Date.now();
                this.setOrderCardCss($(event.target).parents('.apply-module').siblings().find('.order-card'));
                this.startX = event.touches[0].screenX;
                this.startY = event.touches[0].screenY;
                if (this.isMoved) {
                    this.space = 0;
                    event.stopPropagation();
                    event.preventDefault();
                }
            },
            handleTouchEnd(event, canMove) {
                if (!canMove) return;
                let endY = Math.abs(event.changedTouches[0].screenY - this.startY);
                this.canScroll = true;
                this.space = this.space + event.changedTouches[0].screenX - this.startX;
                if (this.isMoved) {
                    $('.order-content').css('left', 0);
                }
                this.isMoved = false;
                /**
                 * touch触发和结束时间小于100ms时,去详情页面
                 */
                C.debug.log('touch触发和结束时间', Date.now() - this.timeStart, 'endY: ' + endY);
                if (Date.now() - this.timeStart < 100 && !C.Utils.App.IS_IOS) {
                    this.goDetail();
                    return;
                }

                if (this.space >= 0 || endY > 100) {
                    this.space = 0;
                } else if (this.space < 0 && this.space >= -this.width / 2) {
                    this.space = 0;
                } else {
                    this.isMoved = true;
                    this.space = -this.width;
                }
                this.setOrderCardCss($(event.target).closest('.order-card'), this.space);
            },
            handleTouchMove(event, canMove) {
                if (!canMove) return;
                this.flag = false;
                let lengthX = Math.abs(event.touches[0].screenX - this.startX),
                    lengthY = Math.abs(event.touches[0].screenY - this.startY),
                    move = this.space + (event.touches[0].screenX - this.startX);
                if (this.canScroll && (lengthX >= lengthY) && (lengthX >= 10)) {
                    this.canScroll = false;
                }
                if (!this.canScroll) {
                    event.stopPropagation();
                    event.preventDefault();
                    if (move >= 0) {
                        move = 0;
                    }
                    $(event.target).closest('.order-content').css('left', +move + 'px');
                }
            },
            setOrderCardCss($ele, space) {
                $ele.css({
                    paddingRight: space ? 0 : '.2rem',
                    left: (space || 0) * (this.isCopy ? 2 : 1) + 'rem'
                }).find('.card-main').css({
                    borderRadius: space ? 0 : '5px'
                });
            }
        }
    };
</script>
<style scoped lang="scss">
    .order-card {
        padding:.2rem .2rem 0;
        color: #666;
        background: #f0f0f0;
        line-height: 1;
        .card-main{
            padding:0 .2rem;
            background: #fff;
            border-radius: 5px;
        }
        .c3 {
            width: 80%;
            display: inline-block;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            color: #333;
            padding: .02rem 0;
        }
    }

    .card-top {
        padding: .2rem 0 .15rem;
        line-height: .4rem;
        border-bottom: solid 1px #f0f0f0;
    }

    .card-btm {
        padding: .18rem 0 .24rem;
        .mid-state{
            position: relative;
            top: .36rem;
            font-size: .32rem;
        }
        .orange{
            color: #fdaf2e;
        }
        .gary{
            color: #333;
        }
        .blue{
            color: #1f85e6;
        }
    }

    .text-row {
        padding: .18rem 0;
        clear: both;
    }

    .apply-module {
        overflow: hidden;
        position: relative;
        .order-content {
            position: relative;
            height: 100%;
            z-index: 999;
        }
        .order-del, .order-copy {
            position: absolute;
            top: 0;
            bottom: 0;
            width: 1.3rem;
            padding-top: .2rem;
            div {
                display:table-cell;
                vertical-align:middle;
                width: 1.3rem;
                height: 2.54rem;
                font-size: .3rem;
                text-align: center;
                color: #fff;
                background: #ccc;
            }
        }
        .order-del{
            right: 0;
            div {
                color: #fff;
                background: #ccc;
            }
        }
        .order-copy{
            right: 1.3rem;
            div {
                color: #fff;
                background: #f15b23;
            }
        }
    }
    .moved {
        transition: all .3s;
    }
    .hide{
        display: none;
    }


</style>
