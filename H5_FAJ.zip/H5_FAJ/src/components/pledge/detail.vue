<template>
    <section class=partner-pledge-detail>
        <m-input v-model="address" :textName="'房产所在地'" disabled noBorder></m-input>
        <m-input v-model=info.houseInfo.houseAddress :textName="'详细地址'" disabled noBorder></m-input>
        <m-input v-model=A6[info.houseInfo.warrantType] :textName="'权证类型'" disabled noBorder></m-input>
        <m-input v-model=info.houseInfo.warrantCode :textName="'权证编号'" disabled setHeight></m-input>
        <m-input v-model=info.houseInfo.houseArea :disabled="isToView" :textName="'建筑面积(m²)'"
                 :placeholder="'请填写'" :type="'text'"></m-input>
        <m-input v-model=info.houseInfo.landParcelCode :textName="'宗地号'" :placeholder="'请与产证保持一致'"
                 :type="'text'" :disabled="isToView" :maxlength="42"></m-input>
        <m-input v-model=info.houseInfo.storeySumNum :textName="'总楼层数量'" :placeholder="'请填写'" :type="'tel'"
                 :disabled="isToView" :maxlength="3"></m-input>
        <m-input v-model=info.houseInfo.houseIndoorArea :disabled="isToView" :textName="'房屋套内面积(m²)'"
                 :placeholder="'请填写'" :type="'text'"></m-input>
        <div class="input-tip-content input-name-flex-8">
            <m-input class="setHeight" v-model="info.houseInfo.buildingName" :textName="'楼宇名称'" type="text"
                     :disabled="isToView" :placeholder="'请输入'" :maxlength="42"
            ></m-input>
            <p class="tip"><i></i>小区名称或地址,请以房产证为准</p>
        </div>
        <m-input v-model=C16[info.houseInfo.houseKinds] :type="'select'" :textName="'房屋类别'"
                 @select-input='pickerEvent("houseInfo.houseKinds","类别","16_all")' :disabled="isToView"></m-input>
        <!--<m-input v-model=C17[info.houseInfo.estateType] :textName="'房产类型'"-->
        <!--@select-input='pickerEvent("houseInfo.estateType","房产类型","17")'-->
        <!--:placeholder="'请选择'" :type="'select'" :disabled="isToView || info.loanVariety == '2'"></m-input>-->

        <div class="input-tip-content input-name-flex-8">
            <m-input v-model=C18[info.houseInfo.houseUse] :class="[houseUse?'setHeight':'']" :textName="'房屋用途'"
                     @select-input='pickerEvent("houseInfo.houseUse","房屋用途","18")'
                     :placeholder="'请选择'" :type="'select'" :disabled="isToView">
            </m-input>
            <span v-show="houseUse" class="tip"><i></i>需提供租房合同</span>
        </div>
        <m-input v-model=info.houseInfo.finishDate :textName="'竣工时间'"
                 @select-input='selectDate({houseInfo:"finishDate"},"竣工时间")'
                 :placeholder="'请选择'" :type="'select'" :disabled="isToView"></m-input>
        <m-input v-model=info.houseInfo.soilUseDeadlineStardDate :disabled="isToView" :textName="'土地使用期限_起始日'"
                 @select-input='selectDate({houseInfo:"soilUseDeadlineStardDate"},"土地使用期限_起始日")'
                 :placeholder="'请选择'" :type="'select'"></m-input>
        <m-input v-model=info.houseInfo.soilUseDeadlineEndDate :textName="'土地使用期限_到期日'"
                 @select-input='selectDate({houseInfo:"soilUseDeadlineEndDate"},"土地使用期限_到期日")'
                 :placeholder="'请选择'" :type="'select'" :disabled="isToView"></m-input>
        <!--这里的值通过计算获得,不可修改-->
        <m-input v-model=info.houseInfo.soilUseDeadline :disabled="isToView" :textName="'土地使用期限(年)'"></m-input>
        <m-upper v-model=info.houseInfo.bargainPrice :disabled="isToView" :textName="'成交价(万元)'" :placeholder="'请填写'"
                 :type="'text'" :maxlength="13" :unit="'W'"></m-upper>
        <m-upper v-model=info.houseInfo.registeredPrice :disabled="isToView" :textName="'登记价(万元)'" :placeholder="'请填写'"
                 :type="'text'" :maxlength="13" :unit="'W'"></m-upper>
        <m-upper v-if="isNative && showEvaluation" v-model="info.houseInfo.evaluationAmount" :textName="'单套评估价值(万元)'"
                 unit="'W'"
                 :placeholder="'请填写'" :type="'text'" maxlength="13" :disabled="isToView"></m-upper>
        <div v-for="(item,index) in info.ownerList" :key="index">
            <div class=title>权利人{{index+1}}
                <!--<span class="remove" v-if='!isOwnerFixed && index >= 1'-->
                <!--@click='removeItem(index)'></span>-->
            </div>
            <m-input v-model=C34[item.warrantOwnGlobalType] :textName="'证件类型'" disabled></m-input>
            <m-input v-model=item.warrantOwnName :textName="'权利人姓名'" disabled></m-input>
            <m-input v-model=item.warrantOwnGlobalId :textName="'证件号码'" disabled></m-input>
            <m-input v-model="item.warrantOwnShare" disabled :textName="'权利人份额'"><span>%</span></m-input>
        </div>
        <m-credit :showCredit=showCredit :creditList="creditList" :selectedList="selectedList" @credit-sure=creditSure
                  @credit-cancel=creditCancel></m-credit>
        <div class="cell-btn" @click="addWarrantOwner" v-if="!isOwnerFixed && !isToView">
            <span><i></i> 编辑权利人</span>
        </div>
        <m-input v-model=ownerNum disabled :textName="'共有产权人数'" :placeholder="'请填写'" class="mt10"></m-input>
        <!--<footer class=footer-bottom v-show="isShowBtn">-->
        <!--<div class=btn @click=save>{{btnName || '保存'}}</div>-->
        <!--</footer>-->

        <m-picker :isPicker='isPicker' :indexText='indexText' :slots='slots' :datakey='datakey' valueKey='v'
                  @confirm='pickerConfirm' @cancel='pickerCancel'></m-picker>
        <m-date-picker :isPicker='isDatePicker' :datakey='dateDataKey' :defaultDate='defaultDate'
                       @confirm='datePickerConfirm' @cancel="datePickerCancel">
        </m-date-picker>
        <m-area-picker :isPicker='isAreaPicker' :datakey='areaDataKey'
                       @confirm='areaPickerConfirm' @cancel="areaPickerCancel">
        </m-area-picker>
    </section>
</template>
<script>
    import mPicker from 'src/components/picker/index';
    import mDatePicker from 'src/components/picker/date-picker.vue';
    import mAreaPicker from 'src/components/picker/area-picker.vue';
    import mInput from 'src/components/cell/cell';
    import mUpper from 'src/components/cell/upper';
    import mCredit from 'm/components/creditSelector/creditSelector.vue';
    import * as types from 'm/vuex/mutation-types';

    export default {
        name: 'common-pledge-detail',
        props: {
            info: {
                type: Object
            },
            isToView: {
                type: Boolean,
                default: true
            },
            btnName: {
                type: String
            },
            isShowBtn: {
                type: Boolean,
                default: true
            },
            isOwnerFixed: {
                type: Boolean,
                default: false
            }
        },
        data() {
            return {
                init: true,
                isPicker: false, // 普通选择器显示或隐藏
                isDatePicker: false, // 时间选择器显示或隐藏
                isAreaPicker: false, // 地区选择器显示或隐藏
                indexText: '选择器', // 选择器名称
                datakey: '', // 选择器结果赋值到对象的key值
                defaultDate: '', // 时间选择器默认值
                showCredit: false,
                dateDataKey: '',
                areaDataKey: '',
                slots: [],
                A6: C.Constant['A6'],
                C16: C.Constant['16_all'],
                C18: C.Constant['18'],
                C34: C.Constant['34'],
                creditList: [],
                selectedList: [],
                isLocalHouseShow: false
            };
        },
        // PLEDGE_DETAIL
        created() {
            this.slots = [{values: []}];
        },
        computed: {
            ownerNum() {
                return this.info.ownerList.length;
            },
            address() {
                let info = this.info.houseInfo;
                return C.Utils.getAreaName(info.houseProvince) + C.Utils.getAreaName(info.houseCity) + C.Utils.getAreaName(info.houseCounty);
            },
            houseUse() {
                return this.info.houseInfo.houseUse === '02';
            },
            isNative() {
                return C.Utils.App.IS_NATIVE;
            },
            // 一手楼不显示单套评估价值
            showEvaluation() {
                let loanVariety = this.info.loanVariety;
                return loanVariety !== '1' && loanVariety !== '5';
            }
        },
        watch: {
            'info.houseInfo.soilUseDeadlineStardDate'(val) {
                if (!this.init && this.info.houseInfo.soilUseDeadlineEndDate) {
                    this.info.houseInfo.soilUseDeadline = C.Utils.computeDate(val, this.info.houseInfo.soilUseDeadlineEndDate);
                }
            },
            'info.houseInfo.soilUseDeadlineEndDate'(val) {
                if (!this.init && this.info.houseInfo.soilUseDeadlineStardDate) {
                    this.info.houseInfo.soilUseDeadline = C.Utils.computeDate(this.info.houseInfo.soilUseDeadlineStardDate, val);
                }
            },
            'info.ownerList': {
                handler(cur) {
                    let length = cur.length, percent = 100 / length;
                    // 这里减法会有精度问题,所以暂时直接赋值33.34
                    cur.map((item, index)=> {
                        if (length === 3 && index === 2) {
                            item.warrantOwnShare = '33.34';
                        } else {
                            item.warrantOwnShare = percent.toFixed(2);
                        }
                    });
                },
                deep: true
            },
            showCredit(val) {
                this.$emit('watchCreditState', val);
            }
        },
        methods: {
            selectHide() {
                this.isPicker = false;
                this.isDatePicker = false;
                this.isAreaPicker = false;
            },
            pickerEvent(key, text, slot) {
                this.datakey = key;
                this.indexText = text;
                this.slots = [{values: C.Utils.objToArr(C.Constant[slot])}];
                this.isPicker = true;
                this.isDatePicker = false;
                this.isAreaPicker = false;
            },
            // 普通选择器 确认
            pickerConfirm(value, key) {
                let jsonKey, arr, num;
                if (key.indexOf('|') === -1) {
                    jsonKey = key.split('.');
                    this.info[jsonKey[0]][jsonKey[1]] = value.k;
                } else {
                    arr = key.split('|');
                    jsonKey = arr[0].split('.');
                    num = +arr[1];
                    this.info[jsonKey[0]][num][jsonKey[1]] = value.k;
                }
                this.isPicker = false;
            },
            pickerCancel() {
                this.isPicker = false;
            },
            // 日期选择器
            selectDate(key, text) {
                this.defaultDate = C.Utils.pickerDateObject(this.info, key);
                this.dateDataKey = key;
                this.dateIndexText = text;
                this.isPicker = false;
                this.isDatePicker = true;
                this.init = false;
                // this.isAreaPicker = false;
            },
            // 日期清除按钮
            datePickerCancel() {
                this.isDatePicker = false;
            },
            // 日期确定按钮
            datePickerConfirm(value, key) {
                this.isDatePicker = false;
                let objName = Object.keys(key)[0], objValue = key[objName];
                this.info[objName][objValue] = value.join('-');
            },
            areaPickerCancel() {
                this.isAreaPicker = false;
            },
            areaPickerConfirm(value, key) {
                let code = value.k.split('-'),
                    name = value.v.split('-');
                this.info[key + 'Province'] = code[0] + '/' + name[0];
                this.info[key + 'City'] = code[1] + '/' + name[1];
                this.info[key + 'County'] = code[2] + '/' + name[2];
                this.isAreaPicker = false;
            },
            clear(key) {
                this.info.houseInfo[key] = '';
            },
            inputFamilyHouseNum(value) {
                if (value === '0') {
                    this.isLocalHouseShow = true;
                    this.$parent.info.isLocalHouse = C.Constant.A7_0;
                } else {
                    this.isLocalHouseShow = false;
                }
            },
            validator() {
                let msg = '',
                    info = this.info;
                if (info.houseInfo.storeySumNum && !C.Utils.isInteger(info.houseInfo.storeySumNum)) {
                    msg = '楼层总数量必须为正整数';
                } else if (info.houseInfo.storeySumNum && !C.Utils.checkAmountRange(info.houseInfo.storeySumNum, 3)()) {
                    msg = '总楼层数量' + C.HT['3_2'];
                } else if (info.houseInfo.houseArea && !C.Utils.isNumber(info.houseInfo.houseArea)) {
                    msg = '建筑面积必须是正数';
                } else if (info.houseInfo.houseArea && !C.Utils.RegexMap.secondDecimal.test(info.houseInfo.houseArea)) {
                    msg = '建筑面积(m²)不能超过两位小数';
                } else if (info.houseInfo.houseKinds !== C.Constant['16_95'] && !isNaN(info.houseInfo.houseArea) && info.houseInfo.houseArea < 25) {
                    msg = '建筑面积不得小于25m²';
                } else if (info.houseInfo.houseArea && info.houseInfo.houseArea <= 0) {
                    msg = '建筑面积需大于0';
                } else if (info.houseInfo.houseArea && !C.Utils.checkAmountRange(info.houseInfo.houseArea, 2)()) {
                    msg = '建筑面积(m²)' + C.HT['2'];
                } else if (info.houseInfo.houseIndoorArea && !C.Utils.isNumber(info.houseInfo.houseIndoorArea)) {
                    msg = '房屋套内面积必须是数字';
                } else if (info.houseInfo.houseIndoorArea && !C.Utils.RegexMap.secondDecimal.test(info.houseInfo.houseIndoorArea)) {
                    msg = '房屋套内面积(m²)不能超过两位小数';
                } else if (info.houseInfo.houseIndoorArea && !C.Utils.checkAmountRange(info.houseInfo.houseIndoorArea, 2)()) {
                    msg = '房屋套内面积(m²)' + C.HT['2'];
                } else if (info.houseInfo.soilUseDeadlineStardDate > info.houseInfo.soilUseDeadlineEndDate) {
                    msg = '起始日不能晚于到期日';
                } else if (info.houseInfo.soilUseDeadline !== null && info.houseInfo.soilUseDeadline !== '' && info.houseInfo.soilUseDeadline < 1) {
                    msg = '土地使用期限需大于0';
                } else if (info.houseInfo.soilUseDeadline && !C.Utils.isInteger(info.houseInfo.soilUseDeadline)) {
                    msg = '土地使用期限只能是整数';
                } else if (info.houseInfo.bargainPrice && !C.Utils.isNumber(info.houseInfo.bargainPrice)) {
                    msg = '成交价必须是数字';
                } else if (info.houseInfo.bargainPrice && !C.Utils.RegexMap.sixDecimal.test(info.houseInfo.bargainPrice)) {
                    msg = '成交价不能超过6位小数';
                } else if (!C.Utils.isEmpty(info.houseInfo.bargainPrice) && info.houseInfo.bargainPrice <= 0) {
                    msg = '成交价需大于0';
                } else if (!C.Utils.isEmpty(info.houseInfo.bargainPrice) && !C.Utils.checkAmountRange(info.houseInfo.bargainPrice * 10000, 1, 'gEToL')()) {
                    msg = '成交价' + C.HT['1'];
                } else if (info.houseInfo.registeredPrice && !C.Utils.isNumber(info.houseInfo.registeredPrice)) {
                    msg = '登记价必须是数字';
                } else if (!C.Utils.isEmpty(info.houseInfo.registeredPrice) && !C.Utils.checkAmountRange(info.houseInfo.registeredPrice * 10000, 1, 'gEToLE')()) {
                    msg = '登记价格' + C.HT['1'];
                } else if (info.houseInfo.registeredPrice && !C.Utils.RegexMap.sixDecimal.test(info.houseInfo.registeredPrice)) {
                    msg = '登记价不能超过6位小数';
                } else if (this.isNative && info.houseInfo.evaluationAmount && !C.Utils.isNumber(info.houseInfo.evaluationAmount)) {
                    msg = '单套评估价值必须是数字';
                } else if (this.isNative && !C.Utils.isEmpty(info.houseInfo.evaluationAmount) && !C.Utils.checkAmountRange(info.houseInfo.evaluationAmount * 10000, 1, 'gEToLE')()) {
                    msg = '单套评估价值' + C.HT['1'];
                } else if (this.isNative && info.houseInfo.evaluationAmount && !C.Utils.RegexMap.sixDecimal.test(info.houseInfo.evaluationAmount)) {
                    msg = '单套评估价值不能超过6位小数';
                }
                return msg;
            },
//            removeItem(index) {
//                this.info.ownerList.splice(index, 1);
//            },
            creditSure(arr) {
                let ownerList = this.info.ownerList = [];
                arr.map((item)=> {
                    ownerList.push({
                        unionId: item.unionId,
                        collateralOwnerId: '',
                        warrantOwnName: item.warrantOwnName,
                        warrantOwnGlobalType: item.warrantOwnGlobalType,
                        warrantOwnGlobalId: item.warrantOwnGlobalId,
                        warrantOwnShare: ''
                    });
                });
            },
            creditCancel() {
                this.getSelectedList(this.creditList);
            },
            actSelector() {
                this.getDefaultOwners();
                this.showCredit = true;
            },
            getDefaultOwners() {
                let owners = this.info.defaultOwners;
                if (this.selectedList.length === 0) {
                    this.creditList.forEach((item, i)=> {
                        if (owners && owners.indexOf(item.unionId) !== -1) {
                            item.selected = true;
                            this.selectedList.push(i);
                        }
                    });
                }
            },
            getSelectedList(creditList) {
                this.selectedList = [];
                creditList.map((item, i)=> {
                    item.selected = false;
                    this.info.ownerList.map((obj)=> {
                        if (item.unionId === obj.unionId) {
                            item.selected = true;
                            this.selectedList.push(i);
                        }
                    });
                });
                this.getDefaultOwners();
            },
            addWarrantOwner() {
                if (this.creditList.length === 0) {
                    C.UI.loading();
                    $.ajax({
                        url: C.Api('SHOW_OWERS'),
                        data: {
                            collateralId: this.info.houseInfo.collateralId
                        },
                        success: (res)=> {
                            C.UI.stopLoading();
                            if (res.flag === C.Flag.SUCCESS) {
                                this.creditList = res.data;
                                this.getSelectedList(this.creditList);
                                this.actSelector();
                            }
                        }
                    });
                } else {
                    this.getSelectedList(this.creditList);
                    this.actSelector();
                }
            },
            validatorAction() {
                let validator = this.validator();
                if (validator) {
                    C.Native.tip(validator);
                    return false;
                }
                return true;
            },
            save() {
                let soilUseDeadline = this.info.houseInfo.soilUseDeadline;
                soilUseDeadline = soilUseDeadline === null ? null : parseInt(soilUseDeadline);
                this.info.houseInfo.ownerNum = this.info.ownerList.length;
                if (this.validatorAction()) {
                    if (soilUseDeadline !== null && (soilUseDeadline !== 40 && soilUseDeadline !== 70)) {
                        C.UI.warn({
                            title: '提示',
                            content: `土地使用期限为【${soilUseDeadline}】,请确认是否有误?`,
                            isShowClose: true,
                            okText: '确认',
                            ok: (store)=> {
                                store.commit(types.SET_DIALOG, {isShowDialog: false});
                                this.$emit('save', this.info);
                            }
                        });
                    } else {
                        this.$emit('save', this.info);
                    }
                }
            }
        },
        components: {
            mPicker,
            mInput,
            mDatePicker,
            mAreaPicker,
            mUpper,
            mCredit
        }
    };
</script>
<style scoped lang="scss" rel="stylesheet/scss">
    .setHeight {
        padding-bottom: .2rem;
    }

    .partner-pledge-detail {

        .cell-btn {
            margin-bottom: .2rem;
            color: #26a2ff;
            line-height: .68rem;
            text-align: center;
            background: #fafafa;
            i {
                position: relative;
                top: .08rem;
                display: inline-block;
                width: .4rem;
                height: .4rem;
                background: url(../../assets/images/m/icons/icon-edit@2x.png) no-repeat center;
                background-size: .36rem .36rem;
            }
        }

        .title {
            height: 0.6rem;
            line-height: 0.6rem;
            padding-left: 0.3rem;
            position: relative;
            .remove {
                position: absolute;
                top: 0.1rem;
                right: .3rem;
                display: inline-block;
                width: .4rem;
                height: .4rem;
                background: url(../../assets/images/m/icons/remove.png) no-repeat center;
                background-size: .4rem .4rem;
            }
        }

        .footer-bottom {
            padding: .2rem 0;
            margin-top: .15rem;
            text-align: center;
            background: #fff;

            .btn {
                position: relative;
                border-radius: 100px;
                height: 100%;
                color: white;
                margin: 0 auto;
            }

        }
    }

    .input-tip-content {
        position: relative;
        background: #fff;
        .m-input {
            border-bottom: none !important;
        }
        .tip {
            position: absolute;
            left: .3rem;
            bottom: .1rem;
            font-size: .25rem;
            color: #999;
            i {
                display: inline-block;
                width: .2rem;
                height: .2rem;
                background: url(../../assets/images/m/icons/icon_-@2x.png) no-repeat;
                background-size: 100%;
                margin-right: .1rem;
            }
        }
    }

</style>
