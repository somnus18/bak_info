<template>
    <section class="pladge-list">
        <div class="list">
            <header @click="goDetail(item.collateralId)">
                <span class="title fl"><span class="title-sm">权证编号:</span>{{item.warrantCode}}</span><span
                class="fr icon_arrow"></span><span class="fr per" :style="{'color':IS_NATIVE ? '#feae2f' : 'orangered'}">{{item.inputRate || 0}}%</span>
            </header>
            <ul>
                <m-cell class="pl-cell" v-model="A16[item.houseKinds]" :textName="'房屋类别'" disabled right
                        noBorder>
                </m-cell>
                <m-cell class="pl-cell" v-model="item.houseAddress" :textName="'详细地址'" disabled right
                        noBorder>
                </m-cell>
            </ul>
        </div>
    </section>
</template>
<script type="text/ecmascript-6">
    import mCell from 'components/cell/cell';
    export default {
        name: 'common-pledge-list',
        props: ['item'],
        data() {
            return {
                // 房屋类型
                A16: Object.assign({}, C.Constant['16'], C.Constant['16_95_object']),
                IS_NATIVE: C.Utils.App.IS_NATIVE,
                // 权证类型
                list: []
            };
        },
        created() {
        },
        mounted() {
        },
        computed: {},
        methods: {
            goDetail() {
                this.$emit('goDetail');
            }
        },
        components: {
            mCell
        }
    };
</script>
<style scoped lang="scss" rel="stylesheet/scss">
    .pladge-list {
        background: #fff;
        margin-top: .1rem;
        border-top: 1px solid #ccc;;
        border-bottom: 1px solid #ccc;
        header {
            line-height: 1.17rem;
            padding: 0 .3rem;
            border-bottom: 1px solid #ccc;
            overflow: hidden;
            .title {
                max-width: 80%;
                color: #333;
                font-size: .36rem;
                text-overflow: ellipsis;
                overflow: hidden;
                white-space: nowrap;
                .title-sm {
                    font-size: .32rem;
                    padding-right: 8px;
                }
            }
            .icon_arrow {
                width: 0.4rem;
                height: 0.4rem;
                line-height: .3rem;
                margin: 0.375rem 0;
                background: url(../../assets/images/app/icons/icon_arrow_r@3x.png) center center no-repeat;
                background-size: auto .27rem;
            }
        }
        ul {
            background: #f8f8f8;
            padding: .2rem 0;
            clear: both;
            .pl-cell {
                background: #f8f8f8;
                font-size: .32rem;
            }
        }
        .per {
            // color: orangered;
            font-size: .36rem;
        }
    }
</style>
