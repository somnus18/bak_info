<template>
    <section>
        <div class="title">
          <span>身份信息</span>
        </div>
        <div class="border-top">
            <m-input v-model="thirtyFour[info.globalType]" :textName="'证件类型'"  :disabled=true :noBorder=true></m-input>
            <m-input v-model="two[info.country]" :textName="'国家和地区'"  :disabled=true :noBorder=true></m-input>
            <m-input v-model="info.clientName" :textName="'姓名'"  :disabled=true :noBorder=true></m-input>
            <m-input v-model="info.globalId" :textName="'证件号码'"  :disabled=true :noBorder=true></m-input>
            <m-input v-model="A9[info.sex]" :textName="'性别'"  :disabled=true :noBorder=true></m-input>
            <m-input v-model="info.birthDate" :textName="'出生日期'"  :disabled=true></m-input>
        </div>

        <div class="title">
          <span>工作信息</span>
        </div>
        <div class="border-top">
            <m-input v-model="info.companyName" :textName="'单位名称'" :disabled="isToView" :type="'text'" :placeholder="'请填写'" maxlength='42'></m-input>
            <m-input v-model="censusAddress" :textName="'工作单位城市'" :disabled="isToView" :type="'select'" :placeholder="censusAddressDefalt" @select-input='workCityPicker'></m-input>
            <m-input v-model="info.companyAddress" :textName="'详细地址'" :disabled="isToView" :type="'text'" :placeholder="'请填写'" maxlength='85'></m-input>
            <m-upper v-model=info.monthIncome :disabled="isToView" :textName="'税后月收入(元)'" :placeholder="'可提供材料所有收入'" :type="'text'" :maxlength="13"></m-upper>
            <m-upper class="input-name-flex-10" v-model=info.socProPaybase :disabled="isToView" :textName="'社保/公积金缴费基数(元)'" :placeholder="'根据社保/公积金显示'" :type="'text'" :maxlength="13"></m-upper>
        </div>

        <div class="title">
          <span>联系方式</span>
        </div>
        <div class="border-top margin-b-5">
            <m-tel v-model=info.companyTelephone :disabled="isToView"></m-tel>
            <div class="lilv">
                <m-input class='setHeight' v-model="info.mobile" :textName="'手机号码'" :disabled="isToView"  :type="'tel'" :placeholder="'请填写'" :maxlength="'11'">
                </m-input>
                <span class="tip"><font class="red-color"></font> 请填写本人实名认证的手机号，以便在线征信授权</span>
            </div>
        </div>

        <div class="bt-bottom" v-show='isShowBtn'>
            <button class="btn" @click="clickEvent">{{btnName || '确认'}}</button>
        </div>

        <m-area-picker :isPicker='isAreaPicker' :datakey='areaDataKey'
        @confirm='areaPickerConfirm' @cancel="areaPickerCancel">
        </m-area-picker>
    </section>
</template>
<script>
import mInput from 'components/cell/cell';
import mAreaPicker from 'src/components/picker/area-picker.vue';
import mButton from 'components/button/button';
import mTel from 'src/components/cell/tel';
import mUpper from 'src/components/cell/upper';
export default {
    name: 'masterBorrower',
    data() {
        return {
            isAreaPicker: false,
            areaDataKey: '',
            A7: C.Constant.A7,
            A8: C.Constant.A8,
            A9: C.Constant.A9,
            two: C.Constant['2'],
            three: C.Constant['3'],
            four: C.Constant['4'],
            six: C.Constant['6'],
            seven: C.Constant['7'],
            eight: C.Constant['8'],
            nine: C.Constant['9'],
            ten: C.Constant['10'],
            eleven: C.Constant['11'],
            twelve: C.Constant['12'],
            fourteen: C.Constant['14'],
            thirtyFour: C.Constant['34']
        };
    },
    props: {
        info: {
            type: Object
        },
        isToView: {
            type: Boolean,
            default: false
        },
        btnName: {
            type: String
        },
        isShowBtn: {
            type: Boolean,
            default: true
        }
    },
    components: {
        mInput,
        mAreaPicker,
        mButton,
        mTel,
        mUpper
    },
    computed: {
        censusAddress() {
            return this.info.companyCounty ? this.censusAddressDefalt : '';
        },
        censusAddressDefalt() {
            return C.Utils.getAreaName(this.info.companyProvince) + C.Utils.getAreaName(this.info.companyCity) + C.Utils.getAreaName(this.info.companyCounty);
        },
        workCity() {
            return C.Utils.getAreaName(this.info.companyProvince) + C.Utils.getAreaName(this.info.companyCity) + C.Utils.getAreaName(this.info.companyCounty);
        }
    },
    methods: {
        workCityPicker() {
            this.areaDataKey = 'company';
            this.isAreaPicker = true;
        },
        areaPickerConfirm(value, key) {
          // {k: "110000-110100-000046", v: "北京市-北京市-北京技术开发区"}
            this.info[key + 'Province'] = value.k.split('-')[0] + '/' + value.v.split('-')[0];
            this.info[key + 'City'] = value.k.split('-')[1] + '/' + value.v.split('-')[1];
            this.info[key + 'County'] = value.k.split('-')[2] + '/' + value.v.split('-')[2];
            this.isAreaPicker = false;
        },
        areaPickerCancel() {
            this.isAreaPicker = false;
        },
        validatorAction() {
            let msg = '';
            if (this.info.monthIncome && !C.Utils.amountFormat(this.info.monthIncome)) {
                msg = '税后月收入(元)格式不对';
            } else if (!C.Utils.isEmpty(this.info.monthIncome) && !C.Utils.checkAmountRange(this.info.monthIncome, null, 'gEToEL')()) {
                msg = '税后月收入(元)' + C.HT['1'];
            } else if (this.info.socProPaybase && !C.Utils.amountFormat(this.info.socProPaybase)) {
                msg = '社保/公积金缴费基数(元)格式不对';
            } else if (this.info.socProPaybase && !C.Utils.checkAmountRange(this.info.socProPaybase)()) {
                msg = '社保/公积金缴费基数(元)' + C.HT['1'];
            } else if (!C.Utils.isEmpty(this.info.companyTelephone) && !(C.Validator.tel(this.info.companyTelephone).result)) {
                msg = '单位电话格式不对';
            } else if (this.info.mobile && !(C.Validator.MobileNo(this.info.mobile).result)) {
                msg = '手机号码格式不对';
            }
            return msg;
        },
        clickEvent() {
            let msg = this.validatorAction();
            if (msg) {
                C.Native.tip(msg);
                return;
            }
            this.$emit('save', this.info);
        }
    }
};
</script>
<style lang="scss" scoped>
.title{
    position: relative;
    span{
        color: #999;
        display:inline-block;
        font-size: .26rem;
        height:.5rem;
        line-height:.58rem;
        padding-left: .3rem;
    }
}
.red-color{
    position:relative;
    top: -1px;
    background:url('./../../assets/images/m/icons/icon_-@2x.png') no-repeat;
    display:inline-block;
    width: 7px;
    height:7px;
    background-size: 7px 7px;
}
.bt-bottom {
    padding:.3rem 0;
    width: 100%;
    line-height: .8rem;
    text-align: center;
    background:#fff;
    border-top: 1px solid #ddd;
}
.border-top{
    border-top: 1px solid #ddd;
}
.setHeight {
    padding-bottom: .4rem;
}
.lilv {
    position: relative;
    .tip{
        position: absolute;
        left: .3rem;
        bottom: .2rem;
        font-size: .2rem;
        color: #999;
    }
    .tip.right{
        right: .74rem;
        left: auto;
        bottom: .06rem;
    }
}
.margin-b-5{
    margin-bottom: .5rem;
}
</style>
