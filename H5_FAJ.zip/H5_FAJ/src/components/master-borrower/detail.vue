<template>
	<section>
        <div class="title">
          <span>身份信息</span>
        </div>
        <div class="border-top">
            <m-input v-model="thirtyFour[info.globalType]" :textName="'证件类型'"  disabled noBorder></m-input>
            <m-input v-model="two[info.country]" :textName="'国家和地区'"  disabled noBorder></m-input>
            <m-input v-model="info.clientName" :textName="'姓名'"  disabled noBorder></m-input>
            <m-input v-model="info.globalId" :textName="'证件号码'"  disabled noBorder></m-input>
            <m-input v-model="A9[info.sex]" :textName="'性别'"  disabled noBorder></m-input>
            <m-input v-model="info.birthDate" :textName="'出生日期'"  disabled noBorder></m-input>
            <m-input v-model="info.finDirExpiryDate" :textName="'证件到期日'"  disabled noBorder></m-input>
            <m-input v-model="info.certificateOrg" :textName="'发证机关所在地'"  disabled noBorder></m-input>
            <m-input v-model="five[info.maritalStatus]" :textName="'婚姻状况'"  disabled setHeight></m-input>

            <m-input v-model="A7[info.mimorChildFlag]" :disabled="isToView" @select-input='pickerEvent("mimorChildFlag", "请选择", "A7")' :textName="'有无未成年子女'" :type="'select'" :placeholder="'请选择'"></m-input>
            <m-input v-model="three[info.education]" :disabled="isToView" @select-input='pickerEvent("education", "请选择", "3")' :textName="'教育程度'" :type="'select'" :placeholder="'请选择'"></m-input>
            <m-input v-model="A8[info.localCensusFlag]" :disabled="isToView" @select-input='pickerEvent("localCensusFlag", "请选择", "A8")' :textName="'是否本地户籍'" :type="'select'" :placeholder="'请选择'"></m-input>
            <m-input v-model="four[info.residenceRegisteredType]" :disabled="isToView" @select-input='pickerEvent("residenceRegisteredType", "请选择", "4")' :textName="'户别'" :type="'select'" :placeholder="'请选择'"></m-input>
            <m-input v-model="A7[info.localSocialFlag]" :disabled="isToView" @select-input='pickerEvent("localSocialFlag", "请选择", "A7")' :textName="'有无当地社保'" :type="'select'" :placeholder="'请选择'"></m-input>
            <m-input v-model="info.socialPayYear" :textName="'社保缴纳年限(月)'" :disabled="isToView" :type="'tel'" :placeholder="'请填写'" maxlength='4'></m-input>
        </div>

        <div class="title">
          <span>家庭信息</span>
        </div>
        <div class="border-top">
            <div class="lilv">
                <m-input class='setHeight-2 input-name-flex-8' v-model="info.familyHouseNum" :textName="'家庭拥有住房套数'" :disabled="isToView" :type="'tel'" :placeholder="'请填写'"></m-input>
                <span class="tip tip-1"><font class="red-color"></font> 夫妻双方及未成年子女名下拥有产权的住房套数总和</span>
            </div>
            <m-input v-model="A7[info.localHouseFlag]" :disabled="isToView || localHouseFlagDisabled" @select-input='pickerEvent("localHouseFlag", "请选择", "A7")' :textName="'有无本地房产'" :type="'select'" :placeholder="'请选择'"></m-input>
            <m-input v-model="info.localYear" :textName="'本地居住年限(年)'" :disabled="isToView" :type="'tel'" :placeholder="'不满1年计1年'"></m-input>
            <m-input v-model="six[info.residentType]" :disabled="isToView" @select-input='pickerEvent("residentType", "请选择", "6")' :textName="'居住状况'" :type="'select'" :placeholder="'请选择'"></m-input>
            <m-input v-model="censusAddress" :textName="'居住城市'" :type="'select'" :placeholder="censusAddressDefalt" :disabled="isToView" @select-input='liveCityePicker'></m-input>
            <m-input v-model="info.homeAddress" :textName="'详细地址'" :disabled="isToView" :type="'text'" :placeholder="'请填写'" maxlength='85'></m-input>
            <m-upper v-model=info.familyMonthCashOut :disabled="isToView" :textName="'家庭月支出(元)'" :placeholder="'请填写'" :type="'text'" :maxlength="13"></m-upper>
        </div>

		<div class="title">
          <span>工作信息</span>
        </div>
        <div class="border-top">
            <m-input v-model="eleven[info.employmentType]" :disabled="isToView" @select-input='pickerEvent("employmentType", "请选择", "11")' :textName="'雇佣类型'" :type="'select'" :placeholder="'请选择'"></m-input>
            <m-input v-model="info.companyName" :textName="'单位名称'" :disabled="isToView" :type="'text'" :placeholder="'请填写'" maxlength='42'></m-input>
            <m-input v-model="seven[info.unitTypeCode]" :disabled="isToView" @select-input='pickerEvent("unitTypeCode", "请选择", "7")' :textName="'单位性质'" :type="'select'" :placeholder="'请选择'"></m-input>
            <m-input v-model="info.deptName" :textName="'部门'" :disabled="isToView" :type="'text'" :placeholder="'请填写'" maxlength='42'></m-input>
            <m-input v-model="info.clientJobyears" class='input-name-flex-8' :textName="'现单位工作年限(年)'" :disabled="isToView" :type="'tel'" :placeholder="'请填写'"></m-input>
            <m-input class='input-name-flex-8' v-model="eight[info.unitKind]" :disabled="isToView" @select-input='pickerEvent("unitKind", "请选择", "8")' :textName="'工作单位所属行业'" :type="'select'" :placeholder="'请选择'"></m-input>
            <m-input v-model="nine[info.positionType]" :disabled="isToView" @select-input='pickerEvent("positionType", "请选择", "9")' :textName="'职业名称'" :type="'select'" :placeholder="'请选择'"></m-input>
            <m-input v-model="info.dutyName" :textName="'职务名称'" :disabled="isToView" :type="'text'" :placeholder="'请填写'" maxlength='42'></m-input>
            <m-input v-model="ten[info.dutyLevel]" :disabled="isToView" @select-input='pickerEvent("dutyLevel", "请选择", "10")' :textName="'职务类型'" :type="'select'" :placeholder="'请选择'"></m-input>
            <m-input v-model="twelve[info.specialQualifacationType]" :disabled="isToView" @select-input='pickerEvent("specialQualifacationType", "请选择", "12")' :textName="'特殊资格类型'" :type="'select'" :placeholder="'请选择'"></m-input>
            <m-upper v-model=info.monthIncome :disabled="isToView" :textName="'税后月收入(元)'" :placeholder="'可提供材料所有收入'" :type="'text'" :maxlength="13"></m-upper>
            <m-upper class="input-name-flex-10" v-model=info.socProPaybase :disabled="isToView" :textName="'社保/公积金缴费基数(元)'" :placeholder="'根据社保/公积金显示'" :type="'text'" :maxlength="13"></m-upper>
            <m-input v-model="censusAddressWork" :textName="'工作单位城市'" :type="'select'" :placeholder="censusAddressDefaltWork" :disabled="isToView" @select-input='workCityPicker'></m-input>
            <m-input v-model="info.companyAddress" :textName="'详细地址'" :disabled="isToView" :type="'text'" :placeholder="'请填写'" maxlength='85'></m-input>
        </div>

        <div class="title">
          <span>联系方式</span>
        </div>
        <div class="border-top">
            <div class="lilv">
                <m-input class='setHeight' v-model="info.mobile" :textName="'手机号码'" :disabled="isToView" :type="'tel'" :placeholder="'请填写'" :maxlength="'11'"></m-input>
                <span class="tip"><font class="red-color"></font> 请填写本人实名认证的手机号，以便在线征信授权</span>
            </div>
            <m-tel v-model=info.companyTelephone :disabled="isToView"></m-tel>
        </div>

        <div class="title">
          <span>还款账户</span>
        </div>
        <div class="border-top">
            <m-input v-model="twentySeven[info.paymentType]" :textName="'支付方式'"  :disabled=true noBorder setHeight></m-input>
            <m-input v-model="info.repaymentAccountBank" :textName="'还款账户开户行'"  :disabled=true noBorder setHeight></m-input>
            <m-input v-model="info.repaymentAccountName" :textName="'还款账户户名'"  :disabled=true setHeight></m-input>
            <m-input v-model="info.repaymentAccountCardNo" :textName="'还款卡号'" :disabled="isToView" :type="'tel'" :placeholder="'若购买履约险则为必填'" maxlength='32'></m-input>
        </div>

        <div class="title">
          <span>其他信息</span>
        </div>
        <div class="border-top margin-b-5">
            <m-input class='input-name-flex-8' v-model="A8[info.sellerCollectMoney]" :disabled="isToView" @select-input='pickerEvent("sellerCollectMoney", "请选择", "A8")' :textName="'是否卖方本人收款'" :type="'select'" :placeholder="'请选择'"></m-input>
            <m-input v-model="thirteen[info.firstMailType]" :textName="'邮寄首选'" :type="'select'" :placeholder="'请选择'" :disabled="isToView" @select-input='pickerEvent("firstMailType", "请选择", "13")'></m-input>
            <m-input v-model="fourteen[info.firstPhoneType]" :disabled="isToView" @select-input='pickerEvent("firstPhoneType", "请选择", "14")' :textName="'联系首选'" :type="'select'" :placeholder="'请选择'"></m-input>
            <m-input v-model="A7[info.insureFlag]" class='input-name-flex-10 input-text-8' :disabled="isToView" @select-input='pickerEvent("insureFlag", "请选择", "A7")' :textName="'在平安投保险2年以上'" :type="'select'" :placeholder="'请选择'"></m-input>
            <m-input v-model="A8[info.ownBranchPayrollWageFlag]" :disabled="isToView" @select-input='pickerEvent("ownBranchPayrollWageFlag", "请选择", "A8")' :textName="'代发工资户'" :type="'select'" :placeholder="'请选择'"></m-input>
        </div>

        <div class="bt-bottom" v-show="isShowBtn">
            <button class="btn" @click="clickEvent">{{btnName || '确认'}}</button>
        </div>

        <m-picker :slots='slots' :isPicker='isPicker' :indexText='indexText'
	    :datakey='datakey' :valueKey='valueKey'
	    @confirm='pickerConfirm' @cancel='pickerCancel'>
	    </m-picker>
	    <m-area-picker :isPicker='isAreaPicker' :datakey='areaDataKey'
	    @confirm='areaPickerConfirm' @cancel="areaPickerCancel">
	    </m-area-picker>
	</section>
</template>
<script>
import mInput from 'components/cell/cell';
import mPicker from 'src/components/picker/index';
import mAreaPicker from 'src/components/picker/area-picker.vue';
import mButton from 'components/button/button';
import mTel from 'src/components/cell/tel';
import mUpper from 'src/components/cell/upper';
export default {
	name: 'masterBorrower',
	data() {
	    return {
	    	isPicker: false,
	    	indexText: '',
	    	valueKey: 'v',
	    	datakey: '',
	    	isAreaPicker: false,
	    	areaDataKey: '',
            localHouseFlagDisabled: false,
	    	slots: [],
        	A7: C.Constant.A7,
        	A8: C.Constant.A8,
        	A9: C.Constant.A9,
            two: C.Constant['2'],
        	three: C.Constant['3'],
        	four: C.Constant['4'],
            five: C.Constant['5'],
        	six: C.Constant['6'],
        	seven: C.Constant['7'],
        	eight: C.Constant['8'],
        	nine: C.Constant['9'],
        	ten: C.Constant['10'],
        	eleven: C.Constant['11'],
        	twelve: C.Constant['12'],
            thirteen: C.Constant['13'],
        	fourteen: C.Constant['14'],
            thirtyFour: C.Constant['34'],
            twentySeven: C.Constant['27']
	    };
	},
    props: {
        info: {
            type: Object
        },
        isToView: {
            type: Boolean,
            default: false
        },
        btnName: {
            type: String
        },
        isShowBtn: {
            type: Boolean,
            default: true
        }
    },
    created() {
    	this.slots = [{values: []}];
    },
	components: {
		mInput,
		mPicker,
		mAreaPicker,
		mButton,
        mTel,
        mUpper
	},
    computed: {
        censusAddress() {
            return this.info.homeCounty ? this.censusAddressDefalt : '';
        },
        censusAddressDefalt() {
            return C.Utils.getAreaName(this.info.homeProvince) + C.Utils.getAreaName(this.info.homeCity) + C.Utils.getAreaName(this.info.homeCounty);
        },
        censusAddressWork() {
            return this.info.companyCounty ? this.censusAddressDefaltWork : '';
        },
        censusAddressDefaltWork() {
            return C.Utils.getAreaName(this.info.companyProvince) + C.Utils.getAreaName(this.info.companyCity) + C.Utils.getAreaName(this.info.companyCounty);
        }
    },
    watch: {
        'info.sellerCollectMoney': function (val) {
            this.info.sellerCollectMoney = val ? this.info.sellerCollectMoney : C.Constant['A8_1'];
        },
        'info.firstMailType': function (val) {
            this.info.firstMailType = val ? this.info.firstMailType : C.Constant['13_10'];
        },
        'info.firstPhoneType': function (val) {
            this.info.firstPhoneType = val ? this.info.firstPhoneType : C.Constant['14_10'];
        },
        'info.insureFlag': function (val) {
            this.info.insureFlag = val ? this.info.insureFlag : C.Constant['A7_0'];
        },
        'info.ownBranchPayrollWageFlag': function (val) {
            this.info.ownBranchPayrollWageFlag = val ? this.info.ownBranchPayrollWageFlag : C.Constant['A8_0'];
        },
        'info.mimorChildFlag': function (val) {
            this.info.mimorChildFlag = val ? this.info.mimorChildFlag : C.Constant['A7_0'];
        },
        'info.localCensusFlag': function (val) {
            this.info.localCensusFlag = val ? this.info.localCensusFlag : C.Constant['A8_1'];
        },
        'info.residenceRegisteredType': function (val) {
            this.info.residenceRegisteredType = val ? this.info.residenceRegisteredType : C.Constant['4_1'];
        },
        'info.localSocialFlag': function (val) {
            this.info.localSocialFlag = val ? this.info.localSocialFlag : C.Constant['A7_1'];
        },
        'info.localHouseFlag': function (val) {
            this.info.localHouseFlag = val ? this.info.localHouseFlag : C.Constant['A7_0'];
        },
        'info.residentType': function (val) {
            this.info.residentType = val ? this.info.residentType : C.Constant['6_2'];
        },
        'info.employmentType': function (val) {
            this.info.employmentType = val ? this.info.employmentType : C.Constant['11_2'];
        },
        'info.specialQualifacationType': function (val) {
            this.info.specialQualifacationType = val ? this.info.specialQualifacationType : C.Constant['12_1'];
        },
        'info.familyHouseNum'(val) {
            this.info.familyHouseNum = !C.Utils.isEmpty(this.info.familyHouseNum) ? val : '';
            if (this.info.familyHouseNum.length && this.info.familyHouseNum * 1 === 0) {
                this.info.localHouseFlag = C.Constant['A7_0'];
                this.localHouseFlagDisabled = true;
            } else {
                this.localHouseFlagDisabled = false;
            }
        }
    },
	methods: {
        pickerEvent(key, text, slot) {
            this.datakey = key;
            this.indexText = text;
        	this.slots = [{values: C.Utils.objToArr(C.Constant[slot])}];
          	this.isPicker = true;
        },
        pickerConfirm(value, key) {
          	// {k: 01, v: '"按揭一手楼"'} dateTime
            this.info[key] = this.valueKey ? value.k : value;
          	this.isPicker = false;
        },
        pickerCancel() {
          	this.isPicker = false;
        },
        liveCityePicker() { // 现居住城市
            this.areaDataKey = 'home';
            this.isAreaPicker = true;
        },
        workCityPicker() { // 工作城市
        	this.areaDataKey = 'company';
        	this.isAreaPicker = true;
        },
        areaPickerConfirm(value, key) {
          // {k: "110000-110100-000046", v: "北京市-北京市-北京技术开发区"}
            this.info[key + 'Province'] = value.k.split('-')[0] + '/' + value.v.split('-')[0];
            this.info[key + 'City'] = value.k.split('-')[1] + '/' + value.v.split('-')[1];
            this.info[key + 'County'] = value.k.split('-')[2] + '/' + value.v.split('-')[2];
            this.isAreaPicker = false;
        },
        areaPickerCancel() {
        	this.isAreaPicker = false;
        },
        validatorAction() {
            let msg = '';
            if (!C.Utils.isEmpty(this.info.socialPayYear) && !C.Utils.RegexMap.integerNumber.test(this.info.socialPayYear)) {
                msg = '社保缴纳年限请输入整数';
            } else if (!C.Utils.isEmpty(this.info.socialPayYear) && !C.Utils.checkAmountRange(this.info.socialPayYear, 3, 'gEToLE')(0, 1200)) {
                msg = '社保缴纳年限' + C.HT['3_1'];
            } else if (!C.Utils.isEmpty(this.info.familyHouseNum) && !C.Utils.isInteger(this.info.familyHouseNum)) {
                msg = '家庭拥有住房套数请输入整数';
            } else if (!C.Utils.isEmpty(this.info.familyHouseNum) && !C.Utils.checkAmountRange(this.info.familyHouseNum, 4)()) {
                msg = '家庭拥有住房套数' + C.HT['4'];
            } else if (this.info.localYear && !C.Utils.isInteger(this.info.localYear)) {
                msg = '本地居住年限请输入整数';
            } else if (this.info.localYear && !C.Utils.checkAmountRange(this.info.localYear, 3)()) {
                msg = '本地居住年限' + C.HT['3_1'];
            } else if (this.info.familyMonthCashOut && !C.Utils.amountFormat(this.info.familyMonthCashOut)) {
                msg = '家庭月支出(元)格式不对';
            } else if (this.info.familyMonthCashOut && !C.Utils.checkAmountRange(this.info.familyMonthCashOut)()) {
                msg = '家庭月支出(元)' + C.HT['1'];
            } else if (this.info.clientJobyears && !C.Utils.isInteger(this.info.clientJobyears)) {
                msg = '现单位工作年限请输入整数';
            } else if (this.info.clientJobyears && !C.Utils.checkAmountRange(this.info.clientJobyears, 3)()) {
                msg = '现单位工作年限' + C.HT['3_1'];
            } else if (this.info.monthIncome && !C.Utils.amountFormat(this.info.monthIncome)) {
                msg = '税后月收入(元)格式不对';
            } else if (!C.Utils.isEmpty(this.info.monthIncome) && this.info.monthIncome <= 0) {
                msg = '税后月收入(元)需大于0';
            } else if (!C.Utils.isEmpty(this.info.monthIncome) && !C.Utils.checkAmountRange(this.info.monthIncome, null, 'gEToL')()) {
                msg = '税后月收入(元)' + C.HT['1'];
            } else if (this.info.socProPaybase && !C.Utils.amountFormat(this.info.socProPaybase)) {
                msg = '社保/公积金缴费基数(元)格式不对';
            } else if (this.info.socProPaybase && !C.Utils.checkAmountRange(this.info.socProPaybase)()) {
                msg = '社保/公积金缴费基数(元)' + C.HT['1'];
            } else if (this.info.mobile && !C.Utils.RegexMap.MobileNo.test(this.info.mobile)) {
                msg = '手机号码格式不对';
            } else if (this.info.companyTelephone && !C.Validator.tel(this.info.companyTelephone).result) {
                msg = '单位电话格式不对';
            }
            return msg;
        },
        clickEvent() {
            let msg = this.validatorAction();
            if (msg) {
                C.Native.tip(msg);
                return;
            }
            this.$emit('save', this.info);
        }
	}
};
</script>
<style lang="scss" scoped>
.red-color{
    position:relative;
    top: -1px;
    background:url('./../../assets/images/m/icons/icon_-@2x.png') no-repeat;
    display:inline-block;
    width: 7px;
    height:7px;
    background-size: 7px 7px;
}
.title{
    position: relative;
    span{
        color: #999;
        display:inline-block;
        font-size: .26rem;
        height:.5rem;
        line-height:.58rem;
        padding-left: .3rem;
    }
}
.bt-bottom {
    padding:.3rem 0;
    width: 100%;
    line-height: .8rem;
    text-align: center;
    background:#fff;
    border-top: 1px solid #ddd;
}
.border-top{
    border-top: 1px solid #ddd;
}
.setHeight {
    padding-bottom: .3rem;
}
.setHeight-2 {
    padding-bottom: .5rem;
}
.lilv {
    position: relative;
    .tip{
        position: absolute;
        left: .3rem;
        bottom: .13rem;
        font-size: .24rem;
        color: #999;
    }
    .tip-1 {
        bottom: .3rem;
    }
    .tip-2 {
        bottom: .1rem;
    }
}
.margin-b-5{
    margin-bottom: .5rem;
}
</style>
