<template>
    <!-- 筛选订单 -->
    <section class="select-order">
        <div class="layer"></div>
        <div class="content">
            <div class="title">筛选条件</div>
            <m-input v-model="A2[info.loanVariety]" @select-input='selectLoanType' :textName="'贷款品种'" :type="'select'" :placeholder="'请选择'"></m-input>
            <m-input v-model="A1[info.orderStatus]" @select-input='selectState("order")' :textName="'订单状态'" :type="'select'" :placeholder="'请选择'"></m-input>
            <m-input v-if="!isDelayOrder" v-model="C43[info.bankStatus]" @select-input='selectState("bank")' :textName="'银行状态'" :type="'select'" :placeholder="'请选择'"></m-input>
            <m-input v-model="info.createdTimeBegin" :textName="'创建起始日期'" :type="'select'" :placeholder="'请选择'" @select-input='selectStartDate'></m-input>
            <m-input v-model="info.createdTimeEnd" :textName="'创建结束日期'" :type="'select'" :placeholder="'请选择'" @select-input='selectEndDate'></m-input>
            <m-input v-model="info.clientName" :textName="'主借款人姓名'" :type="'text'" :placeholder="'请填写'"></m-input>
            <m-input v-model="info.mobile" :textName="'主借款人手机号'" :type="'tel'" :placeholder="'请填写'" maxlength="11"></m-input>
            <m-input v-model="info.barcode" :textName="'KB码'" :type="'tel'" :placeholder="'请填写12位数字'" maxlength="12"><span class="nameFront" slot="name-front">KB</span></m-input>
            <m-input v-model="info.orderNo" :textName="'订单号'" :type="'tel'" :placeholder="'请填写14位数字'" maxlength="14"><span class="nameFront" slot="name-front">FD</span></m-input>
            <div class="btn-bottom clear">
                <span class="fl btn" @click="search">查询</span>
                <span class="fr btn btn-white" @click="reset">重置</span>
            </div>
        </div>
        <m-picker :slots='slots' :isPicker='isPicker' :indexText='indexText'
                  :datakey='dataKey' :valueKey="'v'"
                  @confirm='pickerConfirm' @cancel='pickerCancel'>
        </m-picker>
        <m-date-picker :isPicker='isDatePicker' :datakey='dateDataKey'
                       @confirm='datePickerConfirm' @cancel="datePickerCancel">
        </m-date-picker>
    </section>
</template>
<script type="text/ecmascript-6">
    import mPicker from 'src/components/picker/index';
    import mDatePicker from 'src/components/picker/date-picker.vue';
    import mInput from 'src/components/cell/cell';

    export default {
        name: 'select-order',
        data() {
            return {
                isPicker: false, // 普通选择器显示或隐藏
                isDatePicker: false, // 时间选择器显示或隐藏
                indexText: '筛选条件', // 选择器名称
                dataKey: '', // 选择器结果赋值到对象的key值
                dateDataKey: '',
                slots: [], // slot 对象数组
                info: {
                    loanVariety: '',
                    orderStatus: '',
                    bankStatus: '',
                    createdTimeBegin: '',
                    createdTimeEnd: '',
                    barcode: '',
                    orderNo: '',
                    clientName: '',
                    mobile: ''
                },
                A2: C.Constant.A2,
                A1: C.Constant.A1,
                C43: C.Constant['43'],
                IS_NATIVE: C.Utils.App.IS_NATIVE,
                // 备份创建开始日期
                createdTimeBegin: '',
                // 备份创建结束日期
                createdTimeEnd: '',
                // 是否为待处理订单
                isDelayOrder: false
            };
        },
        created() {
            // H5主页面默认30天,渠道app页面默认7天。
            // 选择日期时,默认30天内可选。超过30天,强制更改为30天内
            this.dateSelectNum = 30;
            this.dateNum = C.Utils.App.IS_NATIVE ? 7 : this.dateSelectNum;
            let createdTimeBegin = new Date();
            createdTimeBegin.setDate(createdTimeBegin.getDate() - (this.dateNum - 1));
            this.info.createdTimeBegin = this.createdTimeBegin = C.Utils.parseDateFormat(createdTimeBegin);
            this.info.createdTimeEnd = this.createdTimeEnd = C.Utils.parseDateFormat(new Date());
            this.slots = [{values: []}];
            this.isDelayOrder = this.$route.fullPath === '/delayOrder';
        },
        mounted() {
        },
        computed: {},
        methods: {
            selectLoanType() {
                this.dataKey = 'loanVariety';
                this.indexText = '贷款品种';
                this.slots = [{values: C.Utils.objToArr(this.A2)}];
                this.isPicker = true;
            },
            selectState(type) {
                let values = '';
                this.dataKey = type + 'Status';
                if (type === 'order') {
                    this.indexText = '订单状态';
                    values = C.Utils.objToArr(this.A1);
                } else {
                    this.indexText = '银行状态';
                    values = C.Utils.objToArr(this.C43);
                }
                this.slots = [{values: values}];
                this.isPicker = true;
            },
            pickerConfirm(value, key) {
                this.info[key] = value.k;
                this.isPicker = false;
            },
            pickerCancel() {
                this.isPicker = false;
            },
            // 创建日期开始选择器
            selectStartDate() {
                this.dateDataKey = 'createdTimeBegin';
                this.isPicker = false;
                this.isDatePicker = true;
                this.isAreaPicker = false;
            },
            // 创建日期结束选择器
            selectEndDate() {
                this.dateDataKey = 'createdTimeEnd';
                this.isPicker = false;
                this.isDatePicker = true;
                this.isAreaPicker = false;
            },
            // 日期清除按钮
            datePickerCancel() {
                this.isDatePicker = false;
            },
            // 日期确定按钮
            datePickerConfirm(value, key) {
                this.info[key] = value.join('-');
                let d = new Date(this.info[key]),
                    d1,
                    day;
                if (key === 'createdTimeBegin') {
                    if (this.info.createdTimeEnd) {
                        d1 = new Date(this.info.createdTimeEnd);
                        day = Math.ceil((d1 - d) / 86400000);
                        if (day >= this.dateSelectNum || day < 0) {
                            d.setDate(d.getDate() + (this.dateSelectNum - 1));
                            this.info.createdTimeEnd = C.Utils.parseDateFormat(d);
                        }
                    }
                } else if (key === 'createdTimeEnd') {
                    if (this.info.createdTimeBegin) {
                        d1 = new Date(this.info.createdTimeBegin);
                        day = Math.ceil((d - d1) / 86400000);
                        if (day >= this.dateSelectNum || day < 0) {
                            d.setDate(d.getDate() - (this.dateSelectNum - 1));
                            this.info.createdTimeBegin = C.Utils.parseDateFormat(d);
                        }
                    }
                }
                this.isDatePicker = false;
            },
            search() {
                let info = this.info,
                    mobileResult = C.Validator.MobileNo(info.mobile);
                if (info.mobile && !mobileResult.result) {
                    C.Native.tip(mobileResult.error);
                    return;
                }
                this.$emit('search-order', $.extend(true, {}, this.info, {
                    barcode: this.info.barcode ? 'KB' + this.info.barcode : '',
                    orderNo: this.info.orderNo ? 'FD' + this.info.orderNo : '',
                    pageNo: 1
                }));
            },
            reset() {
                this.info = {
                    loanVariety: '',
                    orderStatus: '',
                    createdTimeBegin: this.createdTimeBegin,
                    createdTimeEnd: this.createdTimeEnd,
                    barcode: '',
                    orderNo: '',
                    clientName: '',
                    mobile: ''
                };
            }
        },
        components: {
            mPicker,
            mInput,
            mDatePicker
        }
    };
</script>
<style scoped lang="scss">
    .select-order {
        position: relative;
        top: 0;
        height: auto;
        .content{
            position: absolute;
            top: -.04rem;
            left: 0;
            right: 0;
            z-index: 11;
        }
        .layer{
            top: 0;
            z-index: 10;
        }

        .title {
            color: #999;
            background: #f6f6f6;
            height: 0.8rem;
            line-height: 0.8rem;
            padding-left: 0.4rem;
        }
        .nameFront{
            position: relative;
            left: 50px
        }

        .btn-bottom {
            width: 100%;
            padding: .32rem .4rem;
            background: #fff;
            > span {
                display: inline-block;
                width: 45%;
                height: .76rem;
                text-align: center;
                line-height: .76rem;
                border-radius: .38rem;
                font-size: .3rem;
           }
        }

    }
</style>
