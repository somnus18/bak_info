<template>
    <div class="search">
        <div class="search-input">
            <span class="search-input-icon"></span>
            <input v-model="value" :placeholder="placeholder" type="text">
            <div class="input-icon">
                <span @click="clear" v-if="value"></span>
            </div>
        </div>
        <ul class="search-result">
            <li class="search-result-list" v-for="(item,index) in tempList" @click="getResult(item)" :key="index">
                {{item.agencyName[0]}}<span class="red">{{item.agencyName[1]}}</span>{{item.agencyName[2]}}
            </li>
        </ul>
    </div>
</template>
<style lang="scss" rel="stylesheet/scss" scoped>
    @import "../../assets/css/func.scss";
    .input-icon {
        width: 20px;
        height: 20px;
        position:absolute;
        top: 0px;
        right: 15px;
        span {
            padding: 8px;
            background: url('icon_del@3x.png') center center/100% auto no-repeat;
            -webkit-background-size: 7px auto;
            background-size: 7px auto;
        }
    }
    .search {
        .red{
            color: red;
        }
        & .search-input {
            display: block;
            position: relative;
            padding: 0 p2r(15);
            line-height: p2r(62);
            background: white;
            input {
                width: 100%;
                font-size: p2r(15);
                height: p2r(35);
                padding-left: p2r(24);
                border: 1px solid #f1f1f1;
                border-radius: p2r(8);
                background: #f1f1f1;
                padding-right: p2r(5);
            }
            & .search-input-icon {
                position: absolute;
                display: block;
                width: p2r(12);
                height: p2r(15);
                margin: auto;
                top: 0;
                left: p2r(23);
                bottom: 0;
                background: url('icon_search@2x.png') center center/100% auto no-repeat;
                -webkit-background-size: p2r(12) auto;
                background-size: p2r(12) auto;
            }
            & .search-input-cancel {
                display: block;
                position: absolute;
                top: p2r(10);
                right: p2r(10);
            }
        }
        & .search-result {
            & .search-result-list {
                display: block;
                background: white;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                -webkit-text-overflow: ellipsis;
                line-height: p2r(50);
                padding: 0 p2r(20);
                width: 100%;
                &:first-child {
                    border: {
                        top: 1px solid;
                        bottom: 1px solid;
                        color: #e2e2e2;
                    }
                }
                &:not(:first-child) {
                    border: {
                        top: 0 solid;
                        bottom: 1px solid;
                        color: #e2e2e2;
                    }
                }
            }

        }
    }
</style>
<script>
    export default{
        props: {
            placeholder: {
                type: String,
                default: '请输入中介公司名称'
            },
            list: {
                type: Array,
                default: ()=> {
                    return [{
                        agencyCode: '123',
                        agencyName: '123'
                    }, {
                        agencyCode: '123',
                        agencyName: '123'
                    }];
                }
            }
        },
        data() {
            return {
                value: '',
                tempList: []
            };
        },
        watch: {
            // 这里用于模糊查询
            value(val) {
                let tempList = [];
                if (val.length > 0) {
                    this.list.forEach((obj)=> {
                        if (obj.agencyName.indexOf(val) >= 0) {
                            let agency = obj.agencyName,
                                index = agency.indexOf(val),
                                headText = agency.slice(0, index),
                                footText = '';
                                if (val.length > 1) {
                                    footText = agency.slice(index + val.length, agency.length);
                                } else {
                                    footText = agency.slice(index + 1, agency.length);
                                }
                            tempList.push({
                                agencyName: [headText, val, footText],
                                agencyCode: obj.agencyCode
                            });
                        }
                    });
                    this.tempList = tempList;
                    C.debug.log(tempList, '++');
                    this.$emit('watch-value', val);
                }
            }
        },
        methods: {
            clear() {
                this.value = '';
            },
            getResult(item) {
                this.$emit('getResult', item);
            }
        },
        components: {}
    };
</script>
