<template>
    <div v-show="isShow" class="del-container layer">
        <div class="content">
            <div class="close" @click="close"></div>
            <div class="reason" @click='selectCancelReasonType'>
                <div class="reason-text">取消原因</div>
                <div class="reason_select"><span class="select" :class="[reason[info.endReasonType]?'':'unselect']">{{reason[info.endReasonType] || '请选择'}}</span></div>
                <div class="reason-icon">
                    <span></span>
                </div>
            </div>
            <div class="supplement">
                <textarea v-model="info.endReasonExplain" maxlength="40" placeholder="请填写取消订单的原因(限5-40字)"></textarea>
            </div>
            <div class="btn confirm" :class="[isClickBtn ? '' : 'btn-disabled']" @click="confirm">确定</div>
        </div>
        <m-picker :slots='slots' :isPicker='isPicker' :indexText='indexText'
                  :datakey='dataKey' :valueKey="'v'"
                  @confirm='pickerConfirm' @cancel='pickerCancel'>
        </m-picker>
    </div>
</template>

<script type="text/ecmascript-6">
    import mPicker from 'src/components/picker/index';
    import mInput from 'src/components/cell/cell';

    export default {
        name: 'del-order',
        props: ['isShow'],
        mounted() {
        },
        data() {
            return {
                isPicker: false, // 普通选择器显示或隐藏
                indexText: '筛选条件', // 选择器名称
                dataKey: '', // 选择器结果赋值到对象的key值
                reason: C.Constant['36'],
                otherReason: C.Constant['36_1'],
                info: {
                    endReasonType: '',
                    endReasonExplain: ''
                }
            };
        },
        created() {
            this.slots = [{values: []}];
        },
        computed: {
            isClickBtn() {
                if (this.info.endReasonType === this.otherReason) {
                    return /^.{5,40}$/.test(this.info.endReasonExplain);
                }
                return this.info.endReasonType;
            }
        },
        watch: {
            isShow() {
                if (!this.isShow) {
                    this.info.endReasonType = '';
                    this.info.endReasonExplain = '';
                }
            }
        },
        methods: {
            selectCancelReasonType() {
                this.dataKey = 'endReasonType';
                this.indexText = '取消原因';
                this.slots = [{values: C.Utils.objToArr(this.reason)}];
                this.isPicker = true;
            },
            pickerConfirm(value, key) {
                this.info[key] = value.k;
                this.isPicker = false;
            },
            pickerCancel() {
                this.isPicker = false;
            },
            close() {
                this.info.endReasonType = '';
                this.info.endReasonExplain = '';
                this.$parent.isShowDelOrder = false;
            },
            confirm() {
                if (!this.isClickBtn) return;
                this.$emit('del-confirm', this.info);
            }
        },
        components: {
            mPicker,
            mInput
        }
    };
</script>

<style scoped lang="scss">
    .del-container{
        z-index: 999;
        .close{
            position: absolute;
            top: -25%;
            left: 50%;
            width: .6rem;
            height: .6rem;
            margin-left: -.3rem;
            background: url('../../assets/images/m/icons/icon_closepopup@2x.png');
            background-size: 100%;
        }
        .content {
            position: absolute;
            width: 84%;
            height: auto;
            top: 50%;
            left: 50%;
            margin-top: -2.3rem;
            margin-left: -42%;
            text-align: center;
            background-color: white;
            border: 1px solid #fff;
            border-radius: .05rem;
        }
        .reason{
            width: 86%;
            margin: 0 auto;
            font-size: .3rem;
            padding-top: .6rem;
            padding-bottom: .4rem;
            .reason-text {
                display: inline-block;
                vertical-align: top;
                width: 40%;
                color: #f59174;
                text-align: left;
            }
            .reason_select {
                display: inline-block;
                vertical-align: top;
                width: 46%;
                height: .6rem;
                text-align: right;
            }
            .reason-icon {
                display: inline-block;
                width: 10%;
                span{
                    display: inline-block;
                    width: .4rem;
                    height: .4rem;
                    line-height: .3rem;
                    background: url(../../assets/images/app/icons/icon_arrow_r@3x.png) center center no-repeat;
                    background-size: 50%;
                }
            }
        }
        .supplement {
            width: 86%;
            margin: 0 auto;
        }
        .supplement textarea{
            width: 100%;
            height: 1.82rem;
            font-size: .3rem;
            background: #f0f0f0;
            padding: .28rem .32rem;
            border: 1px solid #fff;
            border-radius: .08rem;
        }
        .confirm{
            width: 70%;
            height: 0.8rem;
            line-height: 0.8rem;
            margin: .25rem auto;
        }
    }
</style>
