<template>
    <section class="all-orders-detail">
        <div class="all-orders-content">
            <div class="loanVariety">
                <span class="kb-num">{{info.orderInfo.barcode}}</span>
                <span class="fr">{{A2[info.loanInfo.loanVariety]}}</span>
            </div>
            <m-input class="m-input" v-model="info.orderInfo.orderNo" :disabled=true :textName="'订单号'"></m-input>
            <m-input class="m-input" v-model="C1[info.orderInfo.interviewType]" :disabled=true :textName="'面签模式'"></m-input>
            <m-input class="m-input" v-model="info.orderInfo.createdTime" :disabled=true :textName="'创建日期'"></m-input>
            <m-input class="m-input" v-model="info.orderInfo.clientName" :disabled=true :textName="'主借款人'"></m-input>
            <m-input class="m-input" v-model="info.orderInfo.mobile" :disabled=true :textName="'主借款人手机号'"></m-input>
            <m-input class="m-input" v-model="A1[info.orderInfo.orderStatus]" :disabled=true :textName="'订单状态'"></m-input>
            <div class="title">银行终审信息</div>
            <m-input class="m-input" v-model="Z5[info.bankLastAuditInfo.auditResult]" :disabled=true :textName="'审批意见'"></m-input>
            <m-input class="m-input" v-model="info.bankLastAuditInfo.auditAmount" :disabled=true :textName="'贷款金额(万元)'"></m-input>
            <m-input class="m-input" v-model="info.bankLastAuditInfo.auditDeadline" :disabled=true :textName="'贷款期限(月)'"></m-input>
            <m-input class="m-input" v-model="info.bankLastAuditInfo.auditRate" :disabled=true :textName="'贷款利率'"></m-input>
            <m-input class="m-input" v-model="C20[info.bankLastAuditInfo.repaymentType]" :disabled=true :textName="'还款方式'"></m-input>
            <m-input class="m-input" v-model="info.bankLastAuditInfo.bankManagerUm" :disabled=true :textName="'银行客户经理UM'"></m-input>
            <m-input class="m-input input-name-flex-11" v-model="info.bankLastAuditInfo.bankManagerMobile" :disabled=true :textName="'银行客户经理联系方式'"></m-input>
            <div class="title">银行放款信息</div>
            <m-input class="m-input" v-model="info.bankLoanInfo.loanAuditAmount" :disabled=true :textName="'贷款金额(万元)'"></m-input>
            <m-input class="m-input" v-model="info.bankLoanInfo.loanAuditDeadline" :disabled=true :textName="'贷款期限(月)'"></m-input>
            <m-input class="m-input" v-model="info.bankLoanInfo.loanAuditRate" :disabled=true :textName="'贷款利率'"></m-input>
            <m-input class="m-input" v-model="C20[info.bankLoanInfo.loanRepaymentType]" :disabled=true :textName="'还款方式'"></m-input>
            <template v-for="(item, index) in info.collateralInfoList">
                <div class="title">抵押物信息{{info.collateralInfoList.length !== 1 ? (index + 1):''}}</div>
                <m-input class="m-input" v-model="C16[item.houseKinds]" :disabled=true :textName="'房屋类别'"></m-input>
                <div class="m-input input-disable">
                    <span class="input-name">房产所在地</span>
                    <div class="input-text-content">
                        <span data-v-30b537d6="">{{item.houseProvince | getCName}}{{item.houseCity | getCName}}{{item.houseCounty | getCName}}</span>
                    </div>
                </div>
                <m-input class="m-input" v-model="item.houseAddress" :disabled=true :textName="'详细地址'"></m-input>
                <m-input class="m-input" v-model="item.houseArea" :disabled=true :textName="'建筑面积(m²)'"></m-input>
            </template>
            <div class="title">贷款信息</div>
            <m-input class="m-input" v-model="A2[info.loanInfo.loanVariety]" :disabled=true :textName="'贷款品种'"></m-input>
            <m-input class="m-input" v-model="A3[info.loanInfo.loanPlan]" :disabled=true :textName="'贷款方案'"></m-input>
            <m-input class="m-input" v-model="info.loanInfo.referralName" :disabled=true :textName="'渠道专员'"></m-input>
            <m-input class="m-input" v-model="info.loanInfo.agencyName" :disabled=true :textName="'中介名称'"></m-input>
            <m-input class="m-input" v-model="info.loanInfo.storeName" :disabled=true :textName="'办理门店'"></m-input>
            <m-input class="m-input input-name-flex-9" v-model="info.loanInfo.bizApplyAmount" :disabled=true :textName="'申请金额-商贷(万元)'"></m-input>
            <m-input class="m-input input-name-flex-11" v-model="info.loanInfo.publicReserveApplyAmount" :disabled=true :textName="'申请金额-公积金(万元)'"></m-input>
            <template v-for="(item, index) in info.collateralInfoList">
                <div class="title">询价提示信息{{info.collateralInfoList.length !== 1 ? (index + 1):''}}</div>
                <m-input class="m-input" v-model="item.evaluationCompanyName" :disabled=true :textName="'评估公司名称'"></m-input>
                <m-input class="m-input input-name-flex-9" v-model="item.evaluationCompanyContacts" :disabled=true :textName="'评估公司联系人名称'"></m-input>
                <m-input class="m-input input-name-flex-9 last-m-input" v-model="item.evaluationCompanyMobile" :disabled=true :textName="'评估公司联系人电话'"></m-input>
            </template>
        </div>
    </section>
</template>
<script type="text/ecmascript-6">
    import mInput from 'src/components/cell/cell';

    export default {
        name: 'all-orders-detail',
        data() {
            return {
                // 面签模式
                C1: $.extend(true, {}, C.Constant['1'], {'-': '-'}),
                // 订单状态
                A1: $.extend(true, {}, C.Constant['A1'], {'-': '-'}),
                // 贷款品种
                A2: $.extend(true, {}, C.Constant['A2'], {'-': '-'}),
                // 贷款方案
                A3: $.extend(true, {}, C.Constant['A3'], {'-': '-'}),
                // 房屋类别
                C16: $.extend(true, {}, C.Constant['16'], C.Constant['16_95_object'], {'-': '-'}),
                // 还款方式
                C20: $.extend(true, {}, C.Constant['20'], {'-': '-'}),
                // 终审结果
                Z5: $.extend(true, {}, C.Constant['Z5'], {'-': '-'}),
                info: {
                    orderInfo: {
                        loanVariety: '',
                        barcode: '',
                        orderNo: '',
                        interviewType: '',
                        createdTime: '',
                        clientName: '',
                        mobile: '',
                        orderStatus: ''
                    },
                    bankLastAuditInfo: {
                        auditResult: '',
                        auditAmount: '',
                        auditDeadline: '',
                        auditRate: '',
                        repaymentType: '',
                        bankManagerUm: '',
                        bankManagerMobile: ''
                    },
                    bankLoanInfo: {
                        loanAuditAmount: '',
                        loanAuditDeadline: '',
                        loanAuditRate: '',
                        loanRepaymentType: ''
                    },
                    collateralInfoList: [{
                        houseKinds: '',
                        houseProvince: '',
                        houseCity: '',
                        houseCounty: '',
                        houseAddress: '',
                        houseArea: '',
                        evaluationCompanyName: '',
                        evaluationCompanyContacts: '',
                        evaluationCompanyMobile: ''
                    }],
                    loanInfo: {
                        loanVariety: '',
                        loanPlan: '',
                        referralName: '',
                        agencyName: '',
                        storeName: '',
                        bizApplyAmount: '',
                        publicReserveApplyAmount: ''
                    }
                }
            };
        },
        created() {
        },
        mounted() {
            this.$nextTick(()=> {
                this.orderId = this.$route.params.id;
                this.render();
            });
        },
        methods: {
            render() {
                $.ajax({
                    url: C.Utils.App.IS_NATIVE ? C.Api('GET_ORDER_DETAIL_WITH_BANK_INFO') : C.Api('ALL_ORDER_DETAIL'),
                    data: {
                        orderId: this.orderId
                    },
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            let key,
                                key1,
                                key2,
                                i,
                                val1,
                                val2,
                                obj = res.data,
                                rateNativeLen,
                                amountTransformArr = ['auditAmount', 'loanAuditAmount', 'bizApplyAmount', 'publicReserveApplyAmount'],
                                rate = ['auditRate', 'loanAuditRate'];
                            for (key in this.info) {
                                if (Object.prototype.toString.call(this.info[key]) === '[object Object]') {
                                    for (key1 in this.info[key]) {
                                        val1 = (obj[key] || {})[key1];
                                        // 利率
                                        if (rate.indexOf(key1) !== -1) {
                                            rateNativeLen = (String(val1).split('.')[1] && String(val1).split('.')[1].length) || 0;
                                            this.info[key][key1] = C.Utils.isEmpty(val1) ? '-' : C.Utils.toY(val1, rateNativeLen > 2 ? rateNativeLen - 2 : 0, 100) + '%';
                                        } else if (amountTransformArr.indexOf(key1) !== -1) {
                                            // 金额
                                            this.info[key][key1] = C.Utils.isEmpty(val1) ? '-' : C.Utils.toWY(val1, 6);
                                        } else {
                                            this.info[key][key1] = C.Utils.isEmpty(val1) ? '-' : val1;
                                        }
                                    }
                                } else if (Object.prototype.toString.call(this.info[key]) === '[object Array]') {
                                    obj[key] = obj[key] || [];
                                    for (i = 0; i < obj[key].length; i++) {
                                        for (key2 in obj[key][i]) {
                                            val2 = obj[key][i][key2];
                                            this.info[key][i] = this.info[key][i] || {};
                                            this.info[key][i][key2] = C.Utils.isEmpty(val2) ? '-' : val2;
                                        }
                                    }
                                }
                            }
                        }
                    }
                });
            }
        },
        components: {
            mInput
        }
    };
</script>
<style scoped lang="scss">
    .all-orders-detail{
        position: absolute;
        width: 100%;
        padding: .65rem 4% .3rem;
        border-radius: 5px;
        .all-orders-content{
            background: #fff;
            border-radius: 5px;
        }
        .loanVariety{
            background: #fff;
            color: #666;
            padding: .4rem .4rem .2rem .3rem;
            line-height: .4rem;
            border-bottom: 1px solid #eee;
            border-top-left-radius: 5px;
            border-top-right-radius: 5px;
        }
        .title {
            background: #fafafa;
            color: #999;
            height: 0.8rem;
            line-height: 0.8rem;
            padding-left: 0.3rem;
        }
        .m-input{
            border: none !important;
        }
        .last-m-input {
            border-bottom-left-radius: 5px;
            border-bottom-right-radius: 5px;
        }
        .input-disable{
            min-height: 0.98rem;
            position: relative;
            display: -webkit-box;
            display: flex;
            -webkit-box-align: center;
            align-items: center;
            width: 100%;
            padding-left: 0.3rem !important;
            background: white;
            .input-name {
                -webkit-box-flex: 0.7;
                flex: 0.7;
                padding-top: 0.04rem;
                width: 3rem;
                font-size: 0.32rem;
                line-height: 0.4rem;
                color: #666;
            }
            .input-text-content {
                -webkit-box-flex: 1;
                -ms-flex: 1;
                flex: 1;
                display: -webkit-box;
                display: flex;
                padding: 0.16rem 0.4rem 0.12rem 0;
                line-height: 0.4rem;
                -webkit-box-align: center;
                align-items: center;
                -webkit-box-pack: end;
                justify-content: flex-end;
            }
        }
    }
</style>
