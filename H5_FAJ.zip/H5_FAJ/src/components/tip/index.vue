<template>
    <div v-if="!isNative" v-show="tip.isShowTip" class="ui-tip-container">
        <div class="ui-tip-text">{{tip.msg}}</div>
    </div>
</template>

<script type="text/ecmascript-6">
    export default {
        name: 'tip',
        mounted() {
        },
        data() {
            return {
                isNative: C.Utils.App.IS_NATIVE
            };
        },
        computed: {
            tip() {
                return this.$store.state.tip.data;
            }
        }
    };
</script>

<style scoped>
    .ui-tip-container{
        position: fixed;
        width: 100%;
        top: 44%;
        left: 0;
        right: 0;
        text-align: center;
        z-index: 99999;
    }
    .ui-tip-text{
        display: inline-block;
        max-width: 64%;
        background: #333;
        opacity: .9;
        color: #fff;
        font-size: .28rem;
        text-align: left;
        padding: .2rem .3rem;
        border-radius: .1rem;
    }
</style>
