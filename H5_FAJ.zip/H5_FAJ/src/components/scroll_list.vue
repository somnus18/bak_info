<template>
    <iscroll-view ref="scrollList" :opt="opt" :isMoreData="isMoreData" class="scroll-view" @pullDown="pullDown" @pullUp="pullUp">
        <div class="scroll-main">
            <slot></slot>
            <div class="bottom-load Loading" v-if="!isMoreData && opt.isLoadMore">
                {{noMore}}
            </div>
        </div>
    </iscroll-view>
</template>
<script type="text/ecmascript-6">

    export default{
        name: 'scroll-list',
        props: {
            pageNo: {
                type: Number
            },
            isMoreData: {
                type: Boolean
            },
            opt: {
                type: Object,
                default() {
                    return {
                        // 是否允许加载更多
                        isLoadMore: true,
                        // 是否允许刷新页面
                        isRefresh: true
                    };
                }
            },
            params: {
                type: Object,
                default: null
            }
        },
        data() {
            return {
                isRequestData: false,
                noMore: '',
                page: 1
            };
        },
        created() {
            C.UI.loading();
            this.$parent.page = 1;
        },
        mounted() {
        },
        methods: {
            // 下拉
            pullDown() {
                let timer = null;
                if (!this.opt.isRefresh) {
                    // 不需要刷新加载最新数据,直接返回
                    return;
                }
                // 是否在请求数据中
                if (this.isRequestData) {
                    return;
                }
                clearTimeout(timer);
                this.isRequestData = true;
                timer = setTimeout(()=> {
                    this.page = 1;
                    this.$parent.isRefresh = true;
                    this.$parent.render(this.params ? $.extend(true, this.params, {
                        pageNo: this.page
                    }) : this.page, ()=> {
                        setTimeout(()=> {
                            this.isRequestData = false;
                            this.$refs.scrollList.topLoading = false;
                            this.$refs.scrollList.topLoad = false;
                        }, 200);
                    });
                }, 0);
            },
            // 上拉
            pullUp() {
                let timer = null;
                if (!this.opt.isLoadMore) {
                    // 不需要加载更多功能,直接返回
                    return;
                }
                // 是否在请求数据中
                if (this.isRequestData) {
                    return;
                }
                // 同步筛选页码
                this.page = this.pageNo || this.page;
                clearTimeout(timer);
                this.isRequestData = true;
                if (this.isMoreData) {
                    timer = setTimeout(()=> {
                        this.$parent.isRefresh = false;
                        this.$parent.render(this.params ? $.extend(true, this.params, {
                            pageNo: ++this.page
                        }) : ++this.page, ()=> {
                            this.isRequestData = false;
                            this.$refs.scrollList.bottomLoading = false;
                            this.$refs.scrollList.bottomLoad = false;
                        });
                    }, 200);
                }
            }
        }
    };
</script>

<style scoped>
    .scroll-view {
        /* -- Attention: This line is extremely important in chrome 55+! -- */
        touch-action: none;
        /* -- Attention-- */
        position: fixed;
        bottom: 0;
        left: 0;
        right: 0;
        top: 0;
        overflow: hidden;
        width:100%;
    }

</style>
