<template>
    <section class=loan-info-detail>
        <h3 class="title">贷款信息</h3>
        <m-input v-model="A2[info.loanVariety]" :textName="'贷款品种'" :disabled=true></m-input>
        <m-upper v-model="bizApplyAmount" :disabled="isToView" :textName="'申请金额-商贷(万元)'" :placeholder="'请填写'"
                 :type="'text'" :maxlength="13" :unit="'W'"></m-upper>

        <m-upper v-model="publicReserveApplyAmount" v-if="info.loanPlan == C2 || isToView"
                :textName="'申请金额-公积金(万元)'" :disabled="isToView" :placeholder="'请填写'" :type="'text'" :maxlength="13" :unit="'W'"></m-upper>
        <m-input v-model="publicReserveApplyAmount" v-else :textName="'申请金额-公积金(万元)'" :disabled=true></m-input>
        <h3 class="title">贷款方案</h3>
        <m-input v-model="info.loanLimit" :disabled="isToView"
                 :textName="'贷款期限(月)'" :placeholder="'请填写'"
                 :type="'text'" :maxlength="8"></m-input>
        <m-input v-model="C19[info.loanPurposeType]" :disabled="isToView" :textName="'贷款用途'" :type="'select'"
                 @select-input='pickerEvent("loanPurposeType","贷款用途","19")'
        ></m-input>

        <m-input v-model="info.buildingName" :disabled="isToView" v-show="info.loanPurposeType == C19_1"
                 :textName="'房产名称'" :placeholder="'楼宇名称'" :type="'text'" :maxlength="85"></m-input>

        <m-input v-model="C20[info.repaymentType]" :disabled="isToView" :textName="'还款方式'" :type="'select'"
                 @select-input='pickerEvent("repaymentType","还款方式","20")'
        ></m-input>
        <m-input v-model="C21[info.repaymentPeriod]" :textName="'还款周期'" :disabled=true></m-input>
        <!--<footer class=footer-bottom v-show="isShowBtn">-->
        <!--<div class=btn @click=save>{{btnName || '保存'}}</div>-->
        <!--</footer>-->
        <m-picker :isPicker='isPicker' :indexText='indexText' :slots='slots' :datakey='datakey' valueKey='v'
                  @confirm='pickerConfirm' @cancel='pickerCancel'></m-picker>
    </section>
</template>
<script type=text/ecmascript-6>
    import mPicker from 'src/components/picker/index';
    import mInput from 'src/components/cell/cell';
    import mUpper from 'src/components/cell/upper';

    export default {
        name: 'loan-info-detail',
        props: {
            info: {
                type: Object
            },
            isToView: {
                type: Boolean,
                default: true
            },
            btnName: {
                type: String
            },
            isShowBtn: {
                type: Boolean,
                default: true
            }
        },
        data() {
            return {
                isPicker: false, // 普通选择器显示或隐藏
                isDatePicker: false, // 时间选择器显示或隐藏
                isAreaPicker: false, // 地区选择器显示或隐藏
                indexText: '选择器', // 选择器名称
                datakey: '', // 选择器结果赋值到对象的key值
                bizApplyAmount: '',
                publicReserveApplyAmount: 0,
                dateDataKey: '',
                areaDataKey: '',
                slots: [],
                C2: C.Constant['A3_2'],
                // 贷款品种
                A2: C.Constant['A2'],
                C19: C.Constant['19'],
                // 购买商用房
                C19_1: C.Constant['19_1'],
                C20: C.Constant['20'],
                C21: C.Constant['21']
            };
        },
        created() {
            this.slots = [{values: []}];
        },
        watch: {
            'info.bizApplyAmount': function (val) {
                this.bizApplyAmount = C.Utils.toWY(val);
            },
            'info.publicReserveApplyAmount': function (val) {
                this.publicReserveApplyAmount = C.Utils.toWY(val);
            },
            'info.repaymentType': function (val) {
                switch (val) {
                    case C.Constant['20_1']:
                    case C.Constant['20_2']:
                        this.info.repaymentPeriod = C.Constant['21_1'];
                        break;
                    case C.Constant['20_7']:
                    case C.Constant['20_8']:
                        this.info.repaymentPeriod = C.Constant['21_7'];
                        break;
                }
            },
            'info.loanPurposeType': function (val) {
                this.info.buildingName = val === this.C19_1 ? this.info.buildingName : '';
            }
        },
        methods: {
            getFootMargin() {
                let $body, $head, $middle, $footer, height;
                $body = document.querySelector('body');
                $head = document.querySelector('.navbar');
                $middle = document.querySelector('.loan-info-detail');
                $footer = document.querySelector('.footer-bottom');
                $footer.style.marginTop = '0px';
                height = $body.offsetHeight - $head.offsetHeight - $middle.offsetHeight;
                height = height > 0 ? height : 20;
                $footer.style.marginTop = height + 'px';
            },
            selectHide() {
                this.isPicker = false;
                this.isDatePicker = false;
                this.isAreaPicker = false;
            },
            pickerEvent(key, text, slot) {
                this.datakey = key;
                this.indexText = text;
                this.slots = [{values: C.Utils.objToArr(C.Constant[slot])}];
                this.isPicker = true;
                this.isDatePicker = false;
                this.isAreaPicker = false;
            },
            // 普通选择器 确认
            pickerConfirm(value, key) {
                this.info[key] = value.k;
                this.isPicker = false;
            },
            pickerCancel() {
                this.isPicker = false;
            },
            validator() {
                let msg = '',
                    info = this.info;
                if (info.loanLimit && !/^([1-9]|([1-9]\d)|([1-2]\d{2})|([3][0-5]\d)|360)$/.test(info.loanLimit)) {
                    msg = '贷款期限请输入不大于360的正整数';
                } else if (!this.bizApplyAmount) {
                    msg = '申请金额必填';
                } else if (isNaN(this.bizApplyAmount)) {
                    msg = '申请金额必须为数字';
                } else if (!C.Utils.RegexMap.sixDecimal.test(this.bizApplyAmount)) {
                    msg = '申请金额最多6位小数点';
                } else if (this.bizApplyAmount <= 0) {
                    msg = '申请金额需大于0';
                } else if (!C.Utils.checkAmountRange(this.bizApplyAmount * 10000, null, 'gEToL')()) {
                    msg = '申请金额' + C.HT['1'];
                } else if (this.info.loanPlan === C.Constant['A3_2'] && !this.publicReserveApplyAmount) {
                    msg = '申请金额-公积金必填';
                } else if (this.info.loanPlan === C.Constant['A3_2'] && isNaN(this.publicReserveApplyAmount)) {
                    msg = '申请金额-公积金必须为数字';
                } else if (this.info.loanPlan === C.Constant['A3_2'] && !C.Utils.isEmpty(this.publicReserveApplyAmount) && this.publicReserveApplyAmount <= 0) {
                    msg = '申请金额-公积金需大于0';
                } else if (this.info.loanPlan === C.Constant['A3_2'] && !C.Utils.RegexMap.sixDecimal.test(this.publicReserveApplyAmount)) {
                    msg = '申请金额-公积金最多6位小数点';
                } else if (this.info.loanPlan === C.Constant['A3_2'] && !C.Utils.checkAmountRange(this.publicReserveApplyAmount * 10000, null, 'gEToL')()) {
                    msg = '申请金额-公积金' + C.HT['1'];
                }
                return msg;
            },
            validatorAction() {
                let validator = this.validator();
                if (validator) {
                    C.Native.tip(validator);
                    return false;
                }
            },
            save() {
                let validator = this.validator();
                if (validator) {
                    C.Native.tip(validator);
                    return false;
                }
                this.info.bizApplyAmount = C.Utils.toY(this.bizApplyAmount, 2);
                this.info.publicReserveApplyAmount = C.Utils.toY(this.publicReserveApplyAmount, 2);
                // 未校验
                this.$emit('save', this.info);
            }
        },
        components: {
            mPicker,
            mInput,
            mUpper
        }
    };
</script>
<style scoped lang="scss">

    .loan-info-detail {

    .title {
        height: 0.6rem;
        line-height: 0.65rem;
        padding-left: .3rem;
        font-size: .26rem;
        background: #fafafa;
        color: #999;
    }

    .footer-bottom {
        padding: .2rem 0;
        text-align: center;
        background: #fff;

    .btn {
        height: 0.8rem;
        line-height: 0.80rem;
        margin: 0 auto;
        color: #fff;
        font-size: 0.32rem;
        border-radius: .4rem;
    }

    }
    }
</style>
