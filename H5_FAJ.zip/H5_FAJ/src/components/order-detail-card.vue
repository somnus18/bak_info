<template>
    <div class="order-card">
        <div class="card-top">
            <span class="barcode kb-num">{{item.barcode}}</span>
            <span class="fr">{{A2[item.loanVariety]}}</span>
        </div>
        <div class="card-btm">
            <div class="text-row clear">
                <span class="fl"><div>订单号</div></span>
                <span class="fr">{{item.orderNo}}</span>
            </div>
            <div class="text-row clear">
                <span class="fl">面签模式</span>
                <span class="fr">{{C1[item.interviewType] || '-'}}</span>
            </div>
            <div class="text-row clear">
                <span class="fl">主借款人</span>
                <span class="fr">{{item.clientName}}</span>
            </div>
        </div>
    </div>
</template>
<script type="text/ecmascript-6">
    export default {
        data() {
            return {
                C1: C.Constant['1'],
                A2: C.Constant['A2']
            };
        },
        props: ['item']
    };
</script>
<style scoped lang="scss">
    .order-card {
        background: #fff;

        .card-top {
            padding: .2rem .3rem;
            line-height: .4rem;
            border-bottom: 1px solid #eee;
            span{
                color: #666;
            }
        }

        .card-btm {
            padding: .2rem .3rem;
            .text-row {
                padding: .16rem 0;
                clear: both;
                span.fr{
                    color: #333;
                }
            }
        }
    }
</style>
