<template>
    <div class="order-card" @click="goDetail">
    
    </div>
</template>
<script type="text/ecmascript-6">
    export default {
        data() {
            return {};
        },
        props: ['item'],
        computed: {
           state() {
            return C.Utils.arrToObject(C.Constant.ORDER_STATE)[this.item.state];
           },
           loanType() {
            return C.Utils.arrToObject(C.Constant.LOAN_BREED)[this.item.loanType];
           }
        },
        methods: {
        	goDetail() {
        		this.$emit('goDetail');
        	}
        }
    };
</script>
<style scoped>
	.order-card{padding:0 5px;margin-top: .2rem;background: #fff;}
    .card-top{padding:.2rem .3rem .15rem;line-height: .4rem;border-bottom: solid 1px #ccc;}
    .kb-num{position: relative;padding-left: .6rem;}
    .kb-num:before{position: absolute;width: .3rem;height: .4rem;left: 0;bottom: 0;content: '';background: pink;}
    .card-btm{padding:.2rem .3rem;}
    .text-row{padding:.1rem 0;clear: both;}
    .text-row *{line-height: .5rem;}
</style>
