import Env from './env';

let prefix = '',
    api,
    envStg = Env.toLowerCase(),
    envTest = envStg.replace(/TEST/i, 'stg'),
    IS_H5_SERVER = location.href.indexOf('fang-test.pingan.com.cn') !== -1 || location.href.indexOf('fang.pingan.com.cn') !== -1,
    jsonPrefix = IS_H5_SERVER ? './static/data/' : location.origin + '/';

switch (Env) {
    case 'DEVELOPMENT' :
        prefix = jsonPrefix;
        break;
    case 'STG1':
    case 'STG2':
    case 'STG3':
        // 外网能访问的环境
        prefix = 'https://test-papc-gs.pingan.com.cn:8843/' + envStg + '/mtg2/';
        break;
    case 'TEST1':
    case 'TEST2':
    case 'TEST3':
        // 内网能访问的环境
        prefix = 'https://test-papc-gs.pingan.com.cn/' + envTest + '/mtg2/';
        break;
    case 'PRODUCTION':
        prefix = 'https://papc-gs.pingan.com.cn/mtg2/';
        break;
    default:
        // 供联调开发使用
        prefix = 'http://' + Env + '/mtg2/';
}

api = {
    /**
     * 接口名：公共-删除图片</br>
     * 后端负责人：彭振宇</br>
     * 前端负责人:
     * 描述：
     */
    DELETE_IMAGE: 'common/deleteImage.do',
    /**
     * 接口名：用户-获取登录ticket</br>
     * 后端负责人：张振伟</br>
     * 前端负责人:肖超峰
     * 描述：
     */
    GET_TICKET: 'user/getTicket.do',

    /**
     * 接口名：用户-H5登录</br>
     * 后端负责人：张振伟</br>
     * 前端负责人:肖超峰
     * 描述：
     */
    USER_LOGIN: 'user/login.do',

    /**
     * 接口名：用户-H5用户退出登录</br>
     * 后端负责人：张振伟</br>
     * 前端负责人:肖超峰
     * 描述：
     */
    USER_LOGOUT: 'user/logout.do',

    /**
     * 接口名：转他人录入-登录</br>
     * 后端负责人：张振伟</br>
     * 前端负责人:肖超峰
     * 描述：验证主借款人身份证号，并生成登录态。
     */
    ANOTHER_LOGIN: 'anotherinput/login.do',

    /**
     * 接口名：爱行销入口-静默登录</br>
     * 后端负责人：张振伟</br>
     * 前端负责人: 无(爱行销APP点进件跳转这个URL，接收加密的UM号)
     * 描述：爱行销APP点进件跳转这个URL，接收加密的UM号。
     */
    OPMGT_LOGIN: 'opmgt/login.do',

    /**
     * 接口名：转他人录入-重发短信</br>
     * 后端负责人：张振伟</br>
     * 前端负责人:
     * 描述：
     */
    ANOTHER_REPEAT_MSG: 'anotherinput/repeatShortMsg.do',

    /**
     * 接口名：转他人录入-提交手机号</br>
     * 后端负责人：张振伟</br>
     * 前端负责人:
     * 描述：
     */
    ANOTHER_UPDATE_MOBILE: 'anotherinput/updateMobile.do',


    /**
     * 接口名：抵押物信息-获取订单抵押物列表</br>
     * 后端负责人：王志倦</br>
     * 前端负责人:
     * 描述：
     */
    SHOW_COLLATERAL_LIST: 'collateral/getCollateralList.do',

    /**
     * 接口名：抵押物信息-获取权利人列表</br>
     * 后端负责人：王志倦</br>
     * 前端负责人:
     * 描述：
     */
    SHOW_OWERS: 'collateral/getCollateralOwnerList.do',

    /**
     * 接口名：抵押物信息-获取房产信息详情</br>
     * 后端负责人：王志倦</br>
     * 前端负责人:
     * 描述：
     */
    SHOW_HOUSE_INFO: 'collateral/getCollateralInfo.do',

    /**
     * 接口名：抵押物信息-上传房产信息</br>
     * 后端负责人：王志倦</br>
     * 前端负责人:
     * 描述：
     */
    UPLOAD_HOUSE_INFO: 'collateral/updateCollateralInfo.do',

    /**
     * 接口名：征信模块-重发信息</br>
     * 后端负责人：陈筱倜</br>
     * 前端负责人: 肖超峰
     * 描述：
     */
    CREDIT_RESEND: 'credit/resendShortMsg.do',

    /**
     * 接口名：征信模块-订单征信授权详情</br>
     * 后端负责人：陈筱倜</br>
     * 前端负责人: 肖超峰
     * 描述：
     */
    CREDIT_RESULT: 'credit/getCreditResult.do',

    /**
     * 接口名：征信模块-转线下征信</br>
     * 后端负责人：陈筱倜</br>
     * 前端负责人: 肖超峰
     * 描述：
     */
    TURN_TO_OFFLINE: 'credit/turnToOffline.do',

    /**
     * 接口名：信息录入-获取主借款人信息</br>
     * 后端负责人：张振伟</br>
     * 前端负责人:
     * 描述：
     */
    GET_MAIN_BORROWER_INFO: 'mainBorrower/getMainBorrowerInfo.do',

    /**
     * 接口名：信息录入-查询银行评估公司信息</br>
     * 后端负责人：陈筱倜</br>
     * 前端负责人:
     * 描述：查询银行评估公司信息
     */
    GET_EVALUATION_COMPANY: 'cust/getEvaluationCompany.do',

    /**
     * 接口名：信息录入-提交主借款人信息</br>
     * 后端负责人：张振伟</br>
     * 前端负责人:
     * 描述：
     */
    UPDATE_MAIN_BORROWER_INFO: 'mainBorrower/updateMainBorrowerInfo.do',

    /**
     * 接口名：审批补件-补件详情</br>
     * 后端负责人：彭震宇</br>
     * 前端负责人:
     * 描述：
     */
    GET_EVIDENCE_INFO: 'evidence/getEvidenceInfo.do',

    /**
     * 接口名：审批补件-上传补件材料</br>
     * 后端负责人：彭震宇</br>
     * 前端负责人:
     * 描述：
     */
    UPLOAD_EVIDENCE_MATERIALS: 'evidence/uploadEvidenceMaterialsImage.do',

    /**
     * 接口名：审批补件-提交审批补件信息接口</br>
     * 后端负责人: 彭震宇
     * 描述：
     */
    SUBMIT_EVIDENCE_INFO: 'evidence/submitEvidenceInfo.do',

    /**
     * 接口名：身份验证-获取身份验证信息</br>
     * 后端负责人：张振伟</br>
     * 前端负责人:
     * 描述：
     */
    GET_IDENTITY_CHECK_INFO: 'idCheck/getIdentityCheckInfo.do',

    /**
     * 接口名：身份验证-提交身份验证信息</br>
     * 后端负责人：张振伟</br>
     * 前端负责人:
     * 描述：
     */
    UPDATE_IDENTITY_CHECK_INFO: 'idCheck/updateIdentityCheckInfo.do',

    /**
     * 接口名：预约面签-详细信息</br>
     * 后端负责人：彭震宇</br>
     * 前端负责人:
     * 描述：
     */
    GET_INTERVIEW_INFO: 'interview/getInterviewInfo.do',

    /**
     * 接口名：预约面签-预约信息提交</br>
     * 后端负责人：彭震宇</br>
     * 前端负责人:
     * 描述：
     */
    SUBMIT_INTERVIEW_INFO: 'interview/submitInterviewInfo.do',

    /**
     * 接口名：贷款信息-获取贷款信息详情</br>
     * 后端负责人：王志倦</br>
     * 前端负责人:
     * 描述：
     */
    SHOW_LOAN_INFO: 'loan/getLoanInfo.do',

    /**
     * 接口名：贷款信息-获取补充贷款信息</br>
     * 后端负责人：王志倦</br>
     * 前端负责人:
     * 描述：
     */
    SHOW_SUPPLEMENT_LOAN_INFO: 'loan/getSupplementLoanInfo.do',

    /**
     * 接口名：贷款信息-上传贷款信息</br>
     * 后端负责人：王志倦</br>
     * 前端负责人:
     * 描述：
     */
    UPLOAD_LOAN_INFO: 'loan/uploadLoanInfo.do',

    /**
     * 接口名：贷款信息-上传补充贷款信息</br>
     * 后端负责人：王志倦</br>
     * 前端负责人:
     * 描述：
     */
    UPLOAD_SUPPLEMENT_LOAN_INFO: 'loan/uploadSupplementLoanInfo.do',

    /**
     * 接口名：订单-我的进件</br>
     * 后端负责人：王志倦</br>
     * 前端负责人:
     * 描述：
     */
    OPMGT_MYENTRY: 'opmgt/myEntry.do',

    /**
     * 接口名：订单-爱行销订单列表</br>
     * 后端负责人：王志倦</br>
     * 前端负责人:
     * 描述：
     */
    OPMGT_ORDER_LIST: 'opmgt/getOrderList.do',

    /**
     * 接口名：订单-爱行销及H5订单列表带筛选条件</br>
     * 后端负责人：王志倦</br>
     * 前端负责人:
     * 描述：我的进件【待跟进订单和所有订单共用】及H5所有订单
     */
    ORDER_LIST_WITH_FILTER: 'opmgt/getOrderListWithFilter.do',

    /**
     * 接口名：订单-所有订单详情</br>
     * 后端负责人：王志倦</br>
     * 前端负责人:
     * 描述：
     */
    ALL_ORDER_DETAIL: 'order/getAllOrderDetail.do',

    /**
     * 接口名：订单-订单申请信息</br>
     * 后端负责人：王志倦</br>
     * 前端负责人:
     * 描述：进度百分比页面。如果不存在某项，则值为空。【与爱行销待跟进订单_申请信息录入页共用】
     */
    APPLY_INFO: 'order/getApplyInfo.do',

    /**
     * 接口名：申请材料补充-影像补件处理详情</br>
     * 后端负责人：彭震宇</br>
     * 前端负责人:
     * 描述：
     */
    GET_APPLY_SUPPLY_INFO: 'applysupply/getApplySupplyInfo.do',

    /**
     * 接口名：申请材料补充-影像补件提交</br>
     * 后端负责人：彭震宇</br>
     * 前端负责人:
     * 描述：
     */
    SUBMIT_APPLY_SUPPLYINFO: 'applysupply/submitApplySupplyInfo.do',

    /**
     * 接口名：审核信息-查询审核信息详情</br>
     * 后端负责人：陈筱倜</br>
     * 前端负责人:
     * 描述：
     */
     CHECK_DETAIL: 'checking/getCheckDetail.do',

    /**
     * 接口名：审核信息-确认审核</br>
     * 后端负责人：陈筱倜</br>
     * 前端负责人:
     * 描述：
     */
     SUBMIT_CHECK: 'checking/submitCheck.do',

     /**
     * 接口名：审核信息-统一审核信息接口（共用）</br>
     * 后端负责人：陈筱倜</br>
     * 前端负责人:
     * 描述：
     */
     UNITIVE_CHECK: 'checking/commonCheck.do',

    /**
     * 接口名：订单-取消订单</br>
     * 后端负责人：王志倦</br>
     * 前端负责人: 肖超峰
     * 描述：
     */
    CANCEL_ORDER: 'order/cancelOrder.do',

    /**
     * 接口名：订单-复制订单</br>
     * 后端负责人：王志倦</br>
     * 前端负责人: 肖超峰
     * 描述：
     */
    GET_COPY_CREATE_ORDER: 'order/getCopyCreateOrder.do',

    /**
     * 接口名：订单-创建订单</br>
     * 后端负责人：张振伟</br>
     * 前端负责人: 林泽永
     * 描述：
     */
    CREATE_ORDER: 'order/createOrder.do',

     /**
     * 接口名：订单-获取办理门店</br>
     * 后端负责人：张振伟</br>
     * 前端负责人: 林泽永
     * 描述：
     */
    GET_STORE_LIST: 'order/getStoreList.do',

     /**
     * 接口名：订单-获取渠道专员</br>
     * 后端负责人：张振伟</br>
     * 前端负责人: 林泽永
     * 描述：
     */
    GET_CHANNEL_USER_LIST: 'order/getChannelUserList.do',

     /**
     * 接口名：订单-OCR身份证证件识别</br>
     * 后端负责人：王志倦</br>
     * 前端负责人: 林泽永
     * 描述：
     */
    GET_CARD_INFO: 'common/getCardInfo.do',

    /**
     * 接口名：订单-H5订单列表</br>
     * 后端负责人：王志倦</br>
     * 前端负责人:
     * 描述：
     */
    ORDER_LIST: 'order/getOrderList.do',

    /**
     * 接口名：订单-待处理订单详情</br>
     * 后端负责人：王志倦</br>
     * 前端负责人: 肖超峰
     * 描述：
     */
    PENDING_ORDER_DETAIL: 'order/getPendingOrderDetail.do',

    /**
     * 接口名：申请信息模块-提交申请信息</br>
     * 后端负责人：张振伟</br>
     * 前端负责人:
     * 描述：
     */
    SUBMIT_APPLY_INFO: 'order/submitApplyInfo.do',

    /**
     * 接口名：订单-查询中介公司列表</br>
     * 后端负责人：张振伟</br>
     * 前端负责人:
     * 描述：不需要全加密
     */
    SELECT_AGENCIES: 'order/getAgencyCompanyList.do',

    /**
     * 接口名：信息录入-获取共同借款人或担保人信息</br>
     * 负责人：张振伟</br>
     * 描述： 肖超峰
     */
    GET_PARTNER_OR_GUARANTOR_INFO: 'partnerGuarantor/getPartnerOrGuarantorInfo.do',

    /**
     * 接口名：信息录入-获取共同借款人或担保人列表</br>
     * 负责人：张振伟</br>
     * 描述：肖超峰
     */
    GET_PARTNER_OR_GUARANTOR_LIST: 'partnerGuarantor/getPartnerOrGuarantorList.do',

    /**
     * 接口名：信息录入-提交共同借款人或担保人信息</br>
     * 负责人：张振伟</br>
     * 描述： 肖超峰
     */
    UPDATE_PARTNER_OR_GUARANTOR_INFO: 'partnerGuarantor/updatePartnerOrGuarantorInfo.do',

    /**
     * 接口名：信息录入-获取主借款人配偶信息</br>
     * 后端负责人：张振伟</br>
     * 前端负责人:
     * 描述：
     */
    GET_SPOUSE_INFO: 'spouse/getSpouseInfo.do',

    /**
     * 接口名：信息录入-提交主借款人配偶信息</br>
     * 后端负责人：张振伟</br>
     * 前端负责人:
     * 描述：
     */
    UPDATE_SPOUSE_INFO: 'spouse/updateSpouseInfo.do',

    /**
     * 接口名：询价模块-评估公司列表</br>
     * 后端负责人：陈筱倜</br>
     * 前端负责人:
     * 描述：
     */
    GET_ASSESSMENT_COMPANY: 'enquiry/getAssessmentCompany.do',

    /**
     * 接口名：询价模块-询价信息录入</br>
     * 后端负责人：陈筱倜</br>
     * 前端负责人:
     * 描述：
     */
    INPUT_ENQUIRY_INFO: 'enquiry/getEnquiryInfo.do',
    /**
     * 接口名：询价模块-询价信息提交</br>
     * 后端负责人：陈筱倜</br>
     * 前端负责人:
     * 描述：
     */
    SUBMIT_ENQUIRY_INFO: 'enquiry/submitEnquiryInfo.do',
    /**
     * 接口名：询价模块-上传询价单图片</br>
     * 后端负责人：陈筱倜</br>
     * 前端负责人:
     * 描述：
     */
     UPLOAD_ENQUIRY_IMG: 'enquiry/uploadEnquiryImage.do',

    /**
     * 接口名：获取新建订单mock数据</br>
     * 前端负责人:
     * 描述：mock数据用途
     */
     GET_NEW_ORDER_INFO_TPL: 'template/getNewOrderInfoTpl.do',

    /**
     * 接口名：订单-转他人录入"申请信息"提交</br>
     * 后端负责人: 张振伟
     * 描述：
     */
    SUBMIT_PERSON_INFO: 'anotherinput/submitPersonInfo.do',
    /**
     * 接口名：获取开放贷款城市</br>
     * 后端负责人: 无
     * 前端负责人: 林泽永
     * 描述：
     */
    GET_CHINA_JSON_DEV: 'city/getCityJsonDev.do',
    /**
     * 接口名：校验MD5</br>
     * 后端负责人: 无
     * 前端负责人: 林泽永
     * 描述：
     */
    MD5: 'city/md5.do',
    /**
     * 接口名：发起征信授权</br>
     * 后端负责人: 陈筱倜
     * 前端负责人: 肖超峰
     * 描述：
     */
    SEND_CREDIT_APPLY: 'credit/sendCreditApply.do',
    /**
     * 接口名：材料审核的影响上传和订单详情的拍照上传</br>
     * 后端负责人: 志倦
     * 前端负责人: 林泽永
     * 描述：
     */
    UPLOAD_MATERIALS: 'order/uploadMaterialsImage.do',
    /**
     * 接口名：订单-获取拍照上传</br>
     * 后端负责人: 志倦
     * 前端负责人: 林泽永
     * 描述：
     */
    SHOW_MATERIALS: 'order/getMaterials.do',
    /**
     * 接口名：订单-操作拍照上传</br>
     * 后端负责人: 王志倦
     * 前端负责人:
     * 描述：H5端提交或跳过；渠道APP端上传影像审核通过。
     */
    OPR_TAKE_PHOTO_UPLOAD: 'order/submitMaterials.do',
    /**
     * 接口名 申请材料补充图片上传</br>
     * 后端负责人: 志倦
     * 前端负责人: 林泽永
     * 描述：
     */
    UPLOAD_APPLY_SUPPLY_IMAGE: 'applysupply/uploadApplySupplyImage.do',
    /**
     * 接口名：接口名 我的进件-订单详情(不带银行相关信息)
     * 后端负责人: 王志倦
     * 前端负责人:
     * 描述：渠道app, 待跟进订单详情
     */
    GET_DELAY_ORDER_DETAIL: 'opmgt/getOrderDetail.do',
    /**
     * 接口名 我的进件-订单详情(带银行相关信息)
     * 后端负责人: 志倦
     * 前端负责人: 林泽永
     * 描述：渠道app, 所有订单详情
     */
    GET_ORDER_DETAIL_WITH_BANK_INFO: 'opmgt/getOrderDetailWithBankInfo.do'
};

// 后端GS url 图片拼接时使用
_App.GS_URL = prefix.split('/mtg2/')[0];

export default (name, type)=> {
    if ((type === 'json' || Env === 'DEVELOPMENT') && IS_H5_SERVER) {
        return jsonPrefix + api[name].split('/')[1].replace('.do', '.json');
    }
    return (type === 'json' ? jsonPrefix : prefix) + api[name];
};
