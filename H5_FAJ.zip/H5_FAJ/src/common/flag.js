export default {
    // 登陆超时
    LOGIN_TIMEOUT: '0',
    // 返回成功
    SUCCESS: '1',
    // 业务相关逻辑失败
    FAIL: '2',
    // 校验失败
    VALIDATOR_FAIL: '900504',
    // 未知错误 unknown mistake
    UNKNOWN_MISTAKE: '900101',
    // native接口请求成功
    NATIVE_SUCCESS: '1'
};
