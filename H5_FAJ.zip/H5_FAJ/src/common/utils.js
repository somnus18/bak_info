import JSEncrypt from './rsa';
import CryptoJsAes from 'crypto-js/aes';
import CryptoJsModeEcb from 'crypto-js/mode-ecb';
import CryptoJsPadPkcs7 from 'crypto-js/pad-pkcs7';
import CryptoJsEncUtf8 from 'crypto-js/enc-utf8';

let RSAENCRYPT = new JSEncrypt();
RSAENCRYPT.setPublicKey('-----BEGIN PUBLIC KEY-----\nMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDuAPJo1F8a+c1zcm980yE2ccte\n06lusIoK8eY5wJQ0cNFfp3VvIo0WlxHJ6bv5GCTw/hkxUMwS8AsJN2qLG9Ss+SEH\nR5SoQwhHGLZ/WFS5Ju+JAnky1WNljcLQ31EStBeEUk1mu/yhFsypAcnKK9nm3ycc\nkNM3QoG88OquZHGEGwIDAQAB\n-----END PUBLIC KEY-----');
const ua = navigator.userAgent.toUpperCase();
const chineCode = 3;

/**
 * 如果原生的String.prototype.padStart是函数,就使用原生的padStart。否则使用重写的padStart方法。
 */
if (!String.prototype.padStart) {
    String.prototype.padStart = function (maxLength, fillString = ' ') {
        let str = String(this),
            fillLen;
        if (str.length >= maxLength) {
            return str;
        }
        fillString = String(fillString);
        fillLen = maxLength - str.length;
        /**
         * 低版本浏览器不支持repeat方法
         */
        // return fillString
        //         .repeat(Math.ceil(fillLen / fillString.length))
        //         .slice(0, fillLen) + str;
        return Array.prototype.join.call({
                length: Math.ceil(fillLen / fillString.length) + 1
            }, fillString).slice(0, fillLen) + str;
    };
}

export default {
    /**
     * 设备常量定义
     */
    App: {
        // 当前环境是否为Android平台
        IS_ANDROID: ua.indexOf('ANDROID') !== -1,
        // 当前环境是否为IOS平台
        IS_IOS: ua.indexOf('IPHONE OS') !== -1,
        // 当前环境为爱行销app的Android或IOS平台 opmgt
        IS_NATIVE: ua.indexOf('OPMGT') !== -1,
        // 当前环境为微信环境
        IS_WEIXIN: ua.indexOf('MICROMESSENGER') !== -1,
        // 当前环境为本地环境
        IS_LOCAL: location.hostname === 'localhost',
        // QQ浏览器
        IS_QQ: ua.indexOf('QQBROWSER') !== -1
    },
    /**
     * 常用正则表达式
     */
    RegexMap: {
        // 身份证
        idCard: /^\d{15}$|^\d{18}$|^\d{17}(\d|X)$/,
        // 手机号码
        MobileNo: /^1[34587]\d{9}$/,
        // 中文名  实名认证中的姓名：二到十五位，由汉字和特殊字符“·”组成，用户提交认证时
        chinaName: /^[\u4e00-\u9fa5\·]{2,15}$/,
        // 邮箱
        Email: /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/,
        // 日期格式检测
        parseDateFormat: /\b(\d{4})\b[^\d]+(\d{1,2})\b[^\d]+(\d{1,2})\b(\s(\d{1,2})\:(\d{1,2})\:(\d{1,2}))?[^\d]?/,
        // 正整数
        integerNumber: /^\d+$/,
        // 非空且不大于6个字符的正整数
        positiveSix: /^[0-9]{0,6}$/,
        // 随机分配六位数用户号
        username: /^[\w-]{6,}$/,
        // 密码
        pwd: /^[A-Za-z0-9]{6,16}$/,
        // 最多六个小数
        sixDecimal: /^\d+(\.\d{1,6})?$/,
        // 最多2个小数
        secondDecimal: /^([1-9]\d*|0)(\.\d{1,2})?$/,
        // 固定电话
        Tel: /^(\d{3}-\d{8}|\d{4}-\d{7,8})$/,
        // 数字 整数或者小数
        number: /^\d+(\.\d+)?$/
    },
    /**
     * 获取URL参数对象
     * @param url 当无值代表当前页面
     * @example: http://xxx.com/a.do?productCode=P001
     * @returns {{productCode:'P001'}}
     */
    getQueryMap(url) {
        let regUrl = /^[^\?]+\?([\w\W]+)$/,
            regPara = /([^&=]+)=([\w\W]*?)(&|$|#)/g,
            arrUrl = regUrl.exec(url || location.href),
            ret = {},
            strPara,
            result;
        if (arrUrl && arrUrl[1]) {
            strPara = arrUrl[1];
            while ((result = regPara.exec(strPara))) {
                ret[result[1]] = result[2];
            }
        }
        return ret;
    },
    /**
     * 公共方法定义
     * @example: http://xxx.com/a.do?productCode=P001
     *     Result:  C.getParameter('productCode')  // 'P001'
     */
    getParameter(param) {
        let reg = new RegExp('[&,?,&amp;]' + param + '=([^\\&]*)', 'i'),
            value = reg.exec(decodeURIComponent(decodeURIComponent(location.search || location.hash)));
        return value ? value[1] : '';
    },
    /**
     * 本地数据操作
     * @param key
     * @param value
     */
    data(key, value) {
        let getItemValue = ()=> {
            let data = localStorage.getItem(key);
            try {
                data = JSON.parse(data);
            } catch (e) {
                console.log(e);
            }
            return data;
        };
        if (key && typeof value === 'undefined') {
            return getItemValue();
        }
        switch (toString.call(value)) {
            case '[object Undefined]':
                return getItemValue();
            case '[object Null]':
                localStorage.removeItem(key);
                break;
            default :
                localStorage.setItem(key, JSON.stringify(value));
                break;
        }
    },
    /**
     * forward跳转参数处理方法
     */
    forwardParam(options = {}) {
        let data = options.data,
            url = options.url,
            param = [],
            urlHost,
            urlData,
            key,
            tmp,
            paramKey;
        if (data) {
            for (paramKey in data) {
                data += paramKey + '=' + data[paramKey];
            }
            if (url.indexOf('?') > -1) {
                url += '&' + data;
            } else {
                url += '?' + data;
            }
        }
        // 本地开发浏览器环境
        if (!this.App.IS_NATIVE) {
            location.href = url;
            return;
        }
        // 过滤param
        if (url && url.indexOf('?') > -1) {
            urlHost = url.split('?')[0];
            urlData = this.getQueryMap(url);
            for (key in urlData) {
                tmp = '';
                try {
                    tmp = decodeURIComponent(urlData[key]);
                } catch (e) {
                    tmp = urlData[key];
                }
                param.push(key + '=' + encodeURIComponent(tmp));
            }
            url = urlHost + '?' + param.join('&');
        }
        url = url.replace(/(%2F)/ig, '/');
        options.url = url;
        options.data = data;
    },
    /**
     * 获取填写身份证相关的信息
     * @ param str 截取的出生日期字符串 或 身份证号
     * @ param type 传入第二个值是证明需返回的是string，否则是boolean
     type为true需要返回“年月日”，否则校验是否符合日期格式
     * @ param format 需返回的日期格式，默认：“yyyy年MM月dd日”
     * 检测身份证中的日期是否有效
     */
    strDateTime: function (str, type, format) {
        let isRight = false,
            r,
            now = new Date(),
            d,
            minDate,
            maxDate;

        // 如果传入的是身份证号时，从第6位开始截取8个字符
        if (str.length === 18) {
            str = str.substr(6, 8);
        } else if (str.length === 15) {
            // 19几几年的才有15位身份证的可能. 15位默认添加19
            str = '19' + str.substr(6, 6);
        }
        r = str.match(/^(\d{1,4})(-|\/)?(\d{1,2})\2(\d{1,2})$/);
        if (!r) return false;
        d = new Date(r[1], r[3] - 1, r[4]);
        minDate = new Date('1900-01-01');
        maxDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        // 如果不符合最大当前日期，最小1900年1月1日，则不通过日期校验
        if (d < minDate || d > maxDate) {
            return false;
        }
        isRight = (d.getFullYear() === ~~r[1] && (d.getMonth() + 1) === ~~r[3] && d.getDate() === ~~r[4]);
        if (type && isRight) {
            return this.parseDateFormat(d, format || 'yyyy-MM-dd');
        }
        return isRight;
    },
    /** 转换日期格式
     * @param date : 日期格式|String类型 (如：'2012-12-12' | '2012年12月12日' | new Date())
     * @param format : String类型 （如: 'yyyy年MM月dd日'或'yyyy年MM月dd日 hh时mm分ss秒',默认'yyyy-MM-dd'）
     * @example C.Utils.parseDateFormat(new Date(), 'yyyy年MM月dd日') 输出：'2014年04月29日'
     * @example C.Utils.parseDateFormat(new Date()) 输出：'2014-04-29'
     * @exmaple C.Utils.parseDateFormat('2014-05-07 16:09:47','yyyy年MM月dd日 hh时mm分ss秒')
     *          输出：'2014年05月07日 16时09分47秒'
     **/
    parseDateFormat: function (date, format) {
        let year = '',
            month = '',
            day = '',
            hours = '',
            minutes = '',
            seconds = '',
            dateMatch;
        if (!date) {
            return date;
        }
        function replaceDate(val) {
            return (val + '').toString().replace(/^(\d{4})(\d{2})(\d{2})$/, '$1/$2/$3');
        }

        if (date.length === 8) {
            date = replaceDate(date);
        } else if (date.length === 18) {
            date = replaceDate(date.substr(6, 8));
        } else if (date.length === 15) {
            // 19几几年的才有15位身份证的可能. 15位默认添加19
            date = replaceDate('19' + date.substr(6, 6));
        }
        format = format || 'yyyy-MM-dd';
        if (typeof date === 'string') {
            dateMatch = date.match(this.RegexMap.parseDateFormat);
            if (dateMatch) {
                year = dateMatch[1];
                month = dateMatch[2];
                day = dateMatch[3];
                hours = dateMatch[5];
                minutes = dateMatch[6];
                seconds = dateMatch[7];
            }
        } else {
            year = date.getFullYear();
            month = date.getMonth() + 1;
            day = date.getDate();
            hours = date.getHours();
            minutes = date.getMinutes();
            seconds = date.getSeconds();
        }
        month = this.addZero(month);
        day = this.addZero(day);
        hours = this.addZero(hours);
        minutes = this.addZero(minutes);
        seconds = this.addZero(seconds);
        return format.replace('yyyy', year).replace('MM', month).replace('dd', day).replace('hh', hours).replace('mm', minutes).replace('ss', seconds);
    },
    /**
     * 添加数字为一位时,在数字前添加0
     * @param val 1~9数字
     * @return 01~09数字
     */
    addZero(val) {
        return /^\d{1}$/.test(val) ? '0' + val : val;
    },
    /**
     * 将参数转换为字符串
     */
    paramToString(param) {
        let i,
            len = param.length;
        for (i = 0; i < len; i++) {
            param[i] = typeof param[i] === 'object' ? JSON.stringify(param[i]) : param[i];
        }
        return Array.prototype.join.apply(param, [',']);
    },
    /**
     * 转化数组中的键值对
     * @params [
     *    {k: '01', v: '精装', n: 'fitmentType'},
     *    {k: '02', v: '简装', n: 'fitmentType'}
     * ]
     * @return {'01': '精装','02': '简装'}
     */
    arrToObject(arr, type) {
        let obj = {};
        arr.forEach((item)=> {
            if (type === 'icon') {
                obj[item.k] = item.i;
            } else {
                obj[item.k] = item.v;
            }
        });
        return obj;
    },
    /**
     * 转化数组中的键值对
     * @params {'01': '精装','02': '简装'}
     * @return [
     *    {k: '01', v: '精装', n: 'fitmentType'},
     *    {k: '02', v: '简装', n: 'fitmentType'}
     * ]
     */
    objToArr(obj) {
        let arr = [],
            key,
            count = 0,
            // 选择器key是否以字母开头排序
            isLetterBegin = /^\{(\'|\")[a-zA-Z]{1}/.test(JSON.stringify(obj));
        for (key in obj) {
            arr[count] = {};
            arr[count]['k'] = key;
            arr[count]['v'] = obj[key];
            count++;
        }
        function compare(property) {
            return function (a, b) {
                return a[property] - b[property];
            };
        }

        return isLetterBegin ? arr : arr.sort(compare('k'));
    },
    // rsa加密
    rsa(text) {
        return RSAENCRYPT.encrypt(text);
    },
    // 生成唯一标识key
    getAeskey() {
        function s4() {
            return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
        }

        return s4() + s4() + s4() + s4();
    },
    /**
     * [encrypt 加密]
     * @return string ase加密
     */
    encrypt(data, key) {
        return CryptoJsAes.encrypt(JSON.stringify(data), CryptoJsEncUtf8.parse(key), {
            mode: CryptoJsModeEcb,
            padding: CryptoJsPadPkcs7
        });
    },
    /**
     * [decrypt 解密]
     * @return string ase解密
     */
    decrypt(data, key) {
        return CryptoJsAes.decrypt(data.toString(), CryptoJsEncUtf8.parse(key), {
            mode: CryptoJsModeEcb,
            padding: CryptoJsPadPkcs7
        }).toString(CryptoJsEncUtf8);
    },
    /**
     * 金额转换 元->万元
     * @param data 金额
     * @param pre 精度
     * @param multiple 转换缩小倍数 数值
     * @return String 万元
     */
    toWY(data, pre, multiple = 10000) {
        let result = 1 * data / multiple,
            isNull = this.isEmpty(data),
            decimalPointLen;
        pre = this.isEmpty(pre) ? 6 : pre;
        if (isNaN(data)) return data;
        if (!isNull) {
            decimalPointLen = (String(result).split('.')[1] && String(result).split('.')[1].length) || 0;
            return result.toFixed((decimalPointLen > pre ? pre : decimalPointLen) || 0);
        }
        return '';
    },
    /**
     * 金额转换 默认 万元->元
     * @param data 金额
     * @param pre 精度
     * @param multiple 转换扩大倍数 数值
     * @return String 元
     */
    toY(data, pre, multiple = 10000) {
        let result = 1 * data * multiple,
            isNull = this.isEmpty(data),
            decimalPointLen;
        pre = this.isEmpty(pre) ? 2 : pre;
        if (isNaN(data)) return data;
        if (!isNull) {
            decimalPointLen = (String(result).split('.')[1] && String(result).split('.')[1].length) || 0;
            return result.toFixed((decimalPointLen > pre ? pre : decimalPointLen) || 0);
        }
        return '';
    },
    /**
     * 初始化iscroll高度
     * 先实现 后修改
     */
    initScrollHeight(mainCls, viewCls, maxHeight) {
        // 内容的高
        let scrollMain = document.querySelector(mainCls).clientHeight,
            // 容器的高
            scrollView = document.querySelector(viewCls);
        if (scrollMain < maxHeight - 81) {
            // 内容小于可见区域高度时
            scrollView.style.height = scrollMain - 1 + 'px';
            scrollView.style.overflow = 'initial';
        } else {
            scrollView.style.height = 'auto';
            scrollView.style.overflow = 'hidden';
        }
    },
    /**
     * 浏览器是否支持localstorage，针对各种浏览器的隐私/无痕模式
     */
    isLocalStorageSupported() {
        let testKey = 'test',
            storage = window.localStorage;
        try {
            storage.setItem(testKey, 'testValue');
            if (storage.getItem(testKey)) {
                storage.removeItem(testKey);
                return true;
            } else {
                return false;
            }
        } catch (error) {
            return false;
        }
    },
    /**
     * 省市区,
     * @params 100100/北京市
     * @return 北京市
     */
    getAreaName(str) {
        return str ? str.split('/')[1] : '';
    },
    /**
     * 判断字符串或数字是否为整数
     * @params '100'、100 或 100.1
     * @return true 或 false
     */
    isInteger(val) {
        return this.RegexMap.integerNumber.test(val); // Number.isInteger(val);
    },
    /**
     * 校验金额格式:只能由数字、小数点组成。小数点不是必输项，一旦包含小数点，小数点后最少有1位数字，最多只能有2位数字
     * @param val
     * @return Boolean
     */
    amountFormat(val) {
        return this.RegexMap.secondDecimal.test(val);
    },
    /**
     * 校验数字:只能由数字、小数点组成。小数点不是必输项
     * @param val
     * @return Boolean
     */
    isNumber(val) {
        return this.RegexMap.number.test(val);
    },

    /**
     * 计算时间差
     * @param startDate 开始时间的时间戳
     * @param endDate 结束时间的时间戳
     * @returns {*} 输出：时间差
     */
    computeDate(startDate, endDate) {
        let y, m, d, start, end;
        start = startDate ? new Date(startDate) : new Date(0);
        end = endDate ? new Date(endDate) : new Date(0);
        y = end.getFullYear() - start.getFullYear() + 1;
        m = end.getMonth() - start.getMonth();
        d = end.getDate() - start.getDate();
        if (y >= 0) {
            (m < 0 || (m === 0) && (d < 0 || d === 0)) && y--;
        } else {
            y = 0;
        }
        return y;
    },
    /**
     * 计算年龄
     * @param birth C.Utils.getAge(new Date()) 或 C.Utils.getAge('2014-04-29')
     *              或 C.Utils.getAge('2014年04月29日') 或 C.Utils.getAge('20140429') 或 C.Utils.getAge('身份证号')
     *              输出：年龄
     * @returns {*} 输出：年龄
     */
    getAge(birth, endDate) {
        let returnAge,
            strBirthdayArr = this.parseDateFormat(birth).split('-'),
            birthYear = ~~strBirthdayArr[0],
            birthMonth = ~~strBirthdayArr[1],
            birthDay = ~~strBirthdayArr[2],
            d = endDate ? new Date(endDate) : new Date(),
            nowYear = d.getFullYear(),
            nowMonth = d.getMonth() + 1,
            nowDay = d.getDate(),
            yearDiff,
            monthDiff,
            dayDiff;
        yearDiff = nowYear - birthYear; // 年之差
        if (yearDiff >= 0) {
            if (nowMonth === birthMonth) {
                dayDiff = nowDay - birthDay;// 日之差
                if (dayDiff < 0) {
                    returnAge = yearDiff - 1;
                } else {
                    returnAge = yearDiff;
                }
            } else {
                monthDiff = nowMonth - birthMonth;// 月之差
                if (monthDiff < 0) {
                    returnAge = yearDiff - 1;
                } else {
                    returnAge = yearDiff;
                }
            }
        } else {
            returnAge = 0;// 返回1 表示出生日期输入错误 晚于今天
        }
        return returnAge;// 返回周岁年龄
    },

    compareAge(birthDate, min = 18, max = 65) {
        let age = this.getAge(birthDate);
        return age !== '' ? min <= age && age <= max : null;
    },
    /**
     * 获取日期选择
     * @param day 日期
     * @returns
     */
    getDateSelect(day) {
        let dateSelect = [],
            d,
            i;
        for (i = 0; i <= day; i++) {
            d = new Date();
            d.setDate(d.getDate() - i);
            dateSelect[i] = {};
            dateSelect[i].k = C.Utils.parseDateFormat(d);
            dateSelect[i].v = C.Utils.parseDateFormat(d);
        }
        return dateSelect;
    },
    /**
     * 校验金额范围
     * @param val 需比较的值
     * @param type 最大值范围, 默认为: 1
     *  1: 9999999999.99
     *  2: 999999.99
     *  3: 100
     *  4: 10
     *  5: 20
     * @param comparisonType 比较范围区间 ,是否还等于。 默认为 gEToLE
     *  gToL: 大于和小于
     *  gEToL: 大于等于和小于
     *  gToLE: 大于和小于等于
     *  gEToLE: 大于等于和小于等于
     * @returns {Function}
     */
    checkAmountRange(val, type, comparisonType) {
        let maxTemp = 9999999999.99;

        function comparison(min, max, cType) {
            switch (cType) {
                // 大于和小于 greaterToLess
                case 'gToL':
                    return val < max && val > min;
                // 大于等于和小于 greaterEqualToLess
                case 'gEToL':
                    return val <= max && val > min;
                // 大于和小于等于 greaterToLessEqual
                case 'gToLE':
                    return val < max && val >= min;
                // 大于等于和小于等于 greaterEqualToLessEqual
                case 'gEToLE':
                    return val <= max && val >= min;
                // 大于等于和小于等于 greaterEqualToLessEqual
                default :
                    return val <= max && val >= min;
            }
        }

        return function (min = 0, max) {
            let isTrue;
            /**
             * '1': '需小于100亿元',
             建筑面积、房屋套内面积/m²
             '2': '需小于100万平方米',
             社保缴纳年限(月)(0, 1200)、本地居住年限、总楼层数量
             '3': '不能超过100月',
             '3_1': '不能超过100年',
             '3_2': '不能超过100层',
             家庭拥有住房套数
             '4': '不能超过10套',
             履约险投保权限(天)
             '5': '不能超过20天'
             */
            switch (type) {
                // 成交价,登记价、单套评估价值、申请金额-商贷(万元)、申请金额-公积金(万元)、家庭月支出(元)、税后月收入(月)、社保/公积金缴费基数(元)
                case 1:
                    max = max || maxTemp;
                    break;
                // 建筑面积、房屋套内面积/m² 999999.99
                case 2:
                    max = max || 999999.99;
                    break;
                // 社保缴纳年限(月)、本地居住年限、总楼层数量 100
                case 3:
                case 4:
                    //  家庭拥有住房套数
                    max = max || 100;
                    break;
                default :
                    max = max || maxTemp;
                    break;
            }
            C.debug.log(min, max, type, comparisonType);
            isTrue = comparison(min, max, comparisonType);
            return isTrue;
        };
    },
    /**
     * 返回字符串长度，汉子计数为2
     * @param str 字符串
     * @example '张三' 输出：6
     * @example '张三2李四' 输出：13
     */
    strLength(str) {
        let a = 0,
            i = 0;
        str = str + ''; // 转成字符串
        for (; i < str.length; i++) {
            if (str.charCodeAt(i) > 255) {
                a += chineCode; // 按照预期计数增加2
            } else {
                a++;
            }
        }
        return a;
    },
    /**
     * 判断数值是否存在
     * @param val
     * @returns {boolean}
     */
    isEmpty(val) {
        return val === null || typeof val === 'undefined' || val === '';
    },
    /**
     * 判断是否含有小写字母
     * @param str
     * @returns {boolean}
     */
    hasLowercase(str) {
        let result = str.match(/^.*[a-z]+.*$/);
        if (result === null) return false;
        return true;
    },
    /**
     * 数字金额转大写
     * @param number 字符串或数字类型，如 9999 或 '9999' 或 '12,255.00'
     *                参数长度1-12位（单位：元，最大单位：仟亿）
     * @return str 返回值 'xxxx元整' ，如果数据过长
     * @example C.Utils.parseUpperNumberMoney('12,255.00');  // 返回'壹万贰仟贰佰伍拾伍元整'
     */
    parseUpperNumberMoney(num) {
        // 判断是否符合规则 仟佰
        if (isNaN(Number(num)) || !/^\d{1,13}(\.\d+)?$/.test(num)) return '';
        num = (num + '').replace(/\,/g, '').replace(/\.(\d{1,2})\d*?$/g, '.$1').replace(/\.[0]+$/, '').replace(/\.([^0]+)[0]+$/, '.$1');  // 替换掉千分位符号和小数点及后面的数
        let unit = '万仟佰拾亿仟佰拾万仟佰拾元',
            str = '',
            rightMatch = num.match(/\.(\d*)$/),
            i;
        if (rightMatch && rightMatch.length === 2) {
            num = num.replace(rightMatch[0], rightMatch[1]);
            unit += ('角分'.substring(0, rightMatch[1].length));
        }
        unit = unit.substr(unit.length - num.length);
        for (i = 0; i < num.length; i++) {
            str += '零壹贰叁肆伍陆柒捌玖'.charAt(num.charAt(i)) + unit.charAt(i);
        }
        return str.replace(/零(仟|佰|拾)/g, '零').replace(/(零)+/g, '零').replace(/零(万|亿)/g, '$1').replace(/(.+)零元/g, '$1元').replace(/(亿)万|元(拾)|角(拾)|/g, '$1$2').replace(/^元零?|零$/g, '').replace(/元$/g, '元整').replace(/零角/g, '');
    },
    /**
     * @param {key: value}
     * @return 日期默认值
     **/
    pickerDateObject(info, obj, index) {
        let _key, _value;
        for (let k in obj) {
            _key = k;
            _value = obj[k];
        }
        return index >= 0 ? info[_key][index][_value] || '' : info[_key][_value] || '';
    },
    /**
     * @param(url) String
     * 图片填充http前缀
     * @return 完整图片的链接
     **/
    httpAddImage(imgArr) {
        let token;
        token = (C.Utils.data(C.DK.APP_USER_LOGIN_INFO) || {}).token || (C.Utils.data(C.DK.USER_LOGIN_INFO) || {}).token;
        return _App.GS_URL + imgArr + '?token=' + token;
    },
    /**
     * @param 图片链接
     * 图片链接返回图片ID
     * @reutrn imgId
     **/
    imageSpliceId(imgUrl) {
        let isThumbImg = /showImage\/thumb_/.test(imgUrl),
            i = isThumbImg ? imgUrl.indexOf('showImage/thumb_') : imgUrl.indexOf('showImage/');
        return imgUrl.substring(i + (isThumbImg ? 16 : 10)).split('?')[0];
    }
};
