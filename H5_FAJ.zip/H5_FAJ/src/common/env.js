import Utils from './utils';

// Android iOS app
// userAgent添加opmgt/stg1(环境)
const uaParams = navigator.userAgent.match(/opmgt\/(.*)/);
// 获取环境
let dev = uaParams && uaParams[1];

if (Utils.getParameter('env')) {
    sessionStorage.setItem('base_env', Utils.getParameter('env') || _App.env);
}

// PC浏览器浏览器时,环境由_App的env决定
if (!uaParams) {
    dev = sessionStorage.getItem('base_env') || _App.env;
}

// 域名为fang.pingan.com.cn生产时,直接将环境更改为生产
if (location.host === 'fang.pingan.com.cn') {
    dev = 'PRODUCTION';
}

// prd为生产环境
dev = (dev + '').toLowerCase() === 'prd' ? 'PRODUCTION' : dev;
// dev为开发环境
dev = (dev + '').toLowerCase() === 'dev' ? 'DEVELOPMENT' : dev;

export default (dev || 'PRODUCTION').toUpperCase();
