import Utils from './utils';

export default {
    /**
     * 证件校验
     * @param String
     * @param String 证件类型 校验身份证号码 15位或18位字符
     * @param Boolean true: 校验证件是否为空和格式, false:仅校验证件格式
     * @return Object
     */
    idNo(idNo, type, canNull) {
        let checkResult = {result: true},
            formatErrorResult = {result: false, error: '证件号码格式不对'};
        if (!idNo) {
            canNull && (checkResult = {result: false, error: '证件号码不能为空'});
        } else {
            /**
             * {
                    'Ind01': '身份证',
                    'Ind02': '户口簿',
                    'Ind12': '中国护照',
                    'Ind10': '警官证',
                    'Ind04': '军官证',
                    'Ind05': '士兵证',
                    'Ind06': '港澳居民通行证',
                    'Ind07': '台湾居民通行证',
                    'Ind09': '外国人居留证',
                    'Ind13': '外国人永久居留证',
                    'Ind03': '外国护照',
                    'Ind11': '其他证件'
                }
             */
            switch (type) {
                // 身份证：15或18位字符
                case 'Ind01':
                    if (!(Utils.RegexMap.idCard.test(idNo) && Utils.strDateTime(idNo))) {
                        checkResult = formatErrorResult;
                    }
                    break;
                // 护照 2
                // 士兵证
                // 军官证：6-50位字符(可输中文)
                // case 'Ind12':
                // case 'Ind05':
                // case 'Ind04':
                //     if (!/^[\u4e00-\u9fa5a-zA-Z\d]{6,50}$/.test(idNo)) {
                //         checkResult = formatErrorResult;
                //     }
                //     break;
                // 港澳台回乡证或台胞证: 5-50位字符，只允许大写字母和数字，最多输入50位
                // case 'Ind06':
                // case 'Ind07':
                //     if (!/^[A-Z\d]{5,50}$/.test(idNo)) {
                //         checkResult = formatErrorResult;
                //     }
                //     break;
                default :
                    // 其他：3-50位字符，最多输入50位
                    // if (!/^[a-zA-Z\d]{3,50}$/.test(idNo)) {
                    //     checkResult = formatErrorResult;
                    // }
                    if (C.Utils.strLength(idNo) > 32) {
                        checkResult = formatErrorResult;
                    }
                    break;
            }
        }
        return checkResult;
    },
    /**
     * 姓名 2到4位中文
     * @param String
     * @return Object
     */
    idName(idName) {
        let checkResult = {result: true};

        if (!idName) {
            checkResult = {result: false, error: '姓名不能为空'};
        } else if (!(Utils.RegexMap.chinaName.test(idName))) {
            checkResult = {result: false, error: '姓名格式不对'};
        }
        return checkResult;
    },
    /**
     * 手机号码 /^1[34587]\d{9}$/
     * @param String
     * @return Object
     */
    MobileNo(mobileNo) {
        let checkResult = {result: true};

        if (!mobileNo) {
            checkResult = {result: false, error: '手机号码不能为空'};
        } else if (!(Utils.RegexMap.MobileNo.test(mobileNo))) {
            checkResult = {result: false, error: '手机号码格式不对'};
        }
        return checkResult;
    },
    /**
     * 邮箱 /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/
     * @param String
     * @return Object
     */
    email(email) {
        let checkResult = {result: true};

        if (!email) {
            checkResult = {result: false, error: '邮箱不能为空'};
        } else if (!(Utils.RegexMap.Email.test(email))) {
            checkResult = {result: false, error: '邮箱格式不对'};
        }
        return checkResult;
    },
    // 密码
    pwd: function (result) {
        if (!result) {
            return {result: false, error: '密码不能为空'};
        } else if (!Utils.RegexMap.pwd.test(result)) {
            return {result: false, error: '密码请输入6~16位的字母或数字'};
        }
        return {result: true};
    },
    // 验证用户名
    username: function (username) {
        if (!username) {
            return {result: false, error: '用户名不能为空'};
        } else if (!Utils.RegexMap.username.test(username)) {
            return {result: false, error: '用户名格式不对'};
        }
        return {result: true};
    },
    // 固定电话
    tel: function (tel) {
        // 判断非空
        if (tel && !Utils.RegexMap.Tel.test(tel)) {
            return {result: false, error: '固定电话格式不对'};
        }
        return {result: true};
    }
};
