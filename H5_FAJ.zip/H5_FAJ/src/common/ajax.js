/**
 * Created by jiangxiaogang938 on 17/6/8.
 * description 重写zepto ajax
 */
import Utils from './utils';
import Env from './env';

let _ajax = $.ajax,
    keyObj = {},
    anotherUser = function (opt) {
        return opt._userType === C.Constant.USER_TYPE || C.Utils.getParameter('_ut') === C.Constant.USER_TYPE;
    };

$.ajaxSettings.cache = false;
// 超时 30s
$.ajaxSettings.timeout = 0;
$.ajaxSettings.type = 'POST';
$.ajaxSettings.dataType = Env === 'DEVELOPMENT' ? 'json' : 'text';
$.ajaxSettings.beforeSend = function (xhr) {
    // 使用json向后端传参
    Env !== 'DEVELOPMENT' && arguments[1].type.toLocaleLowerCase() !== 'get' && xhr.setRequestHeader('Content-Type', 'text/plain');
};
$.ajaxSettings.error = function (xhr, errorType) {
    C.UI.stopLoading();
    let str = '';
    if (!navigator.onLine || errorType === 'timeout') {
        str = '网络连接超时，请更换网络！';
    } else {
        str = '系统繁忙，请稍后再试！';
    }
    C.debug.log('error xhr', xhr, errorType, str);
    // 弹出框
    C.Native.tip(str);
};
$.ajaxSettings.complete = function (res, url, tempData) {
    // 集合内的code值不提示
    let whiteCode = [],
        msg = res.msg || res.responseMsg,
        title = '提示';
    try {
        if (res.flag === C.Flag.SUCCESS) {
            return;
        }
        C.UI.stopLoading();
        // 本地环境且登陆失效,跳转至登陆页面
        if (res.flag === C.Flag.LOGIN_TIMEOUT) {
            if (Utils.App.IS_NATIVE) {
                // native登录超时
                C.Utils.data(C.DK.APP_USER_LOGIN_INFO, null);
                // Native提供退出登陆的接口
                C.Native.tokenTimeOut(msg);
            } else if (anotherUser(tempData)) {
                // 子页面登录超时,跳转至失效页面
                C.Utils.data(C.DK.SUB_USER_LOGIN_INFO, null);
                C.Native.forward({
                    url: 'index.html#/failure'
                });
            } else {
                // 主页面登录超时的时候跳转到登录页
                C.Native.tip(msg);
                // 生产使用pc端访问渠道app直接return
                if (location.href.indexOf('fang.pingan.com.cn/faj/2/app/') !== -1) {
                    return;
                }
                C.Utils.data(C.DK.USER_LOGIN_INFO, null);
                C.Native.forwardWebView({
                    url: 'index.html#/login?redirectUrl=' + encodeURIComponent(location.href)
                });
            }
        } else {
            // 订单创建失败
            title = url.indexOf(C.Api('CREATE_ORDER')) !== -1 ? '订单创建失败' : title;
            if (msg && $.inArray(res.flag, whiteCode) === -1) {
                if (url.toLowerCase().indexOf(C.Api('UPLOAD_MATERIALS').toLowerCase()) !== -1 && res.responseCode === C.Flag.UNKNOWN_MISTAKE) {
                    C.Native.tip('上传的图片中有失败的上传, 请重新上传。');
                    return;
                }
                if (res.flag === C.Flag.FAIL && !Utils.App.IS_NATIVE) {
                    C.UI.warn({
                        title: title,
                        okText: '确认',
                        content: msg
                    });
                } else {
                    C.Native.tip(msg);
                }
            }
        }
    } catch (e) {
        C.debug.error('ajax complete catch throw Error', e);
    }
};
export default (opt)=> {
    opt.beforeSend = opt.beforeSend || undefined;
    let tempData = $.extend(true, {}, opt.data),
        fn = {
            error: opt.error || function () {
            },
            success: opt.success || function () {
            },
            complete: opt.complete || function () {
            }
        },
        // 扩展增强处理
        _opt = $.extend(opt, {
            error(xhr, textStatus) {
                if (xhr.code) {
                    // error.code 有值  native.call.js errHandler统一提示
                    return;
                }
                // 执行自定义方法之后  再执行扩展方法
                fn.error(xhr, textStatus);
                $.ajaxSettings.error.apply($.ajaxSettings.error, arguments);
            },
            success(data) {
                let url = (Utils.App.IS_QQ ? _opt.url : (arguments[2].responseURL || _opt.url)).toLowerCase();
                // vue的双大括号会将数据解释为纯文本，而非 HTML 。可以防止 XSS 攻击
                // /^{.+}$/.test(data) 简单判断是否为JSON字符串
                data = typeof data === 'object' ? data
                    : JSON.parse(/^{.+}$/.test(data) ? data : Utils.decrypt(data, keyObj[url]));
                delete keyObj[url];
                C.debug.log(url + '的返回数据：', data);
                fn.success(data);
                $.ajaxSettings.complete(data, url, tempData);
            },
            complete() {
                fn.complete();
            }
        }),
        paramObject = {
            // 设备
            os: C.Utils.App.IS_IOS ? 'iOS' : 'Android',
            // H5资源上线版本号
            ts: _App.ts,
            v: _App.version,
            _: Date.now()
        },
        // H5主分页面token
        loginInfo = Utils.data(C.DK.USER_LOGIN_INFO),
        // 分页面token
        subLoginInfo = Utils.data(C.DK.SUB_USER_LOGIN_INFO),
        // 渠道app token
        appLoginInfo = Utils.data(C.DK.APP_USER_LOGIN_INFO),
        aeskey = Utils.getAeskey(),
        rsaString = Utils.rsa(aeskey),
        len = rsaString.length,
        // 172补充00000172
        pwdStart = ('' + len).padStart(8, '0'),
        noTokenUrls = [
            C.Api('USER_LOGIN'),
            C.Api('GET_TICKET')
        ],
        noLoadingUrls = [
            C.Api('ORDER_LIST_WITH_FILTER'), // ORDER_LIST_WITH_FILTER
            C.Api('OPMGT_MYENTRY'),
            C.Api('ORDER_LIST'),
            C.Api('SELECT_AGENCIES'),
            C.Api('GET_CHANNEL_USER_LIST'),
            // 审批补件图片上传
            C.Api('UPLOAD_EVIDENCE_MATERIALS'),
            // 询价信息图片上传
            C.Api('UPLOAD_ENQUIRY_IMG'),
            C.Api('CANCEL_ORDER')
        ];
    if (!C.Utils.isLocalStorageSupported()) {
        C.UI.stopLoading();
        C.UI.warn({
            title: '提示',
            okText: '确认',
            content: '当前浏览器被设置为隐私/无痕模式,请更改设置。'
        });
        return;
    }

    /* -----------------------参数配置开始----------------------------- */
    // data数据没有参数传{}
    _opt.data = _opt.data || {};
    // 开发环境请求方式都使用get
    _opt.type = C.Env === 'DEVELOPMENT' ? 'get' : _opt.type || 'post';

    /* -----------------------参数配置结束----------------------------- */
    if (Utils.App.IS_NATIVE) {
        appLoginInfo && (paramObject.token = appLoginInfo.token);
    } else {
        if ($.inArray(opt.url, noTokenUrls) === -1 && location.href.indexOf('fang.pingan.com.cn/faj/2/app/') === -1) {
            if (anotherUser(_opt.data)) {
                subLoginInfo && (paramObject.token = subLoginInfo.token);
                _opt.data = $.extend(true, _opt.data, {orderId: (subLoginInfo || {}).orderId});
            } else {
                loginInfo && (paramObject.token = loginInfo.token);
            }
        }
    }

    // 上下拉加载接口不统一添加loading
    if ($.inArray(opt.url, noLoadingUrls) === -1) {
        C.UI.loading();
    }

    if (_opt.url.indexOf('?') !== -1) {
        _opt.url += ('&' + $.param(paramObject));
    } else {
        _opt.url += ('?' + $.param(paramObject));
    }
    // 保存aeskey值
    keyObj[_opt.url.toLowerCase()] = aeskey;
    // 续app token
    if (Utils.App.IS_NATIVE) {
        C.Native.appTokenOvertime();
    }
    // 删除图片的日志
    delete tempData.imgBase64;
    C.debug.log(_opt.url + '入参：', JSON.stringify(tempData));
    if (C.Env !== 'DEVELOPMENT' && _opt.type.toLocaleLowerCase() !== 'get' && $.type(_opt.processData) === 'undefined') {
        _opt.data = pwdStart + rsaString + Utils.encrypt(_opt.data, aeskey);
    }
    _opt.dataType = _opt.type.toLocaleLowerCase() === 'get' ? 'json' : 'text';
    _ajax(_opt);
};
