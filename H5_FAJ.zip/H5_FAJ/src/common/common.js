import Api from './api';
import Utils from './utils';
import Env from './env';
import Flag from './flag';
import Constant from './constant';
import Validator from './validator';
import Expend from './ajax';

// 重写扩展ajax方法
$.ajax = Expend;

export default {
    Utils,
    Flag,
    Constant,
    T: Constant.TITLE,
    HT: Constant.HINT_TEXT,
    DK: Constant.DK,
    Api,
    debug: {
        error() {},
        log() {},
        warn() {},
        clear() {}
    },
    Env,
    Validator
};
