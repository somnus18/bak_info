import Vue from 'vue';
import Vuex from 'vuex';
import header from './modules/common/header';
import tip from './modules/common/tip';
import loading from './modules/common/loading';
import dialog from './modules/common/dialog';
// ES6模块方式
/**
 * vue-router中promise的兼容
 */
import Es6Promise from 'es6-promise';
Es6Promise.polyfill();

Vue.use(Vuex);
/* eslint-disable no-new */
export default new Vuex.Store({
    modules: {
        header,
        tip,
        loading,
        dialog
    }
});
