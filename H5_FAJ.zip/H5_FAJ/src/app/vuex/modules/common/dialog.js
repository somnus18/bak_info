import * as types from '../../mutation-types';

export default {
    state: {
        data: {
            isShowDialog: false,
            title: '',  // 使用title替代headerText,headerText废弃
            titleIcon: '',
            content: '',
            link: '',
            cancelText: '',
            okText: '确认',
            cancel: null,
            ok: null,
            isCancelCloseDialog: true,
            isOkCloseDialog: true,
            isShowClose: false,
            isXCloseDialog: true
        }
    },
    actions: {},
    mutations: {
        [types.SET_DIALOG](state, item) {
            state.data = Object.assign(state.data, item);
        }
    }
};
