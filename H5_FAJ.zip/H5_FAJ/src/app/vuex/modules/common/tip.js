import * as types from '../../mutation-types';

export default {
    state: {
        data: {
            isShowTip: false,
            msg: ''
        }
    },
    getters: {},
    actions: {},
    mutations: {
        [types.SET_TIP](state, item) {
            state.data = item;
        }
    }
};
