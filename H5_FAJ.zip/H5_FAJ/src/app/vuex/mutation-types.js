// 标题
export const SET_HEADER = 'SET_HEADER';
export const SET_HEADER_R_T = 'SET_HEADER_R_T';
export const SET_HEADER_R_I = 'SET_HEADER_R_I';
export const SET_HEADER_R_T_I = 'SET_HEADER_R_T_I';

// tip
export const SET_TIP = 'SET_TIP';

// loading
export const SET_LOADING = 'SET_LOADING';

// SET_DIALOG
export const SET_DIALOG = 'SET_DIALOG';
