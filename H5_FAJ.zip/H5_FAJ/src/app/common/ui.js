import Native from './native';
import Utils from 'common/utils';
import * as types from '../vuex/mutation-types';

export default {
    // C.UI.loading();
    tip(msg) {
        Native.tip(msg);
    },
    loading(msg = '加载中...') {
        Native.loadingBegin(msg);
    },
    // C.UI.stopLoading();
    stopLoading() {
        Native.loadingFinish();
    },
    showDialog(opt = {}) {
        opt.isShowDialog = true;
        opt.cancelText = opt.cancelText || '';
        opt.okText = opt.okText || '确认';
        opt.ok = opt.ok || '';
        opt.cancel = opt.cancel || '';
        opt.content = opt.content || '';
        opt.title = opt.title || '';
        opt.titleIcon = opt.titleIcon || '';
        opt.onlyBtn = opt.onlyBtn || false;
        opt.isCancelCloseDialog = opt.isCancelCloseDialog || true;
        opt.isOkCloseDialog = opt.isOkCloseDialog || true;
        Utils.vm.$store.commit(types.SET_DIALOG, opt);
    },
    success(opt = {}) {
        opt.titleIcon = 'pass';
        this.showDialog(opt);
    },
    error(opt = {}) {
        opt.titleIcon = 'fail';
        this.showDialog(opt);
    },
    warn(opt = {}) {
        opt.titleIcon = 'warn-native';
        this.showDialog(opt);
    }
};
