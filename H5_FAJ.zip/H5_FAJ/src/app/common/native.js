import App from './adapter';
import Utils from 'common/utils';
import Env from 'common/env';
import * as types from '../vuex/mutation-types';

let defaultCallback = function () {
};

_App.H5_URL = location.protocol + '//' + location.host + location.pathname.split('index.html')[0]; // H5测试静态服务器

function prefixURL(url) {
    url = url.indexOf('index.html') > -1 ? url : 'index.html' + url;
    return /^(http|https)/.test(url) ? url : _App.H5_URL + url;
}

export default {
    /**
     * 显示加载动画 C.UI.loading();
     * @param .msg 当不允许取消加载动画时 提示信息
     */
    loadingBegin: function (msg = '') {
        if (!Utils.App.IS_NATIVE) {
            Utils.vm.$store.commit(types.SET_LOADING, {
                isShow: true,
                msg: msg
            });
            return;
        }
        App.call('loadingBegin', {msg: msg});
    },

    /**
     * 关闭加载动画 C.UI.stopLoading();
     */
    loadingFinish: function () {
        if (!Utils.App.IS_NATIVE) {
            Utils.vm.$store.commit(types.SET_LOADING, {
                isShow: false
            });
            return;
        }
        App.call('loadingFinish');
    },

    timer: null,
    /**
     * 提示
     * @param .text 字符串 C.Native.tip('提示内容');
     * 在main.js中重写C.Native.tipMsg
     * 调用方式C.Native.tip('提示内容'),使在pc端看到tip效果
     */
    tip: function (text = '') {
        if (!Utils.App.IS_NATIVE) {
            let msg = text,
                duration = 2000;
            if (typeof text === 'object') {
                msg = text.msg;
                duration = text.duration || duration;
            }
            Utils.vm.$store.commit(types.SET_TIP, {
                isShowTip: true,
                msg: msg
            });
            clearTimeout(this.timer);
            this.timer = setTimeout(()=> {
                Utils.vm.$store.commit(types.SET_TIP, {
                    isShowTip: false
                });
            }, duration);
            return;
        }
        App.call('tip', {text: text});
    },

    /**
     * TalkingData
     * @param .eventId 字符串 埋点id
     * @param .eventLabel 字符串 埋点label
     * @param .jsonData 对象 埋点扩展字段
     *  如：{
         *      custId: '',// 值为字符串
         *      custName:''
         *  }
     */
    TD: function (options = {}) {
        App.call('TDOnEven', options);
    },
    /**
     * 新开webView开启新页面
     * @param options 对象 {title:'',url:''}
     * .url 字符串 跳转的链接
     * .callback 函数 function(){} 请求处理
     * 跳转参数
     */
    forwardWebView: function (options = {}) {
        options.url = prefixURL(options.url);
        Utils.forwardParam(options);
        App.call('forwardToNewPage', options);
    },
    /**
     * 在当前webview开启新页面
     * @param options 对象 {title:'',url:''}
     * .url 字符串 跳转的链接
     * .callback 函数 function(){} 请求处理
     * 跳转参数
     */
    forward: function (options = {}) {
        options.url = prefixURL(options.url);
        Utils.forwardParam(options);
        App.call('forwardInCurPage', options);
    },
    /**
     * 页面返回
     * @param options {url:''}
     * .url back返回的url,为空默认返回上一个页面,
     * .data 返回后Native调用$$.EventListener.onBack(url, data)事件, 并将参数data传递给onback方法
     *                如果返回到流程开始的的页面,需要传页面名字,如'info_loan.html'
     * .callback 函数 function(){} 请求处理
     */
    back: function (options = {}) {
        let url = options.url || '';
        // 本地开发浏览器环境
        if (!Utils.App.IS_NATIVE) {
            if (url) {
                location.href = prefixURL(options.url);
                return;
            }
            history.back();
        }
        if (url) {
            options.url = prefixURL(options.url);
        }
        App.call('back', options);
    },

    /**
     * 发送HTTP请求
     * @import jQuery|Zepto
     * @param options 对象{type:'get',data:{},success:function(res){},error:function(res){}}
     * @param .data JSON对象 请求入参
     * @param .type 字符串 请求方式，默认get
     * @param .url 字符串 请求路径
     * @param .header 字符串 请求头设置
     * @param .success 函数 function(){} 请求成功处理
     * @param .error  函数 function(){} 请求失败处理
     * @param .flag 是否需要Native加密,flag:1加密,0不加密
     */
    request: function (options) {
        let data = options.data || {},
            type = options.type || 'post';
        if (data && typeof data === 'object') {
            data = JSON.stringify(data);
        }
        // 是否需要Native加密,flag:1加密,0不加密
        options.flag = options.flag || '1';
        options.data = data;
        options.type = type;
        options.header = options.header || '';
        App.call('request', options);
    },

    /**
     * 设置头部信息
     * @param options {title:'标题',isBack:true,leftCallback:function(){},isClose:true,closeCallback:function(){}}
     * .title 字符串 设置头部标题
     * .isBack 布尔值 是否有返回图标
     * .leftText 左边文案
     * .leftIcon close
     * .leftCallback function(){} 函数 设置左边回调
     * .rightText 右边文案
     * .rightIcon  右边图标 share
     * .rightCallback function(){} 函数 设置右边回调
     * .data 扩展数据 Json格式
     */
    setHeader: function (options = {}) {
        let clear = options.clear;
        this.loadingBegin();
        // 清除日志
        if (typeof clear === 'undefined') {
            clear = true;
        }
        options.leftIcon = options.leftIcon || 'back';
        options.rightIcon = options.rightIcon || '';
        options.leftText = options.leftText || '';
        options.rightText = options.rightText || '';
        options.title = options.title || '按揭贷款';
        options.leftCallback = options.leftCallback || '';
        options.rightCallback = options.rightCallback || this.back;
        clear && C.debug.clear && C.debug.clear();
        C.debug.log && C.debug.log('当前环境：' + Env);
        C.debug.log && C.debug.log('userAgent：' + navigator.userAgent.toUpperCase());
        if (typeof options.isBack === 'undefined') {
            options.isBack = true;
        }
        document.title = options.title;
        if (Utils.App.IS_NATIVE) {
            App.call('setHeader', options);
        } else {
            options.titleIcon = options.titleIcon || '';
            options.fixed = options.fixed || false;
            if (typeof options.isShowHeader === 'undefined') {
                options.isShowHeader = true;
            }
            Utils.vm.$store.commit(types.SET_HEADER, options);
        }
    },
    /**
     * 设置头部右边文案或图标
     * .rightText 右边文案
     * .rightIcon  右边图标 closed
     */
    setHeaderRight(options) {
        App.call('setHeaderRight', {
            rightText: options.rightText || '',
            rightIcon: options.rightIcon || ''
        });
    },

    /**
     * 状态栏
     * 默认显示 ，在需要隐藏状态栏的时候调用该接口
     * @param options {show:'N'} 设置状态栏的显示 'N':隐藏状态栏,Y 显示:'标题'
     */
    statusBarSwitch: function (options = {}) {
        // show为N时,pc端隐藏头部
        if (options.show === 'N') {
            $('.header-navbar').remove();
        }
        App.call('statusBarSwitch', options);
    },

    /**
     * 选择日期
     * @param options
     *  title 选择器标题
     *  callback  回调   code 1 成功 0 失败   data : {date: 'yyyy-MM-dd'}
     */
    showDatePicker: function (options = {}) {
        App.call('showDatePicker', options);
    },
    /**
     * 年月日时分选择器
     * title : 标题
     * callback  回调  code 1 成功 0 失败
     *                  data {"date":"yyyy-MM-dd HH:mm"}
     */
    showDateTimePicker: function (options) {
        App.call('showyyyyMMddHHmm', options);
    },
    /**
     * 年月选择器
     * @param options
     *  title 标题
     *  callback 回调   code 1 成功 0 失败
     *                  data: {}
     */
    showyyyyMM: function (options) {
        App.call('showyyyyMM', options);
    },
    /**
     * 单行选择器
     * @param options
     *  title 标题
     *  callback 回调   code 1 成功 0 失败
     *  data: [{'c1':'01'}]
     */
    showSinglePicker: function (options) {
        App.call('showSinglePicker', options);
    },
    /**
     * 双行选择器
     * @param options
     *  title 标题
     *  callback 回调   code 1 成功 0 失败
     *  data: [{'c1':'01'},{'c1':'02'}]
     */
    showDoublePicker: function (options) {
        App.call('showDoublePicker', options);
    },
    /**
     * 退出登录
     * @param callback
     *      返参  {code: '1', msg: '', data: {}}
     */
    loginOut: function (callback = defaultCallback) {
        App.call('loginOut', {callback: callback});
    },
    /**
     * token 超时
     * @param options msg 提示语,native默认为"登录失效，请重新登录！"
     */
    tokenTimeOut: function (msg) {
        App.call('tokenTimeOut', {msg: msg});
    },
    /**
     * appTokenOvertime 续爱行销app token
     */
    appTokenOvertime: function () {
        App.call('appTokenOvertime');
    },
    /**
     * 获取图片
     */
    getPhoto: function (options = {}) {
        App.call('getPhoto', options);
    },
    /**
     * Native上传图片
     * @param options
     */
    uploadImage: function (options = {}) {
        let paramObject = {
                // 设备
                os: C.Utils.App.IS_IOS ? 'IOS' : 'A',
                // H5资源上线版本号
                v: _App.ts,
                _: Date.now()
            },
            appLoginInfo = Utils.data(C.DK.APP_USER_LOGIN_INFO);
        appLoginInfo && (paramObject.token = appLoginInfo.token);

        options.url += (options.url.indexOf('?') !== -1 ? '&' : '?') + $.param(paramObject);
        App.call('uploadImage', options);
    },
    /**
     *
     * @param option
     *         type : one 1个按钮  two 两个按钮
     *         sure： 右边按钮文字
     *         cancle  左边按钮文字
     *         context 中间文字
     *         title  标题
     *         sureCallback  右边回调
     *         cancleCallback 左边回调
     */
    showDialog: function (option) {
        option.type = option.type || 'two';
        option.sure = option.sure || '确定';
        option.cancle = option.cancle || '取消';
        option.context = option.context || '';
        option.title = option.title || '';
        option.cancleCallback = option.cancleCallback || defaultCallback;
        option.sureCallback = option.sureCallback || defaultCallback;
        App.call('showDialog', option);
    },
    /**
     *
     * @param option
     *         imgId : '' 当前选中的图片ID
     *         imgUrl: '' 当前选中的图片URL
     *         title: '身份材料证明'  图片种类
     *         deletable: 'Y' 是否可以删除 Y开启 N关闭
     *         delete:(imgId) {} 删除回调
     *         imgList: [ // 图片数组
     *             {imgId: '', imgUrl: ''},
     *             {imgId: '', imgUrl: ''}
     *         ]
     */
    viewImage: function (option) {
        option.imgId = option.imgId;
        option.imgUrl = option.imgUrl;
        option.title = option.title || '身份材料证明';
        option.imgList = option.imgList || [];
        option.delete = option.delete || defaultCallback;
        App.call('viewImage', option);
    },
    /**
     *
     * @param option
     *         imgId : '' 当前选中的图片ID
     *         isDeleted: '' 是否删除成功 Y是 N否
     */
    isImageDeleted: function (option) {
        option.imgId = option.imgId;
        option.isDeleted = option.isDeleted || 'N';
        App.call('isImageDeleted', option);
    }
};
