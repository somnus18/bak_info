import Utils from '../../common/utils';
import Flag from '../../common/flag';

let key,
    $$ = window.$$ = {
        extend(n, o) {
            for (key in o) {
                if (o.hasOwnProperty(key)) {
                    n[key] = o[key];
                }
            }
        },
        EventListener: {
            /**
             * 返回（点击返回按钮或Android物理返回键）
             * @param url
             * @param data
             */
            onBack() {
            },
            needRefresh() {
            },
            /**
             * 返回改界面时需调用$$.EventListener.refresh方法
             * 登录成功后回到H5 页面 主动刷新
             */
            refresh() {
            },
            /**
             * 点击我的进件tab调用$$.EventListener.refreshURL
             */
            refreshURL() {
            }
        }
    },
    /**
     * 模块Native组件方法列表
     * */
    methodList = {
        loadingBegin: 'BusinessCommon',
        loadingFinish: 'BusinessCommon',
        tip: 'BusinessCommon',
        TDOnEven: 'BusinessCommon',
        forwardToNewPage: 'BusinessJump',
        forwardInCurPage: 'BusinessJump',
        back: 'BusinessJump',
        request: 'HttpPlugin',
        setHeader: 'Header',
        setHeaderRight: 'Header',
        statusBarSwitch: 'Header',
        showDialog: 'BusinessCommon',
        showSinglePicker: 'Picker',
        showDoublePicker: 'Picker',
        showDatePicker: 'Picker',
        showyyyyMMddHHmm: 'Picker',
        showyyyyMM: 'Picker',
        loginOut: 'AppInfo',
        tokenTimeOut: 'BusinessCommon',
        // 按揭token
        appTokenOvertime: 'Mortgage',
        getPhoto: 'Mortgage',
        uploadImage: 'Common',
        viewImage: 'Common',
        isImageDeleted: 'Common'
    },
    App = window.$$.platformAdapter = {},
    slice = Array.prototype.slice,
    toString = Object.prototype.toString,
    count = 0;

$$.extend(App, Utils.App);

// ============================ Native App 相关开始 ========================================

function errHandler(error) {
    switch (error.code) {
        case '001':
            App.call('tip', {text: '网络异常，请更换网络环境并重试'});
            break;
        case '002':
            App.call('tip', {text: '没有连接网络'});
            break;
        case '003':
            App.call('tip', {text: '网络超时'});
            break;
        case '004':
            App.call('tip', {text: '服务器发生异常'});
            break;
        default:
            App.call('tip', {text: '未知错误'});
            break;
    }
    // 去掉loading
    App.call('loadingFinish');
}
/**
 * 调用一个Native方法
 * @param {String} name 方法名称
 */
$$.extend(App, {
    /**
     * @private
     * 回调函数集
     */
    _handlers: {},
    /**
     * 调用Native方法
     * @param method
     */
     call(method) {
        let args = arguments[1],
            arg = null,
            callback = null,
            handlers = {},
            i,
            json = {},
            businessClass,
            handlersErrorCallback = function (param) {
                return function (error) {
                    if (!error) {
                        let opt = slice.call(arguments, 1),
                            res;
                        if (opt && (res = opt[0]) && res.code) {
                            if (res.code === Flag.NATIVE_SUCCESS) {
                                C.debug.log('native-' + method + '方法返回参数: ', res.data);
                                param.apply(window, opt);
                            } else {
                                App.call('loadingFinish');
                                App.call('tip', {text: res.msg});
                            }
                        } else {
                            param.apply(window, opt);
                        }
                    } else {
                        errHandler(error);
                    }
                };
            };
        /*
         *请注意！！！！！！！！！arg参数（字符串）安卓和IOS需要单独处理。
         *ios不需要加''号。
         *安卓需要加''号。
         */
        // 参数内容处理
        for (i in args) {
            arg = args[i] || '';
            // 函数型参数转换
            if (toString.call(arg) === '[object Function]') {
                callback = method + '_' + count++;
                handlers = App._handlers;
                // platformAdapter._handlers[callback] = arg
                handlers[callback] = handlersErrorCallback(arg);
                arg = callback;
            }
            json[i] = arg;
        }

        C.debug.log('当前请求Native接口: ' + method, '类名: ' + methodList[method], '入参: ', json);

        if (!C.Utils.App.IS_NATIVE) {
            return;
        }

        if (Utils.App.IS_ANDROID) {
            if (methodList[method]) {
                method = methodList[method] + '.' + method;
            }
            /* eslint no-alert: "off" */
            prompt('call://' + method + '(' + JSON.stringify(json) + ')');
            /*
             setTimeout(function () {
             $$.platformAdapter.callback(callback, null, {'DeviceId': '386453dcad2d534dbb04361d146104d47'})
             }, 3000)
             */
        } else {
            businessClass = methodList[method];
            try {
                window.webkit.messageHandlers[businessClass].postMessage({
                    method: method,
                    params: json
                });
            } catch (e) {
                C.debug.warn('request ios method throw Error', e);
            }
        }
    },
    callback(method) {
        let args = slice.call(arguments, 1),
            handlers = App._handlers,
            callback = handlers[method];

        if (callback && toString.call(callback) === '[object Function]') {
            callback.apply(window, args);
        }
    }
});
window.__callback = $$.platformAdapter.callback;

export default App;
