<template>
    <div class="delay-detail">
        <div class="bg"></div>
        <div class="content">
            <detail-card class="order-detail" :item="orderData"></detail-card>
            <div class="item-card">
                <dl v-if="orderData.applyStatus">
                    <dt>申请信息录入</dt>
                    <dd :class="['ft-yellow',{green:orderData.applyStatus=='03'}]">{{Z4[orderData.applyStatus]}}</dd>
                </dl>
                 <dl v-if="orderData.interviewType=='001' && orderData.creditStatus">
                    <dt>征信授权</dt>
                    <dd :class="['ft-yellow',{green:orderData.creditStatus=='03'}]">{{Z4[orderData.creditStatus]}}</dd>
                </dl>
                 <dl v-if="orderData.applyRoomCheckStatus">
                    <dt>申请房查</dt>
                    <dd :class="['ft-yellow',{green:orderData.applyRoomCheckStatus=='03'}]">{{Z4[orderData.applyRoomCheckStatus]}}</dd>
                </dl>
                 <dl v-if="orderData.applyPropertyTransferStatus">
                    <dt>申请产调</dt>
                    <dd :class="['ft-yellow',{green:orderData.applyPropertyTransferStatus=='03'}]">{{Z4[orderData.applyPropertyTransferStatus]}}</dd>
                </dl>
            </div>
        </div>
    </div>
</template>

<script type='text/ecmascript-6'>
    import detailCard from '@/components/order-detail-card.vue';

    export default {
        name: 'list-detail',
        data() {
            return {
                orderData: {
                    loanVariety: '',
                    barcode: '',
                    orderNo: '',
                    interviewType: '',
                    clientName: '',
                    applyStatus: '',
                    creditStatus: '',
                    applyRoomCheckStatus: '',
                    applyPropertyTransferStatus: ''
                },
                Z4: C.Constant.Z4
            };
        },
        created() {
            C.Native.setHeader({
                fixed: true,
                title: C.T.ORDER_DETAIL
            });
        },
        mounted() {
            this.$nextTick(()=> {
                this.orderId = this.$route.params.id;
                this.render();
            });
        },
        computed: {},
        methods: {
            render() {
                C.UI.loading();
                $.ajax({
                    url: C.Api('GET_DELAY_ORDER_DETAIL'),
                    data: {
                        orderId: this.orderId
                    },
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            let data = res.data;
                            for (let key in data) {
                                this.orderData[key] = data[key];
                            }
                            this.orderData.applyStatus = data.applyStatus || C.Constant['Z1_01'];
                            if (this.Z1_03 === data.applyStatus) {
                                this.isShowApplyArrow = false;
                            }
                        }
                    }
                });
            }
        },
        components: {
            detailCard
        }
    };
</script>

<style scoped lang="scss">
    .delay-detail{
        height: auto;

        .bg{
            width: 100%;
            height: 2.9rem;
            background: #00a0ea;
        }

        .content{
            position: absolute;
            top: 0.2rem;
            width: 92%;
            left: 4%;
        }

        .order-detail{
            border-top-left-radius: 5px;
            border-top-right-radius: 5px;
            padding-top: .1rem;
        }

        .item-card {
            background: #fff;
            dl{
                padding: .5rem .3rem;
                border-top: 1px solid #ccc;
                overflow: hidden;
                dt{
                    float: left;
                }
                dd{
                    float: right;
                    font-size: .32rem;
                    &.green{
                        color: #32b987;
                    }
                }
            }
            &:last-child{
                 border-bottom-left-radius: 5px;
                 border-bottom-right-radius: 5px;
             }
        }
    }
</style>
