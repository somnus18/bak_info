<template>
    <div class="delayOrder">
        <scroll-list v-show="!isShowDefault" class="delay-wrapper" :opt="opt" :isMoreData="isMoreData" ref="scrollViewWrapper" :params="params">
            <order-card v-for="item in orderList" :item="item" :key="item.orderId" @goDetail="goDetail(item)"></order-card>
        </scroll-list>
        <div v-show="isShowDefault">
            <no-orders></no-orders>
        </div>
        <select-order @search-order="searchOrder" v-show="isShowSelect"></select-order>
    </div>
</template>
<script type="text/ecmascript-6">
    import orderCard from '@/components/order-card.vue';
	import noOrders from '@/components/no-orders.vue';
    import scrollList from '@/components/scroll_list';
    import selectOrder from '@/components/select-order';
    import * as types from 'src/app/vuex/mutation-types';

    export default {
        name: 'delayOrder',
        data() {
            return {
                isShowDefault: false, // 没有数据的时候
            	orderList: [],
                // 关于iscroll
                maxHeight: null,
                isRefresh: true, // 判断下拉 还是上拉
                page: 1, // 页面数 接受scroller回传的page值
                isMoreData: false, // 监控上拉有无更多数据 并传递给scroller组件
                opt: {
                    isLoadMore: true,
                    isRefresh: true
                },
                isShowSelect: false,
                select: '筛选',
                close: '',
                params: null
            };
        },
        created() {
            C.Native.setHeader({
                fixed: true,
                title: C.T.DELAY_ORDER,
                rightText: this.select,
                rightIcon: this.close,
                rightCallback: ()=> {
                    this.close = this.close === 'close' ? '' : 'close';
                    this.$store.commit(types.SET_HEADER_R_T_I, {
                        rightIcon: this.close,
                        rightText: this.close === 'close' ? '' : this.select
                    });
                    this.isShowSelect = !this.isShowSelect;
                }
            });
        },
        mounted() {
        	this.$nextTick(()=> {
                // 渲染页面的数据是不需要加载loading的
                this.maxHeight = window.screen.height;
                this.render();
            });
        },
        methods: {
        	render(params, callback) {
                let _data = null,
                    paramData = typeof params === 'object' ? $.extend(true, {
                        pageNo: 1
                    }, params) : {
                        pageNo: params || this.page
                    };
                this.page = paramData.pageNo;
                paramData.searchType = '02';
                C.UI.loading();
                $.ajax({
                    url: C.Api('ORDER_LIST_WITH_FILTER'),
                    data: paramData,
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            _data = res.data.orderList;
                            // 数据
                            this.isMoreData = true;
                            this.isShowDefault = false;
                            if (!_data || !_data.length) {
                                if (parseInt(paramData.pageNo) === 1) {
                                    // 没有数据
                                    this.isShowDefault = true;
                                }
                                this.isMoreData = false;
                                return;
                            }
                            // 下拉就加载最新 上拉就push更多数据
                            if (this.isRefresh || ~~paramData.pageNo === 1) {
                                this.orderList = _data;
                            } else {
                                for (let i = 0; i < _data.length; i++) {
                                    this.orderList.push(_data[i]);
                                }
                            }
                            if (_data.length < 10 || res.data.totalPageNo === paramData.pageNo) {
                                this.isMoreData = false;
                            }
                            setTimeout(()=> {
                                this.$refs.scrollViewWrapper.$children[0].refresh();
                                C.Utils.initScrollHeight('.scroll-main', '.scroll-view', this.maxHeight);
                            }, 0);
                        }
                        callback && callback();
                    }
                });
            },
            goDetail(item) {
                let url;
                if (item.orderStatus === C.Constant.A1_1_1 || item.orderStatus === C.Constant.A1_2) {
                    url = '#/delayOrder/' + item.orderId + '?orderClass=delayOrder';
                } else {
                    url = '#/orderDetail/' + item.orderId + '?orderClass=delayOrder';
                }
                C.Native.forwardWebView({
                    url: url
                });
            },
            searchOrder(params) {
                this.close = '';
                this.isShowSelect = false;
                this.$store.commit(types.SET_HEADER_R_T_I, {
                    rightIcon: this.close,
                    rightText: this.select
                });
                this.params = params;
                this.render(params);
            }
        },
        components: {
        	orderCard,
            scrollList,
            selectOrder,
            noOrders
        }
    };
</script>
<style scoped>
    .delay-wrapper{ top: 0px;}
    /*.no-orders {
        position: fixed;
        left: 0;
        right: 0;
        top: 50%;
        text-align: center;
        span{
            display: inline-block;
            margin: 0 auto;
            text-align: center;
        }
    }*/
</style>
