<template>
    <div class="delayOrder">
        <order-card v-show="!noOrders" v-for="item in orderList" :item="item" :key="item.orderId" @goDetail="goDetail(item)"></order-card>
        <no-orders v-show="noOrders"></no-orders>
    </div>
</template>
<script type="text/ecmascript-6">
    import noOrders from '@/components/no-orders.vue';
    import orderCard from '@/components/order-card.vue';
    export default {
        name: 'enquiryPrice',
        data() {
            return {
                orderList: [],
                noOrders: false
            };
        },
        created() {
            C.Native.setHeader({
                title: C.T.ENQUIRY_PRICE_LIST
            });
        },
        mounted() {
            this.$nextTick(()=> {
                this.getData();
            });
            $$.EventListener.onBack = (url, data)=> {
                if (data === '1') {
                    this.getData();
                }
            };
        },
        methods: {
            getData() {
                C.UI.loading();
                $.ajax({
                    url: C.Api('OPMGT_ORDER_LIST'),
                    data: {
                        searchType: '01'
                    },
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            if (res.data.orderList.length <= 0) {
                                this.noOrders = true;
                            } else {
                                this.orderList = res.data.orderList;
                            }
                        }
                    }
                });
            },
            goDetail(item) {
                C.Native.forwardWebView({
                    url: '#/enquiryPriceDetail/?orderId=' + item.orderId + '&barcode=' + item.barcode + '&collateralId=' + item.taskRelevance
                });
            }
        },
        components: {
            orderCard,
            noOrders
        }
    };
</script>
<style scoped>
    .delay-wrapper{ top: 0px;}
    .delayOrder{ margin-bottom: .2rem;}
</style>
