<template>
    <div style="margin-top:.1rem" v-if="isShowPage">
        <m-input v-model="info.custInfo.clientName" :textName="'主借款人姓名'" :disabled=true :noBorder=true :topBorder=true></m-input>
        <m-input v-model="info.custInfo.globalId" :textName="'证件号码'" :disabled=true :noBorder=true></m-input>
        <m-input v-model="A2[info.loanInfo.loanVariety]" :textName="'贷款品种'" :disabled=true :noBorder=true></m-input>
        <m-input v-model="getCVal" :textName="'房产所在地'" :disabled=true :noBorder=true></m-input>
        <m-input v-model="A3[info.loanInfo.loanPlan]" :textName="'贷款方案'" :disabled=true :noBorder=true></m-input>
        <m-input v-model="info.loanInfo.bizApplyAmount" :textName="'申请金额－商贷(万元)'" :disabled=true :noBorder=true></m-input>
        <m-input v-model="info.loanInfo.publicReserveApplyAmount" :textName="'申请金额－公积金(万元)'" :disabled=true :noBorder=true></m-input>
        <m-input v-model="info.sellerInfo.sellerName" :textName="'卖方姓名'" :disabled=true :noBorder=true></m-input>
        <m-input v-model="info.sellerInfo.sellerMobile" :textName="'卖方联系方式'" :disabled=true :noBorder=true></m-input>
        <m-input v-model="info.sellerInfo.sellerInvestigateDate" :textName="'拟上门调查时间'" :disabled=true :noBorder=true></m-input>
        <m-input v-model="info.houseInfo.houseAddress" :textName="'详细地址'" :disabled=true :noBorder=true></m-input>
        <m-input v-model="info.houseInfo.houseArea" :textName="'建筑面积(m²)'" :disabled=true :noBorder=true></m-input>
        <m-input v-model="A6[info.houseInfo.warrantType]" :textName="'权证类型'" :disabled=true :noBorder=true></m-input>
        <m-input v-model="info.houseInfo.warrantCode" :textName="'权证编号'" :disabled=true :noBorder=true></m-input>
        <m-input v-if="info.evaluationFlag==2" v-model="evaluationCompany" @select-input='evaluationEvent' :textName="'评估公司'"
            :type="'select'" :placeholder="'请选择'"></m-input>
        <m-input v-if="info.evaluationFlag==1" v-model="info.evaluationCompanyInfo.evaluationCompay" :textName="'评估公司'" :disabled=true :noBorder=true></m-input>
        <m-input v-if="info.evaluationFlag==1" v-model="info.evaluationCompanyInfo.evaluationName" :textName="'评估公司联系人'" :disabled=true :noBorder=true></m-input>
        <m-input v-if="info.evaluationFlag==1" v-model="info.evaluationCompanyInfo.evaluationMobile" :textName="'评估公司联系人电话'" :disabled=true :noBorder=true></m-input>
        <m-input v-if="info.evaluationFlag==1" v-model="info.evaluationCompanyInfo.evaluationEmail" :textName="'评估公司联系人邮箱'" :disabled=true ></m-input>
        <m-input v-model="info.enquiryInfo.evaluationDate" :textName="'询价日期'" :type="'select'" :placeholder="'请选择'"
            @select-input='evaluationDateSeleted'></m-input>
        <m-upper  v-model="info.enquiryInfo.evaluationAmount"  :isflex1=true :textName="'单套评估价值(万元)'" unit="'W'" :placeholder="'请填写'" :type="'text'" maxlength="13"></m-upper>
        <m-input v-model="getVal" :textName="'单套认定价值(万元)'" :isflex1=true :disabled=true></m-input>
        <div class="update">
            <div class="tit">询价单<span style="color:#f05a23">(必传)</span></div>
            <upload-image  :imgList="imgList" :isShowAddBtn="isShowAddBtn" :maxLength="maxLength" :curlength="curlength" page="enquiry" :orderId="orderId" :collateralId="collateralId" :token="token"></upload-image>
        </div>
        <div class="option">
            <div class="btn white-btn" style="width: 40%;margin: .2rem .2rem;display:inline-block" @click="submit('save')">保存</div>
            <div class="btn" style="width: 40%;margin: .2rem .2rem;display:inline-block" @click="submit('submit')">提交</div>
        </div>
        <m-picker :slots='slots' :isPicker='isPicker' :indexText='indexText'
            :datakey='dataKey' :valueKey='valueKey'
            @confirm='pickerConfirm' @cancel='pickerCancel'>
        </m-picker>
        <m-date-picker :isPicker='isDatePicker' :datakey='dateDatakey' :defaultDate='defaultDate'
                       @confirm='datePickerConfirm' @cancel="datePickerCancel">
        </m-date-picker>
    </div>
</template>
<script type="text/ecmascript-6">
    import mButton from 'components/button/button';
    import mInput from 'src/components/cell/cell';
    import mPicker from 'src/components/picker/index';
    import mDatePicker from 'src/components/picker/date-picker.vue';
    import uploadImage from 'components/upload/multiple-image';
    import mUpper from 'src/components/cell/upper';
    export default {
        data() {
            return {
                defaultDate: '', // 日期选择器当前选择项
                // 贷款品种
                A2: $.extend(true, {}, C.Constant['A2'], {'-': '-'}),
                // 贷款方案
                A3: $.extend(true, {}, C.Constant['A3'], {'-': '-'}),
                A6: C.Constant['A6'],
                isPicker: false, // 普通选择器显示或隐藏
                isDatePicker: false, // 时间选择器显示或隐藏
                valueKey: 'v', // 下拉框设置 value-key 属性来指定显示的字段名
                indexText: '', // 选择器名称
                dataKey: '',
                dateDatakey: '',
                slots: [],
                info: {
                    enquiryInfo: {},
                    evaluationCompanyList: [],
                    loanInfo: {},
                    custInfo: {},
                    sellerInfo: {},
                    houseInfo: {},
                    evaluationCompanyInfo: {},
                    evaluationFlag: ''
                },
                evaluationCompany: '',
                imgList: [],
                isShowAddBtn: true,
                maxLength: 50,
                curlength: '',
                orderId: '',
                collateralId: '',
                token: '',
                isShowPage: false
            };
        },
        created() {
            this.slots = [{values: []}];
            C.Native.setHeader({
                title: C.T.ENQUIRY_INFO_INPUT
            });
        },
        computed: {
            getVal() {
                if (this.info.houseInfo.bargainPrice) {
                    return (parseFloat(this.info.enquiryInfo.evaluationAmount) >= parseFloat(this.info.houseInfo.bargainPrice) ? this.info.houseInfo.bargainPrice : this.info.enquiryInfo.evaluationAmount) || '-';
                } else {
                    return this.info.enquiryInfo.evaluationAmount || '-';
                }
            },
            getCVal() {
                return (this.info.houseInfo.houseProvince ? this.info.houseInfo.houseProvince.split('/')[1] : '') + (this.info.houseInfo.houseCity ? this.info.houseInfo.houseCity.split('/')[1] : '') + (this.info.houseInfo.houseCounty ? this.info.houseInfo.houseCounty.split('/')[1] : '');
            }
        },
        mounted() {
            this.$nextTick(()=> {
                this.orderId = this.$route.query.orderId;
                this.collateralId = this.$route.query.collateralId;
                this.getData(this.$route.query);
            });
        },
        methods: {
            // uploadImg(formImage, fileName) {
            //     let formData = new FormData();
            //     formData.append('imageFile', formImage, fileName);
            //     formData.append('data', JSON.stringify({orderId: this.orderId, collateralId: this.collateralId}));
            //     $.ajax({
            //         url: C.Api('UPLOAD_ENQUIRY_IMG'),
            //         data: formData,
            //         processData: false,
            //         contentType: false,
            //         beforeSend: ()=> {
            //         },
            //         success: (res)=> {
            //             C.UI.stopLoading();
            //             if (res.flag === C.Flag.SUCCESS) {
            //                 console.log(res.data);
            //             }
            //         }
            //     });
            // },
            getData(info) {
                let imgArr = [];
                C.UI.loading();
                $.ajax({
                    url: C.Api('INPUT_ENQUIRY_INFO'),
                    data: info,
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            this.isShowPage = true;
                            if (!res.data) {
                                this.isShowPage = false;
                                C.Native.tip('数据返回异常, 正在修复中...');
                                return;
                            }
                            this.token = (C.Utils.data(C.DK.APP_USER_LOGIN_INFO) || {}).token || (C.Utils.data(C.DK.USER_LOGIN_INFO) || {}).token;
                            this.info = res.data;
                            this.evaluationCompany = this.info.evaluationCompanyInfo.evaluationCompay;
                            if (this.info.enquiryInfo.evalutationCompanyDefault) {
                                this.evaluationCompany = this.info.enquiryInfo.evalutationCompanyDefault;
                            }
                            if (!this.info.enquiryInfo.evaluationDate) {
                                this.info.enquiryInfo.evaluationDate = C.Utils.parseDateFormat(new Date());
                            }
                            this.info.loanInfo.bizApplyAmount = C.Utils.toWY(this.info.loanInfo.bizApplyAmount);
                            this.info.loanInfo.publicReserveApplyAmount = C.Utils.toWY(this.info.loanInfo.publicReserveApplyAmount);
                            if (!this.info.enquiryInfo.evaluationAmount) {
                                this.info.enquiryInfo.evaluationAmount = '';
                            } else {
                                this.info.enquiryInfo.evaluationAmount = C.Utils.toWY(this.info.enquiryInfo.evaluationAmount);
                            }
                            this.info.houseInfo.bargainPrice = C.Utils.toWY(this.info.houseInfo.bargainPrice);
                            if (this.info.enquiryInfo.enquiryImageUri) {
                                imgArr = this.info.enquiryInfo.enquiryImageUri.split(',');
                                this.curlength = imgArr.length;
                            }
                            for (let i in imgArr) {
                                this.imgList.push({
                                    imgUrl: C.Utils.httpAddImage(imgArr[i])
                                });
                            }
                            if (this.imgList.length >= this.maxLength) {
                                this.isShowAddBtn = false;
                            }
                        }
                    }
                });
            },
            evaluationEvent() {
                this.dataKey = 'evaluationCompanyName';
                this.indexText = '评估公司';
                let evaluationCompanyArr = [];
                for (let i in this.info.evaluationCompanyList) {
                    evaluationCompanyArr.push(this.info.evaluationCompanyList[i]['evaluationCompanyName']);
                }
                this.slots = [{values: C.Utils.objToArr(evaluationCompanyArr)}];
                this.isPicker = true;
            },
            pickerEvent(key, text, slot) {
                this.dataKey = key;
                this.indexText = text;
                this.slots = [{values: C.Constant[slot]}];
                this.isPicker = true;
            },
            pickerConfirm(value) {
                this.evaluationCompany = value.v;
                this.isPicker = false;
            },
            pickerCancel() {
            	this.isPicker = false;
            },
            // 日期选择器
            evaluationDateSeleted() {
                this.defaultDate = this.info.enquiryInfo.evaluationDate;
                this.dateDatakey = 'evaluationDate';
                this.isPicker = false;
                this.isDatePicker = true;
                this.isAreaPicker = false;
            },
            datePickerCancel() {
                this.isDatePicker = false;
            },
            datePickerConfirm(value, key) {
                // cosole.log(value, key) [2017, "01", "01"] "dateTime"
                this.isDatePicker = false;
                this.info.enquiryInfo[key] = value.join('-');
            },
            submit(type) {
                let isSave = type === 'save',
                    data = {
                        submit: !isSave,
                        orderId: this.$route.query['orderId'],
                        affirmAmount: C.Utils.toY(this.getVal === '-' ? '' : this.getVal),
                        evaluationAmount: C.Utils.toY(this.info.enquiryInfo.evaluationAmount),
                        evaluationDate: this.info.enquiryInfo.evaluationDate,
                        collateralId: this.$route.query['collateralId'],
                        evaluationCompany: this.evaluationCompany,
                        evaluationContacts: this.info.evaluationCompanyInfo.evaluationName,
                        evaluationMobile: this.info.evaluationCompanyInfo.evaluationMobile,
                        evaluationEmail: this.info.evaluationCompanyInfo.evaluationEmail,
                        evaluationAddress: this.info.evaluationCompanyInfo.evaluationAddress
                    },
                    msg = this.submitValidate(data, type);
                if (msg) {
                    C.Native.tip(msg);
                    return;
                }
                C.UI.loading();
                $.ajax({
                    url: C.Api('SUBMIT_ENQUIRY_INFO'),
                    data: data,
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            C.Native.tip(isSave ? '保存成功' : '提交成功');
                            !isSave && C.Native.back({data: '1'});
                        }
                    }
                });
            },
            submitValidate(data, type) {
                let msg = '';
                if (type === 'submit') {
                    if (this.info.evaluationFlag === '2' && !this.evaluationCompany) {
                        msg = '未选择评估公司';
                    } else if (!data.evaluationDate) {
                        msg = '询价日期未填写';
                    } else if (data.evaluationAmount !== 0 && !data.evaluationAmount) {
                        msg = '评估价未填写';
                    } else if (this.imgList.length <= 0) {
                        msg = '未上传询价单';
                    }
                }
                if (!msg && (data.evaluationAmount || data.evaluationAmount === 0)) {
                    if (isNaN(this.info.enquiryInfo.evaluationAmount)) {
                        msg = '评估价格式不正确';
                    } else if (data.evaluationAmount <= 0) {
                        msg = '评估价需大于0';
                    } else if (this.info.enquiryInfo.evaluationAmount.toString().indexOf('.') > -1 && !C.Utils.RegexMap.sixDecimal.test(this.info.enquiryInfo.evaluationAmount)) {
                        msg = '评估价最多6位小数';
                    } else if (this.info.enquiryInfo.evaluationAmount > 999999.999999) {
                        msg = '评估价' + C.HT['1'];
                    }
                }
                return msg;
            }
        },
        components: {
            mButton,
            mPicker,
            mInput,
            mDatePicker,
            uploadImage,
            mUpper
        }

    };
</script>
<style scoped lang="scss">
.update{
    width: 100%;
    background-color: white;
    margin-top: .1rem;
    .tit{
        font-size: .28rem;
        padding-top: 0.4rem;
        padding-left: 0.3rem;
    }
}
.option{
    text-align: center;
    background-color: white;
    margin-top: .1rem;
    .white-btn{
        color: #00a0ea;
        background-color: white;
        border: 1px solid #00a0ea;
        border-radius: .08rem
    }
    .btn{
        border: 1px solid #00a0ea;
        border-radius: .08rem
    }
}
.bt-bottom {
    margin:10px 0;
    padding:0 20px;
    position: fixed;
    bottom: 0;
    width: 100%;
    height: .8rem;
    line-height: .8rem;
    text-align: center;
}
</style>
