<template>
    <div>
        <div class="item-box item-class mt5">
            待处理订单
        </div>
        <div class="item-box" @click="goEnquiryPrice">
           询价信息录入 <i class="icon_right">{{taskList['1101']}}</i>
        </div>
        <div class="item-box" @click="goCheckApply">
            审核申请 <i class="icon_right">{{taskList['3001']}}</i>
        </div>
        <div class="item-box" @click="goApplyMaterial">
            申请材料补充 <i class="icon_right">{{taskList['3201']}}</i>
        </div>
        <div class="item-box" @click="goCheckBu">
            审批补件 <i class="icon_right">{{taskList['3101']}}</i>
        </div>
        <div class="item-box" @click="goSignDate">
            预约面签 <i class="icon_right">{{taskList['4001']}}</i>
        </div>

        <div class="item-box item-class mt5" @click="delayOrder">
            待跟进订单<i class="icon_right"></i>
        </div>
        <div class="item-box" @click="goDateInfo">
            预约信息<i class="icon_right"></i>
        </div>

        <div class="item-box item-class mt5" @click="allOrder">
            所有订单<i class="icon_right"></i>
        </div>
    </div>
</template>
<script type="text/ecmascript-6">
    export default {
        data() {
            return {
                // 1101-询价信息录入；3001-审核申请；3101-审批补件；4001-预约面签
                taskList: {
                    '1101': 0,
                    '3001': 0,
                    '3101': 0,
                    '4001': 0,
                    '3201': 0
                }
            };
        },
        created() {
            // 获取爱行销登陆相关数据及token, 仅渠道app初始化我的进件页面时使用
            C.Utils.data(C.DK.APP_USER_LOGIN_INFO, C.Utils.getQueryMap());
            C.Native.setHeader({
                isBack: false,
                title: C.T.MY
            });
        },
        mounted() {
            this.$nextTick(()=> {
                this.getData();
            });
            // 点击tab时,更换token
            $$.EventListener.refreshURL = (url)=> {
                C.debug.log('refreshURL刷新调用成功');
                C.Utils.data(C.DK.APP_USER_LOGIN_INFO, C.Utils.getQueryMap(url));
                this.getData();
            };

            $$.EventListener.onBack = ()=> {
                C.debug.log('onBack刷新调用成功');
                this.getData();
            };
        },
        methods: {
            getData() {
                let arr, key, newJson = {};
                $.ajax({
                    url: C.Api('OPMGT_MYENTRY'),
                    data: {},
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            arr = res.data.taskList;
                            arr.forEach((item)=> {
                                newJson[item.taskType] = item.taskNum;
                            });
                            for (key in this.taskList) {
                                this.taskList[key] = newJson[key] || '0';
                            }
                        }
                    }
                });
            },
            goCheckApply() {
                C.Native.forwardWebView({
                    url: '#/checkApply'
                });
            },
            goApplyMaterial() {
                C.Native.forwardWebView({
                    url: '#/applyMaterial'
                });
            },
            goEnquiryPrice() {
                C.Native.forwardWebView({
                    url: '#/enquiryPrice'
                });
            },
            goCheckBu() {
                C.Native.forwardWebView({
                    url: '#/checkBu'
                });
            },
            goSignDate() {
                C.Native.forwardWebView({
                    url: '#/signDate'
                });
            },
            goDateInfo() {
                C.Native.forwardWebView({
                    url: '#/dateInfo'
                });
            },
            delayOrder() {
                C.Native.forwardWebView({
                    url: '#/delayOrder'
                });
            },
            allOrder() {
                C.Native.forwardWebView({
                    url: '#/allOrder'
                });
            }
        }
    };
</script>
<style scoped>
    .item-box{position: relative;padding-left:.9rem;height: .88rem;line-height: .88rem;background: #f6f6f6;border-bottom: solid 1px #eee;}
    .item-box.item-class{padding-left:.3rem;border-bottom: solid 1px #ddd;background: #fff;}
    .icon_right{
        position: absolute;
        width: .25rem;
        height: .3rem;
        top:50%;
        right: .3rem;
        padding-right: 18px;
        margin-top: -.15rem;
        line-height: .3rem;
        text-indent: -3rem;
        font-size: .36rem;
        color: #f05a23;
        background: url(../../../assets/images/app/icons/icon_arrow_r@3x.png) right center no-repeat;
        -webkit-background-size: 7px auto;
        background-size: 7px auto;
        text-align: right;
    }
</style>

