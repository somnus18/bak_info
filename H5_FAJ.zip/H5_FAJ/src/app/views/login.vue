<template>
    <section class="login" v-if="!isPrd">
        <div class="logo">
            模拟登陆接口,仅供测试环境可以使用。
        </div>
        <div class="user-box">
            <div class="user-box-in">
                <span class="icon-user"></span><input class="ipt1" type="text" placeholder="请输入用户名" v-model="userId"><i class="empty-input-icon" v-if="userId" @click="clear('userId')"></i>
            </div>
        </div>
        <div class="user-box user-other">
            <div class="user-box-in">
                <span class="icon-pwd"></span><input class="ipt1" type="password" placeholder="请输入密码" maxlength="16" v-model="userPwd"><i class="empty-input-icon" v-if="userPwd" @click="clear('userPwd')"></i>
            </div>
        </div>
        <div class="btn-bottom">
            <div class="btn" :class="[isValid ? '' : 'btn-disabled']" @click="login">登录</div>
        </div>
        <footer>
            <p>版权所有&copy;中国平安保险（集团）股份有限公司</p>
            <p>ICP许可证号 粤ICP备06118290号</p>
        </footer>
    </section>
</template>
<script type="text/ecmascript-6">
    export default {
        name: 'login',
        data() {
            return {
                userId: '',
                userPwd: '',
                isPrd: !C.Constant.DEBUG_MODE
            };
        },
        created() {
            if (this.isPrd) {
                this.$router.push('my');
            }
            C.Native.setHeader({
                isShowHeader: false,
                title: C.T.LOGIN
            });
            C.UI.stopLoading();
        },
        mounted() {
        },
        computed: {
            isValid() {
                return this.userId && this.userPwd;
            }
        },
        methods: {
            login() {
                if (this.isPrd) {
                    this.$router.push('my');
                }
                if (!this.userId || !this.userPwd) {
                    return;
                }
                let checkPwd = C.Validator.pwd(this.userPwd);
                if (!checkPwd.result) {
                    C.Native.tip(checkPwd.error);
                    return;
                }
                C.UI.loading('登录中...');
                this.getTicket((ticket)=> {
                    $.ajax({
                        url: C.Api('USER_LOGIN'),
                        data: {
                            userId: this.userId,
                            userPwd: ticket + C.Utils.MD5(this.userPwd)
                        },
                        success: (res)=> {
                            C.UI.stopLoading();
                            if (res.flag === C.Flag.SUCCESS) {
                                C.Utils.data(C.DK.USER_LOGIN_INFO, res.data);
                                this.$router.push('my');
                            }
                        }
                    });
                });
            },
            getTicket(callback) {
                $.ajax({
                    url: C.Api('GET_TICKET'),
                    type: 'get',
                    success: (res)=> {
                        if (res.flag === C.Flag.SUCCESS) {
                            callback && callback(res.data.ticket);
                        }
                    }
                });
            },
            clear(dataKey) {
                this[dataKey] = '';
            }
        }
    };
</script>
<style scoped lang="scss">
    .login{
        width: 100%;
        height: 100%;
        background: #fff;
        padding-top: 3rem;
    .logo{
        margin: 0 auto;
        text-align: center;
        color: #f05b23;
    }
    .user-box{
        padding:2.7rem .9rem 0;
        display: -webkit-box;
    span:before{
        display: inline-block;
        width:0.44rem;
        height:0.44rem;
    }
    }
    .user-box-in{
        position: relative;
        display: block;
        width:100%;
        font-size: 0;
    }
    .icon-user:before,.icon-pwd:before{
        position: absolute;
        display: inline-block;
        content: "";
        margin:0 auto;
        vertical-align: top;
    }
    .icon-user:before{
        background: url(../../assets/images/m/icons/icon_identity@2x.png) no-repeat;
        background-size: 100% auto;
    }
    .icon-pwd:before{
        background: url(../../assets/images/m/icons/icon_password@2x.png) no-repeat;
        background-size: 100% auto;
    }
    .user-other{
        padding-top:0.8rem;
    }
    .ipt1 {
        width: 85%;
        height: 0.4rem;
        border-bottom: 1px solid #ddd;
        padding: .24rem 0;
        font-size: .3rem;
        background: #fff;
        margin-left:.8rem;
    }
    .btn-bottom{
        padding:1.12rem .9rem 0;
    .btn{
        width: 100%;
        height: .88rem;
        line-height: .88rem;
        border-radius: .44rem;
    }
    }
    .empty-input-icon {
        position: absolute;
        top: -.01rem;
        right: .3rem;
        display: inline-block;
        width: .42rem;
        height: .42rem;
        background: url("../../assets/images/m/icons/icon_sign_delete@2x.png") center no-repeat;
        background-size: 100%;
    }
    footer{
        text-align: center;
        font-size: .2rem;
        color:#ccc;
        padding-top: 2.55rem;
    }
    }

</style>
