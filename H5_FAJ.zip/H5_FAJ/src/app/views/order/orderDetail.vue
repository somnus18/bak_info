<template>
    <section class="detail-box">
        <div class="bg"></div>
        <order-detail class="all-box"></order-detail>
    </section>
</template>

<script type='text/ecmascript-6'>
    import orderDetail from '@/components/all-orders/detail.vue';

    export default {
        name: 'all-detail',
        data() {
            return {
            };
        },
        created() {
            C.Native.setHeader({
                // isShowHeader: false,
                title: C.T.ORDER_DETAIL
            });
        },
        mounted() {
        },
        methods: {
        },
        components: {
            orderDetail
        }
    };
</script>

<style scoped>
    .bg{
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 3rem;
        background: #00a0ea;
    }
    .all-box{
        margin-top: -.45rem;
    }
</style>
