<template>
    <div class="delayOrder">
        <date-info-card v-show="!noOrders" v-for="item in orderList" :item="item" :key="item.orderId" @goDetail="goDetail(item)"></date-info-card>
        <no-orders v-show="noOrders"></no-orders>
    </div>
</template>
<script type="text/ecmascript-6">
    import noOrders from '@/components/no-orders.vue';
	import dateInfoCard from '@/components/dateInfo-list-card.vue';
    export default {
        name: 'dateInfo',
        data() {
            return {
                orderList: [],
                noOrders: false
            };
        },
        created() {
            C.Native.setHeader({
                title: C.T.DATE_INFO_LIST
            });
        },
        mounted() {
            this.$nextTick(()=> {
                // 渲染页面的数据是不需要加载loading的
                this.getData();
            });
        },
        methods: {
            getData() {
                C.UI.loading();
                $.ajax({
                    url: C.Api('OPMGT_ORDER_LIST'),
                    data: {
                        searchType: '05'
                    },
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            if (res.data.orderList.length <= 0) {
                                this.noOrders = true;
                            } else {
                                this.orderList = res.data.orderList;
                            }
                        }
                    }
                });
            },
            goDetail(item) {
                C.Native.forwardWebView({
                    url: '#/signDateDetail/?orderId=' + item.orderId + '&fromType=date-info'
                });
            }
        },
        components: {
            dateInfoCard,
            noOrders
        }
    };
</script>
<style scoped>
    .delayOrder{padding:0 .2rem;}
    .delay-wrapper{ top: 0px;}
    .delayOrder{ margin-bottom: .2rem;}    
</style>
