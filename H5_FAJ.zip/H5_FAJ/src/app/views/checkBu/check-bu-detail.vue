<template>
    <div style="margin-top: .1rem;">
        <m-input v-model="info.orderNo" :textName="'订单号'" :type="'text'" disabled='disabled' :noBorder=true></m-input>
        <m-input v-model="info.clientName" :textName="'主借款人'" :type="'text'" disabled='disabled' :noBorder=true></m-input>
        <m-input v-model="info.issuedTime" :textName="'补件下发时间'" :type="'text'" disabled='disabled' :noBorder=true></m-input>
        <div v-if="info.evidenceInfoList.length>0" class="info">
            <div class="tit">补件具体信息</div>
            <div v-for="(v, k) in info.evidenceInfoList" @click="tanInfo(k)" class="evidenceInfo">
                <div :class="[v.evidenceType.length>22?'line2':'line1','content']">
                    {{v.evidenceType}}
                </div>
                <div class="input-icon">
                    <span></span>
                </div>
            </div>
        </div>
        <div class="tit">上传补件</div>
        <div class="upload">
            <div class="tit">补件材料<span style="color:#f05a23">(必传)</span></div>
            <upload-image :imgList="imgList" :isShowAddBtn="isShowAddBtn" :maxLength="maxLength" :curlength="curlength" page="addPiece" :orderId="info.orderId" :token="token"></upload-image>
        </div>
        <div class="bt-bottom">
            <m-button :text="'提交'" @click-button="submit"></m-button>
        </div>
        <detail-order :evidences="info.evidenceInfoList" :ekey="eviKey" :isShow="isShowDelOrder"></detail-order>
    </div>
</template>
<script type="text/ecmascript-6">
    import detailOrder from 'src/components/detail_info';
    import mInput from 'src/components/cell/cell';
    import uploadImage from 'components/upload/multiple-image';
    import mButton from 'components/button/button';
    export default {
        data() {
            return {
                isShowDelOrder: false,
                eviKey: '',
                info: {
                    orderId: '',
                    barcode: '',
                    clientName: '',
                    evidenceInfoList: [],
                    issuedTime: '',
                    imgUrls: ''
                },
                imgList: [],
                isShowAddBtn: true,
                maxLength: 50,
                curlength: '',
                token: ''
            };
        },
        created() {
            C.Native.setHeader({
                title: C.T.CHECK_BU_DETAIL
            });
        },
        mounted() {
            this.$nextTick(()=> {
                this.orderId = this.$route.params.id;
                this.getData(this.orderId);
            });
        },
        methods: {
            tanInfo(k) {
                this.eviKey = k;
                this.isShowDelOrder = true;
            },
            getData(info) {
                let imgArr = [];
                C.UI.loading();
                $.ajax({
                    url: C.Api('GET_EVIDENCE_INFO'),
                    data: {
                        orderId: info
                    },
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            this.token = (C.Utils.data(C.DK.APP_USER_LOGIN_INFO) || {}).token || (C.Utils.data(C.DK.USER_LOGIN_INFO) || {}).token;
                            this.info = res.data;
                            if (this.info.imgUrls) {
                                imgArr = this.info.imgUrls.indexOf(',') !== -1 ? this.info.imgUrls.split(',') : [this.info.imgUrls];
                                this.curlength = imgArr.length;
                            }
                            for (let i in imgArr) {
                                this.imgList.push({
                                    imgUrl: C.Utils.httpAddImage(imgArr[i])
                                });
                            }
                            if (this.imgList.length === this.maxLength) {
                                this.isShowAddBtn = false;
                            }
                        }
                    }
                });
            },
            submit() {
                let msg = this.submitValidate();
                if (msg) {
                    C.Native.tip(msg);
                    return;
                }
                C.UI.loading();
                $.ajax({
                    url: C.Api('SUBMIT_EVIDENCE_INFO'),
                    data: {
                        orderId: this.$route.params.id
                    },
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            C.Native.tip('提交成功');
                            C.Native.back();
                        }
                    }
                });
            },
            submitValidate() {
                let msg = '';
                if (this.imgList.length <= 0) {
                    msg = '未上传补件材料';
                }
                return msg;
            }

        },
        components: {
            detailOrder,
            mButton,
            mInput,
            uploadImage
        }
    };
</script>
<style scoped lang="scss">
    .evidenceInfo{
        width: 100%;
        background: white;
        border-bottom: 1px #e5e5e5 solid;
        .line1{
            line-height: 1.05rem;
        }
        .line2{
            padding-top: .1rem;
        }
        .content{
            width: 91%;
            height: 1.05rem;
            padding-left: .3rem;
            display: inline-block;
        }
        .input-icon {
            float: right;
            line-height: 1.05rem;
            span {
                padding: 8px;
                padding-right: .5rem;
                background: url('../../../components/cell/icon_arrow_r@3x.png') center center/100% auto no-repeat;
                -webkit-background-size: 7px auto;
                background-size: 7px auto;
            }
        }
    }
    .tit{
        color: #999;
        padding: .1rem 0 .1rem .3rem;
    }
    .upload{
        width: 100%;
        height: auto;
        padding-bottom: 1rem;
        background-color: white;
        .tit{
            padding-top: .4rem;
        }
    }
    .bt-bottom {
        position: fixed;
        bottom: 0;
        width: 100%;
        background-color: white;
        height: 1.2rem;
        z-index: 1000;
        .btn{
            margin-top: .15rem;
        }
    }
    .option{
        width: 100%;
        height: 100px;
        background-color: white;
        text-align: center;
        position: absolute;
        bottom: 0;
        .submit{
            display: inline-block;
            background-color: grey;
            width: 100px;
            height: 50px;
            font-size: 16px;
            line-height: 50px;
            margin-top: 25px;
        }
    }
</style>
