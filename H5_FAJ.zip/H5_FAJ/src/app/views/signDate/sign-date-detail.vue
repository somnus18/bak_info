<template>
    <div>
        <div class="con">
            <div class="tit">订单信息</div>
            <m-input v-model="info.barcode" :textName="'KB码'" :type="'text'" disabled='disabled' :noBorder=true></m-input>
            <m-input v-model="info.clientName" :textName="'客户姓名'" :type="'text'" disabled='disabled' :noBorder=true></m-input>
            <m-input v-model="info.mobile" :textName="'联系方式'" :type="'text'" disabled='disabled' :noBorder=true></m-input>
            <m-input v-model="A2[info.interviewType]" :textName="'面签模式'" :type="'text'" disabled='disabled' :noBorder=true></m-input>
            <m-input v-model="info.storeName" :textName="'签约门店'" :type="'text'" disabled='disabled' :noBorder=true></m-input>
            <m-input v-if="isTrialToSign" v-model="info.bankManagerUm" :textName="'客户经理UM'" :type="'text'" disabled='disabled' :noBorder=true></m-input>
            <m-input v-if="isTrialToSign" v-model="info.bankManagerMobile" :textName="'客户经理手机号'" :type="'text'" disabled='disabled' :noBorder=true></m-input>

            <div class="tit">预约信息</div>
            <div v-if="!isTrialToSign" class="needInform" @click="changeNeed"><span :class="[{'inf':info.isInformManager==1,'notInf':info.isInformManager==0}]"></span>需通知客户经理</div>
            <m-input v-if="isTrialToSign || info.isInformManager==1" v-model="info.signDate" :textName="'签约日期'" :type="'select'" :placeholder="'请选择'" @select-input='signDateSelected' :disabled='!isSignDate'></m-input>
            <m-input v-if="isTrialToSign || info.isInformManager==1" v-model="info.signTimeBlock" :textName="'签约时间'" :type="'select'" :placeholder="'请选择'" @select-input="pickerEvent('signTimeBlock','签约时间',A1)" :disabled='!isSignDate'></m-input>
            <m-input v-if="!isTrialToSign" v-model="info.bankManagerUm" :textName="'客户经理'" :type="'select'" placeholder='请选择' @select-input="pickerEvent('bankManagerUm','客户经理',selectUmJson)" :disabled='!isSignDate'></m-input>

            <m-input v-if="!isTrialToSign" v-model="info.bankManagerMobile" :textName="'客户经理手机号'" :type="'text'" :disabled=true></m-input>
        </div>

        <div v-show="isBottom" class="bt-bottom">
            <m-button v-if="isSignDate && (isTrialToSign || info.isInformManager == 1)" :text="'通知客户经理'" @click-button="submit('info')"></m-button>
            <m-button v-else-if="isSignDate && !isTrialToSign &&info.isInformManager != 1" :text="'保存预约信息'" @click-button="submit('save')"></m-button>
            <m-button v-else-if="!isSignDate" :text="'修改预约信息'" @click-button="edit"></m-button>
        </div>

        <m-picker :slots='slots':isPicker='isPicker' :indexText='indexText' :datakey='dataKey' :valueKey="'v'" @confirm='pickerConfirm' @cancel='pickerCancel'></m-picker>
        <m-date-picker :isPicker='isDatePicker' :datakey='dateDatakey' :defaultDate='defaultDate'
            @confirm='datePickerConfirm' @cancel="datePickerCancel">
        </m-date-picker>

    </div>
</template>
<script type="text/ecmascript-6">
    import mButton from 'components/button/button';
    import mInput from 'src/components/cell/cell';
    import mPicker from 'src/components/picker/index';
    import mDatePicker from 'src/components/picker/date-picker.vue';
    export default {
        data() {
            return {
                isBottom: true,
                isSignDate: '', // 原fromType，可依据这个字段判断是否可编辑
                needInform: true,
                isPicker: false, // 普通选择器显示或隐藏
                isDatePicker: false, // 时间选择器显示或隐藏
                defaultDate: '', // 日期选择器当前选择项
                indexText: '', // 选择器名称
                dataKey: '', // 选择器结果赋值到对象的key值
                dateDatakey: '',
                slots: [], // slot 对象数组
                info: {
                    bankManagerInfoList: [{ // 先签后审用
                        selected: '',
                        bankManagerMobile: '',
                        bankManagerUm: ''
                    }],
                    bankManagerUm: '', // 先审后签用
                    bankManagerMobile: '', // 先审后签用
                    barcode: '',
                    orderId: '',
                    clientName: '',
                    mobile: '',
                    interviewType: '',
                    storeName: '',
                    signDate: '',
                    signTimeBlock: '',
                    isInformManager: '' // 是否通知客户经理 0/否 1/是
                },
                A1: C.Constant['37'],
                A2: C.Constant['1'],
                selectUmJson: {}
            };
        },
        computed: {
            isTrialToSign() { // 先审后签约
                return this.info.interviewType === C.Constant['1_1'];
            }
        },
        created() {
            this.slots = [{values: []}];
            this.orderId = this.$route.query.orderId;
            // isSignDate = true 预约面签页面
            // isSignDate = false 预约信息页面
            this.isSignDate = this.$route.query.fromType === 'sign-date';
            C.Native.setHeader({
                title: this.isSignDate ? C.T.SIGN_DATE : C.T.DATE_INFO
            });
        },
        mounted() {
            this.$nextTick(()=> {
                this.getData(this.orderId);
            });
        },
        methods: {
            getData(orderId) {
                $.ajax({
                    url: C.Api('GET_INTERVIEW_INFO'),
                    data: {
                        orderId: orderId
                    },
                    success: (res)=> {
                        C.UI.stopLoading();
                        let i, getManagers = [];
                        if (res.flag === C.Flag.SUCCESS) {
                            this.info = res.data;
                            // 需通知客户经理 的显示和隐藏
                            this.isSignDate ? this.info.isInformManager = '1' : '';
                            // 客户经理list
                            getManagers = this.info.bankManagerInfoList || [];
                            if (this.info.interviewType === C.Constant['1_1']) return;
                            this.info.bankManagerUm = '';
                            this.info.bankManagerMobile = '-';
                            this.selectUmJson = {};
                            for (i = 0; i < getManagers.length; i++) {
                                // {'0': ''} 当key值为0时在iOS9上会有问题
                                this.selectUmJson[getManagers[i].bankManagerMobile + getManagers[i].bankManagerUm] = getManagers[i].bankManagerUm;
                                if (getManagers[i].selected === '1') {
                                    this.info.bankManagerUm = getManagers[i].bankManagerUm;
                                    this.info.bankManagerMobile = getManagers[i].bankManagerMobile;
                                }
                            }
                        }
                    }
                });
            },
            changeNeed() {
                if (this.isSignDate) {
                    this.info.isInformManager = this.info.isInformManager === '1' ? '0' : '1';
                    if (this.info.isInformManager === '0') {
                      this.info.signDate = '';
                      this.info.signTimeBlock = '';
                    }
                }
            },
            // 日期选择器
            signDateSelected() {
                this.defaultDate = this.info.signDate;
                this.dateDatakey = 'signDate';
                this.isPicker = false;
                this.isDatePicker = true;
                this.isAreaPicker = false;
            },
            // 普通选择器
            pickerEvent(key, text, slot) {
                this.dataKey = key;
                this.indexText = text;
                this.slots = [{values: C.Utils.objToArr(slot)}];
                this.isPicker = true;
                this.isDatePicker = false;
                this.isAreaPicker = false;
            },
            datePickerCancel() {
                this.isDatePicker = false;
            },
            datePickerConfirm(value, key) {
                this.isDatePicker = false;
                this.info[key] = value.join('-');
            },
            pickerConfirm(value, key) {
                this.info[key] = value.k;
                this.isPicker = false;
                switch (key) {
                    case 'bankManagerUm' :
                        this.info.bankManagerMobile = value.k.slice(0, 11);
                        this.info.bankManagerUm = value.k.slice(11);
                        break;
                    case 'signTimeBlock' :
                        this.info[key] = value.v;
                        break;
                }
            },
            pickerCancel() {
                this.isPicker = false;
            },
            edit() {
                this.isSignDate = true;
            },
            submit(type) {
                let msg = '',
                tip = type === 'save' ? '保存预约信息成功' : '通知成功';
                if (this.isTrialToSign) {
                    msg = this.timeValidate();
                } else if (this.info.isInformManager === '1') { // !this.isTrialToSign && this.info.isInformManager === '1'
                    msg = this.timeValidate() || this.managerValidate();
                } else if (this.info.isInformManager === '0') { // !this.isTrialToSign && this.info.isInformManager === '0'
                    msg = this.managerValidate();
                }
                if (msg) {
                    C.Native.tip(msg);
                    return;
                }
                $.ajax({
                    url: C.Api('SUBMIT_INTERVIEW_INFO'),
                    data: this.info,
                    success: (res)=> {
                        if (res.flag === C.Flag.SUCCESS) {
                            C.Native.tip(tip);
                            C.Native.back();
                        }
                    }
                });
            },
            timeValidate() {
                let msg = '',
                    startTime = '',
                    endTime = '';
                if (this.info.signTimeBlock && this.info.signDate) {
                    startTime = this.info.signDate.replace(/\-/g, '/');
                    startTime = startTime + ' ' + this.info.signTimeBlock.substring(0, this.info.signTimeBlock.indexOf('-'));
                    startTime = (new Date(startTime)).getTime();
                    endTime = (new Date()).getTime();
                }
                if (!this.info.signDate) {
                    msg = '签约日期未填写';
                } else if (!this.info.signTimeBlock) {
                    msg = '签约时间未填写';
                } else if ((startTime - endTime) <= 0) {
                    msg = '签约时间已过,请重新填写';
                } else if ((startTime - endTime) > (86400000 * 14)) {
                    msg = '仅可选择当前时间后两周内的时间';
                }
                return msg;
            },
            managerValidate() {
                let msg = '';
                if (!this.info.bankManagerUm) {
                    msg = '客户经理UM未选择';
                }
                return msg;
            }
        },
        components: {
            mButton,
            mInput,
            mPicker,
            mDatePicker
        }

    };
</script>
<style scoped lang="scss">
.con{padding-bottom: 1.6rem;}
.tit{
    font-size: .28rem;
    padding: 0.1rem 0 0.1rem .3rem;
    color: #9b9b9b;
}
.needInform{
    width: 100%;
    background-color: white;
    padding-left: .3rem;
    height: .96rem;
    line-height: .96rem;
    border-top: 1px solid #ddd;
    border-bottom: 1px solid #ddd;
    .inf{
        display: inline-block;
        width: 18px;
        height: 18px;
        background: url('../../../assets/images/app/icons/icon_checkbox_sel@3x.png') center center/100% no-repeat;
        position: relative;
        top: 3px;
        margin-right: 10px;
    }
    .notInf{
        display: inline-block;
        width: 18px;
        height: 18px;
        background: url('../../../assets/images/app/icons/icon_checkbox@3x.png') center center/100% no-repeat;
        position: relative;
        top: 3px;
        margin-right: 10px;
    }
}
.option{
    width: 100%;
    height: 100px;
    background-color: white;
    text-align: center;
    position: absolute;
    bottom: 0;
    .inform, .save{
        display: inline-block;
        background-color: grey;
        width: 100px;
        height: 50px;
        font-size: 16px;
        line-height: 50px;
        margin-top: 25px;
    }
}
.bt-bottom {
    position: fixed;
    left: 0;
    bottom: 0;
    width: 100%;
    background-color: white;
    // height: 1.2rem;
    padding: .2rem 0;
}
</style>
