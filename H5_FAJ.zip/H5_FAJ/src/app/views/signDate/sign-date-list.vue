<template>
    <div class="signDataOrder">
        <order-card v-show="!noOrders" v-for="item in orderList" :item="item" :key="item.orderId" @goDetail="goDetail(item)"></order-card>
        <no-orders v-show="noOrders"></no-orders>
    </div>
</template>
<script type="text/ecmascript-6">
    import noOrders from '@/components/no-orders.vue';
    import orderCard from '@/components/order-card.vue';
    export default {
        name: 'signDataOrder',
        data() {
            return {
                orderList: [],
                noOrders: false
            };
        },
        created() {
            C.Native.setHeader({
                title: C.T.SIGN_DATE_LIST
            });
            C.UI.stopLoading();
        },
        mounted() {
            this.$nextTick(()=> {
                // 渲染页面的数据是不需要加载loading的
                this.getData();
            });
            $$.EventListener.onBack = ()=> {
                this.getData();
            };
        },
        methods: {
            getData() {
                $.ajax({
                    url: C.Api('OPMGT_ORDER_LIST'),
                    data: {
                        searchType: '04'
                    },
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            if (res.data.orderList.length <= 0) {
                                this.noOrders = true;
                            } else {
                                this.orderList = res.data.orderList;
                            }
                        }
                    }
                });
            },
            goDetail(item) {
                C.Native.forwardWebView({
                    url: '#/signDateDetail/?orderId=' + item.orderId + '&fromType=sign-date'
                });
            }
        },
        components: {
            orderCard,
            noOrders
        }
    };
</script>
<style scoped>
    .signdata-wrapper{ top: 0px;}
    .signDataOrder{ margin-bottom: .2rem;}
</style>
