<template>
    <div class="error-content">
        <h1 class="error-h1-404">404</h1>
        <p class="error-no-page">出错喽，您请求的网页不存在！</p>
    </div>
</template>
<script type="text/ecmascript-6">
    export default {
        created() {
            C.Native.setHeader({
                title: C.T.ERROR
            });
            C.UI.stopLoading();
        }
    };
</script>
<style scoped>
    .error-content{
        padding-top: 80px;
        text-align: center;
    }
    .error-h1-404{
        font-size: 80px;
        color: #f60;
    }
    .error-no-page{
        font-size: 20px;
        color: #999;
    }
</style>
