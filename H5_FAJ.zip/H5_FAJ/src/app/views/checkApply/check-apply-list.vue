<template>
    <div>
        <div class="delayOrder" v-if='!isShowDefault'>
            <order-card v-for="item in orderList" :item="item" :key="item.orderId" @goDetail="goDetail(item)"></order-card>
        </div>
        <no-orders v-if='isShowDefault'></no-orders>
    </div>
</template>
<script type="text/ecmascript-6">
    import orderCard from '@/components/order-card.vue';
    import noOrders from '@/components/no-orders.vue';
    export default {
        name: 'delayOrder',
        data() {
            return {
                isShowDefault: false, // 没有数据的时候
            	orderList: []
            };
        },
        created() {
            C.Native.setHeader({
                title: C.T.CHECK_APPLY_LIST
            });
        },
        mounted() {
        	this.$nextTick(()=> {
                // 渲染页面的数据是不需要加载loading的
                this.getData();
            });
            $$.EventListener.onBack = ()=> {
                this.getData();
            };
        },
        methods: {
        	getData() {
                $.ajax({
                    url: C.Api('OPMGT_ORDER_LIST'),
                    data: {
                        searchType: '02'
                    },
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            this.orderList = res.data.orderList;
                            this.isShowDefault = !this.orderList.length;
                        }
                    }
                });
            },
            goDetail(item) {
                C.Native.forwardWebView({
                    url: '#/checkApply/' + item.orderId
                });
            }
        },
        components: {
        	orderCard,
            noOrders
        }
    };
</script>
<style scoped>
    .delayOrder{ margin-bottom: .2rem;}
</style>
