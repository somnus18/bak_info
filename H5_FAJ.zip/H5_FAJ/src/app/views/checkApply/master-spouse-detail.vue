<template>
    <section class="partner-detail">
        <!--<div class="left" @click="leftGo">{{isToView?"返回前面":"关闭编辑"}}</div>-->
        <!-- <div class="edit" @click="stateChange" v-if="!checkState">{{checkState ? '' : (isToView ? '编辑' : '保存')}}</div> -->
        <master-spouse-detail :isToView="isToView" :info="info" btnName="审核通过" :isShowBtn="!checkState && isShowBtn" @save="checkPass" ref="hah"></master-spouse-detail>
    </section>
</template>
<script type="text/ecmascript-6">
    import masterSpouseDetail from 'src/components/master-borrower/spouse';
    import * as types from 'src/app/vuex/mutation-types';

    export default {
        name: 'common-borrower-detail',
        data() {
            return {
            	orderId: this.$route.query.orderId,
                isToView: true,
                checkState: this.$route.query.checkState === '1', // 0待处理 1已完成
                info: {
	                clientName: null,
	                globalType: null,
	                globalId: null,
	                country: null,
	                sex: null,
	                birthDate: null,
	                companyName: null,
	                companyProvince: '',
	                companyCity: '',
	                companyCounty: '',
	                companyAddress: '',
	                monthIncome: 0,
	                socProPaybase: 0,
	                companyTelephone: '',
	                mobile: null
	            }
            };
        },
        created() {
            C.Native.setHeader({
                title: C.T.MASTER_SPOUSE,
                rightText: this.checkState ? '' : (this.isToView ? '编辑' : '保存'),
                rightCallback: ()=> {
                    this.stateChange();
                },
                leftCallback: ()=> {
                    this.$router.go(-1);
                }
            });
        },
        mounted() {
            this.$nextTick(()=> {
                this.render();
            });
        },
        computed: {
        	isShowBtn() {
                return this.isToView;
            },
            noEmpty() {
                // let _this = this;
                return Object.assign({
                    companyName: '单位名称必填',
                    companyCounty: '工作单位城市必选',
                    companyAddress: '工作单位详细地址必填',
                	monthIncome: '税后月收入必填',
                	socProPaybase: '社保/公积金缴费基数必填',
                    companyTelephone: '单位电话必填',
                    mobile: '手机号码必填'
                });
            }
        },
        methods: {
            render() {
                C.UI.loading();
                $.ajax({
                    url: C.Api('GET_SPOUSE_INFO'),
                    data: {
                        orderId: this.orderId
                    },
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            for (let key in res.data) {
                                this.info[key] = res.data[key];
                            }
                        }
                    }
                });
            },
            stateChange() {
                if (!this.checkState) {
                    if (this.isToView) {
                        this.isToView = false;
                        this.$store.commit(types.SET_HEADER_R_T_I, {rightText: '保存'});
                    } else {
                        this.uploadEdit();
                    }
                }
            },
            uploadEdit() {
                if (!this.emptyCheck()) {
                    return false;
                }
                let validator = this.$refs.hah.validatorAction();
                if (validator) {
                    C.Native.tip(validator);
                    return false;
                }
                C.UI.loading();
                $.ajax({
                    url: C.Api('UPDATE_SPOUSE_INFO'),
                    data: Object.assign(this.info, {
                    	orderId: this.orderId
                    }),
                    success: res=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            this.isToView = true;
                            this.$store.commit(types.SET_HEADER_R_T_I, {rightText: '编辑'});
                            C.Native.tip('保存成功');
                        }
                    }
                });
                return true;
            },
            emptyCheck() {
                let flag = true;
                for (let key in this.noEmpty) {
                     if (!this.info[key] && this.info[key] !== 0) {
                        C.Native.tip(this.noEmpty[key]);
                        flag = false;
                        return false;
                     }
                }
                return flag;
            },
            checkPass() {
                if (this.emptyCheck()) {
                    C.UI.loading();
                    $.ajax({
                        url: C.Api('UNITIVE_CHECK'),
                        data: {
                         orderId: this.orderId,
                         checkType: '04'  // 01： 主借款人 ； 02： 共同借款人；03：个人保证人 ；04：主借款人配偶 ；05： 抵押物 ； 06： 贷款信息；07：补充贷款信息
                        },
                        success: (res)=> {
                            C.UI.stopLoading();
                            if (res.flag === C.Flag.SUCCESS) {
                                C.Native.tip('审核通过');
                                this.$router.go(-1);
                            }
                        }
                    });
                }
            }
        },
        components: {
            masterSpouseDetail
        }
    };
</script>
<style scoped lang="scss">
    .left,.edit{
        position: fixed;
        top:0;
        background: orange;
        padding:10px;
        z-index: 666;
    }
    .left{
        left: 20%;
    }
    .edit{
        right: 20%;
    }
</style>

