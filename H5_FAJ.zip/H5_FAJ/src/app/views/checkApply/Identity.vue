<template>
    <div class="identity">
        <section>
            <div class="title">
                <span>主借款人身份验证</span>
            </div>
            <!-- 固定字段 -->
            <div>
                <m-cell v-model="idType[majorCustMap.globalType]" :textName="'证件类型'" :disabled=true :noBorder=true></m-cell>
                <m-cell v-model="countryTpye[majorCustMap.country]" :textName="'国家和地区'" :disabled=true :noBorder=true></m-cell>
                <m-cell v-model="majorCustMap.clientName" :textName="'姓名'" :disabled=true :noBorder=true></m-cell>
                <m-cell v-model="majorCustMap.globalId" :textName="'证件号码'" :disabled=true></m-cell>
            </div>
            <!-- 保存后 -->
            <div>
                <m-cell v-model="sexType[majorCustMap.sex]" :textName="'性别'" :disabled=true></m-cell>
                <m-cell v-model="sexType[majorCustMap.birthDate]" :textName="'出生日期'" :disabled=true></m-cell>
                <m-cell v-model="longTermType[majorCustMap.longTerm]" :textName="'证件到期日 - 长期有效'" :disabled=true></m-cell>
                <m-cell v-model="majorCustMap.finDirExpiryDate" :textName="'证件到期日'" :disabled=true></m-cell>
                <m-cell v-model="majorCustMap.certificateOrg" :textName="'发证机关所在地'" :disabled=true></m-cell>
                <m-cell v-model="maritalStatusType[majorCustMap.maritalStatus]" :textName="'主借款人婚姻状况'" :disabled=true></m-cell>
            </div>
            <br>
            <!-- 编辑状态 -->
            <div>
                <m-cell v-model="sexType[majorCustMap.sex]" :textName="'性别'" :type="'select'" @select-input='pickerEvent("majorCustMap.sex", "性别", "A9")'></m-cell>
                <m-cell v-model="majorCustMap.birthDate" :textName="'出生日期'" :type="'select'"  @select-input='selectDate("majorCustMap.birthDate", "出生日期")'></m-cell>
                <m-cell v-model="longTermType[majorCustMap.longTerm]" :textName="'证件到期日 - 长期有效'" :type="'select'" @select-input='pickerEvent("masterCardId", "主借款人证件类型", "34")'></m-cell>
                <m-cell v-model="majorCustMap.finDirExpiryDate" :textName="'证件到期日'" :type="'select'" @select-input='pickerEvent("masterCardId", "主借款人证件类型", "34")'></m-cell>
                <m-cell v-model="majorCustMap.certificateOrg" :textName="'发证机关所在地'" type="text" :placeholder="'请输入'"></m-cell>
                <m-cell v-model="maritalStatusType[majorCustMap.maritalStatus]" :textName="'主借款人婚姻状况'" :type="'select'" @select-input='pickerEvent("masterCardId", "主借款人证件类型", "34")'></m-cell>
            </div>
        </section><br><br>
        <!-- <section>
            <div class="title">
                <span>主借款人配偶身份验证</span>
            </div>
            <m-cell v-model="msg" :textName="'证件类型'" :type="'select'" @select-input="click">
            </m-cell>
            <m-cell v-model="msg" :textName="'国家和地区'" :type="'select'" @select-input="click">
            </m-cell>
            <m-cell :textName="'证件号码'" :disabled=true @select-input="click">
                <div class="wh-20">
                    <m-button :text="'OCR'"></m-button>
                </div>
            </m-cell>
            <m-cell v-model="msg" :textName="'姓名'" :type="'text'" @select-input="click">
            </m-cell>
            <m-cell v-model="msg" :textName="'性别'" :type="'select'" @select-input="click">
            </m-cell>
            <m-cell v-model="msg" :textName="'出生日期'" :type="'select'" @select-input="click">
            </m-cell>
            <m-cell v-model="msg" :textName="'借款关系人类型'" :type="'select'" @select-input="click">
            </m-cell>
        </section>
        <section>
            <div class="title">
                <span>共同借款人</span>
            </div>
            <m-cell v-model="msg" :textName="'与主借款人关系'" :type="'select'" @select-input="click">
            </m-cell>
            <m-cell v-model="msg" :textName="'与主借款人关系-其他'" :type="'select'" @select-input="click">
            </m-cell>
            <m-cell v-model="msg" :textName="'证件类型'" :type="'select'" @select-input="click">
            </m-cell>
            <m-cell v-model="msg" :textName="'国家和地区'" :type="'select'" @select-input="click">
            </m-cell>
            <m-cell :textName="'姓名'" :disabled=true>
                <div class="wh-20">
                    <m-button :text="'OCR'"></m-button>
                </div>
            </m-cell>
            <m-cell v-model="msg" :textName="'性别'" :type="'select'" @select-input="click">
            </m-cell>
            <m-cell v-model="msg" :textName="'出生日期'" :type="'select'" @select-input="click">
            </m-cell>
            <m-cell v-model="msg" :textName="'证件号码'" :type="'text'" @select-input="click">
            </m-cell>
        </section>
        <div class="cell-btn">
            <span>+ 添加共同借款人</span>
        </div>
        <section>
            <div class="title">
                <span>个人保证人</span>
            </div>
            <m-cell v-model="msg" :textName="'与主借款人关系'" :type="'select'" @select-input="click">
            </m-cell>
            <m-cell v-model="msg" :textName="'证件类型'" :type="'select'" @select-input="click">
            </m-cell>
            <m-cell v-model="msg" :textName="'国家和地区'" :type="'select'" @select-input="click">
            </m-cell>
            <m-cell v-model="msg" :textName="'姓名'" :type="'text'">
            </m-cell>
            <m-cell v-model="msg" :textName="'性别'" :type="'select'" @select-input="click">
            </m-cell>
            <m-cell v-model="msg" :textName="'出生日期'" :type="'select'" @select-input="click">
            </m-cell>
            <m-cell v-model="msg" :textName="'证件号码'" :type="'text'" @select-input="click">
            </m-cell>
            <m-cell v-model="msg" :textName="'证件到期日-长期有效'" :type="'text'" @select-input="click">
            </m-cell>
            <m-cell v-model="msg" :textName="'证件到期日'" :type="'text'" @select-input="click">
            </m-cell>
        </section>
        <div class="cell-btn">
            <span>+ 添加个人保证人</span>
        </div> -->
        <div class="submit">
            <m-button :text="'保存'" @click-button="saveOrder"></m-button>
        </div>
        <m-picker :isPicker='isPicker' :indexText='indexText' :slots='slots' :datakey='datakey' :valueKey='valueKey' @confirm='pickerConfirm' @cancel='pickerCancel'></m-picker>
        <m-date-picker :isPicker='isDatePicker' :indexText='dateIndexText' :datakey='dateDataKey' @confirm='datePickerConfirm' @cancel="datePickerCancel"></m-date-picker>
    </div>
</template>
<script>
    import mCell from 'components/cell/cell';
    import mCircle from 'components/circle/circle';
    import mButton from 'components/button/button';
    import mPicker from 'src/components/picker/index';
    import mDatePicker from 'src/components/picker/date-picker.vue';
    export default{
        data() {
            return {
                msg: '123',
                isPicker: false, // 普通选择器显示或隐藏
                indexText: '筛选条件', // 选择器名称
                dateIndexText: '筛选条件', // 选择器名称
                datakey: '', // 选择器结果赋值到对象的key值
                dateDataKey: '',
                valueKey: 'v', // 下拉框设置 value-key 属性来指定显示的字段名
                slots: [], // slot 对象数组
                isDatePicker: false, // 时间选择器显示或隐藏
                // 各类字段
                idType: C.Constant['34'],
                countryTpye: C.Constant['2'],
                sexType: C.Constant['A9'],
                longTermType: C.Constant['A8'],
                maritalStatusType: C.Constant['5'],
                // 主借款人
                majorCustMap: {
                    globalType: 'Ind01',
                    country: 'CHN',
                    clientName: '李四',
                    globalId: '431025384756458902',
                    sex: 'F',
                    birthDate: '',
                    longTerm: '0',
                    finDirExpiryDate: '2044-03-03',
                    certificateOrg: '',
                    maritalStatus: '20',
                    // ---------
                    loanType: '',
                    state: '',
                    createStartTime: '',
                    createEndTime: '',
                    KB: '',
                    orderId: '',
                    masterName: '',
                    masterMobile: ''
                },
                A2: C.Constant.A2,
                A1: C.Constant.A1
            };
        },
        created() {
            C.Native.setHeader({
                title: '身份验证',
                leftCallback: ()=> {
                }
            });
        },
        components: {
            mCell,
            mCircle,
            mButton,
            mPicker,
            mDatePicker
        },
        methods: {
            // 普通选择器
            pickerEvent(key, text, slot) {
                this.datakey = key;
                this.indexText = text;
                this.slots = [{values: C.Utils.objToArr(C.Constant[slot])}];
                this.isPicker = true;
                this.isDatePicker = false;
                this.isAreaPicker = false;
            },
            // 普通选择器 确认
            pickerConfirm(value, key) {
                let jsonKey = key.split('.');
                this[jsonKey[0]][jsonKey[1]] = value.k;
                // console.log(value);
                this.isPicker = false;
            },
            // 普通选择器 取消
            pickerCancel() {
              this.isPicker = false;
            },
            // 日期选择器
            selectDate(key, text) {
                this.dateDataKey = key;
                this.dateIndexText = text;
                this.isPicker = false;
                this.isDatePicker = true;
                // this.isAreaPicker = false;
            },
            // 日期清除按钮
            datePickerCancel() {
                this.isDatePicker = false;
            },
            // 日期确定按钮
            datePickerConfirm(value, key) {
                this.isDatePicker = false;
                let jsonKey = key.split('.');
                this[jsonKey[0]][jsonKey[1]] = value.join('-');
            },
            click() {
            },
            saveOrder() {
            }
        }
    };
</script>
<style lang="scss" scoped rel="stylesheet/scss">
    .submit {
        background: white;
        box-sizing: content-box;
        margin-top: .2rem;
        padding: .4rem 1rem;
        height: .8rem;
        line-height: .8rem;
        text-align: center;
    }

    .cell-btn {
        margin-top: .2rem;
        color: #26a2ff;
        line-height: 1rem;
        text-align: center;
        background: white;
    }

    .wh-20 {
        text-align: center;
        width: 1rem;
    }

    .setHeight {
        height: 1.5rem;
    }

    .title {
        position: relative;
        .remove {
            color: red;
            position: absolute;
            top: 0;
            right: .3rem;
        }
        span {
            padding: .2rem .3rem .1rem .3rem;
            color: #999;
            display: inline-block;
        }
    }
</style>
