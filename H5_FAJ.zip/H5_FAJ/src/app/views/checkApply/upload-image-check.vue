<template>
    <section>
        <photo-page v-for='item in initImgsList'
            :key="item.kbType"
            :item='item'
            :isPhotoMain='item.isPhotoMain'
            :isShowAddBtn='!isToView && (item.imgList.length < maxLength)'
            :canShowBigImg="!isToView"
            :notRemoveIcon=true
            page="uploadMeterials"
            :orderId="orderId"
            :kbType="item.kbType"
        ></photo-page>
        <div class="btn-wrap" v-if="!isToView">
            <div class="btn" :class="[curTotalImgNum?'':'btn-disabled']" @click="submit">审核通过</div>
        </div>
    </section>
</template>

<script type='text/ecmascript-6'>
import photoPage from '@/components/photograph/index.vue';
export default {
    name: 'pending-photo',
    data() {
        return {
            isToView: false,
            orderId: '',
            maxLength: 40,
            applyStatus: '',
            initImgsList: [{
                kbType: '',
                imgList: [{
                    imgId: '',
                    imgUrl: '',
                    bigImgUrl: ''
                }]
            }]
        };
    },
    components: {
        photoPage
    },
    computed: {
        curTotalImgNum() {
            let num = false;
            if (this.initImgsList) {
                for (let i = 0; i < this.initImgsList.length; i++) {
                    if (this.initImgsList[i].imgList && this.initImgsList[i].imgList.length > 0) {
                        num = true;
                        break;
                    }
                }
            }
            return num;
        }
    },
    created() {
        // '0'：待处理；'1'：已审核
        this.isToView = this.$route.query.checkState === '1';
        this.orderId = this.$route.query.orderId;
        C.Native.setHeader({
            title: C.T.UPLOAD_IMAGE_CHECK,
            leftCallback: ()=> {
                this.$router.go(-1);
            }
        });
    },
     mounted() {
        this.$nextTick(()=> {
            this.initData();
        });
    },
    methods: {
        // 初始化写在页面外，不要写在组件
        initData() {
            C.UI.loading();
            $.ajax({
                url: C.Api('SHOW_MATERIALS'),
                data: {
                    orderId: this.orderId
                },
                success: (res)=> {
                    C.UI.stopLoading();
                    if (res.flag === C.Flag.SUCCESS) {
                        this.initImgsList = res.data;
                        this.initImgsList.forEach((item)=> {
                            item.title = C.Constant.KB_T[item.kbType];
                            // item.isPhotoMain = (item.kbType === C.Constant.KB_01 || item.imgList.length !== 0); // 图片上传DIV显示与隐藏
                            item.isPhotoMain = false; // 图片上传DIV显示与隐藏
                            item.imgList.forEach((it)=> {
                                it.imgUrl = C.Utils.httpAddImage(it.imgUrl);
                                it.bigImgUrl = C.Utils.httpAddImage(it.bigImgUrl || it.imgUrl);
                            });
                        });
                    }
                }
            });
        },
        submit() {
            if (this.curTotalImgNum) {
                C.UI.loading();
                $.ajax({
                    url: C.Api('UNITIVE_CHECK'),
                    data: {
                        orderId: this.$route.query.orderId,
                        checkType: '08'  // 01： 主借款人 ； 02： 共同借款人；03：个人保证人 ；04：主借款人配偶 ；05： 抵押物 ； 06： 贷款信息；07：补充贷款信息；08： 审核上传影像；
                    },
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            C.Native.tip('审核通过');
                            this.$router.go(-1);
                        }
                    }
                });
            }
        }
    }
};
</script>

<style scoped lang="scss">
section{
    padding-bottom: 1.5rem;
}
.btn-wrap {
    position: fixed;
    left: 0;
    bottom: 0;
    width:100%;
    padding:.2rem 0;
    margin-top: .2rem;
    background: white;
    .btn{
        margin: 0 auto;
    }
}
</style>

