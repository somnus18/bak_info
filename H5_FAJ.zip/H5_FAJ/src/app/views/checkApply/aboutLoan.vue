<template>
    <section class="partner-detail">
        <!-- <div class="left" @click="leftGo">{{isToView?"返回前面":"关闭编辑"}}</div> -->
        <!-- <div class="edit" @click="stateChange" v-if="!checkState">{{checkState ? '' : (isToView ? '编辑' : '保存')}}</div> -->
        <loan-detail :isToView="isToView" :info="info" btnName="审核通过" :isShowBtn=false ref="hah"></loan-detail>
        <div class="btn-wrap" v-if="!checkState && isShowBtn">
            <div class="btn" @click="checkPass">审核通过</div>
        </div>
    </section>
</template>
<script type="text/ecmascript-6">
    import loanDetail from '@/components/loan-info/detail';
    import * as types from 'src/app/vuex/mutation-types';

    export default {
        name: 'loan-info',
        data() {
            return {
            	orderId: '',
                isToView: true,
                checkState: true,
                // 贷款用途 购买商用房
                C19_1: C.Constant['19_1'],
                info: {
                	loanId: '',
					orderId: '',
					commercialBuidingName: '',
					buildingName: '',
					loanVariety: '',
					bizApplyAmount: '',
					publicReserveApplyAmount: '',
                    loanPlan: '',
					loanLimit: '',
					loanPurposeType: '',
					repaymentType: '',
					repaymentPeriod: ''
	            }
            };
        },
        created() {
            this.orderId = this.$route.query.orderId;
            this.checkState = this.$route.query.checkState === '1';
            C.Native.setHeader({
                title: C.T.LOAN_INFO,
                rightText: this.checkState ? '' : (this.isToView ? '编辑' : '保存'),
                rightCallback: ()=> {
                    this.stateChange();
                },
                leftCallback: ()=> {
                    this.$router.go(-1);
                }
            });
        },
        mounted() {
            this.$nextTick(()=> {
                this.render();
            });
        },
        computed: {
        	isShowBtn() {
                return this.isToView;
            },
            noEmpty() {
                return Object.assign({
                	loanLimit: '贷款期限必填',
                	loanPurposeType: '贷款用途必选'
                }, this.info.loanPurposeType === this.C19_1 && {buildingName: '房产名称必填'}, {
                	repaymentType: '还款方式必选'
                });
            }
        },
        methods: {
            render() {
                C.UI.loading();
                $.ajax({
                    url: C.Api('SHOW_LOAN_INFO'),
                    data: {
                        orderId: this.orderId
                    },
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            for (let key in res.data) {
                                this.info[key] = res.data[key];
                            }
                            // 需排除数字0
                            // this.info.publicReserveApplyAmount = +this.info.publicReserveApplyAmount || '-';
                        }
                    }
                });
            },
            stateChange() {
                if (!this.checkState) {
                    if (this.isToView) {
                        this.isToView = false;
                        this.$store.commit(types.SET_HEADER_R_T_I, {rightText: '保存'});
                    } else {
                        this.uploadEdit();
                    }
                }
            },
            uploadEdit() {
                let validator, data;
                // 空校验
                if (!this.emptyCheck()) {
                    return false;
                }
                // 逻辑校验
                validator = this.$refs.hah.validator();
                if (validator) {
                    C.Native.tip(validator);
                    return false;
                }
                // 入参 单位处理
                data = Object.assign({}, this.info, {
                    orderId: this.orderId,
                    submitType: '02' // 01-新建时提交；02-审核时提交【于201801需求添加】
                });
                data.bizApplyAmount = C.Utils.toY(this.$refs.hah.bizApplyAmount, 2);
                data.publicReserveApplyAmount = C.Utils.toY(this.$refs.hah.publicReserveApplyAmount, 2);
                // 上传
                C.UI.loading();
                $.ajax({
                    url: C.Api('UPLOAD_LOAN_INFO'),
                    data: data,
                    success: res=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            this.isToView = true;
                            this.$store.commit(types.SET_HEADER_R_T_I, {rightText: '编辑'});
                            C.Native.tip('保存成功');
                        }
                    }
                });
            },
            emptyCheck() {
                let flag = true;
                for (let key in this.noEmpty) {
                     if (!this.info[key] && this.info[key] !== 0) {
                        C.Native.tip(this.noEmpty[key]);
                        flag = false;
                        return false;
                     }
                }
                return flag;
            },
            checkPass() {
                if (this.emptyCheck()) {
                    $.ajax({
                        url: C.Api('UNITIVE_CHECK'),
                        data: {
                         orderId: this.orderId,
                         checkType: '06'  // 01： 主借款人 ； 02： 共同借款人；03：个人保证人 ；04：主借款人配偶 ；05： 抵押物 ； 06： 贷款信息；07：补充贷款信息
                        },
                        success: (res)=> {
                            C.UI.stopLoading();
                            if (res.flag === C.Flag.SUCCESS) {
                                C.Native.tip('审核通过');
                                this.$router.go(-1);
                            }
                        }
                    });
                }
            }
        },
        components: {
            loanDetail
        }
    };
</script>
<style scoped lang="scss">
    .left,.edit{
        position: fixed;
        top:0;
        background: orange;
        padding:10px;
        z-index: 666;
    }
    .left{
        left: 20%;
    }
    .edit{
        right: 20%;
    }
    .btn-wrap {
        position: fixed;
        left: 0;
        bottom: 0;
        width:100%;
        padding:.2rem 0;
        margin-top: .2rem;
        background: white;
        .btn{
            margin: 0 auto;
        }
    }
</style>

