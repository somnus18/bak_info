<template>
    <section class="partner-detail">
        <!--<div class="left" @click="leftGo">{{isToView?"返回前面":"关闭编辑"}}</div>-->
        <!-- <div class="edit" @click="stateChange" v-if="!checkState">{{checkState ? '' : (isToView ? '编辑' : '保存')}}</div> -->
        <master-borrower-detail :isToView="isToView" :info="info" btnName="审核通过" :isShowBtn="!checkState && isShowBtn" @save="checkPass" ref="hah"></master-borrower-detail>
    </section>
</template>
<script type="text/ecmascript-6">
    import masterBorrowerDetail from 'src/components/master-borrower/detail';
    import * as types from 'src/app/vuex/mutation-types';

    export default {
        name: 'common-borrower-detail',
        data() {
            return {
            	orderId: this.$route.query.orderId,
                checkState: this.$route.query.checkState === '1',
                isToView: true,
                info: {
					'clientName': '',
					'globalType': '',
					'globalId': '',
					'country': '',
					'sex': '',
					'birthDate': '',
					'secuFinDirExpiryDate': '',
					'finDirExpiryDate': '',
					'certificateOrg': '',
					'maritalStatus': '',
					'mimorChildFlag': '',
					'education': '',
					'localCensusFlag': '',
					'residenceRegisteredType': '',
					'localSocialFlag': '',
					'socialPayYear': 0,
					'familyHouseNum': 0,
					'localHouseFlag': '',
					'localYear': 0,
					'residentType': '',
					'homeProvince': '',
					'homeCity': '',
					'homeCounty': '',
					'homeAddress': '',
					'familyMonthCashOut': 0,
					'employmentType': '',
					'companyName': '',
					'deptName': '',
					'unitTypeCode': '',
					'clientJobyears': 0,
					'unitKind': '',
					'positionType': '',
					'dutyName': '',
					'dutyLevel': '',
					'specialQualifacationType': '',
					'monthIncome': 0,
					'socProPaybase': 0,
					'companyProvince': '',
					'companyCity': '',
					'companyCounty': '',
					'companyAddress': '',
					'mobile': '',
					'companyTelephone': '',
					'paymentType': '',
					'repaymentAccountBank': '',
					'repaymentAccountName': '',
					'repaymentAccountCardNo': '',
					'sellerCollectMoney': '',
					'firstMailType': '',
					'firstPhoneType': '',
					'insureFlag': '',
					'ownBranchPayrollWageFlag': ''
				}
            };
        },
        created() {
            C.Native.setHeader({
                title: C.T.MASTER_BORROWER,
                rightText: this.checkState ? '' : (this.isToView ? '编辑' : '保存'),
                rightCallback: ()=> {
                    this.stateChange();
                },
                leftCallback: ()=> {
                   this.$router.go(-1);
                }
            });
        },
        mounted() {
            this.$nextTick(()=> {
                this.render();
            });
        },
        computed: {
        	isShowBtn() {
                return this.isToView;
            },
            noEmpty() {
                return Object.assign({
                	mimorChildFlag: '有无未成年子女必选',
                    education: '教育程度必选',
                    localCensusFlag: '是否本地户籍必选',
                    residenceRegisteredType: '户别必选',
                    localSocialFlag: '有无当地社保必选',
                    socialPayYear: '社保缴纳年限必填',
                    familyHouseNum: '家庭拥有住房套数必填',
                    localHouseFlag: '有无本地房产必选',
                    localYear: '本地居住年限必填',
                    residentType: '居住状况必选',
                    homeCounty: '居住城市必选',
                    homeAddress: '居住详细地址必填',
                    familyMonthCashOut: '家庭月支出必填',
                    employmentType: '雇佣类型必选',
                    companyName: '单位名称必填',
                    unitTypeCode: '单位性质必选',
                    deptName: '部门必填',
                    clientJobyears: '现单位工作年限必填',
                    unitKind: '工作单位所属行业必选',
                    dutyLevel: '职务类型必选',
                    dutyName: '职务名称必填',
                    positionType: '职业名称必填',
                    specialQualifacationType: '特殊资格类型必选',
                    monthIncome: '税后月收入必填',
                    socProPaybase: '社保/公积金缴费基数必填',
                    companyCity: '工作单位城市必选',
                    companyAddress: '工作单位详细地址必填',
                    mobile: '手机号码必填',
                    companyTelephone: '单位电话必填',
                    sellerCollectMoney: '是否卖方本人收款必选',
                    firstMailType: '邮寄首选必选',
                    firstPhoneType: '联系首选必选',
                    insureFlag: '在平安投保险2年以上必选',
                    ownBranchPayrollWageFlag: '代发工资户必选'
                });
            }
        },
        methods: {
            render() {
                C.UI.loading();
                $.ajax({
                    url: C.Api('GET_MAIN_BORROWER_INFO'),
                    data: {
                        orderId: this.orderId
                    },
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            for (let key in res.data) {
                                this.info[key] = res.data[key];
                            }
                        }
                    }
                });
            },
            stateChange() {
                if (!this.checkState) {
                    if (this.isToView) {
                        this.isToView = false;
                        this.$store.commit(types.SET_HEADER_R_T_I, {rightText: '保存'});
                    } else {
                        this.uploadEdit();
                    }
                }
            },
            uploadEdit() {
                // 家庭拥有住房套数 可以为 0 ，将number转为string
                this.info.familyHouseNum = this.info.familyHouseNum + '';
                if (!this.emptyCheck()) {
                    return false;
                }
                let validator = this.$refs.hah.validatorAction();
                if (validator) {
                    C.Native.tip(validator);
                    return false;
                }
                C.UI.loading();
                $.ajax({
                    url: C.Api('UPDATE_MAIN_BORROWER_INFO'),
                    data: Object.assign(this.info, {
                    	orderId: this.orderId
                    }),
                    success: res=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            this.isToView = true;
                            this.$store.commit(types.SET_HEADER_R_T_I, {rightText: '编辑'});
                            C.Native.tip('保存成功');
                        }
                    }
                });
                return true;
            },
            emptyCheck() {
                let flag = true;
                for (let key in this.noEmpty) {
                     if (!this.info[key] && this.info[key] !== 0) {
                        C.Native.tip(this.noEmpty[key]);
                        flag = false;
                        return false;
                     }
                }
                return flag;
            },
            checkPass() {
                if (this.emptyCheck()) {
                    C.UI.loading();
                    $.ajax({
                        url: C.Api('UNITIVE_CHECK'),
                        data: {
                         orderId: this.orderId,
                         checkType: '01'  // 01： 主借款人 ； 02： 共同借款人；03：个人保证人 ；04：主借款人配偶 ；05： 抵押物 ； 06： 贷款信息；07：补充贷款信息
                        },
                        success: (res)=> {
                            C.UI.stopLoading();
                            if (res.flag === C.Flag.SUCCESS) {
                                C.Native.tip('审核通过');
                                this.$router.go(-1);
                            }
                        }
                    });
                }
            }
        },
        components: {
            masterBorrowerDetail
        }
    };
</script>
<style scoped lang="scss">
    .left,.edit{
        position: fixed;
        top:0;
        background: orange;
        padding:10px;
        z-index: 666;
    }
    .left{
        left: 20%;
    }
    .edit{
        right: 20%;
    }
</style>

