<template>
    <section class="pledge-detail">
    	<!-- <div class="left" @click="leftGo">{{isToView?"返回前面":"关闭编辑"}}</div> -->
        <!-- <div class="edit" @click="stateChange" v-if="!checkState">{{checkState ? '' : (this.isToView ? '编辑' : '保存')}}</div> -->
        <pledge-detail :isToView="isToView" :info="info" btnName="审核通过" :isShowBtn="false" ref="hah" :isOwnerFixed=false @watchCreditState="showCredit"></pledge-detail>
    </section>
</template>
<script type="text/ecmascript-6">
    import pledgeDetail from 'src/components/pledge/detail';
    import * as types from 'src/app/vuex/mutation-types';

    export default {
        name: 'common-pledge-detail',
        data() {
            return {
                hasWarn: false,
            	isToView: true,
                checkState: this.$route.query.checkState === '1',
                info: {
                    defaultOwners: [],
                    loanVariety: '',
                    globalType: '',
                    globalId: '',
                    clientName: '',
                    houseInfo: {
                        collateralId: '',
                        houseProvince: '',
                        houseCity: '',
                        houseCounty: '',
                        houseAddress: '',
                        houseArea: '',
                        warrantType: '',
                        warrantCode: '',
                        houseKinds: '',
                        landParcelCode: '',
                        storeySumNum: '',
                        houseIndoorArea: '',
                        buildingName: '',
                        houseUse: '',
                        finishDate: '',
                        soilUseDeadline: '',
                        soilUseDeadlineStardDate: '',
                        soilUseDeadlineEndDate: '',
                        bargainPrice: '',
                        registeredPrice: '',
                        evaluationAmount: '',
                        ownerNum: ''
                    },
                    ownerList: [
                        {
                            unionId: '',
                            collateralOwnerId: '',
                            warrantOwnName: '',
                            warrantOwnGlobalType: '',
                            warrantOwnGlobalId: '',
                            warrantOwnShare: ''
                        }
                    ]
                },
                // 选择权利人弹框状态
                showCreditDialog: false
            };
        },
        created() {
            C.Native.setHeader({
                title: C.T.PLEDGE_DETAIL,
                rightText: this.checkState ? '' : '编辑',
                rightCallback: ()=> {
                    if (this.showCreditDialog || this.hasWarn) return;
                    this.stateChange();
                },
                leftCallback: ()=> {
                    C.Native.back();
                }
            });
        },
        mounted() {
            this.$nextTick(()=> {
                this.render();
            });
        },
        watch: {
            // 'isToView'(val) {
            //     switch (val) {
            //         case false:
            //             this.$store.commit(types.SET_HEADER_R_T_I, {rightText: '保存'});
            //             break;
            //         case true:
            //             this.$store.commit(types.SET_HEADER_R_T_I, {rightText: '编辑'});
            //             break;
            //         case 'empty':
            //             this.$store.commit(types.SET_HEADER_R_T_I, {rightText: ' '});
            //             break;
            //     }
            // }
        },
        computed: {
            noEmpty() {
                let ownerArr = [], json = {};
                for (let i = 0, len = this.info.ownerList.length; i < len; i++) {
                    json = {};
                    json['warrantOwnGlobalType' + i] = '权利人' + (i + 1) + '的证件类型必选';
                    json['warrantOwnName' + i] = '权利人' + (i + 1) + '的姓名必填';
                    json['warrantOwnGlobalId' + i] = '权利人' + (i + 1) + '的权利人证件号码必填';
                    ownerArr.push(json);
                }
                return Object.assign({
                    houseArea: '建筑面积(m²)必填',
                    landParcelCode: '宗地号必填',
                    storeySumNum: '总楼层数量必填',
                    houseIndoorArea: '房屋套内面积必填',
                    buildingName: '楼宇名称必填',
                    // estateType: '房产类型必选',
                    houseUse: '房屋用途必选',
                    finishDate: '竣工时间必选',
                    soilUseDeadlineStardDate: '土地使用期限_起始日必选',
                    soilUseDeadlineEndDate: '土地使用期限_到期日必选',
                    soilUseDeadline: '土地使用期限必填',
                    bargainPrice: '成交价必填',
                    registeredPrice: '登记价必填'
                }, this.info.loanVariety === C.Constant['A2_2'] ? {evaluationAmount: '单套评估价值必填'} : {},
                ...ownerArr);
            }
        },
        methods: {
        	render() {
                C.UI.loading();
                $.ajax({
                    url: C.Api('SHOW_HOUSE_INFO'),
                    data: {
                        collateralId: this.$route.params.id
                    },
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            // for (let key in res.data.houseInfo) {
                            //     this.info.houseInfo[key] = res.data.houseInfo[key];
                            // }
                            for (let key in res.data) {
                                this.info[key] = res.data[key];
                            }
                            // 为null时,设置为[]数组。防止组件报错
                            this.info.ownerList = res.data.ownerList || [];
                            this.info.houseInfo.bargainPrice = C.Utils.toWY(res.data.houseInfo.bargainPrice);
                            this.info.houseInfo.registeredPrice = C.Utils.toWY(res.data.houseInfo.registeredPrice);
                            this.info.houseInfo.evaluationAmount = C.Utils.toWY(res.data.houseInfo.evaluationAmount);
                        }
                    }
                });
            },
            stateChange() {
                if (!this.checkState) {
                    if (this.isToView) {
                        this.isToView = false;
                        this.$store.commit(types.SET_HEADER_R_T_I, {rightText: '保存'});
                    } else {
                        this.uploadEdit();
                    }
                }
            },
            createPostData() {
                // let param = $.extend(true, {}, this.info);
                let param = $.extend(true, {}, this.info, {submitType: '02'});
                param.houseInfo.bargainPrice = C.Utils.toY(param.houseInfo.bargainPrice);
                param.houseInfo.registeredPrice = C.Utils.toY(param.houseInfo.registeredPrice);
                param.houseInfo.evaluationAmount = C.Utils.toY(param.houseInfo.evaluationAmount);
                return param;
            },
            uploadEdit() {
                let validator,
                    param = this.createPostData(),
                    solidUseYear = +this.info.houseInfo.soilUseDeadline;
                if (!this.emptyCheck()) {
                    return false;
                }
                validator = this.$refs.hah.validator();
                if (validator) {
                    C.Native.tip(validator);
                    return false;
                }
                if ((solidUseYear === 40) || (solidUseYear === 70)) {
                    this.uploadData(param);
                } else {
                    this.$store.commit(types.SET_HEADER_R_T_I, {rightText: ' '});
                    this.hasWarn = true;
                    C.UI.warn({
                        isShowClose: true,
                        title: '提示',
                        content: '土地使用期限为【' + solidUseYear + '】，请确认是否有误？',
                        okText: '确定',
                        onlyBtn: true,
                        ok: ()=> {
                            this.uploadData(param);
                            this.hasWarn = false;
                        },
                        closeX: ()=> {
                            this.$store.commit(types.SET_HEADER_R_T_I, {rightText: '保存'});
                            this.hasWarn = false;
                        }
                    });
                }
            },
            uploadData(param) {
                C.UI.loading();
                $.ajax({
                    url: C.Api('UPLOAD_HOUSE_INFO'),
                    data: param,
                    success: res=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            this.isToView = true;
                            this.$store.commit(types.SET_HEADER_R_T_I, {rightText: '编辑'});
                            C.Native.tip('保存成功');
                        } else {
                            this.isToView = false;
                            this.$store.commit(types.SET_HEADER_R_T_I, {rightText: '保存'});
                        }
                    }
                });
            },
            emptyCheck() {
                let flag = true, newJson = {...(this.info.houseInfo)};
                for (let i = 0, len = this.info.ownerList.length; i < len; i++) {
                    let json = {};
                    json['warrantOwnGlobalType' + i] = this.info.ownerList[i].warrantOwnGlobalType;
                    json['warrantOwnName' + i] = this.info.ownerList[i].warrantOwnName;
                    json['warrantOwnGlobalId' + i] = this.info.ownerList[i].warrantOwnGlobalId;
                    Object.assign(newJson, json);
                }
                for (let key in this.noEmpty) {
                     if (!newJson[key] && this.info[key] !== 0) {
                        C.Native.tip(this.noEmpty[key]);
                        flag = false;
                        return false;
                     }
                }
                return flag;
            },
            showCredit(val) {
                this.showCreditDialog = val;
                // rightText为空需设置为' ', 设置''无效
                val ? this.$store.commit(types.SET_HEADER_R_T_I, {rightText: ' '}) : this.$store.commit(types.SET_HEADER_R_T_I, {rightText: '保存'});
            }
        },
        components: {
            pledgeDetail
        }
    };
</script>
<style scoped lang="scss">
    .left,.edit{
        position: fixed;
        top:0;
        background: orange;
        padding:10px;
        z-index: 666;
    }
    .left{
        left: 20%;
    }
    .edit{
        right: 20%;
    }
</style>
