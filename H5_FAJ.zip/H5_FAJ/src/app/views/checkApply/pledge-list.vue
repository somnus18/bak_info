<template>
    <section class="pledge-list">
        <pledge-list v-for="item in list" :key="item.id" :item="item" @goDetail="goDetail(item.collateralId)"></pledge-list>
        <div class="btn-wrap" v-if="!isToView">
            <div class="btn" @click="submit">审核通过</div>
        </div>
    </section>
</template>
<script type="text/ecmascript-6">
    import pledgeList from 'src/components/pledge/list';
    export default {
        name: 'm-pledge-list',
        data() {
            return {
                isToView: false,
                list: []
            };
        },
        created() {
            // '0'：待处理；'1'：已审核
            this.isToView = this.$route.query.checkState === '1';
            C.Native.setHeader({
                title: C.T.PLEDGE_LIST,
                leftCallback: ()=> {
                    this.$router.go(-1);
                }
            });
        },
        mounted() {
            this.$nextTick(()=> {
                this.render();
            });
            $$.EventListener.onBack = ()=> {
                this.render();
            };
        },
        computed: {},
        methods: {
            render() {
                C.UI.loading();
                $.ajax({
                    url: C.Api('SHOW_COLLATERAL_LIST'),
                    data: {
                        orderId: C.Utils.getParameter('orderId'),
                        listType: '02'
                    },
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            this.list = res.data.collateralList;
                        }
                    }
                });
            },
            goDetail(id) {
                C.Native.forwardWebView({
                    url: '#/checkApply/pledge/' + id + '?checkState=' + this.$route.query.checkState
                });
            },
            submit() {
                C.UI.loading();
                $.ajax({
                    url: C.Api('UNITIVE_CHECK'),
                    data: {
                     orderId: this.$route.query.orderId,
                     checkType: '05'  // 01： 主借款人 ； 02： 共同借款人；03：个人保证人 ；04：主借款人配偶 ；05： 抵押物 ； 06： 贷款信息；07：补充贷款信息
                    },
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            C.Native.tip('审核通过');
                            this.$router.go(-1);
                        }
                    }
                });
            }
        },
        components: {
            pledgeList
        }
    };
</script>
<style scoped lang="scss">
    .pledge-list{
        padding-bottom: 1.5rem;
    }
    .btn-wrap {
        position: fixed;
        left: 0;
        bottom: 0;
        width:100%;
        padding:.2rem 0;
        margin-top: .2rem;
        background: white;
        .btn{
            margin: 0 auto;
        }
    }
</style>
