<template>
    <div class="apply-wrap">
        <show-card :itemArr="showCard" class="mt5"></show-card>
        <item-card class="itemRow0 itemRow2 mt5" textName="贷款相关人信息" :disabled=true></item-card>
        <div class="itemRow1" v-for="(item,index) in contianPerson" :key="index" @click="toDetail(item.url)" v-if="item.show">
            <div class="item-card">
                <span class="grey">{{item.textName}}</span>
                <span class="fr hasRight" :class="!item.state?'ft-yellow':'ft-blue'">{{item.state ? '已完成' : '待处理'}}</span>
                <i class="icon-arrow-r"></i>
            </div>
        </div>
        <div class="itemRow2 mt5" v-for="(item,index) in otherItem" :key="index + 'aa'" @click="toDetail(item.url)"  v-if="item.show">
            <div class="item-card">
                <span class="grey">{{item.textName}}</span>
                <span class="fr hasRight" :class="!item.state?'ft-yellow':'ft-blue'">{{item.state ? '已完成' : '待处理'}}</span>
                <i class="icon-arrow-r"></i>
            </div>
        </div>

        <div class="bt-bottom">
            <div class="btn" :class="[canClick?'':'btn-disabled']" @click="clickEvent">确定</div>
        </div>
    </div>
</template>
<script type="text/ecmascript-6">
    import showCard from '@/components/show-card.vue';
    import itemCard from '@/components/order-item-card.vue';
    export default {
        name: 'checkApply',
        data() {
            return {
                orderId: '',
            	orderInfo: {
                    orderId: '',
                    orderNo: '',
                    barCode: '',
                    clientName: ''
                },
                stateInfo: {
                    mainBorrowerStatus: 0, // 主借款人
                    spouseStatus: 0, // 主借款人配偶
                    partnerStatus: 0, // 共同借款人
                    guarantorStatus: 0, // 担保人
                    collateralInfoStatus: 0, // 抵押物信息
                    loanInfoStatus: 0, // 贷款信息
                    supplyLoanInfoStatus: 0 // 补充贷款信息
                },
                canClick: false
            };
        },
        computed: {
            showCard() {
                return [
                    {name: '订单号', value: this.orderInfo.orderNo},
                    {name: 'KB码', value: this.orderInfo.barCode},
                    {name: '借款人', value: this.orderInfo.clientName}
                ];
            },
            contianPerson() {
                let orderId = this.orderInfo.orderId;
            	return [{
                    show: true,
                    textName: '主借款人详细信息',
                    state: +this.stateInfo.mainBorrowerStatus,
                    url: '#/checkApply/masterBorrower?orderId=' + orderId + '&checkState=' + this.stateInfo.mainBorrowerStatus
                }, {
                    show: this.stateInfo.spouseStatus,
                    textName: '主借款人配偶详细信息',
                    state: +this.stateInfo.spouseStatus,
                    url: '#/checkApply/masterSpouse?orderId=' + orderId + '&checkState=' + this.stateInfo.spouseStatus
                }, {
                    show: this.stateInfo.partnerStatus,
                    textName: '共同借款人详细信息',
                    state: +this.stateInfo.partnerStatus,
                    url: '#/checkApply/partner?orderId=' + orderId + '&checkState=' + this.stateInfo.partnerStatus
                }, {
                    show: this.stateInfo.guarantorStatus,
                    textName: '个人保证人详细信息',
                    state: +this.stateInfo.guarantorStatus,
                    url: '#/checkApply/guarantor?orderId=' + orderId + '&checkState=' + this.stateInfo.guarantorStatus
                }];
            },
            otherItem() {
                let orderId = this.orderInfo.orderId;
                return [{
                    show: true,
                    textName: '抵押物信息',
                    state: +this.stateInfo.collateralInfoStatus,
                    url: '#/checkApply/pledge?orderId=' + orderId + '&checkState=' + this.stateInfo.collateralInfoStatus
                }, {
                    show: true,
                    textName: '贷款信息',
                    state: +this.stateInfo.loanInfoStatus,
                    url: '#/checkApply/aboutLoan?orderId=' + orderId + '&checkState=' + this.stateInfo.loanInfoStatus
                }, {
                    show: true,
                    textName: '补充贷款信息',
                    state: +this.stateInfo.supplyLoanInfoStatus,
                    url: '#/checkApply/aboutLoanAdd?orderId=' + orderId + '&checkState=' + this.stateInfo.supplyLoanInfoStatus
                }, {
                    show: this.stateInfo.uploadImStatus,
                    textName: '审核上传影像',
                    state: +this.stateInfo.uploadImStatus,
                    url: '#/checkApply/uploadImageCheck?orderId=' + orderId + '&checkState=' + this.stateInfo.uploadImStatus
                }];
            }
        },
        created() {
            this.orderId = this.$route.params.id;
            C.Native.setHeader({
                title: C.T.CHECK_APPLY
            });
        },
        mounted() {
        	this.$nextTick(()=> {
                this.getData();
            });
        },
        methods: {
        	getData() {
                C.UI.loading();
        		$.ajax({
                    url: C.Api('CHECK_DETAIL'),
                    data: {
                        orderId: this.orderId
                    },
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            this.orderInfo.orderId = res.data.orderId;
                            this.orderInfo.orderNo = res.data.orderNo;
                            this.orderInfo.barCode = res.data.barCode;
                            this.orderInfo.clientName = res.data.clientName;
                            // '0'：待处理；'1'：已审核
                            this.stateInfo.loanInfoStatus = res.data.loanInfoStatus;
                            this.stateInfo.supplyLoanInfoStatus = res.data.supplyLoanInfoStatus;
                            this.stateInfo.partnerStatus = res.data.loanClientInfo.partnerStatus;
                            this.stateInfo.guarantorStatus = res.data.loanClientInfo.guarantorStatus;
                            this.stateInfo.spouseStatus = res.data.loanClientInfo.spouseStatus;
                            this.stateInfo.mainBorrowerStatus = res.data.loanClientInfo.mainBorrowerStatus;
                            this.stateInfo.collateralInfoStatus = res.data.collateralInfoStatus;
                            this.stateInfo.uploadImStatus = res.data.uploadImStatus;
                            // '0'：不显示；'1'：显示；用于列表是否显示审核按钮
                            this.canClick = +res.data.checkStatus;
                            // 用于单位电话自动出房产所在地的"区号"
                            C.Utils.data(C.DK.HOUSE_CITY, res.data.houseCity);
                        }
                    }
                });
        	},
        	toDetail(url) {
                C.Native.forward({
                    url: url
                });
            },
            clickEvent() {
                if (this.canClick) {
                    C.UI.loading();
                    $.ajax({
                        url: C.Api('SUBMIT_CHECK'),
                        data: {
                            orderId: this.orderId
                        },
                        success: (res)=> {
                            if (res.flag === C.Flag.SUCCESS) {
                                C.UI.stopLoading();
                                C.Native.back();
                            }
                        }
                    });
                }
            }
        },
        components: {
            showCard,
            itemCard
        }
    };
</script>
<style scoped>
    .apply-wrap{
        padding-bottom: 1.44rem;
    }
    .bt-bottom {
        position: fixed;
        bottom: 0;
        width: 100%;
        height: 1.24rem;
        line-height: 1.24rem;
        text-align: center;
        background: #fff;
    }
    .btn{
        display: inline-block;
        vertical-align: middle;
    }
    .itemRow1{
        padding: .22rem 0 .22rem .9rem;
        border-bottom: solid 1px #eee;
        background-color: #f6f6f6;
    }
    .itemRow2{
        padding: .22rem 0 .22rem .3rem;
        background: #fff;
        border-bottom: solid 1px #ddd;
    }
    .itemRow0{
        border-bottom: solid 1px #ddd;
    }
    .itemRow .item-card{margin-bottom: 1px;}
    .item-card{position: relative;}
    .grey{color: #666}
    .hasRight{margin-right: .8rem;_display:inline-block;}
    .icon-arrow-r{position: absolute;top:50%;right:.3rem;margin-top:-8px;padding: 8px; background: url('../../../assets/images/app/icons/icon_arrow_r@3x.png') center center/100% auto no-repeat; -webkit-background-size: 7px auto; background-size: 7px auto;}
</style>
