<template>
    <div class="identity">
    	<!-- 固定字段 -->
        <div class="fixed-row">
            <m-cell v-model="signType[info.interviewType]" :textName="'业务模式'" :disabled=true :noBorder=true></m-cell>
            <m-cell v-model="sealType[info.sealType]" :textName="'用印类型'" :disabled=true :noBorder=true></m-cell>
            <m-cell v-model="C35[info.intTatesExecuteType]" :textName="'利率执行方式'" :disabled=true :noBorder=true></m-cell>
            <m-cell v-model="info.percentAge" :textName="'贷款成数'" :disabled=true :noBorder=true></m-cell>
        </div>
        <section>
        	<div class="lilv">
                <m-cell class="setHeight" v-model="info.intFloatSpread" :disabled="isToView" :textName="''" type="text" :placeholder="'请输入'"></m-cell>
        		<div class="tip">
                    <p>利率浮动幅度</p>
                    <span><span class="star"></span>
                    请输入0-100的数值，最多两位小数</span>
                </div>
        		<ul v-if="!isToView">
	        		<li class="plus" :class="{act:aboveZero=='true'}" @click="floatChange('+')"></li>
	        		<li class="reduce" :class="{act:aboveZero=='false'}" @click="floatChange('-')"></li>
        		</ul>
        		<span v-if="!isToView" class="unit">%</span>
        	</div>
        	<m-cell v-model="info.firstDeveloperName" :disabled="isToView" :textName="'一手楼开发商名称'" :maxlength="42" type="text" :placeholder="'请填写'"
                v-if="info.loanVariety!=A2_2"
            ></m-cell>
        	<m-cell v-model="info.firstLimitCode" :disabled="isToView" :textName="'一手楼额度编号'" :maxlength="32" type="text" :placeholder="'请填写'"
                v-if="info.loanVariety!=A2_2"
            ></m-cell>
        	<m-cell v-model="info.assureCompanyName" :disabled="isToView" :textName="'担保公司名称'" :maxlength="42" type="text" :placeholder="'请填写'"></m-cell>
        	<m-cell v-model="info.assureCompanyLimitNo" :disabled="isToView" :textName="'担保公司额度号'" :maxlength="32" type="text" :placeholder="'请填写'"></m-cell>
        	<m-cell v-model="assureType[info.assureType]" :textName="'担保方式'" :disabled=true></m-cell>
        	<m-cell v-model="isAppointInsureType[info.isAppointInsure]" :disabled="isToView" :textName="'是否投保履约险'" :type="'select'"
        		@select-input='chooseInsure'>
        	</m-cell>
        	<m-cell v-model="info.appointInsureTerm" :disabled="isToView" :textName="'履约险投保期限(天)'" type="tel" :maxlength="16" :placeholder="'请填写'"
        		v-if="info.isAppointInsure!=C23_0"
        	></m-cell>
        	<m-cell v-model="info.repaymentAccountCardNo" :disabled="isToView" :textName="'还款卡号'" type="tel" :maxlength="32" :placeholder="'请填写卡号'"></m-cell>
        	<m-cell v-model="mortgageInsuranceLiabilityType[info.mortgageInsuranceLiability]" :disabled="isToView" :textName="'房贷险投保责任'" :type="'select'"
        		@select-input='pickerEvent("info.mortgageInsuranceLiability", "房贷险投保责任", "24")'
                v-if="info.interviewType==C1_2"
            ></m-cell>
        	<m-cell v-model="mortgageInsurancePeriodType[info.mortgageInsurancePeriod]" :disabled="isToView" :textName="'房贷险投保期限'" :type="'select'"
        		@select-input='pickerEvent("info.mortgageInsurancePeriod", "房贷险投保期限", "25")'
        		v-if="info.mortgageInsuranceLiability!=C24_1 && info.interviewType==C1_2"
    		></m-cell>
        </section>
        <div class="btn-wrap" v-if="!isToView">
        	<div class="btn" @click="submit">保存</div>
        </div>
        <m-picker :isPicker='isPicker' :indexText='indexText' :slots='slots' :datakey='datakey' :valueKey='valueKey' @confirm='pickerConfirm' @cancel='pickerCancel'></m-picker>
    </div>
</template>
<script type="text/ecmascript-6">
	import mCell from 'components/cell/cell';
    import mPicker from 'src/components/picker/index';
    export default{
        data() {
            return {
                orderId: '',
                isToView: false,
            	aboveZero: 'empty', // empty true false
            	// 选择器字段
            	isPicker: false, // 普通选择器显示或隐藏
                indexText: '筛选条件', // 选择器名称
                datakey: '', // 选择器结果赋值到对象的key值
                valueKey: 'v', // 下拉框设置 value-key 属性来指定显示的字段名
                slots: [], // slot 对象数组
            	// 各种类字段
                loanVarietyType: C.Constant['A2'],
            	signType: C.Constant['1'],
            	sealType: C.Constant['22'],
            	assureType: C.Constant['26'],
            	isAppointInsureType: C.Constant['23'],
            	mortgageInsuranceLiabilityType: C.Constant['24'],
            	mortgageInsurancePeriodType: C.Constant['25'],
                C35: C.Constant['35'],
                // 房贷险投保责任:不购买
                C24_1: C.Constant['24_1'],
                // 先签后审
                C1_2: C.Constant['1_2'],
                // 二手楼按揭
                A2_2: C.Constant['A2_2'],
                // 贷款品种 一手楼按揭
                A2_1: C.Constant['A2_1'],
                // 贷款品种 一手楼按揭(直客式)
                A2_3: C.Constant['A2_3'],
                // 是否投保履约险: 不购买
                C23_0: C.Constant['23_0'],
            	// 出参
            	info: {
                    loanId: '',
                    loanVariety: '', // 贷款品种
					loanSchemeId: '', // 贷款方案ID
					interviewType: '', // 业务模式
					sealType: '', // 用印类型 01-电子公章；02-实物公章
					intTatesExecuteType: '', // 利率执行方式
					percentAge: '', // 贷款成数
					intFloatSpread: 0.00, // 利率浮动幅度
					firstDeveloperName: '', // 一手楼开发商名称
					firstLimitCode: '', // 一手楼额度编号
					assureCompanyName: '', // 担保公司名称
					assureCompanyLimitNo: '', // 担保公司额度号
					assureType: '', // 担保方式
					isAppointInsure: this.C23_0, // 是否投保履约险
					appointInsureTerm: 0, // 履约险投保期限
					repaymentAccountCardNo: '', // 还款账户卡号
					mortgageInsuranceLiability: this.C24_1, // 房贷险投保责任
					mortgageInsurancePeriod: 0 // 房贷险投保期限
				}
            };
        },
        created() {
            this.slots = [{values: []}];
            this.orderId = this.$route.query.orderId;
            this.isToView = this.$route.query.checkState === '1';
            C.Native.setHeader({
                title: C.T.ABOUT_LOAN_ADD,
                leftCallback: ()=> {
                    this.$router.go(-1);
                }
            });
        },
        mounted() {
            this.$nextTick(()=> {
                this.getData();
            });
        },
        watch: {
            'info.assureCompanyName': function (val) {
                this.info.assureType = val ? C.Constant['26_2'] : C.Constant['26_1'];
            }
        },
        computed: {
            noEmpty() {
                return Object.assign({
                    intFloatSpread: '利率浮动幅度必填'
                }, this.info.loanVariety !== this.A2_2 && { // 非二手楼时,需校验开发商名称和额度编号是否为空
                    firstDeveloperName: '一手楼开发商名称必填',
                    firstLimitCode: '一手楼额度编号必填'
                }, this.info.assureCompanyName && { // 公司名称有值时,需校验公司额度号
                    assureCompanyLimitNo: '担保公司额度号必填'
                }, this.info.assureCompanyLimitNo && {
                    assureCompanyName: '担保公司名称必填'
                }, this.info.isAppointInsure !== this.C23_0 && {
                    appointInsureTerm: '履约险投保期限必填',
                    repaymentAccountCardNo: '还款账户卡号必填'
                }, (this.info.mortgageInsuranceLiability !== this.C24_1 && this.info.interviewType === this.C1_2) && {
                    mortgageInsurancePeriod: '房贷险投保期限必选'
                });
            }
        },
        methods: {
        	getData() {
                C.UI.loading();
                $.ajax({
                    url: C.Api('SHOW_SUPPLEMENT_LOAN_INFO'),
                    data: {
                        orderId: this.orderId
                    },
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            let intFloatSpread = res.data.intFloatSpread;
                            Object.keys(this.info).forEach((item)=> {
                              this.info[item] = res.data[item];
                            });
                            // 贷款成数 转换 成百分号显示
                            this.info.percentAge = res.data.percentAge ? C.Utils.toY(res.data.percentAge, 5, 100) + '%' : '';
                            // 利率浮动幅度 转换 成百分号显示 且 区分正负数
                            if (!this.isToView) {
                                this.aboveZero = typeof intFloatSpread === 'number' ? (intFloatSpread >= 0) + '' : 'empty';
                                this.info.intFloatSpread = intFloatSpread ? Math.abs(C.Utils.toY(intFloatSpread, 2, 100)) : '';
                            } else {
                                this.info.intFloatSpread = C.Utils.toY(intFloatSpread, 2, 100) + '%';
                                // 展示页 担保公司名称 和 额度编号为空时
                                this.info.assureCompanyName = this.info.assureCompanyName || '-';
                                this.info.assureCompanyLimitNo = this.info.assureCompanyLimitNo || '-';
                                this.info.repaymentAccountCardNo = this.info.repaymentAccountCardNo || '-';
                            }
                            // 未审核 即 编辑初始状态下：是否投保履约险 默认‘不购买’
                            // 未审核 即 编辑初始状态下：如果‘业务模式’为：‘先签后审’，房贷险投保责任 默认房贷险投保责任:不购买
                            if (this.$route.query.checkState === '0') {
                                this.info.isAppointInsure = this.C23_0;
                                this.info.interviewType === this.C1_2 ? this.info.mortgageInsuranceLiability = this.C24_1 : '';
                            }
                            // 贷款品种 为 ‘一手楼按揭’或‘一手楼按揭(直客式)’ 时，是否投保履约险 只能选‘不购买’
                            if (this.info.loanVariety === this.A2_1 || this.info.loanVariety === this.A2_3) {
                                this.isAppointInsureType = C.Constant['23_01'];
                            }
                        }
                    }
                });
        	},
        	floatChange(i) {
                this.aboveZero = i === '+' ? 'true' : 'false';
        	},
            submit() {
            	let data, validator;
                for (let key in this.noEmpty) {
                     if (!this.info[key] && this.info[key] !== 0) {
                        C.Native.tip(this.noEmpty[key]);
                        return false;
                     }
                }
                validator = this.validator();
                if (validator) {
                    C.Native.tip(validator);
                    return false;
                }
                if (this.aboveZero === 'empty') {
                    C.Native.tip('请选择利率浮动幅度的+／-符号');
                    return false;
                }
            	data = Object.assign({}, this.info, {
            		intFloatSpread: (this.aboveZero === 'true' ? 1 : -1) * C.Utils.toWY(this.info.intFloatSpread, 4, 100)
            	});
                // percentAge贷款成数无需传给后端
                delete data.percentAge;
                C.UI.loading();
                $.ajax({
                    url: C.Api('UPLOAD_SUPPLEMENT_LOAN_INFO'),
                    data: {supplementInfo: data},
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            this.checkPass();
                        }
                    }
                });
            },
            checkPass() {
                C.UI.loading();
                $.ajax({
                    url: C.Api('UNITIVE_CHECK'),
                    data: {
                     orderId: this.orderId,
                     checkType: '07'  // 01： 主借款人 ； 02： 共同借款人；03：个人保证人 ；04：主借款人配偶 ；05： 抵押物 ； 06： 贷款信息；07：补充贷款信息
                    },
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            C.Native.tip('成功保存并审核');
                            this.$router.go(-1);
                        }
                    }
                });
            },
            validator() {
                let msg = '',
                    info = this.info;
                if (info.intFloatSpread && (info.intFloatSpread < 0 || info.intFloatSpread > 100)) {
                    msg = '利率浮动幅度请输入0-100的数值';
                } else if (info.intFloatSpread && !C.Utils.RegexMap.secondDecimal.test(info.intFloatSpread)) {
                    msg = '利率浮动幅度格式不对';
                } else if (C.Utils.strLength(this.info.firstLimitCode) > 32) {
                    msg = '一手楼额度编号格式错误';
                 } else if (C.Utils.strLength(this.info.assureCompanyLimitNo) > 32) {
                    msg = '担保公司额度号格式错误';
                } else if (info.isAppointInsure !== this.C23_0 && info.appointInsureTerm && !C.Utils.isInteger(info.appointInsureTerm)) {
                    msg = '履约险投保期限请输入整数';
                }
                return msg;
            },
            chooseInsure() {
                if (this.info.loanVariety === this.A2_1 || this.info.loanVariety === this.A2_3) {
                    this.pickerEvent('info.isAppointInsure', '是否投保履约险', '23_01');
                } else {
                    this.pickerEvent('info.isAppointInsure', '是否投保履约险', '23');
                }
            },
            // 普通选择器
            pickerEvent(key, text, slot) {
                this.datakey = key;
                this.indexText = text;
                this.slots = [{values: C.Utils.objToArr(C.Constant[slot])}];
                this.isPicker = true;
                this.isDatePicker = false;
                this.isAreaPicker = false;
            },
            // 普通选择器 确认
            pickerConfirm(value, key) {
                let jsonKey = key.split('.');
                this[jsonKey[0]][jsonKey[1]] = value.k;
                // console.log(value);
                this.isPicker = false;
            },
            // 普通选择器 取消
            pickerCancel() {
              this.isPicker = false;
            }
        },
        components: {
            mCell,
            mPicker
        }
    };
</script>
<style scoped lang="scss">
    section{padding-bottom: 1.5rem;}
    .fixed-row{
        margin-top: 5px;
        padding: .15rem 0;
        border-top: solid 1px #ddd;
        border-bottom: 1px solid #ddd;
        background: #fff;
    }
	.btn-wrap {
        position: fixed;
        left: 0;
        bottom: 0;
        width:100%;
		padding:.2rem 0;
        margin-top: .2rem;
        background: white;
        .btn{
            margin: 0 auto;
        }
    }
    .setHeight{
    	padding: .2rem 0;
    }
    .lilv{
    	position: relative;
    	.tip{
    		left: .3rem;
            width: 5.5rem;
    		font-size: .2rem;
    		color: #999;
            background:#fff;
            p{
                font-size: .32rem;
                color: #666;
            }
            .star{
                width: .12rem;
                height: .12rem;
                margin-top: -.04rem;
                background: url(../../../assets/images/m/icons/icon_-@2x.png) 0 0 no-repeat;
                background-size: 100% 100%;
                -webkit-background-size: 100% 100%;
                display: inline-block;
                vertical-align: middle;
            }
    	}
    	ul, .unit,.tip{
    		position: absolute;
    		top: 50%;
    		transform: translateY(-50%);
    	}
    	ul{
    		width: 1.08rem;
    		right: 1.9rem;
    		overflow: hidden;
    		li{
				float: left;
				padding: 0;
				width: .54rem;
				height: .44rem;
                &.plus{ 
                    background: url(../../../assets/images/app/icons/icon_plus_nor@3x.png) 0 0 no-repeat;
                    background-size: 100% 100%;
                    -webkit-background-size: 100% 100%;
                }
                &.reduce{ 
                    background: url(../../../assets/images/app/icons/icon_minus_nor@3x.png) 0 0 no-repeat; 
                    background-size: 100% 100%;
                    -webkit-background-size: 100% 100%;
                    margin-left: -1px;
                }
    		}
            li.act.plus{ background-image: url(../../../assets/images/app/icons/icon_plus_sel@3x.png); }
    		li.act.reduce{ background-image: url(../../../assets/images/app/icons/icon_minus_sel@3x.png); }
    	}
    	.unit{
    		right: .3rem;
            padding-right: .1rem;
            background: #fff;
    	}
    }
</style>
