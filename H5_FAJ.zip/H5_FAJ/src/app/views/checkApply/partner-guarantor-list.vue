<template>
    <section class="partner-list">
        <partner-list v-for="item in list" :key="item.id" :item="item" @goDetail="goDetail(item.partnerGuarantorId)"></partner-list>
        <div class="btn-wrap" v-if="!isToView">
            <div class="btn" @click="submit">审核通过</div>
        </div>
    </section>
</template>
<script type="text/ecmascript-6">
    import partnerList from 'src/components/partner-guarantor/list';
    export default {
        name: 'app-partner-list',
        data() {
            return {
                isToView: false,
                isPartner: true,
                list: []
            };
        },
        created() {
            /checkApply\/partner/.test(this.$route.path) ? this.isPartner = true : this.isPartner = false;
            this.isToView = this.$route.query.checkState === '1';
            C.Native.setHeader({
                title: this.isPartner ? C.T.PARTNER_LIST : C.T.GUARANTOR_LIST,
                leftCallback: ()=> {
                    this.$router.go(-1);
                }
            });
        },
        mounted() {
            this.$nextTick(()=> {
                this.render();
            });
        },
        computed: {},
        methods: {
            render() {
                C.UI.loading();
                $.ajax({
                    url: C.Api('GET_PARTNER_OR_GUARANTOR_LIST'),
                    data: {
                        // 01：共同借款人；02：担保人
                        borrowerType: this.isPartner ? '01' : '02',
                        orderId: this.$route.query.orderId,
                        listType: '02'
                    },
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            this.list = res.data.userList;
                        }
                    }
                });
            },
            goDetail(id) {
                // 人 id
                C.Native.forwardWebView({
                    url: '#/checkApply/' + (this.isPartner ? 'partner/' : 'guarantor/') + id + '?checkState=' + this.$route.query.checkState
                });
            },
            submit() {
                C.UI.loading();
                $.ajax({
                    url: C.Api('UNITIVE_CHECK'),
                    data: {
                     orderId: this.$route.query.orderId,
                     checkType: this.isPartner ? '02' : '03'  // 01： 主借款人 ； 02： 共同借款人；03：个人保证人 ；04：主借款人配偶 ；05： 抵押物 ； 06： 贷款信息；07：补充贷款信息
                    },
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            C.Native.tip('审核通过');
                            this.$router.go(-1);
                        }
                    }
                });
            }
        },
        components: {
            partnerList
        }
    };
</script>
<style scoped lang="scss">
    .partner-list{
        padding-bottom: 1.5rem;
    }
    .btn-wrap {
        position: fixed;
        left: 0;
        bottom: 0;
        width:100%;
        padding:.2rem 0;
        margin-top: .2rem;
        background: white;
        .btn{
            margin: 0 auto;
        }
    }
</style>
