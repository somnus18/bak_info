<template>
    <div class="delayOrder">
        <order-card v-show="!noOrders" v-for="item in orderList" :item="item" :key="item.orderId" @goDetail="goDetail(item)"></order-card>
        <no-orders v-show="noOrders"></no-orders>
    </div>
</template>
<script type="text/ecmascript-6">
    import noOrders from '@/components/no-orders.vue';
    import orderCard from '@/components/order-card.vue';
    export default {
        name: 'enquiryPrice',
        data() {
            return {
                orderList: [],
                noOrders: false
            };
        },
        created() {
            C.Native.setHeader({
                title: C.T.APPLY_MATERAIL_LIST
            });
        },
        mounted() {
            this.$nextTick(()=> {
                // 渲染页面的数据是不需要加载loading的
                this.getData();
            });
            $$.EventListener.onBack = (url, data)=> {
                if (data === '1') {
                    this.getData();
                }
            };
        },
        methods: {
            getData() {
                C.UI.loading();
                $.ajax({
                    url: C.Api('OPMGT_ORDER_LIST'),
                    data: {
                        searchType: '06' // 待后台确定申请补充材料订单列表 代号是啥
                    },
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            if (res.data.orderList.length <= 0) {
                                this.noOrders = true;
                            } else {
                                this.orderList = res.data.orderList;
                            }
                        }
                    }
                });
            },
            goDetail(item) {
                C.Native.forwardWebView({
                    url: '#/applyMaterial/' + item.orderId
                });
            }
        },
        components: {
            orderCard,
            noOrders
        }
    };
</script>
<style scoped>
    .delay-wrapper{ top: 0px;}
    .delayOrder{ margin-bottom: .2rem;}
</style>
