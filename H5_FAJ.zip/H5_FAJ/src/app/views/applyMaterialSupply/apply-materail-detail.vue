<template>
    <section>
        <div class="order-dis">
            <div class="card-top">
                <span class="kb-num">{{info.barcode}}</span>
                <span class="fr">{{info.clientName}}</span>
            </div>
            <div class="card-btm">
                补件要求：<span class="dis-con">{{info.supplyInfo || '-'}}</span>
            </div>
        </div>
        <div class="material-box">
            <photo-page v-for="(item,index) in initImgsList"
                :key="index"
                :item="item"
                :isPhotoMain=false
                :isShowAddBtn="item.imgList.length < maxLength"
                :maxLength="maxLength"
                :kbType="item.kbType"
                :orderId="orderId"
                page="applySupplyImage"></photo-page>
        </div>
        <div class="btn-wrap">
            <div class="btn" :class="[curTotalImgNum?'':'btn-disabled']" @click="submit">提交</div>
        </div>
    </section>
</template>

<script type='text/ecmascript-6'>
import photoPage from '@/components/photograph/index.vue';
export default {
    name: 'apply-material',
    data() {
        return {
            orderId: '',
            maxLength: 40,
            initImgsList: [],
            info: {}
        };
    },
    components: {
        photoPage
    },
    created() {
        C.Native.setHeader({
            title: C.T.APPLY_MATERAIL_DETAIL
        });
    },
    mounted() {
        this.$nextTick(()=> {
            this.orderId = this.$route.params.id;
            this.getData();
        });
    },
    computed: {
        curTotalImgNum() {
            let num = false;
            if (this.initImgsList) {
                for (let i = 0; i < this.initImgsList.length; i++) {
                    if (this.initImgsList[i].imgList && this.initImgsList[i].imgList.length > 0) {
                        num = true;
                        break;
                    }
                }
            }
            return num;
        }
    },
    methods: {
        getData() {
            let imgArr = [],
                cellJson = {};
            C.UI.loading();
            $.ajax({
                url: C.Api('GET_APPLY_SUPPLY_INFO'),
                data: {
                    orderId: this.orderId
                },
                success: (res)=> {
                    C.UI.stopLoading();
                    if (res.flag === C.Flag.SUCCESS) {
                        this.info = res.data;
                        this.info.imgInfoList.forEach((item)=> {
                            cellJson = {
                                title: '',
                                imgList: []
                            };
                            cellJson.kbType = item.kbType;
                            cellJson.title = C.Constant.KB_T[item.kbType];
                            if (item.imgUrls) {
                                imgArr = item.imgUrls.indexOf(',') !== -1 ? item.imgUrls.split(',') : [item.imgUrls];
                                for (let i in imgArr) {
                                    let _url = C.Utils.httpAddImage(imgArr[i]);
                                    cellJson.imgList.push({
                                        'imgUrl': _url,
                                        'imgId': C.Utils.imageSpliceId(_url)
                                    });
                                }
                            }
                            this.initImgsList.push(cellJson);
                        });
                    }
                }
            });
        },
        submit() {
            if (this.curTotalImgNum) {
                C.UI.loading();
                $.ajax({
                    url: C.Api('SUBMIT_APPLY_SUPPLYINFO'),
                    data: {
                     orderId: this.orderId
                    },
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            C.Native.tip('提交成功！');
                            C.Native.back({data: '1'});
                        }
                    }
                });
            }
        }
    }
};
</script>

<style scoped lang="scss">
    .order-dis{
        margin-top: 5px;
        background: #fff;
        padding:.1rem .24rem;
    }
    .card-top {
        padding: .2rem .15rem .15rem;
        line-height: .4rem;
        border-bottom: solid 1px #f0f0f0;
    }
    .card-btm{
        padding:.35rem .15rem;
        text-align: justify;
        .dis-con{color:#333;}
    }
    .material-box{
        margin-top: 5px;
        padding-bottom: 1.5rem;
    }
    .btn-wrap {
        position: fixed;
        left: 0;
        bottom: 0;
        width:100%;
        padding:.2rem 0;
        margin-top: .2rem;
        background: white;
        z-index: 999;
        .btn{
            margin: 0 auto;
        }
    }
</style>
