// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue';
import App from './App';
import router from './routes';
import store from './vuex/store';
import Filters from 'filters/index';
import C from 'common/common';
import Native from './common/native';
import UI from './common/ui';
import MD5 from 'src/m/common/md5';
import IScroll from 'iscroll';
import iScrollView from 'components/iscroll-view/index';

// 初始化全局css
import 'assets/css/app.scss';

Vue.use(iScrollView, IScroll);

window.Vue = Vue;
window.eventHub = new Vue();
window.C = C;
C.Native = Native;
C.Utils.MD5 = MD5;
C.UI = UI;

Filters.init();

window.onerror = function (msg, url, line, column) {
    C.debug.error('msg:' + msg + '<br>url:' + url + ',line:' + line + ',line:' + line + ',column:' + column);
};

Vue.config.productionTip = false;

/* eslint-disable no-new */
C.Utils.vm = new Vue({
    el: '#app',
    router,
    store,
    created() {
        for (let key in C.debug) {
            C.debug[key] = (...arg)=> {
                eventHub.$emit('debug-' + key, {
                    type: key,
                    text: arg
                });
            };
        }
    },
    template: '<App/>',
    components: {App}
});
