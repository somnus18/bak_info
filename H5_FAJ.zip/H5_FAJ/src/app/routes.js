import Vue from 'vue';
import Router from 'vue-router';
import * as MAP from './routes-map';

Vue.use(Router);

export default new Router({
    mode: 'hash',
    base: __dirname,
    scrollBehavior(to, from, savedPosition) {
        if (savedPosition) {
            return savedPosition;
        } else {
            // 滚到到页面顶部
            return { x: 0, y: 0 };
        }
    },
    routes: [{
        path: '',
        redirect: '/my'
    }, {
            path: '/login',
            component: MAP.login
    }, {
        path: '/error',
        component: MAP.error
    }, {
        path: '/my', // 我的进件
        component: MAP.my
    }, {
        path: '/my/:token', // 我的进件
        component: MAP.my
    }, {
            path: '/orderDetail/:id',
            name: 'orderDetail',
            component: MAP.orderDetail
    }, {
            path: '/delayOrder', // 待跟进订单
            component: MAP.delayOrder,
            children: [
                {
                    path: '',
                    component: MAP.delayOrderIndex
                }
            ]
    }, {
        path: '/delayOrder/:id', // 申请中／材料收集中 订单详情
        name: 'orderProgress',
        component: MAP.orderProgress
    }, {
            path: '/allOrder',
            component: MAP.allOrder
    }, {
            path: '/enquiryPrice',
            component: MAP.enquiryPrice
    }, {
            path: '/enquiryPriceDetail',
            component: MAP.enquiryPriceDetail
    }, {
            path: '/checkApply', // 我的进件
            component: MAP.checkApplyPort,
            children: [
                {
                    path: '', // 审核信息
                    component: MAP.checkApplyList
                },
                {
                    path: 'masterBorrower',
                    name: 'masterBorrower',
                    component: MAP.masterBorrower
                },
                {
                    path: 'masterSpouse',
                    component: MAP.masterSpouse
                },
                {
                    path: 'partner',
                    component: MAP.partnerList
                },
                {
                    path: 'partner/:id',
                    component: MAP.partnerDetail
                },
                {
                    path: 'guarantor',
                    component: MAP.guarantorList
                },
                {
                    path: 'guarantor/:id',
                    component: MAP.guarantorDetail
                },
                {
                    path: 'pledge',
                    component: MAP.pledgeList
                },
                {
                    path: 'pledge/:id',
                    component: MAP.pledgeDetail
                },
                {
                    path: 'aboutLoan',
                    name: 'aboutLoan',
                    component: MAP.aboutLoan
                },
                {
                    path: 'aboutLoanAdd',
                    name: 'aboutLoanAdd',
                    component: MAP.aboutLoanAdd
                },
                {
                    path: 'uploadImageCheck',
                    name: 'uploadImageCheck',
                    component: MAP.uploadImageCheck
                }
            ]
    }, {
        path: '/checkApply/:id', // 审核信息详情
        component: MAP.checkApplyDetail
    }, {
            path: '/applyMaterial',
            component: MAP.applyMaterial
    }, {
            path: '/applyMaterial/:id',
            component: MAP.applyMaterialDetail
    }, {
            path: '/checkBu',
            component: MAP.checkBu
    }, {
            path: '/checkBu/:id',
            component: MAP.checkBuDetail
    }, {
            path: '/signDate',
            component: MAP.signDate
    }, {
            path: '/signDateDetail',
            component: MAP.signDateDetail
    }, {
            path: '/dateInfo',
            component: MAP.dateInfo
    }, {
        path: '/interface',
        component: MAP.interfaceNative
    }, {
        path: '/test',
        component: MAP.test
    }, {
        path: '*',
        redirect: '/error'
    }]
});
