export const error = resolve=> require.ensure([], require=> resolve(require('./views/error.vue')), 'error');
export const test = resolve=> require.ensure([], require=> resolve(require('../m/views/test.vue')), 'test');
export const login = resolve=> require.ensure([], require=> resolve(require('./views/login.vue')), 'login');
export const interfaceNative = resolve=> require.ensure([], require=> resolve(require('../m/views/interface.vue')), 'interface');

export const my = resolve=> require.ensure([], require=> resolve(require('./views/my')), 'my');
// 订单详情
export const orderDetail = resolve=> require.ensure([], require=> resolve(require('./views/order/orderDetail.vue')), 'orderDetail');
// 待跟进订单 申请中／材料收集 订单的订单详情
export const orderProgress = resolve=> require.ensure([], require=> resolve(require('./views/delayOrder/orderProgress.vue')), 'orderProgress');

export const delayOrder = resolve=> require.ensure([], require=> resolve(require('./views/delayOrder.vue')), 'delayOrder');
export const delayOrderIndex = resolve=> require.ensure([], require=> resolve(require('./views/delayOrder/delayOrder.vue')), 'delayOrderIndex');
export const allOrder = resolve=> require.ensure([], require=> resolve(require('./views/order/allOrder.vue')), 'allOrder');

// 询价信息录入
export const enquiryPrice = resolve=> require.ensure([], require=> resolve(require('./views/enquiryPrice/enquiry-price-list.vue')), 'enquiryPrice');
export const enquiryPriceDetail = resolve=> require.ensure([], require=> resolve(require('./views/enquiryPrice/enquiry-price-detail.vue')), 'enquiryPriceDetail');

// 审核信息
export const checkApplyPort = resolve=> require.ensure([], require=> resolve(require('./views/checkApply.vue')), 'checkApplyPort');
// 审核信息 订单列表
export const checkApplyList = resolve=> require.ensure([], require=> resolve(require('./views/checkApply/check-apply-list.vue')), 'checkApplyList');
// 审核信息 订单详情
export const checkApplyDetail = resolve=> require.ensure([], require=> resolve(require('./views/checkApply/check-apply-detail.vue')), 'checkApplyDetail');

// 贷款相关人信息 主借款人信息
export const masterBorrower = resolve=> require.ensure([], require=> resolve(require('./views/checkApply/master-borrower-detail.vue')), 'masterBorrower');
// 贷款相关人信息 配偶信息
export const masterSpouse = resolve=> require.ensure([], require=> resolve(require('./views/checkApply/master-spouse-detail.vue')), 'masterSpouse');

// 贷款相关人信息 共同借款人信息列表
export const partnerList = resolve=> require.ensure([], require=> resolve(require('./views/checkApply/partner-guarantor-list.vue')), 'partnerList');
// 贷款相关人信息 共同借款人信息详情
export const partnerDetail = resolve=> require.ensure([], require=> resolve(require('./views/checkApply/partner-guarantor-detail.vue')), 'partnerDetail');
// 贷款相关人信息 个人保证人信息列表
export const guarantorList = resolve=> require.ensure([], require=> resolve(require('./views/checkApply/partner-guarantor-list.vue')), 'guarantorList');
// 贷款相关人信息 个人保证人信息详情
export const guarantorDetail = resolve=> require.ensure([], require=> resolve(require('./views/checkApply/partner-guarantor-detail.vue')), 'guarantorDetail');

// 贷款相关人信息 抵押物信息列表
export const pledgeList = resolve=> require.ensure([], require=> resolve(require('./views/checkApply/pledge-list.vue')), 'pledgeList');
// 贷款相关人信息 抵押物信息详情
export const pledgeDetail = resolve=> require.ensure([], require=> resolve(require('./views/checkApply/pledge-detail.vue')), 'pledgeDetail');

// 贷款相关人信息 贷款信息
export const aboutLoan = resolve=> require.ensure([], require=> resolve(require('./views/checkApply/aboutLoan.vue')), 'aboutLoan');
// 贷款相关人信息 补充贷款信息
export const aboutLoanAdd = resolve=> require.ensure([], require=> resolve(require('./views/checkApply/aboutLoanAdd.vue')), 'aboutLoanAdd');
// 贷款相关人信息 审核影像上传
export const uploadImageCheck = resolve=> require.ensure([], require=> resolve(require('./views/checkApply/upload-image-check.vue')), 'uploadImageCheck');

// 申请材料补充
export const applyMaterial = resolve=> require.ensure([], require=> resolve(require('./views/applyMaterialSupply/apply-materail-list.vue')), 'applyMaterial');
export const applyMaterialDetail = resolve=> require.ensure([], require=> resolve(require('./views/applyMaterialSupply/apply-materail-detail.vue')), 'applyMaterialDetail');

// 审批补件
export const checkBu = resolve=> require.ensure([], require=> resolve(require('./views/checkBu/check-bu-list.vue')), 'checkBuList');
export const checkBuDetail = resolve=> require.ensure([], require=> resolve(require('./views/checkBu/check-bu-detail.vue')), 'checkBuDetail');

// 预约面签
export const signDate = resolve=> require.ensure([], require=> resolve(require('./views/signDate/sign-date-list.vue')), 'signDate');
export const signDateDetail = resolve=> require.ensure([], require=> resolve(require('./views/signDate/sign-date-detail.vue')), 'signDateDetail');

// 预约信息
export const dateInfo = resolve=> require.ensure([], require=> resolve(require('./views/dateInfo/date-info-list.vue')), 'dateInfo');
// 预约信息详情 和 预约面签编辑页 共用
// export const dateInfoDetail = resolve=> require.ensure([], require=> resolve(require('./views/dateInfo/date-info-detail.vue')), 'dateInfoDetail');
