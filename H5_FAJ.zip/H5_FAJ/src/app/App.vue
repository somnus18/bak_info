<template>
    <div id="app">
        <v-header></v-header>
        <router-view></router-view>
        <debug v-if="isDebug"></debug>
        <v-dialog></v-dialog>
        <tip></tip>
        <loading></loading>
    </div>
</template>

<script>
    import debug from '@/components/debug';
    import vDialog from '@/components/dialog';
    import tip from '@/components/tip';
    import loading from '@/components/loading';
    import vHeader from '@/components/header';

    export default {
        name: 'app',
        data() {
            return {
                isDebug: C.Constant.DEBUG_MODE
            };
        },
        components: {
            vDialog,
            debug,
            tip,
            loading,
            vHeader
        }
    };
</script>

<style>
    #app{
        /*对字体进行抗锯齿渲染可以使字体看起来会更清晰舒服*/
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
    }
</style>
