export const error = resolve=> require.ensure([], require=> resolve(require('./views/error.vue')), 'error');
export const demo = resolve=> require.ensure([], require=> resolve(require('./views/interface.vue')), 'interface');
export const test = resolve=> require.ensure([], require=> resolve(require('./views/test.vue')), 'test');
export const picker = resolve=> require.ensure([], require=> resolve(require('./views/picker.vue')), 'picker');

// 主页面登陆
export const login = resolve=> require.ensure([], require=> resolve(require('./views/login.vue')), 'login');
export const list = resolve=> require.ensure([], require=> resolve(require('./views/list.vue')), 'list');
export const listIndex = resolve=> require.ensure([], require=> resolve(require('./views/list/index.vue')), 'listIndex');
export const pendingOrders = resolve=> require.ensure([], require=> resolve(require('./views/list/pending-orders.vue')), 'pendingOrders');
export const allOrders = resolve=> require.ensure([], require=> resolve(require('./views/list/all-orders.vue')), 'allOrders');
export const allDetail = resolve=> require.ensure([], require=> resolve(require('./views/list/all-detail.vue')), 'allDetail');
export const pendingDetail = resolve=> require.ensure([], require=> resolve(require('./views/list/pending-detail.vue')), 'pendingDetail');
export const pendingPhotos = resolve=> require.ensure([], require=> resolve(require('./views/list/pending-photo.vue')), 'pendingPhotos');

// 创建订单
export const create = resolve=> require.ensure([], require=> resolve(require('./views/create.vue')), 'create');
export const createIndex = resolve=> require.ensure([], require=> resolve(require('./views/create/index.vue')), 'createIndex');
// 订单录入
export const apply = resolve=> require.ensure([], require=> resolve(require('./views/apply/index.vue')), 'apply');
export const typeIn = resolve=> require.ensure([], require=> resolve(require('./views/apply/typeIn.vue')), 'typeIn');
export const masterBorrower = resolve=> require.ensure([], require=> resolve(require('./views/apply/master_borrower.vue')), 'masterBorrower');
export const masterSpouse = resolve=> require.ensure([], require=> resolve(require('./views/apply/matser_spouse.vue')), 'masterSpouse');

// 共同借款人及个人保证人列表
export const partnerGuarantorList = resolve=> require.ensure([], require=> resolve(require('./views/apply/partner-guarantor-list.vue')), 'partnerGuarantorList');
// 共同借款人及个人保证人详情
export const partnerGuarantorDetail = resolve=> require.ensure([], require=> resolve(require('./views/apply/partner-guarantor-detail.vue')), 'partnerGuarantorDetail');
// 抵押物贷款
export const pledgeList = resolve=> require.ensure([], require=> resolve(require('./views/apply/pledge-list.vue')), 'pledgeList');
// 抵押物详情
export const pledgeDetail = resolve=> require.ensure([], require=> resolve(require('./views/apply/pledge-detail.vue')), 'pledgeDetail');
// 贷款信息
export const loanInfo = resolve=> require.ensure([], require=> resolve(require('./views/apply/loanInfo.vue')), 'loanInfo');
// 身份验证
export const identity = resolve=> require.ensure([], require=> resolve(require('./views/apply/identity.vue')), 'identity');
// 征信路由入口
export const credit = resolve=> require.ensure([], require=> resolve(require('./views/credit.vue')), 'credit');
// 征信授权
export const creditIndex = resolve=> require.ensure([], require=> resolve(require('./views/credit/index.vue')), 'creditIndex');
export const creditLaunch = resolve=> require.ensure([], require=> resolve(require('./views/credit/launch.vue')), 'creditLaunch');

// 分页面登陆
export const verify = resolve=> require.ensure([], require=> resolve(require('./views/sub/verify.vue')), 'verify');
export const failure = resolve=> require.ensure([], require=> resolve(require('./views/sub/failure.vue')), 'failure');
export const entry = resolve=> require.ensure([], require=> resolve(require('./views/sub/entry.vue')), 'entry');
