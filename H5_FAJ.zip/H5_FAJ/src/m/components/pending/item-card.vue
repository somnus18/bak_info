<template>
    <div class="item-card" @click="goDetail" :class="{'gray-content': isGray}">
        <span class="grey">{{textName}}</span>
        <span class="fr hasRight" :class="{'green': !isShowArrow, 'gray-color': isGray}">{{value}}</span>
        <i :class="[isGray ? 'icon-arrow-r-gray': 'icon-arrow-r']" :style="{'visibility': isShowArrow ? 'visible' : 'hidden'}"></i>
    </div>
</template>
<script type="text/ecmascript-6">
    export default {
        data() {
            return {};
        },
        props: {
            textName: {
                type: String,
                default: ''
            },
            value: {
                type: String,
                default: ''
            },
            // 是否显示右箭头
            isShowArrow: {
                type: Boolean,
                default: true
            },
            isGray: {
                type: Boolean,
                default: false
            }
        },
        methods: {
            goDetail() {
                if (!this.isShowArrow) return;
                this.$emit('goDetail');
            }
        }
    };
</script>
<style scoped lang="scss">
    .item-card {
        position: relative;
        background: #fff;
        border-top: 1px solid #ccc;
    }

    .grey {
        color: #333;
    }

    .hasRight {
        margin-right: .8rem;
        display: inline-block;
        vertical-align: top;
        color: #fdb02b;
    }

    .green {
        color: #35ba88 !important;
    }

    .icon-arrow-r, .icon-arrow-r-gray{
        position: absolute;
        top: .6rem;
        right: .3rem;
        width: .3rem;
        height: .4rem;
    }
    .icon-arrow-r {
        background: url('../../../assets/images/app/icons/icon_arrow_r@3x.png') center center no-repeat;
        background-size: .16rem auto;
    }
    .icon-arrow-r-gray {
        background: url(icon_arrow_r_gray@2x.png) center center no-repeat;
        background-size: .16rem auto;
    }
    .gray-content {
        background: #f6f6f6;
        .grey {
            color: #999;
        }
        .gray-color {
            color: #999 !important;
        }
    }
</style>
