<template>
    <section class="cs layer" :style="'-webkit-transition:transform,0.4s' +
                        ';transition:transform,0.4s' +
                        ';-webkit-transform: translateX(' + position + 'px);' +
                        'opacity:' + opacityStu + ';' +
                        'transform: translateX(' + position + 'px)'">
        <div class="cs-c">
            <div class="cs-c-top line" :style="{'color':IS_NATIVE ? '#26a2ff' : 'orangered'}">
                <span class="cs-c-btn fl" @click.prevent="cancel">取消</span>
                <span class="cs-c-title">选择权利人</span>
                <span class="cs-c-btn fr" @click.prevent="sure">确定</span>
            </div>
            <ul class="cs-c-ul">
                <li v-for="(item,index) in creditList" :key="index" :class="[item.selected?'c':'','line']"
                    v-if="item.warrantOwnName" @click="choose(item,index)">
                    <span class="cs-li-text">{{item.warrantOwnName}}</span>
                    <span class="cs-li-i"></span></li>
            </ul>
        </div>
    </section>
</template>

<script type='text/ecmascript-6'>
    export default {
        data() {
            return {
                IS_NATIVE: C.Utils.App.IS_NATIVE,
                width: window.innerWidth,
                opacity: 0
            };
        },
        props: {
            showCredit: {
                type: Boolean,
                default: false
            },
            creditList: {
                type: Array,
                default: ()=> {
                    return [];
                }
            },
            selectedList: {
                type: Array,
                default: ()=> {
                    return [];
                }
            }

        },
        computed: {
            opacityStu() {
                return this.showCredit ? 1 : 0;
            },
            position() {
                return this.showCredit ? 0 : this.width;
            }
        },
        mounted() {
            this.$nextTick(()=> {
                let isOrientation = ('orientation' in window && 'onorientationchange' in window);
                if (isOrientation) {
                    window.addEventListener('orientationchange', ()=> {
                        setTimeout(()=> {
                            this.width = window.innerWidth;
                        }, 10);
                    }, false);
                } else {
                    window.addEventListener('resize', ()=> {
                        setTimeout(()=> {
                            this.width = window.innerWidth;
                        }, 10);
                    }, false);
                }
            });
        },
        methods: {
            sure() {
                let list = this.getParamList();
                this.$emit('credit-sure', list);
                this.$parent.showCredit = false;
            },
            cancel() {
                this.$emit('credit-cancel');
                this.$parent.showCredit = false;
            },
            getParamList() {
                let list = [];
                this.selectedList.forEach((val)=> {
                    list.push(this.creditList[val]);
                });
                return list;
            },
            choose(item, creditIndex) {
                let flag = item.selected, i = this.selectedList.indexOf(creditIndex);
                if (!this.check(this.selectedList, flag)) {
                    return;
                } else {
                    flag ? this.selectedList.splice(i, 1) : this.selectedList.push(creditIndex);
                    // 赋值且更新数据
                    this.$set(this.creditList, creditIndex, Object.assign(item, {selected: !flag}));
                }
            },
            check(...param) {
                if (param[1] && param[0].length <= 1) {
                    C.Native.tip('权利人不能少于1人');
                    return false;
                }
                if (!param[1] && param[0].length > 4) {
                    C.Native.tip('权利人不能多于5人');
                    return false;
                }
                return true;
            }
        }
    };
</script>

<style scoped lang="scss" rel="stylesheet/scss">
    .cs {
        // top: 1rem;
        z-index: 1008;
        .line {
            height: 1rem;
            line-height: 1rem;
            border-bottom: 1px solid #ddd;
        }
        .cs-c {
            width: 76%;
            height: 100%;
            background: #fff;
            float: right;
            position: relative;
            .cs-c-top {
                text-align: center;
                font-size: .34rem;
                // color: orangered;
                .cs-c-title {
                    color: #666;
                }
                .cs-c-btn {
                    padding: 0 .3rem;
                }
            }
            .cs-c-ul {
                li {
                    padding: 0 .3rem;
                    font-size: .36rem;
                    .cs-li-text {
                        display: inline-block;
                        max-width: 4rem;
                        white-space: nowrap;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        -webkit-text-overflow: ellipsis;
                    }
                }
                .c {
                    color: #26a2ff;
                    .cs-li-i {
                        width: .5rem;
                        height: 100%;
                        background: url(icon-Check@2x.png) no-repeat center center;
                        background-size: .4rem .28rem;
                    }

                }
                .cs-li-i {
                    width: .5rem;
                    clear: both;
                    float: right;
                }
            }
        }
    }
</style>
