<template>
    <section class="sidebar layer" :style="'-webkit-transition:all,' + sidebar.time +
                        ';transition:all,' + sidebar.time +
                        ';-webkit-transform: translateX(-' + width + 'px);' +
                        'transform: translateX(-' +width + 'px)'" @click="hide">
        <div class="container">
            <div class="sidebar-top">
                <p>{{userName}}</p>
            </div>
            <div class="sidebar-bottom">
                <div class="logout btn" @click.stop="logout">退出登录</div>
            </div>
        </div>
    </section>
</template>

<script type='text/ecmascript-6'>
    import * as types from '../../vuex/mutation-types';

    export default {
        data() {
            return {
                userName: ''
            };
        },
        computed: {
            sidebar() {
                return this.$store.state.sidebar.data;
            },
            width() {
                return this.$store.getters.width;
            }
        },
        mounted() {
            this.$nextTick(()=> {
                let isOrientation = ('orientation' in window && 'onorientationchange' in window);
                if (isOrientation) {
                    window.addEventListener('orientationchange', ()=> {
                        setTimeout(()=> {
                            this.$store.commit(types.SET_SIDEBAR, {width: this.width ? window.innerWidth : 0});
                        }, 10);
                    }, false);
                } else {
                    window.addEventListener('resize', ()=> {
                        setTimeout(()=> {
                            this.$store.commit(types.SET_SIDEBAR, {width: this.width ? window.innerWidth : 0});
                        }, 10);
                    }, false);
                }
                this.userName = (C.Utils.data(C.DK.USER_LOGIN_INFO) || {}).userName;
            });
        },
        methods: {
            logout() {
                C.UI.warn({
                    title: '是否退出登录',
                    cancelText: '取消',
                    okText: '确认',
                    ok: (store)=> {
                        C.UI.loading();
                        $.ajax({
                            url: C.Api('USER_LOGOUT'),
                            success: (res)=> {
                                C.UI.stopLoading();
                                if (res.flag === C.Flag.SUCCESS) {
                                    this.hide();
                                    store.commit(types.SET_DIALOG, {isShowDialog: false});
                                    C.Utils.data(C.DK.USER_LOGIN_INFO, null);
                                    C.Native.forwardWebView({
                                        url: 'index.html#/login'
                                    });
                                }
                            }
                        });
                    }
                });
            },
            hide() {
                this.$store.commit(types.SET_SIDEBAR, {width: window.innerWidth});
            }
        }
    };
</script>

<style scoped lang="scss">
    .sidebar {
        z-index: 1008;
        .container {
            width: 73%;
            height: 100%;
            background: #fff;
            position: relative;
            text-align:center;
            .sidebar-top {
                width: 100%;
                height: 100%;
                background: url(./bg_account.jpg) no-repeat;
                background-size: 100%;
                p {
                    padding-top: 85%;
                    font-size: 0.32rem;
                    color: #fff;
                }
            }
            .sidebar-bottom {
                position: absolute;
                width: 100%;
                bottom: 0.2rem;
                text-align: center;
                .logout {
                    width: 80%;
                    height: .84rem;
                    line-height: .84rem;
                    margin: 0 auto 1.6rem;
                    color: #f15b23;
                    background: #fff;
                    border: 1px solid #f15b23;
                    border-radius: .42rem;

                }
            }
        }
    }
</style>
