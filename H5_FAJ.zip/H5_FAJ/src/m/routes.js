import Vue from 'vue';
import Router from 'vue-router';
import * as MAP from './routes-map';

Vue.use(Router);

export default new Router({
    mode: 'hash',
    base: __dirname,
    scrollBehavior(to, from, savedPosition) {
        if (savedPosition) {
            return savedPosition;
        } else {
            // 滚到到页面顶部
            return { x: 0, y: 0 };
        }
    },
    routes: [{
        path: '',
        redirect: '/login'
    }, {
        path: '/login',
        component: MAP.login
    }, {
        // 分页面验证页面
        path: '/verify',
        component: MAP.verify
    }, {
        // 分页面验证失效页面
        path: '/failure',
        component: MAP.failure
    }, {
        // 分页面申请信息录入页面
        path: '/entry',
        component: MAP.entry
    }, {
        path: '/interface',
        component: MAP.demo
    },
    // 订单列表
    {
        path: '/list',
        component: MAP.list,
        children: [
            {
                path: '',
                component: MAP.listIndex,
                children: [
                    {
                        path: '/',
                        redirect: 'pending'
                    }, {
                        path: 'pending',
                        component: MAP.pendingOrders
                    }, {
                        path: 'all',
                        component: MAP.allOrders
                    }
                ]
            },
            {
                path: 'pending/:id',
                component: MAP.pendingDetail
            },
            {
                path: 'photos/:orderId&:applyStatus',
                name: 'photos',
                component: MAP.pendingPhotos
            },
            {
                path: 'all/:id',
                component: MAP.allDetail
            }
        ]
    },
    {
        path: '/credit',
        component: MAP.credit,
        children: [
            {
                path: '',
                component: MAP.creditIndex
            },
            {
                path: 'launch',
                component: MAP.creditLaunch
            }
        ]
    },
    // 创建订单
    {
        path: '/create',
        component: MAP.create,
        children: [
            {
                path: '',
                redirect: 'index'
            },
            {
                path: 'index',
                component: MAP.createIndex
            }
        ]
    }, {
        path: '/apply',
        component: MAP.apply,
        children: [
            {
                path: '',
                component: MAP.typeIn
            },
            {
                path: 'identity',
                name: 'identity',
                component: MAP.identity
            },
            {
                // 共同借款人列表
                path: 'partner',
                name: 'partnerList',
                component: MAP.partnerGuarantorList
            },
            {
                // 共同借款人详情
                path: 'partner/:id',
                name: 'partnerDetail',
                component: MAP.partnerGuarantorDetail
            },
            {
                // 个人保证人列表
                path: 'guarantor',
                name: 'guarantorList',
                component: MAP.partnerGuarantorList
            },
            {
                // 个人保证人详情
                path: 'guarantor/:id',
                name: 'guarantorDetail',
                component: MAP.partnerGuarantorDetail
            }, {
                // 抵押物列表
                path: 'pledge',
                name: 'pledgeList',
                component: MAP.pledgeList
            },
            {
                // 抵押物详情
                path: 'pledge/:id',
                name: 'pledgeDetail',
                component: MAP.pledgeDetail
            },
            {
                path: 'masterBorrower',
                name: 'masterBorrower',
                component: MAP.masterBorrower
            },
            {
                path: 'masterSpouse',
                name: 'masterSpouse',
                component: MAP.masterSpouse
            },
            {
                path: 'loanInfo',
                name: 'loanInfo',
                component: MAP.loanInfo
            }
        ]
    }, {
        path: '/test',
        component: MAP.test
    }, {
        path: '/picker',
        component: MAP.picker
    }, {
        path: '/error',
        component: MAP.error
    }, {
        path: '*',
        redirect: '/error'
    }]
});
