<template>
    <div id="app">
        <v-header></v-header>
        <router-view></router-view>
        <debug v-if="isDebug"></debug>
        <loading></loading>
        <tip></tip>
        <v-dialog></v-dialog>
    </div>
</template>

<script>
    import vHeader from '@/components/header';
    import tip from '@/components/tip';
    import debug from '@/components/debug';
    import loading from '@/components/loading';
    import vDialog from '@/components/dialog';

    export default {
        name: 'app',
        data() {
            return {
                isDebug: C.Constant.DEBUG_MODE
            };
        },
        components: {
            debug,
            tip,
            loading,
            vHeader,
            vDialog
        }
    };
</script>

<style scoped>
    #app {
        width: 100%;
        height: 100%;
        /*对字体进行抗锯齿渲染可以使字体看起来会更清晰舒服*/
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
    }
</style>
