import Utils from 'common/utils';
import Env from 'common/env';
import Constant from 'common/constant';
import * as types from '../vuex/mutation-types';

export default {
    /**
     * 显示加载动画 C.UI.loading();
     * @param .msg 当不允许取消加载动画时 提示信息
     */
    loadingBegin: function (msg = '') {
        Utils.vm.$store.commit(types.SET_LOADING, {
            isShow: true,
            msg: msg
        });
    },

    /**
     * 关闭加载动画 C.UI.stopLoading();
     */
    loadingFinish: function () {
        Utils.vm.$store.commit(types.SET_LOADING, {
            isShow: false,
            msg: ''
        });
    },

    timer: null,
    /**
     * 提示
     * @param
     *      .text 字符串 C.Native.tip('提示内容');
     *      .obj 字符串 C.Native.tip({msg: '提示内容'});
     */
    tip(opt) {
        let msg = opt,
            duration = 2000;
        if (typeof opt === 'object') {
            msg = opt.msg;
            duration = opt.duration || duration;
        }
        Utils.vm.$store.commit(types.SET_TIP, {
            isShowTip: true,
            msg: msg
        });
        clearTimeout(this.timer);
        this.timer = setTimeout(()=> {
            Utils.vm.$store.commit(types.SET_TIP, {
                isShowTip: false
            });
        }, duration);
    },
    forward(options = {}) {
        Utils.forwardParam(options);
    },
    forwardWebView(options = {}) {
        location.href = options.url;
        location.reload();
    },
    /**
     * 页面返回
     * @param options {url:''}
     * .url back返回的url,为空默认返回上一个页面,
     * .data
     *      url 跳转至具体页面。
     *      page 几层
     * .callback 函数 function(){} 请求处理
     */
    back(options = {}) {
        let url = options.url || '',
            page = options.page || -1;
        if (url) {
            location.href = url;
            return;
        }
        history.go(page);
    },
    /**
     * 设置头部信息
     * @param options {title:'标题',isBack:true,leftCallback:function(){},isClose:true,closeCallback:function(){}}
     * .title 字符串 设置头部标题
     * .isBack 布尔值 是否有返回图标
     * .leftText 左边文案
     * .leftIcon close
     * .leftCallback function(){} 函数 设置左边回调
     * .rightText 右边文案
     * .rightIcon  右边图标 share
     * .rightCallback function(){} 函数 设置右边回调
     * .data 扩展数据 Json格式
     */
    setHeader(options = {}) {
        let clear = options.clear;
        options.leftIcon = options.leftIcon || 'back';
        options.rightIcon = options.rightIcon || '';
        options.titleIcon = options.titleIcon || '';
        options.leftText = options.leftText || '';
        options.rightText = options.rightText || '';
        options.title = options.title || '按揭贷款';
        options.fixed = options.fixed || false;
        options.titleCallback = options.titleCallback || '';
        options.leftCallback = options.leftCallback || '';
        options.rightCallback = options.rightCallback || '';
        // 清除日志
        if (typeof clear === 'undefined') {
            clear = true;
        }
        if (typeof options.isShowHeader === 'undefined') {
            options.isShowHeader = true;
        }
        clear && C.debug.clear && C.debug.clear();
        C.debug.log && C.debug.log('当前环境：' + Env);
        C.debug.log && C.debug.log('userAgent：' + navigator.userAgent.toUpperCase());
        if (typeof options.isBack === 'undefined') {
            options.isBack = true;
        }
        document.title = options.title || Constant.TITLE.DEFAULT;
        Utils.vm.$store.commit(types.SET_HEADER, options);
    }
};
