import Native from './native';
import Utils from 'common/utils';
import * as types from '../vuex/mutation-types';

export default {
    // C.UI.loading();
    tip(msg) {
        Native.tip(msg);
    },
    loading(msg) {
        Native.loadingBegin(msg);
    },
    stopLoading() {
        Native.loadingFinish();
    },
    showDialog(opt = {}) {
        opt.isShowDialog = true;
        opt.cancelText = opt.cancelText || '';
        opt.okText = opt.okText || '确认';
        opt.ok = opt.ok || '';
        opt.cancel = opt.cancel || '';
        opt.content = opt.content || '';
        opt.title = opt.title || '';
        opt.titleIcon = opt.titleIcon || '';
        opt.onlyBtn = opt.onlyBtn || false;
        opt.isShowClose = typeof opt.isShowClose === 'undefined' ? false : opt.isShowClose;
        opt.isCancelCloseDialog = typeof opt.isCancelCloseDialog === 'undefined' ? true : opt.isCancelCloseDialog;
        opt.isOkCloseDialog = typeof opt.isOkCloseDialog === 'undefined' ? true : opt.isOkCloseDialog;
        Utils.vm.$store.commit(types.SET_DIALOG, opt);
    },
    success(opt = {}) {
        opt.titleIcon = 'pass';
        this.showDialog(opt);
    },
    error(opt = {}) {
        opt.titleIcon = 'fail';
        this.showDialog(opt);
    },
    warn(opt = {}) {
        opt.titleIcon = 'warn';
        this.showDialog(opt);
    }
};
