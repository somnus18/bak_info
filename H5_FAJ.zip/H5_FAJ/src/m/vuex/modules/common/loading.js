import * as types from '../../mutation-types';

export default {
    state: {
        data: {
            isShow: false,
            msg: '加载中...'
        }
    },
    getters: {},
    actions: {},
    mutations: {
        [types.SET_LOADING](state, item) {
            state.data = Object.assign(state.data, item);
        }
    }
};
