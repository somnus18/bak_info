import * as types from '../../mutation-types';

export default {
    state: {
        data: {
            isShowHeader: true,
            isBack: true,
            title: '',
            titleCallback: null,
            titleIcon: '',
            leftText: '',
            leftIcon: 'back',
            rightText: '',
            rightIcon: '',
            leftCallback: null,
            rightCallback: null,
            fixed: false
        }
    },
    getters: {
        leftIcon: (state)=> {
            return state.data.leftText ? '' : state.data.leftIcon;
        },
        titleIcon: (state)=> {
            return state.data.titleIcon;
        }
    },
    actions: {},
    mutations: {
        [types.SET_HEADER](state, item) {
            state.data = $.extend(true, state.data, item);
        },
        [types.SET_HEADER_R_T](state, item) {
            state.data.rightText = item.rightText;
        },
        [types.SET_HEADER_R_I](state, item) {
            state.data.rightIcon = item.rightIcon;
        },
        [types.SET_HEADER_TITLE](state, item) {
            state.data.title = item.title;
        }
    }
};
