import * as types from '../../mutation-types';

export default {
    state: {
        data: {
            imgHeader: '',
            username: '',
            time: '0.5s',
            width: window.innerWidth
        }
    },
    getters: {
        width(state) {
            window.onresize = ()=> {
                return state.data.width ? 0 : window.innerWidth;
            };
            return state.data.width;
        }
    },
    actions: {},
    mutations: {
        [types.SET_SIDEBAR](state, item) {
            state.data = Object.assign(state.data, item);
        }
    }
};
