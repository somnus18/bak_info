// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue';
import App from './App';
import router from './routes';
import store from './vuex/store';
import Filters from 'filters/index';
import C from 'common/common';
import Native from './common/native';
import MD5 from './common/md5';
import UI from './common/ui';
import IScroll from 'iscroll';
import iScrollView from 'components/iscroll-view/index';

// 初始化全局css
import 'assets/css/m.scss';
Vue.use(iScrollView, IScroll);

window.Vue = Vue;
window.eventHub = new Vue();
window.C = C;
C.Native = Native;
C.UI = UI;
C.Utils.MD5 = MD5;

Filters.init();

window.onerror = function (msg, url, line, column) {
    C.debug.error('msg:' + msg + '<br>url:' + url + ',line:' + line + ',line:' + line + ',column:' + column);
};

Vue.config.productionTip = false;

/* eslint-disable no-new */
C.Utils.vm = new Vue({
    el: '#app',
    router,
    store,
    created() {
        for (let key in C.debug) {
            C.debug[key] = (...arg)=> {
                eventHub.$emit('debug-' + key, {
                    type: key,
                    text: arg
                });
            };
        }
    },
    template: '<App/>',
    components: {App}
});

// 隐私/无痕模式
if (!C.Utils.isLocalStorageSupported()) {
    C.UI.warn({
        title: '提示',
        okText: '确认',
        content: '当前浏览器被设置为隐私/无痕模式,请更改设置。'
    });
}

// 配置路由 中间验证
router.beforeEach((to, from, next)=> {
    next();
});

router.afterEach(()=> {
    // 判断当前路由的背景颜色
    let hasWhite = ['', 'login', 'verify'],
        hash = '';
    setTimeout(function () {
        hash = location.hash.split('?')[0];
        if (hasWhite.indexOf(hash.replace('#/', '')) !== -1) {
            $(document.body).css('background', '#fff');
        } else {
            $(document.body).css('background', '#f0f0f0');
        }
    }, 0);
    C.Utils.vm.$nextTick(()=> {
        setTimeout(()=> {
            document.body.scrollTop = 0;
            window.scrollTo(0, 0);
        }, 400);
    });
});
