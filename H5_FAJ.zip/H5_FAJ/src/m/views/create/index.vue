<template>
  <section>
        <div class="create-info" v-show='createInfo'>
            <div class="title">
              <span>主借款人信息</span>
            </div>
            <div class="border-top">
                <m-input v-model="idType[info.custInfo.globalType]" @select-input='pickerEvent({custInfo:"globalType"}, "证件类型", "34")' :textName="'证件类型'" :type="'select'" :placeholder="'请选择'"></m-input>
                <m-input v-model="two[info.custInfo.country]" @select-input='pickerEvent({custInfo:"country"}, "国家和地区", "2")' :textName="'国家和地区'" :type="'select'" :placeholder="'请选择'" :disabled='isCard || isCardType'></m-input>
                <div class="client">
                    <m-input v-model="info.custInfo.clientName" :placeholder="'请填写'" :class='{clientName: isCard}' :textName="'姓名'" :type='"text"' :nodel='isCard' maxlength='42'>
                    </m-input>
                    <upload-ocr v-show='isCard' class='ocr'  @uploadOcrMaster="uploadOcrMaster" :mark="'Master'"></upload-ocr>
                </div>
                <m-input v-model="info.custInfo.globalId" :textName="'证件号码'" :type="'text'" :placeholder="'请填写'" maxlength='32'></m-input>
                <m-input v-model="A9[info.custInfo.sex]" @select-input='pickerEvent({custInfo:"sex"}, "性别", "A9")' :textName="'性别'" :type="'select'" :placeholder="'请选择'"></m-input>
                <m-input v-model="info.custInfo.birthDate" :textName="'出生日期'" :type="'select'" :placeholder="'请选择'" @select-input='dateTimeSeleted({custInfo: "birthDate"})'></m-input>
                <m-input class='input-name-flex-10' v-model="A8[info.custInfo.secuFinDirExpiryDate]" @select-input='pickerEvent({custInfo:"secuFinDirExpiryDate"}, "是否长期有效", "A8")' :textName="'证件到期日-长期有效'" :type="'select'" :placeholder="'请选择'"></m-input>
                <m-input v-show='info.custInfo.secuFinDirExpiryDate === "0"' v-model="info.custInfo.finDirExpiryDate" :textName="'证件到期日'" :type="'select'" :placeholder="'请选择'" @select-input='dateTimeSeleted({custInfo: "finDirExpiryDate"})'></m-input>
                <m-input v-model="info.custInfo.certificateOrg" :textName="'发证机关所在地'" :type="'text'" :placeholder="'请填写'" maxlength='42'></m-input>
            </div>

            <div class="title">
              <span>贷款信息</span>
            </div>
            <div class="border-top">
                <m-input v-model="A2[info.loanInfo.loanVariety]" @select-input='pickerEvent({loanInfo:"loanVariety"}, "贷款品种", "A2")' :data-data='info.loanInfo.loanVariety' :textName="'贷款品种'" :type="'select'" :placeholder="'请选择'"></m-input>
                <m-input v-model="A3[info.loanInfo.loanPlan]" @select-input='pickerEvent({loanInfo:"loanPlan"}, "贷款方案", "A3")' :textName="'贷款方案'" :type="'select'" :placeholder="'请选择'"></m-input>
                <m-upper class='input-name-flex-10' v-model=info.loanInfo.bizApplyAmount :textName="'申请金额-商贷(万元)'" unit='w' :placeholder="'请填写'" :type="'text'" :maxlength="13"></m-upper>
                <m-upper class='input-name-flex-10' v-model=info.loanInfo.publicReserveApplyAmount :disabled='publicReserveApplyAmountDisabled' unit='w' :textName="'申请金额-公积金(万元)'" :placeholder="'请填写'" :type="'text'" :maxlength="13"></m-upper>
                <m-input v-model="address.v" :textName="'房产所在地'" :type="'select'" :placeholder="'请与房产证保持一致'" @select-input='areaSeleted'></m-input>
            </div>

            <div class="title">
              <span>销售信息</span>
            </div>
            <div class="border-top">
                <m-input v-model="referral" @select-input='pickerEvent({sellInfo:"referralName"}, "渠道专员", "referralName")' :disabled='isChannelUser' :textName="'渠道专员'" :type="'select'" :placeholder="'请选择'"></m-input>
                <m-input v-model="info.sellInfo.agencyName" @select-input='intermediaryEvent' :disabled='isIntermediary' :textName="'中介名称'" :type="'select'" :placeholder="'请选择'"></m-input>
                <m-input v-model="info.sellInfo.storeName" @select-input='pickerEvent({sellInfo:"storeName"}, "办理门店", "storeName")'  :textName="'办理门店'" :type="'select'" :placeholder="'请选择客户面签地点'"></m-input>
            </div>

            <div v-if='isTwoLoanVariety'>
                <div class="title">
                    <span>卖家信息</span>
                </div>
                <div class="border-top">
                    <m-input v-model="info.sellerInfo.sellerName" :textName="'卖方姓名'" :type="'text'" :placeholder="'请填写'" maxlength='42'></m-input>
                    <div class="lilv">
                        <m-input class="setHeight" v-model="info.sellerInfo.sellerMobile" :textName="'卖方联系方式'" :type="'text'" :placeholder="'请填写'" maxlength='32'></m-input>
                        <span class="tip"><font class="red-color"></font> 请准确填写，以便房产评估公司联系上门</span>
                    </div>
                    <m-input v-model="info.sellerInfo.sellerInvestigateDate" :textName="'拟上门调查日期'" :type="'select'" :placeholder="'请选择'" @select-input='dateTimeSeleted({sellerInfo: "sellerInvestigateDate"})'></m-input>
                </div>
            </div>

            <template  v-for='(item, index) in info.houseList'>
            <div class="title">
                <span>抵押物信息 <font v-if='isCollateralsEvent || isCopyEnvent'>{{index + 1}}</font></span>
                <span class="remove" v-if='index > 0'  @click='removeCollateralsEvent(index)'></span>
            </div>
            <div class="collateral border-top">
                <m-input v-model="address.v" :textName="'房产所在地'" :disabled='addressDisabled' :type="'text'" :placeholder="'请与房产证保持一致'"></m-input>
                <m-input v-model="item.houseAddress" :textName="'详细地址'" :type="'text'" :placeholder="'请与房产证保持一致'" maxlength='85'></m-input>
                <m-input v-model="item.houseArea" maxlength='9' :textName="'建筑面积(m²)'" :type="'text'" :placeholder="'请与房产证保持一致'"></m-input>
                <m-input v-model="seventeen[item.estateType]" @select-input='pickerEvent({value:"houseList", index: index, name: "estateType" }, "房产类型", "17")' :textName="'房产类型'" :type="'select'" :placeholder="'房产类型'" :disabled='isHouseType'></m-input>
                <div v-if='isTwoLoanVariety'>
                    <m-input v-model="A6[item.warrantType]" @select-input='pickerEvent({value:"houseList", index: index, name: "warrantType" }, "权证类型", "A6")' :textName="'权证类型'" :type="'select'" :placeholder="'请选择'"></m-input>
                </div>
                <div class="lilv">
                    <m-input class='setHeight' v-model="item.warrantCode" :textName="'权证编号'" :type="'text'" :placeholder="warrantCodeText" maxlength='42'></m-input>
                    <span class="tip"><font class="red-color"></font> 一手楼填写预售合同号</span>
                </div>
                <m-input v-model="sixteen[item.houseKinds]" @select-input='pickerEvent({value:"houseList", index: index, name: "houseKinds" }, "房屋类别", "16")' :textName="'房屋类别'" :type="'select'" :placeholder="'请选择'"></m-input>
            </div>
            </template>

            <div class="cell-btn" v-show='isAddCollaterals'>
                <span @click='addCollateralsEvent' class="add"><i></i> 添加抵押物</span>
            </div>
            <div class="bt-bottom">
                <button class='btn' @click="clickEvent">创建订单</button>
            </div>
        </div>

        <!-- 搜索中介 -->
        <div class="search-info" v-show="!createInfo">
            <mSearch :list='intermediaryDataArray' @getResult='getResult'></mSearch>
        </div>

    <m-picker :slots='slots' :isPicker='isPicker' :indexText='indexText'
    :datakey='datakey' :valueKey='valueKey'
    @confirm='pickerConfirm' @cancel='pickerCancel'>
    </m-picker>
    <m-date-picker :isPicker='isDatePicker' :datakey='dateDatakey' :defaultDate='defaultDate'
    @confirm='datePickerConfirm' @cancel="datePickerCancel">
    </m-date-picker>
    <m-area-picker :isPicker='isAreaPicker' :datakey='areaDataKey'  :devCity='devCity'
    @confirm='areaPickerConfirm' @cancel="areaPickerCancel">
    </m-area-picker>
  </section>
</template>

<script>
import mPicker from 'src/components/picker/index';
import mDatePicker from 'src/components/picker/date-picker.vue';
import mAreaPicker from 'src/components/picker/area-picker.vue';
import mInput from 'components/cell/cell';
import mSearch from 'components/search/search';
import mUpper from 'src/components/cell/upper';
import * as types from 'src/m/vuex/mutation-types';
import mButton from 'components/button/button';
import uploadOcr from 'components/upload/ocr';
export default {
    name: 'sell_info',
    data() {
        return {
            title: C.T.SELL_INFO,
            createInfo: true,
            searchInfo: false,
            devCity: true, // 贷款开发城市
            isPicker: false, // 普通选择器显示或隐藏
            isDatePicker: false, // 时间选择器显示或隐藏
            isAreaPicker: false, // 地区选择器显示或隐藏
            addressDisabled: false,
            defaultDate: '', // 日期选择器当前选择项
            valueKey: 'v', // 下拉框设置 value-key 属性来指定显示的字段名
            indexText: '贷款品种', // 选择器名称
            datakey: '', // 选择器结果赋值到对象的key值
            dateDatakey: 'sellerInvestigateDate',
            areaDataKey: 'loanAddress',
            warrantCodeText: '如：沪字第XXXXXX号',
            slots: [], // slot 对象数组
            address: {k: '', v: ''},
            A2: C.Constant.A2,
            A3: C.Constant.A3,
            A4: C.Constant.A4,
            A5: C.Constant.A5,
            A6: C.Constant.A6,
            A8: C.Constant.A8,
            A9: C.Constant.A9,
            seventeen: C.Constant['17'],
            idType: C.Constant['34'],
            two: C.Constant['2'],
            intermediaryDataArray: [],  // 搜索中介ajax结果
            isIntermediary: false,
            channelUserList: [], // 渠道专员
            isChannelUser: false,
            storeList: [], // 门店列表
            appUser: '', // 登录用户
            cardInfo: {}, // ocr身份证证件识别
            clickRepeat: false, // 防止点击重复
            amendSex: '', // 用于身份证和性别选择器双向绑定
            amendBirthDate: '', // 用于身份证和生日选择器双向绑定
            copyId: '', // 复制ID
            isCopyEnvent: false,
            info: {
                sourceOrderId: '',
                // 主借款人信息
                custInfo: {
                    globalType: C.Constant['34_Ind01'],
                    country: C.Constant['2_CHN'],
                    globalId: '',
                    clientName: '',
                    sex: '',
                    birthDate: '',
                    secuFinDirExpiryDate: C.Constant['A8_0'],
                    finDirExpiryDate: '',
                    certificateOrg: ''
                },
                // 贷款信息
                loanInfo: {
                    loanVariety: C.Constant['A2_2'],
                    loanPlan: C.Constant['A3_1'],
                    bizApplyAmount: '',
                    publicReserveApplyAmount: ''
                },
                // 抵押物信息列表
                houseList: [{
                    collateralId: '',
                    houseKinds: C.Constant['16_10'],
                    warrantType: C.Constant['A6_10'],
                    warrantCode: '',
                    houseProvince: '',
                    houseCity: '',
                    houseCounty: '',
                    houseAddress: '',
                    houseArea: '',
                    estateType: '' // 二期需求
                }],
                // 卖家信息
                sellerInfo: {
                    sellerInvestigateDate: '',
                    sellerMobile: '',
                    sellerName: ''
                },
                // 销售信息
                sellInfo: {
                    storeName: '',
                    storeId: '',
                    agencyName: '',
                    agencyCode: '',
                    referralName: '',
                    referralUm: ''
                }
            }
        };
    },
    components: {
        mPicker,
        mInput,
        mDatePicker,
        mAreaPicker,
        mSearch,
        mButton,
        uploadOcr,
        mUpper
    },
    computed: {
        isAddCollaterals() {
            return this.info.houseList.length < 5;
        },
        isTwoLoanVariety() {
            this.warrantCodeText = this.info.loanInfo.loanVariety === C.Constant.A2_2 ? '如：沪字第XXXXXX号' : '一手楼填写预售合同号';
            return this.info.loanInfo.loanVariety === C.Constant['A2_2'];
        },
        publicReserveApplyAmountDisabled() {
            this.info.loanInfo.publicReserveApplyAmount = this.info.loanInfo.loanPlan === C.Constant.A3_1 ? '0' : (this.info.loanInfo.publicReserveApplyAmount || '');
            return this.info.loanInfo.loanPlan === C.Constant.A3_1;
        },
        referral() {
            return this.info.sellInfo.referralName && (this.info.sellInfo.referralName + ' / ' + this.info.sellInfo.referralUm);
        },
        isCard() {
            if (this.info.custInfo.globalType === C.Constant['34_Ind01']) {
                this.info.custInfo.country = C.Constant['2_CHN'];
            }
            return this.info.custInfo.globalType === C.Constant['34_Ind01'];
        },
        // 二期需求
        isHouseType() {
            let bool = false;
            if (this.info.loanInfo.loanVariety === C.Constant['A2_2']) { // 二手楼按揭 => 现房 不可修改
                this.info.houseList.forEach((item)=> {
                    item.estateType = item.estateType ? item.estateType : C.Constant['17_1'];
                });
                bool = true;
            } else if (this.info.loanInfo.loanVariety === C.Constant['A2_1'] || this.info.loanInfo.loanVariety === C.Constant['A2_3']) { // 一手楼直客式 期房 可修改
                this.info.houseList.forEach((item)=> {
                    item.estateType = item.estateType ? item.estateType : C.Constant['17_2'];
                });
                bool = false;
            }
            return bool;
        },
        // 二期需求
        isCardType() {
            let bool = false, k = this.info.custInfo.globalType;
            if (C.Constant['2_A'].indexOf(k) !== -1) {  // 身份证
                this.info.custInfo.country = C.Constant['2_CHN'];
                bool = true;
            } else if (C.Constant['2_C'].indexOf(k) !== -1) { // 台湾
                this.info.custInfo.country = C.Constant['2_TWN'];
                bool = true;
            } else if (C.Constant['2_D'].indexOf(k) !== -1) { // 外国
                this.info.custInfo.country = C.Constant['2_OTH'];
                bool = true;
            } else if (C.Constant['2_E'].indexOf(k) !== -1) { // 其他
                this.info.custInfo.country = C.Constant['2_CHN'];
                bool = false;
            }
            return bool;
        },
        isCollateralsEvent() {
            return this.info.houseList.length !== 1;
        },
        sixteen() {
            return $.extend(true, {}, C.Constant['16_95_object'], C.Constant['16']);
        }
    },
    watch: {
        // 二期需求
        info: {
            handler(newValue) {
                let val = newValue.custInfo.globalId;
                if (val.length === 18 && this.info.custInfo.globalType === C.Constant['34_Ind01']) {
                    this.amendBirthDate = C.Utils.strDateTime(val, true, 'yyyy-MM-dd');
                    this.amendSex = val[16] % 2 === 0 ? C.Constant.A9_2 : C.Constant.A9_1;
                }
            },
            deep: true
        },
        amendSex(val) {
            this.info.custInfo.sex = val;
        },
        amendBirthDate(val) {
            this.info.custInfo.birthDate = val;
        }
    },
    created() {
        // 页面多个普通下拉框(非联动,)，需要改变数组，必须在created赋值, 然后就可以在每个方法赋值
        this.slots = [{values: []}];
        this.user = C.Utils.data(C.Constant.DK.USER_LOGIN_INFO);
        this.user.userRole !== '01' && this.getIntermediaryList(); // 中介
        this.user.userRole !== '03' && this.getChannelUserList(); // 渠道专员
        if (this.user.userRole === '01') {
            this.isIntermediary = true;
            this.info.sellInfo.agencyName = this.user.agencyName;
            this.info.sellInfo.agencyCode = this.user.agencyCode;
        } else if (this.user.userRole === '03') {
            this.isChannelUser = true;
            this.info.sellInfo.referralName = this.user.name;
            this.info.sellInfo.referralUm = this.user.um;
        }
        C.Utils.data(C.Constant.DK.STORE_CITY_CODE, null); // 清空房产所在地的城市code
        C.Native.setHeader({
            title: C.T.SELL_INFO,
            // mock数据填写,生产无效
            titleCallback: ()=> {
                let key, key1, i, key2;
                C.UI.loading();
                $.ajax({
                    url: C.Api('GET_NEW_ORDER_INFO_TPL', 'json'),
                    type: 'get',
                    success: (res)=> {
                        C.UI.stopLoading();
                            if (res.flag === C.Flag.SUCCESS) {
                                for (key in res.data) {
                                    if (Object.prototype.toString.call(res.data[key]) === '[object Object]') {
                                        for (key1 in res.data[key]) {
                                            this.info[key][key1] = this.info[key][key1] || res.data[key][key1];
                                        }
                                    } else {
                                        for (i = 0; i < res.data[key].length; i++) {
                                            for (key2 in res.data[key][i]) {
                                                this.info[key][i][key2] = this.info[key][i][key2] || res.data[key][i][key2];
                                            }
                                        }
                                    }
                                }
                            }
                    }
                });
            },
            leftCallback: ()=> {
                if (this.createInfo) {
                    this.$router.go(-1);
                } else {
                    this.createInfo = true;
                    this.searchInfo = false;
                    this.$store.commit(types.SET_HEADER_TITLE, {title: C.T.SELL_INFO});
                }
            }
        });
    },
    mounted() {
        this.copyId = C.Utils.getParameter('orderId');
        this.info.sourceOrderId = this.copyId;
        if (this.copyId) {
            this.copyOrder(this.copyId);
        }
    },
    methods: {
        copyOrder(orderId) {
            console.log(orderId, 'orderId');
            $.ajax({
                url: C.Api('GET_COPY_CREATE_ORDER'),
                data: {sourceOrderId: orderId},
                success: (res)=> {
                    C.UI.stopLoading();
                    if (res.flag === C.Flag.SUCCESS) {
                        let key, key1, i, key2, storeCityCode, houseList, houseProvince, houseCounty, houseCity;
                        for (key in res.data) {
                            if (Object.prototype.toString.call(res.data[key]) === '[object Object]') {
                                for (key1 in res.data[key]) {
                                    this.info[key][key1] = (key1 === 'bizApplyAmount' || key1 === 'publicReserveApplyAmount') ? C.Utils.toWY(res.data[key][key1]) : res.data[key][key1];
                                }
                            } else {
                                if (res.data[key]) {
                                    for (i = 0; i < res.data[key].length; i++) {
                                        this.addCollateralsEvent(); // 复制订单 抵押物input的clean Icon图标删除无效
                                        for (key2 in res.data[key][i]) {
                                            this.info[key][i] = this.info[key][i] || {};
                                            this.info[key][i][key2] = res.data[key][i][key2];
                                        }
                                        this.removeCollateralsEvent(i + 1); // 复制订单 抵押物input的clean Icon图标删除无效
                                    }
                                }
                            }
                        }
                        // 房产所在地和门店
                        houseList = res.data.houseList[0];
                        houseProvince = houseList.houseProvince.split('/');
                        houseCounty = houseList.houseCounty.split('/');
                        houseCity = houseList.houseCity.split('/');
                        this.addressDisabled = true;
                        this.address = {
                            v: houseProvince[1] + houseCity[1] + houseCounty[1],
                            k: `${houseProvince[0]}-${houseCity[0]}-${houseCounty[0]}`
                        };
                        storeCityCode = houseCity[0];
                        this.getStoreList(storeCityCode);
                        this.isCopyEnvent = res.data.houseList.length > 1;
                    }
                }
            });
        },
        uploadOcrMaster(param) {
            C.UI.loading();
            $.ajax({
                url: C.Api('GET_CARD_INFO'),
                data: {
                    cardSide: param.type,
                    imgName: param.imgName,
                    imgBase64: param.imgBase64
                },
                success: (res)=> {
                    C.UI.stopLoading();
                    if (res.flag === C.Flag.SUCCESS) {
                        res.data.cardNo && (this.info.custInfo.globalId = res.data.cardNo);
                        res.data.name && (this.info.custInfo.clientName = res.data.name);
                        res.data.birthday && (this.info.custInfo.birthDate = res.data.birthday);
                        res.data.issueAuthority && (this.info.custInfo.certificateOrg = res.data.issueAuthority);
                        if (res.data.sex) {
                            if (res.data.sex === '男') {
                                this.info.custInfo.sex = '1';
                            } else if (res.data.sex === '女') {
                                this.info.custInfo.sex = '2';
                            }
                        }
                        if (res.data.validPeriod) {
                            let _ValidPeriod = res.data.validPeriod.indexOf('长期') !== -1;
                            this.info.custInfo.secuFinDirExpiryDate = _ValidPeriod ? C.Constant['A8_1'] : C.Constant['A8_0'];
                            this.info.custInfo.finDirExpiryDate = _ValidPeriod ? C.Constant.LAST_YEAR : res.data.validPeriod.split(',')[1];
                        }
                    }
                }
            });
        },
        pickerEvent(key, text, slot) {
            this.datakey = key;
            this.indexText = text;
            // 房屋类别
            let newSolot;
            // 门店或渠道独自处理
            if (slot === 'referralName') {
                newSolot = this.channelUserList;
                this.valueKey = 'referral';
            } else if (slot === 'storeName') {
                if (!this.address.k && !this.address.v) {
                    C.Native.tip('请先选择房产所在地');
                    return;
                } else if (this.storeList.length === 0) {
                    C.Native.tip('该城市没有门店');
                    return;
                }
                this.valueKey = slot;
                newSolot = this.storeList;
            } else if (key.name === 'houseKinds' && key.index > 0) {
                newSolot = C.Utils.objToArr(C.Constant['16_95_object']);
                this.valueKey = 'v';
            } else if (slot === '2' && this.info.custInfo.globalType === C.Constant['2_B']) {
                newSolot = C.Utils.objToArr(C.Constant['2_1']);
                this.valueKey = 'v';
            } else {
                newSolot = C.Utils.objToArr(C.Constant[slot]);
                this.valueKey = 'v';
            }
            this.slots = [{values: newSolot}];
            this.isPicker = true;
            this.isDatePicker = false;
            this.isAreaPicker = false;
        },
        pickerConfirm(value, key) {
            // {k: 01, v: '"按揭一手楼"'} dateTime
            // {value:"houseList", index: index, name: "collateralWarrantType" }
            if (key.hasOwnProperty('value')) {
                this.info[key.value][key.index][key.name] = value.k;
                this.info[key.value][key.index][key.name] = value.k;
            } else {
                if (Object.prototype.toString.call(key) === '[object Object]') {
                    let ObjKey = Object.keys(key)[0],
                        ObjValue = Object.values(key)[0];
                    switch (ObjValue) { // 独自处理门店和渠道
                        case 'referralName':
                            this.info[ObjKey].referralUm = value.referralUm;
                        break;
                        case 'loanVariety': // 非复制订单 对房产类型重置
                            this.info.houseList.forEach(item=> {
                                item.estateType = '';
                            });
                        break;
                        case 'storeName':
                            this.info[ObjKey].storeId = value.storeId;
                        break;
                    }
                    if (ObjValue === 'loanPlan' && value.k === '2' && this.info.loanInfo.loanPlan === C.Constant['A3_1']) {
                        this.info.loanInfo.publicReserveApplyAmount = '';
                    }
                    this.info[ObjKey][ObjValue] = value[(ObjValue === 'referralName' || ObjValue === 'storeName') ? ObjValue : 'k'];
                } else {
                    this.info[key] = value.k;
                }
            }
            // 二期需求 当选择港澳通行证的时候
            if (value.k === C.Constant['2_B'] && C.Constant['2_HKG_MAC'].indexOf(this.info.custInfo.country) === -1) {
                this.info.custInfo.country = C.Constant['2_HKG'];
            }
            this.isPicker = false;
        },
        pickerCancel() {
          this.isPicker = false;
        },
        // 选择中介
        intermediaryEvent() {
            this.createInfo = false;
            this.searchInfo = true;
            this.$store.commit(types.SET_HEADER_TITLE, {title: C.T.INTERMEDIARY});
        },
        // 选择中介公司
        getResult(value) {
            this.info.sellInfo.agencyName = value.agencyName.join('');
            this.info.sellInfo.agencyCode = value.agencyCode;
            this.createInfo = true;
            this.searchInfo = false;
            this.$store.commit(types.SET_HEADER_TITLE, {title: C.T.SELL_INFO});
        },
        // 中介名称
        getIntermediaryList() {
            $.ajax({
                url: C.Api('SELECT_AGENCIES'),
                data: {},
                success: (res)=> {
                    if (res.flag === C.Flag.SUCCESS) {
                        this.intermediaryDataArray = res.data.agencyList;
                    }
                }
            });
        },
        // 办理门店
        getStoreList(code) {
            C.UI.loading();
            $.ajax({
                url: C.Api('GET_STORE_LIST'),
                data: {cityCode: code},
                success: (res)=> {
                    C.UI.stopLoading();
                    if (res.flag === C.Flag.SUCCESS) {
                        this.storeList = res.data.storeList;
                    } else {
                        this.address = {};
                    }
                }
            });
        },
        // 渠道专员
        getChannelUserList() {
            $.ajax({
                url: C.Api('GET_CHANNEL_USER_LIST'),
                data: {},
                success: (res)=> {
                    if (res.flag === C.Flag.SUCCESS) {
                        res.data.userList.forEach((item)=> {
                            item.referral = item.referralName + ' / ' + item.referralUm;
                        });
                        this.channelUserList = res.data.userList;
                    }
                }
            });
        },
        // 添加抵押物
        addCollateralsEvent() {
            this.info.houseList.push({
                    collateralId: '',
                    houseKinds: C.Constant['16_95'],
                    warrantType: C.Constant['A6_10'],
                    warrantCode: '',
                    houseProvince: this.info.houseList[0].houseProvince,
                    houseCity: this.info.houseList[0].houseCity,
                    houseCounty: this.info.houseList[0].houseCounty,
                    houseAddress: '',
                    houseArea: '',
                    estateType: '' // 二期需求
            });
        },
        // 删除抵押物
        removeCollateralsEvent(index) {
            this.info.houseList.splice(index, 1);
            this.isCopyEnvent = this.info.houseList > 1;
        },
        // 日期选择器
        dateTimeSeleted(obj) {
            // 参数1：this.info.custInfo.birthDate
            // 参数2：obj => {custInfo: "birthDate"}
            this.defaultDate = C.Utils.pickerDateObject(this.info, obj);
            this.dateDatakey = obj;
            this.isPicker = false;
            this.isDatePicker = true;
            this.isAreaPicker = false;
        },
        datePickerCancel() {
          this.isDatePicker = false;
        },
        datePickerConfirm(value, key) {
            let _key, _value;
            _key = Object.keys(key)[0];
            _value = Object.values(key)[0];
            this.isDatePicker = false;
            this.info[_key][_value] = value.join('-');
        },
        // 地区选择
        areaSeleted() {
            this.isPicker = false;
            this.isDatePicker = false;
            this.isAreaPicker = true;
        },
        areaPickerCancel() {
          this.isAreaPicker = false;
        },
        areaPickerConfirm(value) {
          // {k: "110000-110100-000046", v: "北京市-北京市-北京技术开发区"}
            this.isAreaPicker = false;
            this.addressDisabled = true;
            this.info.houseList.forEach((item)=> {
                item.houseProvince = value.k.split('-')[0] + '/' + value.v.split('-')[0];
                item.houseCity = value.k.split('-')[1] + '/' + value.v.split('-')[1];
                item.houseCounty = value.k.split('-')[2] + '/' + value.v.split('-')[2];
            });
            let storeCityCode = value.k.split('-')[1];
            this.address.v = value.v.replace(/\-/g, '');
            this.address.k = value.k;
            if (!C.Utils.data(C.Constant.DK.STORE_CITY_CODE) || C.Utils.data(C.Constant.DK.STORE_CITY_CODE) !== storeCityCode) {
                this.info.sellInfo.storeName = '';
                C.Utils.data(C.Constant.DK.STORE_CITY_CODE, storeCityCode);
                this.getStoreList(storeCityCode);
            }
        },
        // 创建订单
        clickEvent() {
            if (this.info.custInfo.globalType !== C.Constant['34_Ind01']) {
                C.UI.warn({
                    title: ' ',
                    content: '在线征信授权仅支持身份证, <br/>非身份证订单请提前沟通客户采用“先签后审”模式',
                    okText: '确定',
                    isShowClose: true,
                    ok: ()=> {
                        this.createdOrder();
                    }
                });
            } else {
                this.createdOrder();
            }
        },
        createdOrder() {
            let msg, someHouseType = [], warrantTip = '';
            msg = this.dataValidator();
            if (msg) {
                C.Native.tip(msg);
                return;
            }
            someHouseType = this.info.houseList.filter((item)=> {
                return item.estateType === C.Constant['17_1'];
            });
            if (someHouseType.length !== 0 && someHouseType[0].warrantCode) {
                warrantTip = '权证编号：' + someHouseType[0].warrantCode;
            }
            // 二期需求  1.一手楼现房验证 2.非空/格式等验证 3.非身份证提示验证  4.创建订单
            if ((this.info.loanInfo.loanVariety === C.Constant.A2_1 || this.info.loanInfo.loanVariety === C.Constant.A2_3) && someHouseType.length !== 0) {
                C.UI.warn({
                    title: ' ',
                    content: '<div style="text-align: center">"一手楼-现房"业务，<br/>请联系银行客户经理并采用先签后审模式<br/>' + warrantTip + '</div>',
                    okText: '确定',
                    isShowClose: true,
                    ok: ()=> {
                        this.createdSuccess();
                    }
                });
            } else {
                this.createdSuccess();
            }
        },
        createdSuccess() {
            C.UI.loading();
            if (this.info.custInfo.secuFinDirExpiryDate === C.Constant.A8_1) {
                this.info.custInfo.finDirExpiryDate = C.Constant.LAST_YEAR;
            }
            if (this.clickRepeat) return;
            this.clickRepeat = true;
            $.ajax({
                url: C.Api('CREATE_ORDER'),
                data: $.extend(true, {}, this.info, {
                    loanInfo: {
                        bizApplyAmount: C.Utils.toY(this.info.loanInfo.bizApplyAmount, 2),
                        publicReserveApplyAmount: C.Utils.toY(this.info.loanInfo.publicReserveApplyAmount, 2)
                    }
                }),
                success: (res)=> {
                    C.UI.stopLoading();
                    this.clickRepeat = false;
                    if (res.flag === C.Flag.SUCCESS) {
                        C.Utils.data(C.Constant.DK.ORDER_ID, res.data.orderId);
                        C.UI.success({
                            title: '订单创建成功',
                            content: '',
                            okText: '确认',
                            onlyBtn: true,
                            ok: ()=> {
                                this.$router.push({path: '/apply?type=create'});
                            }
                        });
                    }
                }
            });
        },
        dataValidator() {
            let msg = '',
                length,
                validatorIdNo = C.Validator.idNo(this.info.custInfo.globalId, this.info.custInfo.globalType);
            if (!this.info.custInfo.country) {
                msg = '国家和地区必填';
            } else if (!this.info.custInfo.clientName) {
                msg = '姓名必填';
            } else if (!this.info.custInfo.globalId) {
                msg = '证件号码必填';
            } else if (C.Utils.strLength(this.info.custInfo.globalId) > 32) {
                msg = '证件号码不得超过32个字节';
            } else if (!validatorIdNo.result) {
                msg = validatorIdNo.error;
            } else if (!this.info.custInfo.sex) {
                msg = '性别必选';
            } else if (!this.info.custInfo.birthDate) {
                msg = '出生日期必选';
            } else if (C.Utils.getAge(this.info.custInfo.birthDate) < 18 || C.Utils.getAge(this.info.custInfo.birthDate) > 65) {
                msg = '年龄应在18~65周岁';
            } else if (!this.info.custInfo.finDirExpiryDate && this.info.custInfo.secuFinDirExpiryDate === C.Constant.A8_0) {
                msg = '证件到期必选';
            } else if (!this.info.custInfo.certificateOrg) {
                msg = '发证机关所在地必填';
            } else if (!this.info.loanInfo.loanVariety) {
                msg = '贷款品种必选';
            } else if (!this.info.loanInfo.bizApplyAmount) {
                msg = '申请金额必填';
            } else if (isNaN(this.info.loanInfo.bizApplyAmount)) {
                msg = '申请金额必须为数字';
            } else if (!C.Utils.RegexMap.sixDecimal.test(this.info.loanInfo.bizApplyAmount)) {
                msg = '申请金额最多6位小数点';
            } else if (this.info.loanInfo.bizApplyAmount <= 0) {
                msg = '申请金额需大于0';
            } else if (!C.Utils.checkAmountRange(this.info.loanInfo.bizApplyAmount * 10000, null, 'gEToL')()) {
                msg = '申请金额' + C.HT['1'];
            } else if (this.info.loanInfo.loanPlan === C.Constant['A3_2'] && !this.info.loanInfo.publicReserveApplyAmount) {
                msg = '申请金额-公积金必填';
            } else if (this.info.loanInfo.loanPlan === C.Constant['A3_2'] && isNaN(this.info.loanInfo.publicReserveApplyAmount)) {
                msg = '申请金额-公积金必须为数字';
            } else if (this.info.loanInfo.loanPlan === C.Constant['A3_2'] && !C.Utils.isEmpty(this.info.loanInfo.publicReserveApplyAmount) && this.info.loanInfo.publicReserveApplyAmount <= 0) {
                msg = '申请金额-公积金需大于0';
            } else if (this.info.loanInfo.loanPlan === C.Constant['A3_2'] && !C.Utils.RegexMap.sixDecimal.test(this.info.loanInfo.publicReserveApplyAmount)) {
                msg = '申请金额-公积金最多6位小数点';
            } else if (this.info.loanInfo.loanPlan === C.Constant['A3_2'] && !C.Utils.checkAmountRange(this.info.loanInfo.publicReserveApplyAmount * 10000, null, 'gEToL')()) {
                msg = '申请金额-公积金' + C.HT['1'];
            } else if (!this.address.k || !this.address.v) {
                msg = '房产所在地必填';
            } else if (!this.info.sellInfo.referralUm || !this.info.sellInfo.referralName) {
                msg = '渠道专员必填';
            } else if (!this.info.sellInfo.agencyName || !this.info.sellInfo.agencyCode) {
                msg = '中介名称必填';
            } else if (!this.info.sellInfo.storeName || !this.info.sellInfo.storeId) {
                msg = '办理门店必选';
            }
            if (msg) {
                return msg;
            }
            length = this.info.houseList.length;
            for (let i = 0; i < length; i++) {
                let item = this.info.houseList[i];
                console.log(item.houseArea, 'item.houseArea');
                if (!item.houseAddress) {
                    msg = '抵押物详细地址不能为空';
                } else if (item.houseAddress && !(/[一二三四五六七八九十〇壹贰叁肆伍陆柒捌玖零1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ]/.test(item.houseAddress))) {
                    msg = '请填写详细地址（含门牌号）';
                } else if (!item.houseArea && item.houseArea !== 0) {
                    msg = '抵押物建筑面积不能为空';
                } else if (item.houseArea && isNaN(item.houseArea)) {
                    msg = '建筑面积请输入正确数字';
                } else if (item.houseKinds !== C.Constant['16_95'] && item.houseArea && !isNaN(item.houseArea) && item.houseArea < 25) {
                    msg = '建筑面积不得小于25m²';
                } else if (item.houseKinds !== C.Constant['16_95'] && item.houseArea && !isNaN(item.houseArea) && !C.Utils.RegexMap.secondDecimal.test(item.houseArea)) {
                    msg = '建筑面积为整数或最多两位小数';
                } else if (item.houseKinds !== C.Constant['16_95'] && item.houseArea && !isNaN(item.houseArea) && !C.Utils.checkAmountRange(item.houseArea, 2, 'gEToLE')(25)) {
                    msg = '抵押物建筑面积' + C.HT['2'];
                } else if (item.houseKinds === C.Constant['16_95'] && item.houseArea && !isNaN(item.houseArea) && !C.Utils.checkAmountRange(item.houseArea, 2, 'gToL')(0)) {
                    msg = '建筑面积' + C.HT['5'];
                } else if (!item.warrantCode) {
                    msg = '抵押物权证编号不能为空';
                }
                if (msg) break;
            }
            if (msg) {
                return msg;
            }
            if (length > 1) {
                let arr = this.info.houseList, hash = {};
                for (let i = 0; i < arr.length; i++) {
                    if (hash[arr[i].warrantCode]) {
                        msg = '多抵押物时抵押物权证编号不能相同';
                        break;
                    } else {
                        hash[arr[i].warrantCode] = true;
                    }
                }
                return msg;
            }
        }
    }
};
</script>

<style lang="scss" scoped>
.setHeight {
    padding-bottom: .3rem;
}
.red-color{
    position:relative;
    top: -1px;
    background:url(./../../../assets/images/m/icons/icon_-@2x.png) no-repeat;
    display:inline-block;
    width: 7px;
    height:7px;
    background-size: 7px 7px;
}
.title{
    position: relative;
    span{
        color: #999;
        display:inline-block;
        font-size: .26rem;
        height:.5rem;
        line-height:.58rem;
        padding-left: .3rem;
    }
    .remove{
        position:absolute;
        top: 0.1rem;
        right: .3rem;
        display:inline-block;
        width: .34rem;
        height: .34rem;
        background:url(./../../../assets/images/m/icons/remove.png) no-repeat;
        background-size: .34rem .34rem;
    }
}
.bt-bottom {
    margin:.2rem 0 0 0;
    padding:.3rem 0;
    width: 100%;
    line-height: .8rem;
    text-align: center;
    background:#fff;
    border-top: 1px solid #ddd;
}
.border-top{
    border-top: 1px solid #ddd;
}
.cell-btn{
    height: .8rem;
    line-height: .8rem;
    text-align:center;
    background:#fafafa;
    color: #1f87e5;
    .add {
        padding: .1rem 0;
        i{
            position: relative;
            top: .1rem;
            left: .05rem;
            padding: 0 0.05rem;
            display:inline-block;
            width: .4rem;
            height: .4rem;
            background:url(./../../../assets/images/m/icons/add.png) no-repeat;
            background-size: .4rem .4rem;
            padding-left: .4rem;
        }
    }
}
.lilv {
    position: relative;
    .tip {
        position: absolute;
        left: .3rem;
        bottom: .1rem;
        font-size: .24rem;
        color: #999;
    }
}
.client{
    position: relative;
    .clientName{
        padding-right: .3rem;
    }
    .ocr{
        position: absolute;
        top: .22rem;
        right: .3rem;
    }
}
</style>
