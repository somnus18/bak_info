<template>
	<section>
		<m-input v-model="this.info.loanBreed" @select-input='loanBreedEvent' :textName="'贷款品种'" :type="'select'" :placeholder="'请选择'"></m-input>
		<m-input v-model="this.info.loanPlan" @select-input='loanPlanEvent' :textName="'贷款方案'" :type="'select'" :placeholder="'请选择'"></m-input>
		<m-input v-model="this.info.dateTime" :textName="'拟上门调查日期'" :type="'select'" :placeholder="'请选择'" @select-input='dateTimeSeleted'></m-input>
		<m-input v-model="this.info.areaData" :textName="'地区选择'" :type="'select'" :placeholder="'请选择'" @select-input='areaSeleted'></m-input>
		<m-picker :slots='slots' :isPicker='isPicker' :indexText='indexText' 
		:datakey='datakey' :valueKey='valueKey' 
		@confirm='pickerConfirm' @cancel='pickerCancel'>
		</m-picker>
		<m-date-picker :isPicker='isDatePicker' :datakey='dateDatakey' 
		@confirm='datePickerConfirm' @cancel="datePickerCancel">
		</m-date-picker>
		<m-area-picker :isPicker='isAreaPicker' :datakey='areaDataKey' 
		@confirm='areaPickerConfirm' @cancel="areaPickerCancel">
		</m-area-picker>
	</section>
</template>

<script>
import mPicker from 'src/components/picker/index';
import mDatePicker from 'src/components/picker/date-picker.vue';
import mAreaPicker from 'src/components/picker/area-picker.vue';
import mInput from 'components/cell/cell';
export default {
  name: 'sell_info',
  data() {
    return {
    	isPicker: false, // 普通选择器显示或隐藏
    	isDatePicker: false, // 时间选择器显示或隐藏
    	isAreaPicker: false, // 地区选择器显示或隐藏
    	valueKey: 'v', // 下拉框设置 value-key 属性来指定显示的字段名
    	indexText: '贷款品种', // 选择器名称
    	isSell: true,
    	datakey: '', // 选择器结果赋值到对象的key值
    	dateDatakey: 'dateTime',
    	areaDataKey: 'areaData',
    	slots: [], // slot 对象数组
    	msg: '',
    	info: {
    		loanBreed: '',
    		loanPlan: '',
    		dateTime: '',
    		areaData: ''
    	}
    };
  },
  components: {
  	mPicker,
  	mInput,
  	mDatePicker,
  	mAreaPicker
  },
  created() {
  	// 页面多个普通下拉框(非联动,)，需要改变数组，必须在created赋值, 然后就可以在每个方法赋值
    // 单个则在data定义slots即可
  	this.slots = [{values: []}];
  },
  methods: {
  	loanBreedEvent() {
  		this.datakey = 'loanBreed';
    	this.indexText = '贷款品种';
  		this.slots = [{values: C.Constant.LOAN_BREED}];
  		this.isPicker = true;
  	},
  	loanPlanEvent() {
  		this.datakey = 'loanPlan';
    	this.indexText = '贷款方案';
  		this.slots = [{values: C.Constant.LOAN_PLAN}];
  		this.isPicker = true;
  	},
  	pickerConfirm(value, key) {
  		// {k: 01, v: '"按揭一手楼"'} dateTime
  		this.info[key] = value[this.valueKey];
  		this.isPicker = false;
  	},
  	pickerCancel() {
  		this.isPicker = false;
  	},
  	// 日期选择器
  	dateTimeSeleted() {
  		this.dateDatakey = 'dateTime';
  		this.isDatePicker = true;
  	},
  	datePickerCancel() {
  		this.isDatePicker = false;
  	},
  	datePickerConfirm(value, key) {
  		// cosole.log(value, key) [2017, "01", "01"] "dateTime"
  		this.isDatePicker = false;
  		this.info[key] = value.join('-');
  	},
  	// 地区选择
  	areaSeleted() {
  		this.isAreaPicker = true;
  	},
  	areaPickerCancel() {
  		this.isAreaPicker = false;
  	},
  	areaPickerConfirm(value, key) {
  		// {k: "110000-110100-000046", v: "北京市-北京市-北京技术开发区"}
  		this.isAreaPicker = false;
  		this.info[key] = value.v;
  	}
  }
};
</script>

<style lang="scss" scoped>
section{
	margin-top: 1rem;
}
.cell-btn button{
	margin: 0 auto;
	margin-top: .5rem;
	width: 70%;
    background-color: #26a2ff;
	-webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    border-radius: 4px;
    border: 0;
    box-sizing: border-box;
    color: inherit;
    display: block;
    height: .8rem;
	font-size: .28rem;
    outline: 0;
    overflow: hidden;
    position: relative;
    text-align: center;
	color: #fff;
}
</style>
