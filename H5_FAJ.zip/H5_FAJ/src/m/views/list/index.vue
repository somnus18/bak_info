<template>
    <div class="list">
        <nav class="tab-nav fixed">
            <router-link tag="div" :to="{ path: 'pending'}" class="border-right-1" active-class="selected" replace><span>待处理订单</span></router-link>
            <router-link tag="div" :to="{ path: 'all'}" active-class="selected" replace><span>所有订单</span></router-link>
        </nav>
        <sidebar></sidebar>
        <router-view></router-view>
        <footer class="footer-bottom">
            <div class="btn new-create" @click="goCreate"><span></span>新建订单</div>
        </footer>
    </div>
</template>

<script type='text/ecmascript-6'>
    import sidebar from 'src/m/components/sidebar';

    export default {
        name: 'list-index',
        methods: {
            goCreate() {
//                this.$router.push('../create');
                C.Native.forward({
                    url: 'index.html#create/index'
                });
            }
        },
        components: {
            sidebar
        }
    };
</script>

<style scoped lang="scss">
    .list {
        height: 100%;
        .tab-nav {
            display: -webkit-box;
            top: 1rem;
            width: 100%;
            height: 1rem;
            line-height: 1rem;
            background: #f0f0f0;
            z-index: 10;
            > div {
                background: #fff;
                -webkit-box-flex: 1;
                width: 50%;
                text-align: center;
                padding: 0 .9rem;
                border-bottom: 1px solid #f0f0f0;
                &.selected span {
                    padding: .3rem 0rem;
                    color: #f05a23;
                    border-bottom: 2px solid #f05a23;
                }
            }
        }
        .footer-bottom{
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            height: 1.2rem;
            line-height: 1.2rem;
            text-align: center;
            background: #fff;
            .new-create {
                display: inline-block;
                vertical-align: middle;
                width: 54%;
                height: .8rem;
                line-height: .8rem;
                background: #fff;
                color: #f05a23;
                border: 1px solid #f05a23;
                border-radius: .4rem;
                margin: 0 auto;
                span{
                    display: inline-block;
                    vertical-align: middle;
                    content: '';
                    margin-top: -.08rem;
                    margin-right: .2rem;
                    width: .32rem;
                    height: .32rem;
                    background: url('../../../assets/images/m/icons/icon_neworder@2x.png') no-repeat;
                    background-size: 100%;
                }
            }
        }
    }
</style>
