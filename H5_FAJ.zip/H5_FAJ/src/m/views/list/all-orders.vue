<template>
    <div class="all-orders">
        <scroll-list v-show="!isShowDefault" class="all-wrapper" :opt="opt" :isMoreData="isMoreData" ref="scrollAllOrders" :pageNo="page" :params="params">
            <order-card v-for="item in orderList" :key="item.orderId" :canMove=true :showBankStatus=true :item="item" @goDetail="goDetail(item.orderId)" @delete="del" isCopy=true></order-card>
        </scroll-list>
        <no-orders v-show="isShowDefault"></no-orders>
        <select-order @search-order="searchOrder" v-show="isShowSelect"></select-order>
        <del-order :isShow="isShowDelOrder" @del-confirm="delConfirm"></del-order>
    </div>
</template>

<script type='text/ecmascript-6'>
    import orderCard from '@/components/order-card.vue';
    import scrollList from '@/components/scroll_list';
    import * as types from 'src/m/vuex/mutation-types';
    import selectOrder from 'src/components/select-order';
    import delOrder from 'src/components/del-order';
    import noOrders from 'src/components/no-orders';

    export default {
        name: 'all-orders',
        data() {
            return {
                isShowDefault: false,
                orderList: [],
                // 关于iscroll
                maxHeight: null,
                isRefresh: true, // 判断下拉 还是上拉
                page: 1, // 页面数 接受scroller回传的page值
                isMoreData: false, // 监控上拉有无更多数据 并传递给scroller组件
                opt: {
                    isLoadMore: true,
                    isRefresh: true
                },
                isShowSelect: false,
                isShowDelOrder: false,
                params: null
            };
        },
        created() {
            this.select = this.rightText = '筛选';
            this.close = '';
            C.Native.setHeader({
                fixed: true,
                leftIcon: 'user',
                leftCallback: ()=> {
                    this.$store.commit(types.SET_SIDEBAR, {width: 0});
                },
                title: C.T.ALL_ORDER,
                titleIcon: 'logo',
                rightText: this.rightText,
                rightIcon: this.close,
                rightCallback: ()=> {
                    this.close = this.close === 'close' ? '' : 'close';
                    this.$store.commit(types.SET_HEADER_R_I, {rightIcon: this.close});
                    this.isShowSelect = !this.isShowSelect;
                }
            });
        },
        mounted() {
            this.$nextTick(()=> {
                // 确定筛选DOM的top 高度
                let headerHeight = document.querySelector('.navbar').clientHeight,
                    navHeight = document.querySelector('.tab-nav').clientHeight;
                this.maxHeight = window.screen.height - headerHeight - navHeight;
                C.UI.loading();
                this.render();
            });
        },
        methods: {
            render(params, callback) {
                let _data = null,
                    paramData = typeof params === 'object' ? $.extend(true, {
                        pageNo: 1
                    }, params) : {
                        pageNo: params || this.page
                    };
                this.page = paramData.pageNo;
                paramData.searchType = '01';
                $.ajax({
                    url: C.Api('ORDER_LIST'),
                    data: paramData,
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            _data = res.data.allOrderList || res.data.orderList;
                            // 数据
                            this.isMoreData = true;
                            this.isShowDefault = false;
                            if (!_data || !_data.length) {
                                if (parseInt(paramData.pageNo) === 1) {
                                    // 没有数据
                                    this.isShowDefault = true;
                                }
                                this.isMoreData = false;
                                return;
                            }
                            // 下拉就加载最新 上拉就push更多数据
                            if (this.isRefresh || ~~paramData.pageNo === 1) {
                                this.orderList = _data;
                            } else {
                                for (let i = 0; i < _data.length; i++) {
                                    this.orderList.push(_data[i]);
                                }
                            }
                            if (_data.length < 10 || res.data.totalPageNo === paramData.pageNo) {
                                this.isMoreData = false;
                            }
                            setTimeout(()=> {
                                this.$refs.scrollAllOrders.$children[0].refresh();
                                C.Utils.initScrollHeight('.scroll-main', '.scroll-view', this.maxHeight);
                                if (~~paramData.pageNo === 1) {
                                    this.$refs.scrollAllOrders.$children[0].scrollTo(0, 0);
                                }
                            }, 10);
                        }
                        callback && callback();
                    }
                });
            },
            searchOrder(params) {
                this.isShowSelect = false;
                this.close = '';
                this.$store.commit(types.SET_HEADER_R_I, {rightText: ''});
                this.params = params;
                this.render(params);
            },
            goDetail(id) {
//                this.$router.push('all/' + id);
                C.Native.forward({
                    url: 'index.html#list/all/' + id
                });
            },
            del(item, e) {
                this.delOrderData = item;
                this.delEl = e.target;
                this.isShowDelOrder = true;
            },
            delConfirm(info) {
                $.ajax({
                    url: C.Api('CANCEL_ORDER'),
                    data: $.extend({
                        orderId: this.delOrderData.orderId
                    }, info),
                    success: (res)=> {
                        if (res.flag === C.Flag.SUCCESS) {
                            this.isShowDelOrder = false;
                            /**
                             * 更改该订单状态为取消状态
                             */
                            this.delOrderData.orderStatus = C.Constant['A1_9'];
                            /**
                             * 还原取消按钮
                             */
                            $(this.delEl).parents('.apply-module').find('.order-card').css({
                                paddingRight: '.2rem',
                                left: '0rem'
                            }).find('.card-main').css({
                                borderRadius: '5px'
                            });
                        }
                    }
                });
            }
        },
        components: {
            scrollList,
            orderCard,
            selectOrder,
            delOrder,
            noOrders
        }
    };
</script>

<style scoped lang="scss">
    .all-wrapper {
        top: 1.5rem !important;
        margin-bottom: 1.23rem;
    }
</style>
