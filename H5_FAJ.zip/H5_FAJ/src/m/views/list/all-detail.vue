<template>
    <div class="all-detail">
        <div class="bg"></div>
        <order-detail class="content"></order-detail>
    </div>
</template>

<script type='text/ecmascript-6'>
    import orderDetail from '@/components/all-orders/detail.vue';

    export default {
        name: 'all-detail',
        data() {
            return {
            };
        },
        created() {
            C.Native.setHeader({
                fixed: true,
                title: C.T.ORDER_DETAIL,
                leftCallback: ()=> {
                    let timer = null,
                        timer2 = null;
                    if (C.Utils.App.IS_QQ && C.Utils.App.IS_ANDROID) {
                        document.body.scrollTop = 0;
                        C.UI.loading();
                        clearTimeout(timer);
                        clearTimeout(timer2);
                        timer = setTimeout(()=> {
                            document.body.scrollTop = 0;
                            timer2 = setTimeout(()=> {
                                C.Native.back();
                            }, 300);
                        }, 400);
                    } else {
                        C.Native.back();
                    }
                }
            });
        },
        mounted() {
        },
        methods: {
        },
        components: {
            orderDetail
        }
    };
</script>

<style scoped lang="scss">
    .all-detail{
        .bg{
            position: fixed;
            width: 100%;
            height: 3rem;
            background: #f15b23;
        }
    }
</style>
