<template>
    <div class="pending-orders">
        <scroll-list v-if="!isShowDefault" class="pending-wrapper" :opt="opt" :isMoreData="isMoreData" ref="scrollViewWrapper">
            <order-card v-for="item in orderList" :key="item.orderId" :item="item" @goDetail="goDetail(item.orderId)"></order-card>
        </scroll-list>
        <no-orders v-else></no-orders>
    </div>
</template>

<script type='text/ecmascript-6'>
    import orderCard from '@/components/order-card.vue';
    import scrollList from '@/components/scroll_list';
    import noOrders from 'src/components/no-orders';
    import * as types from 'src/m/vuex/mutation-types';

    export default {
        name: 'pending-orders',
        data() {
            return {
                isShowDefault: false,
                orderList: [],
                // 关于iscroll
                maxHeight: null,
                isRefresh: true, // 判断下拉 还是上拉
                page: 1, // 页面数 接受scroller回传的page值
                isMoreData: false, // 监控上拉有无更多数据 并传递给scroller组件
                opt: {
                    isLoadMore: true,
                    isRefresh: true
                }
            };
        },
        created() {
            C.Native.setHeader({
                fixed: true,
                leftIcon: 'user',
                leftCallback: ()=> {
                    this.$store.commit(types.SET_SIDEBAR, {width: 0});
                },
                title: C.T.PENDING_ORDER,
                titleIcon: 'logo'
            });
        },
        mounted() {
            this.$nextTick(()=> {
                // 确定筛选DOM的top 高度
                let headerHeight = document.querySelector('.navbar').clientHeight,
                    navHeight = document.querySelector('.tab-nav').clientHeight;
                this.maxHeight = window.screen.height - headerHeight - navHeight;
                C.UI.loading();
                this.render();
            });
        },
        methods: {
            render(page, callback) {
                let _data = null;
                this.page = page || this.page;
                $.ajax({
                    url: C.Api('ORDER_LIST'),
                    data: {
                        pageNo: this.page,
                        searchType: '02'
                    },
                    success: (res)=> {
                        C.UI.stopLoading();
                        callback && callback();
                        if (res.flag === C.Flag.SUCCESS) {
                            _data = res.data.pendingOrderList || res.data.orderList;
                            // 数据
                            this.isMoreData = true;
                            if (!_data || !_data.length) {
                                if (parseInt(this.page) === 1) {
                                    // 没有数据
                                    this.isShowDefault = true;
                                }
                                this.isMoreData = false;
                                return;
                            }
                            this.isShowDefault = false;
                            // 下拉就加载最新 上拉就push更多数据
                            if (this.isRefresh) {
                                this.orderList = _data;
                            } else {
                                for (let i = 0; i < _data.length; i++) {
                                    this.orderList.push(_data[i]);
                                }
                            }
                            if (_data.length < 10 || res.data.totalPageNo === this.page) {
                                this.isMoreData = false;
                            }
                            setTimeout(()=> {
                                 this.$refs.scrollViewWrapper.$children[0].refresh();
                                 C.Utils.initScrollHeight('.scroll-main', '.scroll-view', this.maxHeight);
                            }, 0);
                        }
                    }
                });
            },
            goDetail(id) {
//                this.$router.push('pending/' + id);
                C.Native.forward({
                    url: 'index.html#list/pending/' + id
                });
            }
        },
        components: {
            scrollList,
            orderCard,
            noOrders
        }
    };
</script>

<style scoped lang="scss">
    .pending-wrapper {
        top: 1.5rem !important;
        margin-bottom: 1.23rem;
    }
</style>
