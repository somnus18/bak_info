<template>
    <div class="pending-detail">
        <div class="bg"></div>
        <div class="content">
            <detail-card class="order-detail" :item="orderData"></detail-card>
            <item-card :textName="'申请信息录入'" :value="Z1[orderData.applyStatus]" @goDetail="applyInfo" :isShowArrow='isShowApplyArrow'></item-card>
            <item-card :textName="'征信授权'" :value="Z2[orderData.creditStatus || Z2_0]" @goDetail="creditAuthor(orderData.orderNo)" v-if="isShowCredit" :isShowArrow="isShowCreditArrow"></item-card>
            <item-card :textName="'拍照上传'" @goDetail="playPhoto" v-if="isShowCredit" :value="Z2[orderData.takePhotoStatus || Z2_0]" :isGray="orderData.takePhotoStatus == Z2_0" :isShowArrow='isShowApplyArrowPhoto'></item-card>
        </div>
    </div>
</template>

<script type='text/ecmascript-6'>
    import detailCard from '@/components/order-detail-card.vue';
    import itemCard from 'src/m/components/pending/item-card.vue';

    export default {
        name: 'list-detail',
        data() {
            return {
                orderData: {
                    orderId: '',
                    loanVariety: '',
                    barcode: '',
                    orderNo: '',
                    interviewType: '',
                    clientName: '',
                    applyStatus: '',
                    creditStatus: '',
                    takePhotoStatus: '', // 拍照上传状态
                    isCreditable: '' // 是否可发起征信授权
                },
                isShowCreditArrow: true,
                isShowApplyArrow: true,
                Z1: C.Constant.Z1,
                Z1_01: C.Constant.Z1_01,
                Z1_02: C.Constant.Z1_02,
                Z1_03: C.Constant.Z1_03,
                Z2: C.Constant.Z2,
                Z2_0: C.Constant.Z2_0,
                C1_1: C.Constant['1_1'],
                C1_2: C.Constant['1_2']
            };
        },
        created() {
            C.Native.setHeader({
                fixed: true,
                title: C.T.ORDER_DETAIL
            });
        },
        mounted() {
            this.$nextTick(()=> {
                this.orderId = this.$route.params.id;
                this.render();
            });
        },
        computed: {
            /**
             * 当征信授权为“待处理”、“处理中”、“已完成”此页展示
             * @return {boolean}
             */
            isShowCredit() {
                if (this.orderData.interviewType === this.C1_2) {
                    return false;
                }
                return true;
            },
            isShowApplyArrowPhoto() {
                return this.orderData.takePhotoStatus !== this.Z1_03;
            }
        },
        methods: {
            render() {
                C.UI.loading();
                $.ajax({
                    url: C.Api('PENDING_ORDER_DETAIL'),
                    data: {
                        orderId: this.orderId
                    },
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            let data = res.data;
                            for (let key in data) {
                                this.orderData[key] = data[key];
                            }
                            this.orderData.applyStatus = data.applyStatus || C.Constant['Z1_01'];
                            if (this.Z1_03 === data.applyStatus) {
                                this.isShowApplyArrow = false;
                            }
                            if (this.Z1_03 === data.creditStatus) {
                                this.isShowCreditArrow = false;
                            }
                        }
                    }
                });
            },
            applyInfo() {
                // 跳转至申请信息录入页面
                C.Utils.data(C.DK.ORDER_ID, this.orderId);
                this.$router.push('../../apply');
            },
            creditAuthor(orderNo) {
                // 跳转至征信授权页面
                C.Utils.data(C.DK.CREDIT_INFO, {
                    orderId: this.orderId,
                    orderNo,
                    barcode: this.orderData.barcode,
                    isCreditable: this.orderData.isCreditable
                });// CREDIT_INFO
                if (this.orderData.creditStatus === this.Z1_01) {
                    // 待处理状态时,发起征信授权
                    this.$router.push('../../credit/launch');
                } else {
                    this.$router.push('../../credit');
                }
            },
            playPhoto() {
                if (this.orderData.creditStatus === this.Z1_03) {
                    this.$router.push({
                        name: 'photos',
                        params: {
                            orderId: this.orderId,
                            applyStatus: this.orderData.applyStatus === this.Z1_03 ? 'Y' : 'N'
                        }
                    });
                }
            }
        },
        components: {
            detailCard,
            itemCard
        }
    };
</script>

<style scoped lang="scss">
    .pending-detail{
        .bg{
            position: fixed;
            width: 100%;
            height: 3.1rem;
            background: #f15b23;
        }

        .content {
            position: absolute;
            width: 100%;
            padding: .65rem 4% .3rem;
            .order-detail{
                border-top-left-radius: .1rem;
                border-top-right-radius: .1rem;
                padding-top: .2rem;
            }

            .item-card {
                padding: .6rem 0 .5rem .3rem;
                &:last-child{
                     border-bottom-left-radius: .1rem;
                     border-bottom-right-radius: .1rem;
                 }
            }
        }
    }
</style>
