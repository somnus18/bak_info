<template>
	<div class="photo">
		<photo-page v-for='(item,index) in initImgsList'
        :item='item'
        :isPhotoMain='item.isPhotoMain'
        :orderId='orderId'
        :page='"pending"'
        :isShowAddBtn='item.imgList.length < maxLength && isShowAddBtn'
        :key="index"></photo-page>
        <div class="height2"></div>
        <div class="bt-bottom">
            <div class="btn" :class="[curTotalImgNum?'':'btn-disabled']" @click="clickEvent('01')">提交</div>
        </div>
	</div>
</template>

<script type='text/ecmascript-6'>
import photoPage from '@/components/photograph/index.vue';
export default {
	name: 'pending-photo',
	data() {
	    return {
            orderId: '',
            applyStatus: '',
            maxLength: 40,
            initImgsList: [{
                kbType: '',
                imgList: [{
                    imgId: '',
                    imgUrl: '',
                    bigImgUrl: ''
                }]
            }],
            isShowAddBtn: true
	    };
	},
	components: {
		photoPage
	},
    computed: {
        curTotalImgNum() { // true可以提交 false不可以提交
            let num = false;
            if (this.initImgsList) {
                for (let i = 0; i < this.initImgsList.length; i++) {
                    if (this.initImgsList[i].imgList && this.initImgsList[i].imgList.length > 0) {
                        num = true;
                        break;
                    }
                }
            }
            return num;
        }
    },
    created() {
        this.orderId = this.$route.params.orderId;
        this.applyStatus = this.$route.params.applyStatus;
        C.Native.setHeader({
            fixed: true,
            title: C.T.ORDER_PHOTO,
            rightText: '跳过',
            rightCallback: ()=> {
            	C.UI.warn({
                    title: '提示',
                    content: '若选择跳过拍照上传，需线下将申请材料交至房交所门店扫描，是否确认跳过？',
                    okText: '确定',
                    isShowClose: true,
                    ok: ()=> {
                        this.takePhotoAjax('02');
                    }
                });
            }
        });
        this.initData();
    },
    methods: {
        // 初始化写在页面外，不要写在组件
        initData() {
            $.ajax({
                url: C.Api('SHOW_MATERIALS'),
                data: {
                    orderId: this.orderId
                },
                success: (res)=> {
                    C.UI.stopLoading();
                    if (res.flag === C.Flag.SUCCESS) {
                        this.initImgsList = res.data;
                        this.initImgsList.forEach((item)=> {
                            item.title = C.Constant.KB_T[item.kbType];
                            // item.isPhotoMain = (item.kbType === C.Constant.KB_01 || item.imgList.length !== 0); // 图片上传DIV显示与隐藏
                            item.isPhotoMain = false;
                            item.imgList.forEach((it)=> {
                                it.imgUrl = C.Utils.httpAddImage(it.imgUrl); // 缩略图
                                it.bigImgUrl = C.Utils.httpAddImage(it.bigImgUrl || it.imgUrl); // 原图，以防材料补充接口无bigImgUrl原图出参
                            });
                        });
                    }
                }
            });
        },
        clickEvent(type) {
            if (!this.curTotalImgNum) return;
            C.UI.warn({
                title: '提示',
                content: '<div style="text-align:center">点击上传后不可修改,请确认上传</div>',
                okText: '确定',
                isShowClose: true,
                ok: ()=> {
                    this.takePhotoAjax(type);
                }
            });
        },
        takePhotoAjax(type) {
            $.ajax({
                url: C.Api('OPR_TAKE_PHOTO_UPLOAD'), // api临时写 振伟定义再修改
                data: {
                    orderId: this.orderId,
                    oprType: type
                },
                success: (res)=> {
                    C.UI.stopLoading();
                    if (res.flag === C.Flag.SUCCESS) {
                        if (this.applyStatus === 'Y') {
                            this.$router.go(-2);
                        } else {
                            this.$router.go(-1);
                        }
                    }
                }
            });
        }
    }
};
</script>

<style scoped lang="scss">
.height2{
    height: 2rem;
}
.bt-bottom {
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    margin:.2rem 0 0 0;
    padding:.3rem 0;
    width: 100%;
    line-height: .8rem;
    text-align: center;
    background:#fff;
    border-top: 1px solid #ddd;
    z-index: 10;
}
</style>
