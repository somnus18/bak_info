<template>
    <div>
        <upload-image-h5 :imgList="imgList" :isShowAddBtn="isShowAddBtn" :maxLength="maxLength" @uploadImage="uploadImg"></upload-image-h5>
        <!--如果需要调整高度直接在外部添加即可 例如:class="setHeight"-->
        <m-cell class="setHeight" v-model="msg" :textName="'输入框'" :type="'text'" :placeholder="'请输入'"></m-cell>
        <m-cell v-model="msg" :textName="'输入框长的'" :type="'text'" :placeholder="'请输入'"></m-cell>
        <m-cell v-model="msg" :textName="'输入框更长的'" :type="'text'" :placeholder="'请输入'"></m-cell>
        <m-cell class="setHeight" v-model="msg" :textName="'输入框超超超超级长的'" :type="'text'" :placeholder="'请输入'"></m-cell>
        <!--带图标的cell-->
        <m-cell v-model="msg" :textName="'选择框'" :type="'select'" :placeholder="'选择'">
            <m-circle slot="name-icon" :size="40" :per="60"></m-circle>
        </m-cell>
        <m-cell v-model="msg" :textName="'名称'" :disabled=true>
        </m-cell>
        </m-cell>
        <m-cell v-model="msg" :textName="'OCR'" :disabled=true>
        </m-cell>
        <m-tel v-model="tel"></m-tel>
        <m-upper v-model="money"></m-upper>
        <!--这里可以放icon-->
        <m-cell :textName="'姓名'" :disabled=true>
            <m-circle :size="60" :per="100"></m-circle>
            <m-circle :size="70" :per="20"></m-circle>
            <m-circle :size="80" :per="40"></m-circle>
        </m-cell>
        <ul class="buttons">
            <li>
                <m-button :text="'button1'" :canClick=false></m-button>
            </li>
            <li>
                <m-button :text="'button2'"></m-button>
            </li>
            <li>
                <m-button :text="'button3'"></m-button>
            </li>
            <li>
                <m-button :text="'button4'"></m-button>
            </li>
        </ul>
        <!--这里可以放icon-->
        <m-cell :textName="'ocr及图片上传'" :disabled=true class="upload">
            <upload-ocr @uploadOcrMaster="uploadOcrMaster" :mark="'Master'"></upload-ocr>
        </m-cell>
        <div class="bt-bottom">
            <m-button :text="'big-button'" @click-button="clickEvent"></m-button>
        </div>
    </div>
</template>
<style lang="scss" scoped>
    .buttons {
        margin: 5px;

    li {
        padding: 2px;
        display: inline-block;
        vertical-align: bottom;
        width: 24%;
        line-height: .8rem;

        text-align: center;
    }

    }
    .bt-bottom {
        margin: 10px 0;
        padding: 0 20px;
        position: fixed;
        bottom: 0;
        width: 100%;
        height: .8rem;
        line-height: .8rem;
        text-align: center;
    }

    .setHeight {
        height: 1.5rem;
    }
</style>
<script>
    import mCell from 'components/cell/cell';
    import mCircle from 'components/circle/circle';
    import mButton from 'components/button/button';
    import uploadOcr from 'components/upload/ocr';
    import uploadImage from 'components/upload/multiple-image';
    import uploadImageH5 from 'components/upload/multiple-image-h5';
    import dialogInput from 'components/dialog/index-input';
    import mTel from 'components/cell/tel';
    import mUpper from 'components/cell/upper';

    export default{
        data() {
            return {
                msg: '123',
                imgList: [{
                    src: 'https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1506411050&di=5231633905a929081a521a615a89341d&src=http://www.zhlzw.com/UploadFiles/Article_UploadFiles/201204/20120412123914329.jpg',
                    imgId: '123123'
                }, {
                    src: 'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1506421213672&di=92af7e48f2fd84321aa063cbce5637ac&imgtype=0&src=http%3A%2F%2Fwww.zhlzw.com%2FUploadFiles%2FArticle_UploadFiles%2F201204%2F20120412123926750.jpg',
                    imgId: '123123123'
                }],
                info: {
                    isShow: false
                },
                isShowAddBtn: true,
                maxLength: 5,
                tel: '',
                money: '121231'
            };
        },
        components: {
            mCell,
            mCircle,
            mButton,
            uploadOcr,
            uploadImage,
            dialogInput,
            mTel,
            mUpper,
            uploadImageH5
        },
        methods: {
            clickEvent() {
                console.log('clickEvent');
            },
            uploadOcrMaster(base64Img) {
                console.log('uploadOcrMaster', base64Img);
            },
            uploadImg() {
                $.ajax({
                    url: location.origin + '/order/uploadImgTest.do',
                    type: 'get',
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            this.imgList.push({
                                src: res.data.newImgUrl,
                                id: res.data.newImgId
                            });
                            if (this.imgList.length === this.maxLength) {
                                this.isShowAddBtn = false;
                            }
                        }
                    }
                });
            }
        }
    };
</script>
