<template>
    <section class="credit">
        <header>
            <div class="text-row clear">
                <span class="fl">订单号</span>
                <span class="fr">{{orderNo}}</span>
            </div>
            <div class="text-row clear">
                <span class="fl">KB码</span>
                <span class="fr">{{barcode}}</span>
            </div>
        </header>
        <ul>
            <li class="credit-list">
                <div class="con-left">
                    <p>主借款人</p>
                    <p>手机号码</p>
                </div>
                <div class="con-middle">
                    <p>{{custInfo.clientName}}</p>
                    <p>{{custInfo.clientMobile}}</p>
                </div>
                <div class="con-right">
                    <p v-if="creditLoading" class="credit—loading"></p>
                    <p v-if="!creditLoading" :class="[Z3_1[custInfo.clientStatus] ? 'blue' : 'yellow' ]">{{Z3[custInfo.clientStatus]}}</p>
                    <p v-if="!creditLoading" :style="{visibility: Z3_0[custInfo.clientStatus]?'visible':'hidden'}"><span class="btn btn-blue" :class="[custInfo.sendText == sendText?'':'btn-blue-disabled']" @click="Z3_0[custInfo.clientStatus] && send(custInfo, 'client')">{{custInfo.sendText}}</span></p>
                </div>
            </li>
            <li class="credit-list" v-if="custSpouseInfo" v-show="custSpouseInfo.spouseGlobalId">
                <div class="con-left">
                    <p>主借款人配偶</p>
                    <p>手机号码</p>
                </div>
                <div class="con-middle">
                    <p>{{custSpouseInfo.spouseName}}</p>
                    <p>{{custSpouseInfo.spouseMobile}}</p>
                </div>
                <div class="con-right">
                    <p v-if="creditLoading" class="credit—loading"></p>
                    <p v-if="!creditLoading" :class="[Z3_1[custSpouseInfo.spouseStatus] ? 'blue' : 'yellow' ]">{{Z3[custSpouseInfo.spouseStatus]}}</p>
                    <p v-if="!creditLoading" :style="{visibility: Z3_0[custSpouseInfo.spouseStatus]?'visible':'hidden'}"><span class="btn btn-blue" :class="[custSpouseInfo.sendText == sendText?'':'btn-blue-disabled']" @click="Z3_0[custSpouseInfo.spouseStatus] && send(custSpouseInfo, 'spouse')">{{custSpouseInfo.sendText}}</span></p>
                </div>
            </li>
            <li class="credit-list" v-for="(item,index) in custPartnerInfo" v-if="item.partnerName">
                <div class="con-left">
                    <p>共同借款人{{index + 1}}</p>
                    <p>手机号码</p>
                </div>
                <div class="con-middle">
                    <p>{{item.partnerName}}</p>
                    <p>{{item.partnerMobile}}</p>
                </div>
                <div class="con-right">
                    <p v-if="creditLoading" class="credit—loading"></p>
                    <p v-if="!creditLoading" :class="[Z3_1[item.partnerStatus] ? 'blue' : 'yellow' ]">{{Z3[item.partnerStatus]}}</p>
                    <p v-if="!creditLoading" :style="{visibility: Z3_0[item.partnerStatus]?'visible':'hidden'}"><span class="btn btn-blue" :class="[item.sendText == sendText?'':'btn-blue-disabled']" @click="Z3_0[item.partnerStatus] && send(item, 'partner', index)">{{item.sendText}}</span></p>
                </div>
            </li>
            <li class="credit-list" v-for="(item,index) in guarantorInfo" v-if="item.guarantorName">
                <div class="con-left">
                    <p>个人保证人{{index + 1}}</p>
                    <p>手机号码</p>
                </div>
                <div class="con-middle">
                    <p>{{item.guarantorName}}</p>
                    <p>{{item.guarantorMobile}}</p>
                </div>
                <div class="con-right">
                    <p v-if="creditLoading" class="credit—loading"></p>
                    <p v-if="!creditLoading" :class="[Z3_1[item.guarantorStatus] ? 'blue' : 'yellow' ]">{{Z3[item.guarantorStatus]}}</p>
                    <p v-if="!creditLoading" :style="{visibility: Z3_0[item.guarantorStatus]?'visible':'hidden'}"><span class="btn btn-blue" :class="[item.sendText == sendText?'':'btn-blue-disabled']" @click="Z3_0[item.guarantorStatus] && send(item, 'guarantor', index)">{{item.sendText}}</span></p>
                </div>
            </li>
        </ul>
        <footer v-if="creditStatus !== '000'">
            <span class="offline" @click="offline">转线下征信授权</span>
            <p class="tip"><span></span>若线上征信授权失败，请转线下征信授权处理</p>
        </footer>
    </section>
</template>
<script type="text/ecmascript-6">
    export default {
        name: 'credit',
        data() {
            return {
                orderId: '',
                barcode: '',
                orderNo: '',
                creditLoading: true,
                Z3: C.Constant['Z3'],
                Z3_0: C.Constant['Z3_0'],
                // 查询成功
                Z3_1: C.Constant['Z3_1'],
                custPartnerInfo: [
                    {
                        partnerStatus: '',
                        partnerMobile: '',
                        partnerName: '',
                        sendText: ''
                    },
                    {
                        sendText: ''
                    },
                    {
                        sendText: ''
                    },
                    {
                        sendText: ''
                    },
                    {
                        sendText: ''
                    }
                ],
                guarantorInfo: [
                    {
                        guarantorStatus: '',
                        guarantorMobile: '',
                        guarantorName: '',
                        sendText: ''
                    },
                    {
                        sendText: ''
                    },
                    {
                        sendText: ''
                    },
                    {
                        sendText: ''
                    },
                    {
                        sendText: ''
                    }
                ],
                custSpouseInfo: {
                    spouseStatus: '',
                    spouseMobile: '',
                    spouseName: '',
                    sendText: ''
                },
                custInfo: {
                    clientStatus: '',
                    clientMobile: '',
                    clientName: '',
                    sendText: ''
                },
                // 000: 全部查询成功, 111: 未成功
                creditStatus: '111',
                sendText: '重发短信',
                timers: []
            };
        },
        created() {
            C.Native.setHeader({
                title: C.T.CREDIT,
                leftCallback: ()=> {
                    this.back();
                },
                rightText: '更新征信',
                rightCallback: ()=> {
                    this.render();
                }
            });
        },
        mounted() {
            this.$nextTick(()=> {
                let creditInfo = C.Utils.data(C.DK.CREDIT_INFO);
                this.orderId = creditInfo.orderId;
                this.barcode = creditInfo.barcode;
                this.orderNo = creditInfo.orderNo;
                this.render();
            });
        },
        computed: {},
        methods: {
            render() {
                let custKey,
                    spouseKey,
                    partnerKey,
                    guarantorKey;
                this.creditLoading = true;
                C.UI.loading();
                $.ajax({
                    url: C.Api('CREDIT_RESULT'),
                    data: {
                        orderId: this.orderId,
                        barCode: this.barcode
                    },
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            this.timers.forEach((timer)=> {
                                clearInterval(timer);
                            });
                            this.creditStatus = res.data.creditStatus || '';
                            for (custKey in res.data.custInfo) {
                                this.custInfo[custKey] = res.data.custInfo[custKey];
                            }
                            this.custInfo.sendText = this.sendText;
                            // 配偶为res.data.custSpouseInfo
                            for (spouseKey in res.data.custSpouseInfo) {
                                this.custSpouseInfo[spouseKey] = res.data.custSpouseInfo[spouseKey];
                            }
                            res.data.custSpouseInfo ? (this.custSpouseInfo.sendText = this.sendText) : (this.custSpouseInfo = null);

                            // 共同借款人
                            res.data.custPartnerInfo && res.data.custPartnerInfo.forEach((item, index)=> {
                                for (partnerKey in item) {
                                    this.custPartnerInfo[index][partnerKey] = item[partnerKey];
                                }
                                this.custPartnerInfo[index].sendText = this.sendText;
                            });

                            // 个人保证人
                            res.data.guarantorInfo && res.data.guarantorInfo.forEach((item, index)=> {
                                for (guarantorKey in item) {
                                    this.guarantorInfo[index][guarantorKey] = item[guarantorKey];
                                }
                                this.guarantorInfo[index].sendText = this.sendText;
                            });
                            this.creditLoading = false;
                        }
                    }
                });
            },
            send(data, type, index) {
                if (data.sendText !== this.sendText) return;
                let params = {
                    orderId: this.orderId,
                    globalId: data[type + 'GlobalId']
                };
                C.UI.loading();
                $.ajax({
                    url: C.Api('CREDIT_RESEND'),
                    data: params,
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            C.Native.tip('发送短信成功');
                            this.sendTimeDown(data, type, index);
                        }
                    }
                });
            },
            sendTimeDown(options) {
                let tipSpeedTime = 120,
                    _time = tipSpeedTime;

                clearInterval(options.timeTimer);
                this.remove(options.timeTimer);
                options.sendText = _time + 's';
                options.timeTimer = setInterval(()=> {
                    if (_time <= 0) {
                        options.sendText = this.sendText;
                        clearInterval(options.timeTimer);
                        this.remove(options.timeTimer);
                    } else {
                        _time--;
                        options.sendText = _time + 's';
                    }
                }, 1000);
                this.timers.push(options.timeTimer);
            },
            /**
             * 删除定时器
             * @param timer
             */
            remove: function (timer) {
                let index = this.timers.indexOf(timer);
                if (index !== -1) {
                    this.timers.splice(index, 1);
                }
            },
            offline() {
                C.UI.warn({
                    title: '提示',
                    content: '若转线下征信授权，则必须待客户经理线下征信授权后方可提交审批。是否仍选择线下征信授权？',
                    okText: '确定',
                    ok: ()=> {
                        C.UI.loading();
                        $.ajax({
                            url: C.Api('TURN_TO_OFFLINE'),
                            data: {
                                orderId: this.orderId
                            },
                            success: (res)=> {
                                C.UI.stopLoading();
                                if (res.flag === C.Flag.SUCCESS) {
                                    C.UI.warn({
                                        title: '提示',
                                        content: '该订单签转为线下征信授权，请联系渠道专员' + res.data.referralName + '（' + res.data.referralMobile + '）',
                                        okText: '确定',
                                        ok: ()=> {
                                            this.back();
                                        }
                                    });
                                }
                            }
                        });
                    }
                });
            },
            back() {
                if (C.Utils.getParameter('type') === 'launch') {
                    this.$router.go(-2);
                } else {
                    C.Native.back();
                }
            }
        },
        destroyed() {
            // 清除定时器
            this.timers.forEach((timer)=> {
                clearInterval(timer);
            });
        }
    };
</script>
<style scoped lang="scss">
.credit{
    margin-top: .1rem;
    header {
        padding: .2rem .3rem;
        background: #fff;
        .text-row {
            padding: .1rem 0;
            clear: both;
        }

        .text-row * {
            line-height: .5rem;
        }
    }
    ul li.credit-list{
        margin-top: .1rem;
        padding: .2rem .3rem;
        background: #fff;
        width: 100%;
        font-size: 0;
        div {
            font-size: .32rem;
            display: inline-block;
            &.con-left{
                width: 40%;
             }
            &.con-middle{
                width: 35%;
             }
            &.con-right{
                position: relative;
                width: 25%;
                p{
                    text-align: right;
                    &.credit—loading{
                         position: absolute;
                         top: -1.1rem;
                         right: .45rem;
                         width: .5rem;
                         height: .5rem;
                         background: url(../../../assets/images/m/icons/credit_loading@2x.png) no-repeat;
                         background-size: 100%;
                         -webkit-animation: loading 1s linear infinite;
                         -moz-animation: loading 1s linear infinite;
                         animation: loading 1s linear infinite;
                     }
                }
             }
            p {
                width: 100%;
                text-overflow: ellipsis;
                overflow: hidden;
                white-space: nowrap;
                height: .8rem;
                line-height: .8rem;
                .btn{
                    display: inline-block;
                    width: 80%;
                    height: .6rem;
                    line-height: .6rem;
                    font-size: .28rem;
                    border-radius: .08rem;
                }
                &.blue{
                     color: #2086e5;
                 }
                &.yellow{
                     color: #ffaf2f;
                 }
            }
        }
    }
    footer{
        margin-top: .5rem;
        text-align: center;
        .offline{
            display: inline-block;
            color: #26a2ff;
            font-size: .32rem;
            border-bottom: 1px solid #26a2ff;
            margin-bottom: .3rem;
        }
        .tip{
            color: #aaa;
            font-size: .25rem;
            padding-bottom: 1rem;
            span{
                display: inline-block;
                width: .2rem;
                height: .2rem;
                background: url(../../../assets/images/m/icons/icon_-@2x.png);
                background-size: 100%;
                margin-right: .1rem;
            }
        }
    }
    @keyframes credit—loading {
        0% { -webkit-transform: rotateZ(0deg); }
        100% { -webkit-transform: rotateZ(360deg); }
    }
    @-webkit-keyframes credit—loading {
        0% { -webkit-transform: rotateZ(0deg); }
        100% { -webkit-transform: rotateZ(360deg); }
    }
}
</style>
