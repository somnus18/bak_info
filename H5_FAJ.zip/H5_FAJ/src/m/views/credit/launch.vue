<template>
    <section class="credit">
        <header>
            <div class="text-row clear">
                <span class="fl">订单号</span>
                <span class="fr">{{orderNo}}</span>
            </div>
            <div class="text-row clear">
                <span class="fl">KB码</span>
                <span class="fr">{{barcode}}</span>
            </div>
        </header>
        <footer class=footer-bottom>
            <div class=btn @click=launchCredit :class="{'btn-disabled': !isCreditable}">发起征信授权</div>
        </footer>
    </section>
</template>
<script type="text/ecmascript-6">
    export default {
        name: 'credit',
        data() {
            return {
                orderId: '',
                barcode: '',
                orderNo: '',
                isCreditable: 0
            };
        },
        created() {
            C.Native.setHeader({
                title: C.T.CREDIT
            });
        },
        mounted() {
            this.$nextTick(()=> {
                let creditInfo = C.Utils.data(C.DK.CREDIT_INFO);
                this.orderId = creditInfo.orderId;
                this.barcode = creditInfo.barcode;
                this.orderNo = creditInfo.orderNo;
                this.isCreditable = ~~creditInfo.isCreditable; // 0: 否, 1: 是
                C.UI.stopLoading();
            });
        },
        computed: {},
        methods: {
            launchCredit() {
                if (!this.isCreditable) return;
                C.UI.loading();
                $.ajax({
                    url: C.Api('SEND_CREDIT_APPLY'),
                    data: {
                        orderId: this.orderId
                    },
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            this.$router.push('../credit?type=launch');
                        }
                    }
                });
            }
        }
    };
</script>
<style scoped lang="scss">
.credit{
    margin-top: .1rem;
    header {
        padding: .2rem .3rem;
        background: #fff;
        .text-row {
            padding: .1rem 0;
            clear: both;
        }

        .text-row * {
            line-height: .5rem;
        }
    }
    .footer-bottom{
        margin-top: 1.2rem;
        text-align: center;
        .btn {
            width: 80%;
            margin: 0 auto;
        }
    }
}
</style>
