<template>
    <div class="identity">
        <section>
            <div class="title">
                <span>主借款人身份验证</span>
            </div>
            <!--如果需要调整高度直接在外部添加即可 例如:class="setHeight"-->
            <m-cell v-model="dict.A34[info.custInfo.globalType]" :textName="'证件类型'" :type="'select'"
                    @select-input="pickerEvent({custInfo:'globalType'},'证件类型','34')">
            </m-cell>
            <m-cell v-model="dict['A2'][info.custInfo.country]" :textName="'国家和地区'" :type="'select'"
                    :disabled="dict['A2_A'].indexOf(info.custInfo.globalType)!=-1 || info.custInfo.globalType == 'Ind07' || dict['A2_D'].indexOf(info.custInfo.globalType)!=-1"
                    @select-input="pickerEvent({custInfo:'country'},'国家和地区',countryListSelect(info.custInfo.globalType))">
            </m-cell>
            <div class="client">
                <m-cell v-model="info.custInfo.clientName" :maxlength="42"
                        :class='{ocrInput: info.custInfo.globalType == "Ind01"}'
                        :textName="'姓名'" :type='"text"' :placeholder="'请输入'"
                        :nodel="info.custInfo.globalType == 'Ind01'">
                </m-cell>
                <upload-ocr
                    v-show='info.custInfo.globalType == "Ind01"' class='ocr'
                    @uploadOcr="uploadOcr" :objName="'custInfo'"></upload-ocr>
            </div>
            <m-cell v-model="info.custInfo.globalId" :textName="'证件号码'" @input="checkGlobalId(info.custInfo)"></m-cell>
            <m-cell v-model="dict['A9'][info.custInfo.sex]" :textName="'性别'" :type="'select'"
                    @select-input="pickerEvent({custInfo:'sex'},'性别','A9')">
            </m-cell>
            <m-cell v-model="info.custInfo.birthDate" :textName="'出生日期'" :type="'select'"
                    @select-input="dateTimeSeleted({custInfo:'birthDate'})">
            </m-cell>
            <m-cell v-model="dict['A10'][info.custInfo.secuFinDirExpiryDate]"
                    :textName="'证件到期日-长期有效'" :type="'select'"
                    @select-input="pickerEvent({custInfo:'secuFinDirExpiryDate'},'证件到期日-长期有效','A10')">
            </m-cell>
            <m-cell v-if="showFinDirExpiryDate" v-model="info.custInfo.finDirExpiryDate" :textName="'证件到期日'"
                    :type="'select'" @select-input="dateTimeSeleted({custInfo:'finDirExpiryDate'})">
            </m-cell>
            <m-cell v-model="info.custInfo.certificateOrg" :textName="'发证机关所在地'"></m-cell>
            <m-cell v-model="dict['A10'][info.custInfo.isWarrantFlag]" :textName="'是否为权利人'" :type="'select'"
                    @select-input="pickerEvent({custInfo:'isWarrantFlag'},'是否权利人','A10')">
            </m-cell>
            <m-cell v-model="dict['A5'][info.custInfo.maritalStatus]" :textName="'主借款人婚姻状况'" :type="'select'"
                    @select-input="pickerEvent({custInfo:'maritalStatus'},'主借款人婚姻状况','5')">
            </m-cell>
            <div class="lilv">
                <m-cell class='setHeight' v-model="info.custInfo.mobile" :textName="'手机号码'" :type="'tel'"
                        :placeholder="'请填写'" :maxlength="'11'"></m-cell>
                <span class="tip"><font class="red-color"></font> 请填写本人实名认证的手机号，以便在线征信授权</span>
            </div>
        </section>
        <section v-if="showSpouseInfo">
            <div class="title">
                <span>主借款人配偶身份验证</span>
            </div>
            <m-cell v-model="dict['A10'][info.spouseInfo.isWarrantFlag]" :textName="'是否为权利人'" :type="'select'"
                    @select-input="pickerEvent({spouseInfo:'isWarrantFlag'},'是否权利人','A10')">
            </m-cell>
            <m-cell v-model="dict['A34'][info.spouseInfo.globalType]" :textName="'证件类型'" :type="'select'"
                    @select-input="pickerEvent({spouseInfo:'globalType'},'证件类型','34')">
            </m-cell>
            <m-cell v-model="dict['A2'][info.spouseInfo.country]" :textName="'国家和地区'" :type="'select'"
                    :disabled="dict['A2_A'].indexOf(info.spouseInfo.globalType)!=-1 || info.spouseInfo.globalType == 'Ind07' || dict['A2_D'].indexOf(info.spouseInfo.globalType)!=-1"
                    @select-input="pickerEvent({spouseInfo:'country'},'国家和地区',countryListSelect(info.spouseInfo.globalType))">
            </m-cell>
            <div class="client">
                <m-cell v-model="info.spouseInfo.clientName" :maxlength="42"
                        :class='{ocrInput: info.spouseInfo.globalType == "Ind01"}'
                        :textName="'姓名'" :type='"text"' :placeholder="'请输入'"
                        :nodel="info.spouseInfo.globalType == 'Ind01'">
                </m-cell>
                <upload-ocr
                    v-show='info.spouseInfo.globalType == "Ind01"' class='ocr'
                    @uploadOcr="uploadOcr" :objName="'spouseInfo'"></upload-ocr>
            </div>
            <m-cell v-model="info.spouseInfo.globalId" :textName="'证件号码'" :type="'text'" :placeholder="'请输入'"
                    :maxlength="32" @input="checkGlobalId(info.spouseInfo)">
            </m-cell>

            <m-cell v-model="dict['A9'][info.spouseInfo.sex]" :textName="'性别'" :type="'select'"
                    @select-input="pickerEvent({spouseInfo:'sex'},'性别','A9')">
            </m-cell>
            <m-cell v-model="info.spouseInfo.birthDate" :textName="'出生日期'" :type="'select'"
                    @select-input="dateTimeSeleted({spouseInfo:'birthDate'})">
            </m-cell>
            <div class="lilv">
                <m-cell class='setHeight' v-model="info.spouseInfo.mobile" :textName="'手机号码'" :type="'tel'"
                        :placeholder="'请填写'" :maxlength="'11'"></m-cell>
                <span class="tip"><font class="red-color"></font> 请填写本人实名认证的手机号，以便在线征信授权</span>
            </div>
        </section>
        <section v-for="(item,index) in info.partnerList">
            <div class="title">
                <span>共同借款人 {{index + 1}}</span>
                <span class="remove"
                      v-if='!(item.mainBorrowerRelation == "0301" && (houseCityCode == "510100" || isSpouseWarrantFlag))'
                      @click='removeItem(index,"partnerList")'></span>
            </div>
            <m-cell v-model="dict['A15'][item.mainBorrowerRelation]" :textName="'与主借款人关系'" :type="'select'"
                    :disabled="item.mainBorrowerRelation == '0301'"
                    @select-input="pickerEvent({partnerList:'mainBorrowerRelation'},'与主借款人关系',mainBorrowerRelationSelect,index)">
            </m-cell>
            <m-cell v-model="item.mainBorrowerRelationOther" :textName="'与主借款人关系其他'" :placeholder="'请输入'"
                    :maxlength="10"
                    v-if="item.mainBorrowerRelation == '0310'">
            </m-cell>
            <m-cell v-model="dict['A34'][item.globalType]" :textName="'证件类型'" :type="'select'"
                    :disabled="item.mainBorrowerRelation == '0301'"
                    @select-input="pickerEvent({partnerList:'globalType'},'证件类型','34',index)">
            </m-cell>
            <m-cell v-model="dict['A2'][item.country]" :textName="'国家和地区'" :type="'select'"
                    :disabled="item.mainBorrowerRelation == '0301' || dict['A2_A'].indexOf(item.globalType)!=-1 || item.globalType == 'Ind07' || dict['A2_D'].indexOf(item.globalType)!=-1"
                    @select-input="pickerEvent({partnerList:'country'},'国家和地区',countryListSelect(item.globalType),index)">
            </m-cell>
            <div class="client">
                <m-cell v-model="item.clientName"
                        :class='{ocrInput: item.globalType == "Ind01" && item.mainBorrowerRelation != "0301"}'
                        :textName="'姓名'" :type='"text"' :placeholder="'请输入'" :nodel="item.globalType == 'Ind01'"
                        :maxlength="42" :disabled="item.mainBorrowerRelation == '0301'">
                </m-cell>
                <upload-ocr
                    v-show='item.globalType == "Ind01" && item.mainBorrowerRelation != "0301"' class='ocr'
                    @uploadOcr="uploadOcr" :objName="'partnerList'" :index="index"></upload-ocr>
            </div>
            <m-cell v-model="item.globalId" @input="checkGlobalId(item)" :textName="'证件号码'" :type="'text'"
                    :placeholder="'请输入'"
                    :disabled="item.mainBorrowerRelation == '0301'" :maxlength="32">
            </m-cell>
            <m-cell v-model="dict['A9'][item.sex]" :textName="'性别'" :type="'select'"
                    :disabled="item.mainBorrowerRelation == '0301'"
                    @select-input="pickerEvent({partnerList:'sex'},'性别','A9',index)">
            </m-cell>
            <m-cell v-model="item.birthDate" :textName="'出生日期'" :type="'select'"
                    :disabled="item.mainBorrowerRelation == '0301'"
                    @select-input="dateTimeSeleted({partnerList:'birthDate'},index)">
            </m-cell>
            <div class="lilv">
                <m-cell class='setHeight' v-model="item.mobile" :textName="'手机号码'" :type="'tel'" :placeholder="'请填写'"
                        :maxlength="'11'" :disabled="item.mainBorrowerRelation == '0301'"></m-cell>
                <span class="tip"><font class="red-color"></font> 请填写本人实名认证的手机号，以便在线征信授权</span>
            </div>
        </section>
        <div :class="[info.partnerList.length>0?'':'mt-20','cell-btn']" @click="addPartner(info.partnerList)"
             v-if="info.partnerList.length<5">
            <span><i></i> 添加共同借款人</span>
        </div>

        <section v-for="(item,index) in info.guarantorList">
            <div class="title">
                <span>个人保证人 {{index + 1}}</span>
                <span class="remove" v-if='index >= 0'
                      @click='removeItem(index,"guarantorList")'></span>
            </div>
            <m-cell v-model="dict['A15'][item.mainBorrowerRelation]" :textName="'与主借款人关系'" :type="'select'"
                    :disabled="item.mainBorrowerRelation == '0301'" :maxlength="10"
                    @select-input="pickerEvent({guarantorList:'mainBorrowerRelation'},'与主借款人关系',mainBorrowerRelationSelect,index)">
            </m-cell>
            <m-cell v-model="item.mainBorrowerRelationOther" :textName="'与主借款人关系其他'" :placeholder="'请输入'"
                    :maxlength="10"
                    v-if="item.mainBorrowerRelation == '0310'">
            </m-cell>
            <m-cell v-model="dict['A34'][item.globalType]" :textName="'证件类型'" :type="'select'"
                    :disabled="item.mainBorrowerRelation == '0301'"
                    @select-input="pickerEvent({guarantorList:'globalType'},'证件类型','34',index)">
            </m-cell>
            <m-cell v-model="dict['A2'][item.country]" :textName="'国家和地区'" :type="'select'"
                    :disabled="item.mainBorrowerRelation == '0301' || dict['A2_A'].indexOf(item.globalType)!=-1 || item.globalType == 'Ind07' || dict['A2_D'].indexOf(item.globalType)!=-1"
                    @select-input="pickerEvent({guarantorList:'country'},'国家和地区',countryListSelect(item.globalType),index)">
            </m-cell>

            <div class="client">
                <m-cell v-model="item.clientName"
                        :class='{ocrInput:item.globalType == "Ind01" && item.mainBorrowerRelation != "0301"}'
                        :textName="'姓名'" :maxlength="42" :placeholder="'请输入'" :nodel="item.globalType == 'Ind01'"
                        :type='"text"' :disabled="item.mainBorrowerRelation == '0301'">
                </m-cell>
                <upload-ocr v-show='item.globalType == "Ind01" && item.mainBorrowerRelation != "0301"' class='ocr'
                            @uploadOcr="uploadOcr"
                            :objName="'guarantorList'" :index="index"></upload-ocr>
            </div>
            <m-cell v-model="item.globalId" :textName="'证件号码'" :type="'text'" :placeholder="'请输入'"
                    :disabled="item.mainBorrowerRelation == '0301'" :maxlength="32"
                    @input="checkGlobalId(item)">
            </m-cell>
            <m-cell v-model="dict['A9'][item.sex]" :textName="'性别'" :type="'select'"
                    :disabled="item.mainBorrowerRelation == '0301'"
                    @select-input="pickerEvent({guarantorList:'sex'},'性别','A9',index)">
            </m-cell>
            <m-cell v-model="item.birthDate" :textName="'出生日期'" :type="'select'"
                    :disabled="item.mainBorrowerRelation == '0301'"
                    @select-input="dateTimeSeleted({guarantorList:'birthDate'},index)">
            </m-cell>
            <div class="lilv">
                <m-cell class='setHeight' v-model="item.mobile" :textName="'手机号码'" :type="'tel'" :placeholder="'请填写'"
                        :maxlength="'11'" :disabled="item.mainBorrowerRelation == '0301'"></m-cell>
                <span class="tip"><font class="red-color"></font> 请填写本人实名认证的手机号，以便在线征信授权</span>
            </div>
        </section>
        <div :class="[info.guarantorList.length>0?'':'mt-20','cell-btn']" @click="addGuarantor"
             v-if="info.guarantorList.length < 5">
            <span><i></i> 添加个人保证人</span>
        </div>
        <!--<div class="submit">-->
        <!--<m-button :text="'保存'" @click-button="saveOrder"></m-button>-->
        <!--</div>-->
        <m-picker :slots='slots' :isPicker='isPicker' :indexText='indexText'
                  :datakey='datakey' @confirm='pickerConfirm' @cancel='pickerCancel'>
        </m-picker>
        <m-date-picker :isPicker='isDatePicker' :datakey="dateDataKey" :defaultDate='defaultDate'
                       @confirm='datePickerConfirm' @cancel="datePickerCancel">
        </m-date-picker>
        <m-area-picker :isPicker='isAreaPicker' isZone :datakey='areaDataKey'
                       @confirm='areaPickerConfirm' @cancel="areaPickerCancel">
        </m-area-picker>
    </div>
</template>
<style lang="scss" scoped rel="stylesheet/scss">
    .identity {
        .mt-20 {
            margin-top: .2rem;
        }
        .setHeight {
            padding-bottom: .3rem;
        }
        .client {
            position: relative;
            .ocrInput {
                padding-right: .4rem;
            }
            .ocr {
                position: absolute;
                top: .22rem;
                right: .3rem;
            }
        }
        .ocrInput {
            padding-right: .1rem;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-flex: 1;
            -ms-flex: 1;
            flex: 1;
            font-size: 0.3rem;
            line-height: .4rem;
        }
        .submit {
            background: white;
            box-sizing: content-box;
            margin-top: .2rem;
            padding: .4rem 0rem;
            height: .8rem;
            line-height: .8rem;
            text-align: center;
        }
        .cell-btn {
            color: #1f85e6;
            line-height: .68rem;
            text-align: center;
            background: #fafafa;
            i {
                position: relative;
                top: .08rem;
                display: inline-block;
                width: .4rem;
                height: .4rem;
                background: url(./../../../assets/images/m/icons/add.png) no-repeat center;
                background-size: .36rem .36rem;
            }
        }
        .title {
            position: relative;
            .remove {
                position: absolute;
                top: 0.1rem;
                right: .3rem;
                display: inline-block;
                width: .4rem;
                height: .4rem;
                background: url(./../../../assets/images/m/icons/remove.png) no-repeat center;
                background-size: .4rem .4rem;
            }
            span {
                padding: .1rem .3rem .1rem .3rem;
                color: #999;
                display: inline-block;
            }
        }
        .lilv {
            position: relative;
            .tip {
                position: absolute;
                left: .3rem;
                bottom: .13rem;
                font-size: .24rem;
                color: #999;
            }
            .tip-1 {
                bottom: .3rem;
            }
            .tip-2 {
                bottom: .1rem;
            }
            .red-color {
                position: relative;
                top: -1px;
                background: url('./../../../assets/images/m/icons/icon_-@2x.png') no-repeat;
                display: inline-block;
                width: 7px;
                height: 7px;
                background-size: 7px 7px;
            }
        }
    }
</style>

<script>
    import mCell from 'components/cell/cell';
    import mCircle from 'components/circle/circle';
    import mButton from 'components/button/button';
    import mPicker from 'components/picker/index';
    import mDatePicker from 'components/picker/date-picker.vue';
    import mAreaPicker from 'components/picker/area-picker.vue';
    import uploadOcr from 'components/upload/ocr';
    export default{
        components: {
            mCell, mCircle, mButton, mPicker, mDatePicker, mAreaPicker, uploadOcr
        },
        data() {
            return {
                dict: {
                    // 证件类型
                    A34: C.Constant['34'],
                    // 性别
                    A9: C.Constant['A9'],
                    // 国家和地区
                    A2: C.Constant['2'],
                    // 与主借款人关系
                    A15: C.Constant['15'],
                    // 与主借款人关系去掉配偶
                    A15_1: C.Constant['15_1'],
                    // 证件到期日-长期有效
                    A8: C.Constant['A8'],
                    // 婚姻状况
                    A5: C.Constant['5'],
                    // 权利人
                    A10: C.Constant['A10'],
                    // 证件类型国外
                    A2_D: C.Constant['2_D'],
                    // 身份证/户口本/中国护照/警官证/军官证/士兵证
                    A2_A: C.Constant['2_A']
                },
                tempIndex: '',
                dateDataKey: '',
                defaultDate: '',
                isPicker: false, // 普通选择器显示或隐藏
                indexText: '筛选条件', // 选择器名称
                datakey: '', // 选择器结果赋值到对象的key值
                areaDataKey: '',
                slots: [], // slot 对象数组
                isDatePicker: false, // 时间选择器显示或隐藏
                isAreaPicker: false,
                isSpouse: false,
                houseCityCode: '',
                hasSpouse: false,
                spouseObj: {},
                info: {
                    custInfo: {
                        country: '',
                        globalType: '',
                        globalId: '',
                        clientName: '',
                        sex: '',
                        birthDate: '',
                        secuFinDirExpiryDate: '',
                        finDirExpiryDate: '',
                        certificateOrg: '',
                        maritalStatus: '',
                        isWarrantFlag: '1',
                        mobile: ''
                    },
                    spouseInfo: {
                        country: '',
                        globalType: 'Ind01',
                        globalId: '',
                        clientName: '',
                        sex: '',
                        birthDate: '',
                        isWarrantFlag: '1',
                        mobile: ''
                    },
                    partnerList: [{
                        mainBorrowerRelation: '0301',
                        mainBorrowerRelationOther: null,
                        country: '',
                        globalType: '',
                        globalId: '',
                        clientName: '',
                        sex: '',
                        birthDate: '',
                        mobile: ''
                    }],
                    guarantorList: []
                }
            };
        },
        created() {
            this.slots = [{values: []}];
            C.Native.setHeader({
                fixed: true,
                title: C.T.ALL_PEOPLE_BASIC_INFO,
                rightText: '保存',
                titleCallback: ()=> {
                    C.UI.loading();
                    $.ajax({
                        url: C.Api('GET_IDENTITY_CHECK_INFO', 'json'),
                        type: 'get',
                        success: (res)=> {
                            C.UI.stopLoading();
                            if (res.flag === C.Flag.SUCCESS) {
                                for (let key in this.info) {
                                    if (!this.info[key]) {
                                        this.info[key] = res.data[key];
                                    }
                                }
                            }
                        }
                    });
                },
                rightCallback: ()=> {
                    this.saveOrder();
                }
            });
        },
        computed: {
            // 这俩方法都是判断是否为配偶
            showSpouseInfo() {
                return this.info.custInfo.maritalStatus === '20';
            },
            // 如果已经存在配偶,则不能再选择配偶
            mainBorrowerRelationSelect() {
                return this.info.custInfo.maritalStatus === '20' && !this.hasSpouse ? '15' : '15_1';
            },
            // 判断配偶是否存在且为权利人
            isSpouseWarrantFlag() {
                return this.info.custInfo.maritalStatus === '20' && this.info.spouseInfo.isWarrantFlag === '1';
            },
            // 显示 showFinDirExpiryDate
            showFinDirExpiryDate() {
                return this.info.custInfo.secuFinDirExpiryDate === '0';
            }
        },
        mounted() {
            this.$nextTick(()=> {
                let spouseInfo = this.info.spouseInfo;
                // 选择身份证 国家默认中国不可修改
                spouseInfo.country = spouseInfo.globalType === 'Ind01' ? 'CHN' : spouseInfo.country;
                this.orderId = C.Utils.data(C.DK.ORDER_ID);
                this.render();
            });
        },
        watch: {
            'info.custInfo.globalType'(curval) {
                this.setCountryDef(curval, this.info.custInfo);
            },
            'info.custInfo.maritalStatus'(curval) {
                let info = this.info, maritalStatus = curval === '20';
                this.hasSpouse = maritalStatus ? this.hasSpouse : false;
                if (this.isSpouseWarrantFlag) {
                    this.getRelationItem();
                }
                // 与借款人关系为配偶 且城市为四川成都 则共同借款人必须有一个是配偶
                if (maritalStatus && this.houseCityCode === '510100') {
                    // 如果共同借款人不存在或者第一个不是配偶,那就添加一个共同借款人(配偶)
                    if (info.partnerList.length < 1 || (info.partnerList.length > 0 && info.partnerList[0].mainBorrowerRelation !== '0301')) {
                        this.addPartner(this.info.partnerList, 'shift');
                        info.partnerList[0].mainBorrowerRelation = '0301';
                        info.partnerList[0].globalId = info.spouseInfo.globalId;
                        info.partnerList[0].country = info.spouseInfo.country;
                        info.partnerList[0].globalType = info.spouseInfo.globalType;
                        info.partnerList[0].clientName = info.spouseInfo.clientName;
                        info.partnerList[0].sex = info.spouseInfo.sex;
                        info.partnerList[0].birthDate = info.spouseInfo.birthDate;
                        info.partnerList[0].mobile = info.spouseInfo.mobile;
                    }
                }
                // 主借款人关系不是配偶则清空共同借款人与主借款人关系为配偶的项
                !maritalStatus && info.partnerList.some((item)=> {
                    if (item.mainBorrowerRelation === '0301') {
                        item.mainBorrowerRelation = '';
                        return true;
                    }
                });
                !maritalStatus && info.guarantorList.some((item)=> {
                    if (item.mainBorrowerRelation === '0301') {
                        item.mainBorrowerRelation = '';
                        return true;
                    }
                });
            },
            'info.spouseInfo': {
                handler(cur) {
                    this.setCountryDef(cur.globalType, this.info.spouseInfo);
                    // 更改为港澳地区则无默认值
                    if (this.showSpouseInfo) {
                        this.valuate(this.info.partnerList, 'partnerList');
                        this.valuate(this.info.guarantorList, 'guarantorList');
                    }
                    if (this.isSpouseWarrantFlag) {
                        let hasGuarantor = typeof this.spouseObj['guarantorList'] !== 'undefined', index;
                        index = hasGuarantor ? this.spouseObj['guarantorList'] : null;
                        if (index !== null) {
                            this.info.guarantorList[index].mainBorrowerRelation = '';
                        }
                        this.getRelationItem();
                    }
                },
                deep: true
            },
            'info.partnerList': {
                // 选择了共同借款人选择了配偶关系,同步主借款人配偶信息且不可修改
                handler(cur) {
                    this.valuate(cur, 'partnerList');
                },
                deep: true
            },
            'info.guarantorList': {
                // 选择了个人保证人选择了配偶关系,同步主借款人配偶信息且不可修改
                handler(curval) {
                    this.valuate(curval, 'guarantorList');
                },
                deep: true
            }
        },
        methods: {
            checkGlobalId(item) {
                if (item.globalId.length === 18 && item.globalType === 'Ind01') {
                    item.birthDate = C.Utils.strDateTime(item.globalId, true, 'yyyy-MM-dd');
                    item.sex = item.globalId[16] % 2 === 0 ? C.Constant.A9_2 : C.Constant.A9_1;
                }
            },
            // 根据证件类型生成默认国家
            countryDefaultVal(ObjKey, index, globalType) {
                let obj = index >= 0 ? this.info[ObjKey][index] : this.info[ObjKey];
                if (globalType === 'Ind11') {
                    obj.country = 'CHN';
                }
            },
            // 根据证件类型显示列表选项
            countryListSelect(type) {
                return type === 'Ind07' ? '' : type === 'Ind11' ? '2' : type === 'Ind06' ? '2_1' : type === 'Ind09' || type === 'Ind13' || type === 'Ind03' ? '' : '2';
            },
            // 添加或移动与主借款人关系为配偶的共同借款人到列表的第一个
            getRelationItem() {
                let spouseObj = this.spouseObj, partnerList = Object.assign([],
                    this.info.partnerList), i = spouseObj.partnerList, tempItem;
//                debugger;
                if (i >= 0) {
                    tempItem = partnerList.splice(i, 1)[0];
                    partnerList.unshift(tempItem);
                } else if (partnerList.length === 0 || partnerList[0].mainBorrowerRelation !== '0301') {
                    // 共同借款人列表为空或者第一个不是配偶时,添加一个共同借款人
                    this.addPartner(partnerList, 'shift');
                    partnerList[0].mainBorrowerRelation = '0301';
                }
                this.info.partnerList = partnerList;
            },
            valuate(obj, parentName) {
                if (this.info[parentName].length === 0) {
                    delete this.spouseObj[parentName];
                }
                obj.map((item, index)=> {
                    if (item.mainBorrowerRelation === '0301') {
                        this.hasSpouse = true;
                        this.spouseObj[parentName] = index;
                        item.country = this.info.spouseInfo.country;
                        item.globalType = this.info.spouseInfo.globalType;
                        item.globalId = this.info.spouseInfo.globalId;
                        item.clientName = this.info.spouseInfo.clientName;
                        item.sex = this.info.spouseInfo.sex;
                        item.birthDate = this.info.spouseInfo.birthDate;
                        item.mobile = this.info.spouseInfo.mobile;
                        if (!this.showSpouseInfo) {
                            item.mainBorrowerRelation = '';
                        }
                    } else {
                        this.setCountryDef(item.globalType, item);
                        // 当与主借款人关系不是配偶时,去掉配偶记录
                        if (typeof this.spouseObj[parentName] !== 'undefined' && this.spouseObj[parentName] === index) {
                            this.hasSpouse = false;
                            delete this.spouseObj[parentName];
                        }
                    }
                });
            },
            // 根据证件类型设置国家和地区默认值
            setCountryDef(globalType, obj) {
                let gt = globalType, HKG = C.Constant['2_HKG'];
                // 更改为港澳地区则无默认值
                if (gt === 'Ind06' && obj.country !== HKG && obj.country !== 'MAC') {
                    obj.country = HKG;
                }
                // 选择身份证 国家默认中国不可修改
                obj.country = gt === 'Ind07' ? 'TWN' : gt === 'Ind11' ? obj.country : gt === 'Ind06' ? obj.country : gt === 'Ind09' || gt === 'Ind13' || gt === 'Ind03' ? 'OTH' : 'CHN';
            },
            render() {
                let key;
                C.UI.loading();
                $.ajax({
                    url: C.Api('GET_IDENTITY_CHECK_INFO'),
                    data: {
                        orderId: this.orderId
                    },
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            this.houseCityCode = res.data.houseCityCode;
                            this.info.partnerList = res.data.partnerList || [];
                            this.info.guarantorList = res.data.guarantorList || [];
                            this.info.custInfo.maritalStatus = '20';
                            for (key in res.data.custInfo) {
                                this.info.custInfo[key] = res.data.custInfo[key] ? res.data.custInfo[key] : this.info.custInfo[key];
                            }
                            for (key in res.data.spouseInfo) {
                                this.info.spouseInfo[key] = res.data.spouseInfo[key] ? res.data.spouseInfo[key] : this.info.spouseInfo[key];
                            }
                        }
                    }
                });
            },
            removeItem(index, listName) {
                if (this.info[listName][index].mainBorrowerRelation === '0301') {
                    this.hasSpouse = false;
                }
                this.info[listName].splice(index, 1);
            },
            saveOrder() {
                let postData = this.createPostData();
                if (this.validatorAction(postData)) {
                    C.UI.loading();
                    $.ajax({
                        url: C.Api('UPDATE_IDENTITY_CHECK_INFO'),
                        data: postData,
                        success: (res)=> {
                            if (res.flag === C.Flag.SUCCESS) {
                                C.Native.tip('保存成功');
                                this.$router.go(-1);
                            }
                        }
                    });
                }
            },
            validatorAction(param) {
                let validator = this.validator(param);
                if (validator) {
                    C.Native.tip(validator);
                    return false;
                }
                return true;
            },
            validator(param) {
                let msg = '',
                    ageMsg = '年龄应在18~65周岁',
                    info = param, spId = C.Validator.idNo(info.spouseInfo.globalId, info.spouseInfo.globalType),
                    csId = C.Validator.idNo(info.custInfo.globalId, info.custInfo.globalType);
                if (C.Utils.strLength(info.custInfo.globalId) > 32) {
                    msg = '证件号码不得超过32个字节';
                    return msg;
                } else if (!csId.result) {
                    msg = csId.error;
                    return msg;
                } else if (info.custInfo.birthDate && C.Utils.compareAge(info.custInfo.birthDate) === false) {
                    msg = ageMsg;
                    return msg;
                } else if (this.info.custInfo.mobile && !C.Utils.RegexMap.MobileNo.test(this.info.custInfo.mobile)) {
                    msg = '手机号码格式不对';
                } else if (C.Utils.strLength(info.spouseInfo.globalId) > 32) {
                    msg = '证件号码不得超过32个字节';
                    return msg;
                } else if (!spId.result) {
                    msg = spId.error;
                    return msg;
                } else if (info.spouseInfo.birthDate && C.Utils.compareAge(info.spouseInfo.birthDate) === false) {
                    msg = ageMsg;
                    return msg;
                } else if (this.info.spouseInfo.mobile && !C.Utils.RegexMap.MobileNo.test(this.info.spouseInfo.mobile)) {
                    msg = '手机号码格式不对';
                }
                info.guarantorList.some((item)=> {
                    let result = C.Validator.idNo(item.globalId, item.globalType);
                    if (C.Utils.strLength(item.globalId) > 32) {
                        msg = '证件号码不得超过32个字节';
                        return true;
                    } else if (!result.result) {
                        msg = result.error;
                        return true;
                    } else if (item.birthDate && C.Utils.compareAge(item.birthDate) === false) {
                        msg = ageMsg;
                        return true;
                    } else if (item.mobile && !C.Utils.RegexMap.MobileNo.test(item.mobile)) {
                        msg = '手机号码格式不对';
                    }
                });
                info.partnerList.some((item)=> {
                    let result = C.Validator.idNo(item.globalId, item.globalType);
                    if (C.Utils.strLength(item.globalId) > 32) {
                        msg = '证件号码不得超过32个字节';
                        return true;
                    } else if (!result.result) {
                        msg = result.error;
                        return true;
                    } else if (item.birthDate && C.Utils.compareAge(item.birthDate) === false) {
                        msg = ageMsg;
                        return true;
                    } else if (item.mobile && !C.Utils.RegexMap.MobileNo.test(item.mobile)) {
                        msg = '手机号码格式不对';
                    }
                });
                return msg;
            },
            Obj() {
                return {
                    mainBorrowerRelation: '',
                    mainBorrowerRelationOther: '',
                    country: '',
                    globalType: 'Ind01',
                    globalId: '',
                    clientName: '',
                    sex: '',
                    birthDate: '',
                    mobile: ''
                };
            },
            pushData(obj) {
                obj.push(this.Obj());
            },
            unShiftData(obj) {
                obj.unshift(this.Obj());
            },
            addPartner(obj, type) {
                if (obj.length >= 5) {
                    obj.pop();
                }
                type === 'shift' ? this.unShiftData(obj) : this.pushData(obj);
            },
            addGuarantor() {
                if (this.info.guarantorList.length < 5) {
                    this.pushData(this.info.guarantorList);
                }
            },
            createPostData() {
                let postData = {
                    orderId: this.orderId,
                    custInfo: this.info.custInfo ? this.info.custInfo : {},
                    spouseInfo: this.showSpouseInfo ? this.info.spouseInfo : {},
                    partnerList: this.info.partnerList,
                    guarantorList: this.info.guarantorList
                };
                return postData;
            },
            uploadOcr(param) {
                C.UI.loading();
                $.ajax({
                    url: C.Api('GET_CARD_INFO'),
                    data: {
                        cardSide: param.type,
                        imgName: param.imgName,
                        imgBase64: param.imgBase64
                    },
                    success: (res)=> {
                        let obj = typeof (param.index) == 'number' ? this.info[param.objName][param.index] : this.info[param.objName];
                        if (res.flag === C.Flag.SUCCESS) {
                            if (res.data.code === '1000') {
                                obj.globalId = res.data.cardNo ? res.data.cardNo : obj.globalId;
                                obj.clientName = res.data.name ? res.data.name : obj.clientName;
                                obj.sex = res.data.sex === '男' ? '1' : res.data.sex === '女' ? '2' : obj.sex;
                                obj.birthDate = res.data.birthday ? res.data.birthday : obj.birthDate;
                                obj.certificateOrd = res.data.issueAuthority ? res.data.issueAuthority : obj.certificateOrd;
                                if (res.data.validPeriod) {
                                    let _validPeriod = res.data.validPeriod.split(',')[1].indexOf('长期') !== -1;
                                    this.info.custInfo.secuFinDirExpiryDate = _validPeriod ? C.Constant['A8_1'] : C.Constant['A8_0'];
                                    this.info.custInfo.finDirExpiryDate = _validPeriod ? C.Constant.LAST_YEAR : res.data.validPeriod.split(',')[1];
                                }
                            } else {
                                C.Native.tip('证件识别失败，请重新上传识别');
                            }
                            C.UI.stopLoading();
                        }
                    }
                });
            },
            // 此方法以下均为picker选择器调用方法
            pickerEvent(key, text, slot, index) {
                this.datakey = key;
                this.indexText = text;
                this.tempIndex = index;
                this.slots = [{values: C.Utils.objToArr(C.Constant[slot])}];
                this.isPicker = true;
            },
            dateTimeSeleted(key, index) {
                this.defaultDate = index >= 0 ? C.Utils.pickerDateObject(this.info, key, index) : this.defaultDate = C.Utils.pickerDateObject(this.info, key);
                this.dateDataKey = key;
                this.tempIndex = index;
                this.isPicker = false;
                this.isDatePicker = true;
                this.isAreaPicker = false;
            },
            pickerConfirm(value, key) {
                // {value:"collaterals", index: index, name: "collateralWarrantType" }
                // {k: 01, v: '"按揭一手楼"'} dateTime
                let index = this.tempIndex;
                if (key.hasOwnProperty('value')) {
                    this.info[key.value][key.index][key.name] = value.k;
                    this.info[key.value][key.index][key.name] = value.k;
                } else {
                    if (Object.prototype.toString.call(key) === '[object Object]') {
                        let ObjKey = Object.keys(key)[0],
                            ObjValue = Object.values(key)[0];
                        if (index >= 0) {
                            this.info[ObjKey][index][ObjValue] = value.k;
                        } else {
                            this.info[ObjKey][ObjValue] = value.k;
                        }
                        if (ObjValue === 'globalType') {
                            this.countryDefaultVal(ObjKey, index, value.k);
                        }
                    } else {
                        this.info[key] = value.k;
                    }
                }
                this.isPicker = false;
            },
            pickerCancel() {
                this.isPicker = false;
            },
            getArea(areaKey) {
                this.areaDataKey = areaKey;
                this.isAreaPicker = true;
            },
            areaPickerConfirm(value, key) {
                // {k: "110000-110100-000046", v: "北京市-北京市-北京技术开发区"}
                this.isAreaPicker = false;
                this.info.custInfo[key] = value.v;
            },
            areaPickerCancel() {
                this.isAreaPicker = false;
            },
            datePickerCancel() {
                this.isDatePicker = false;
            },
            datePickerConfirm(value, key) {
                let objName = Object.keys(key)[0], objValue = key[objName];
                this.isDatePicker = false;
                if (this.tempIndex >= 0) {
                    this.info[objName][this.tempIndex][objValue] = value.join('-');
                } else {
                    this.info[objName][objValue] = value.join('-');
                }
            }
        }
    };
</script>
