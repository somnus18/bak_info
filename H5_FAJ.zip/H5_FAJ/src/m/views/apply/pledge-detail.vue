<template>
    <section class="pledge-detail">
        <pledge-detail :info="info" :isToView=false ref="pd" @save="save"></pledge-detail>
    </section>
</template>
<script>
    import pledgeDetail from 'src/components/pledge/detail';

    export default {
        name: 'common-pledge-detail',
        data() {
            return {
                info: {
                    loanVariety: '',
                    clientName: '',
                    defaultOwners: [],
                    houseInfo: {
                        collateralId: '',
                        houseProvince: '',
                        houseCity: '',
                        houseCounty: '',
                        houseAddress: '',
                        houseArea: 0,
                        warrantType: '01',
                        warrantCode: '',
                        houseKinds: '10',
                        landParcelCode: '',
                        storeySumNum: '',
                        houseIndoorArea: '',
                        buildingName: '',
                        estateType: '10',
                        houseUse: '01',
                        finishDate: '',
                        soilUseDeadline: '',
                        soilUseDeadlineStardDate: '',
                        soilUseDeadlineEndDate: '',
                        bargainPrice: '',
                        registeredPrice: '',
                        ownerNum: '',
                        evaluationAmount: ''
                    },
                    ownerList: []
                }
            };
        },
        created() {
            C.Native.setHeader({
                fixed: true,
                title: C.T.PLEDGE_DETAIL,
                rightText: '保存',
                titleCallback: ()=> {
                    C.UI.loading();
                    $.ajax({
                        url: C.Api('SHOW_HOUSE_INFO', 'json'),
                        type: 'get',
                        success: (res)=> {
                            C.UI.stopLoading();
                            if (res.flag === C.Flag.SUCCESS) {
                                for (let key in this.info.houseInfo) {
                                    if (!this.info.houseInfo[key]) {
                                        this.info.houseInfo[key] = res.data.houseInfo[key];
                                    }
                                }
                                for (let key in this.ownerList) {
                                    if (!this.info.ownerList[key]) {
                                        this.info.ownerList[key] = res.data.ownerList[key];
                                    }
                                }
                            }
                            this.info.houseInfo.bargainPrice = C.Utils.toWY(res.data.houseInfo.bargainPrice, 6);
                            this.info.houseInfo.registeredPrice = C.Utils.toWY(res.data.houseInfo.registeredPrice, 6);
                            this.info.houseInfo.evaluationAmount = C.Utils.toWY(res.data.houseInfo.evaluationAmount, 6);
                        }
                    });
                },
                rightCallback: ()=> {
                    this.$refs.pd.save();
                }
            });
        },
        mounted() {
            this.$nextTick(()=> {
                this.orderId = C.Utils.data(C.DK.ORDER_ID);
                this.info.houseInfo.collateralId = this.$route.params.id;
                this.render();
            });
        },
        computed: {},
        methods: {
            render() {
                C.UI.loading();
                $.ajax({
                    url: C.Api('SHOW_HOUSE_INFO'),
                    data: {
                        collateralId: this.info.houseInfo.collateralId
                    },
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            for (let key in res.data.houseInfo) {
                                this.info.houseInfo[key] = '' || res.data.houseInfo[key];
                            }
                            this.info.clientName = res.data.clientName;
                            this.info.defaultOwners = res.data.defaultOwners;
                            this.info.loanVariety = res.data.loanVariety;
                            this.info.ownerList = res.data.ownerList || this.info.ownerList;
                            this.info.houseInfo.estateType = res.data.houseInfo.estateType || '10';
                            this.info.houseInfo.houseUse = res.data.houseInfo.houseUse || '01';
                            this.info.houseInfo.bargainPrice = C.Utils.toWY(res.data.houseInfo.bargainPrice, 6);
                            this.info.houseInfo.buildingName = res.data.houseInfo.buildingName;
                            this.info.houseInfo.registeredPrice = C.Utils.toWY(res.data.houseInfo.registeredPrice, 6);
                            this.info.houseInfo.evaluationAmount = C.Utils.toWY(res.data.houseInfo.evaluationAmount, 6);
                        }
                    }
                });
            },
            createPostData() {
                let param = JSON.parse(JSON.stringify(this.info));
                param.houseInfo.bargainPrice = C.Utils.toY(this.info.houseInfo.bargainPrice);
                param.houseInfo.registeredPrice = C.Utils.toY(this.info.houseInfo.registeredPrice);
                param.houseInfo.evaluationAmount = C.Utils.toY(this.info.houseInfo.evaluationAmount);
                param.houseInfo.orderId = this.orderId;
                param.submitType = '01';
                return param;
            },
            save() {
                let param = this.createPostData();
                C.UI.loading();
                $.ajax({
                    url: C.Api('UPLOAD_HOUSE_INFO'),
                    data: $.extend(true, param),
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            C.Native.tip('保存成功');
                            this.$router.go(-1);
                        }
                    }
                });
            }
        },
        components: {
            pledgeDetail
        }
    };
</script>
<style scoped lang="scss">
</style>
