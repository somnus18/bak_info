<template>
	<section>
        <master-detail :info='info' :isShowBtn=false ref='borrower' :btnName="'保存'" @save='save'></master-detail>
	</section>
</template>
<script>
import masterDetail from 'components/master-borrower/detail';
export default {
	name: 'masterBorrower',
	data() {
	    return {
            info: {},
            orderId: ''
	    };
	},
    created() {
        this.orderId = C.Utils.data(C.DK.ORDER_ID);
    	C.Native.setHeader({
            title: C.T.MASTER_BORROWER,
            fixed: true,
            rightText: '保存',
            rightCallback: ()=> {
                this.$refs.borrower.clickEvent();
            },
            // mock数据填写,生产无效
            titleCallback: ()=> {
                C.UI.loading();
                $.ajax({
                    url: C.Api('GET_MAIN_BORROWER_INFO', 'json'),
                    type: 'get',
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            for (let key in this.info) {
                                if (!this.info[key]) {
                                    this.info[key] = res.data[key];
                                }
                            }
                        }
                    }
                });
            }
        });
    },
    mounted() {
        this.$nextTick(()=> {
            this.getResponseInfo();
        });
    },
	components: {
        masterDetail
	},
	methods: {
        getResponseInfo() {
            C.UI.loading();
            $.ajax({
                url: C.Api('GET_MAIN_BORROWER_INFO'),
                data: {
                    orderId: this.orderId
                },
                success: (res)=> {
                    C.UI.stopLoading();
                    if (res.flag === C.Flag.SUCCESS) {
                        this.info = res.data;
                    }
                }
            });
        },
        save(info) {
            if (typeof info === 'object') {
                info.orderId = this.orderId;
            }
            C.UI.loading();
            $.ajax({
                url: C.Api('UPDATE_MAIN_BORROWER_INFO'),
                data: info,
                success: (res)=> {
                    C.UI.stopLoading();
                    if (res.flag === C.Flag.SUCCESS) {
                        C.Native.tip('保存成功');
                        this.$router.go(-1);
                    }
                }
            });
        }
	}
};
</script>
<style lang="scss" scoped>
</style>
