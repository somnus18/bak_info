<template>
    <section class="partner-detail">
        <partner-detail :info="info" :isShowBtn=false ref='partnerDetail' @save='save'></partner-detail>
    </section>
</template>
<script type="text/ecmascript-6">
    import partnerDetail from 'src/components/partner-guarantor/detail';

    export default {
        name: 'm-partner-detail',
        data() {
            return {
                info: {
                    clientName: '',
                    globalType: '',
                    globalId: '',
                    country: '',
                    sex: '',
                    birthDate: '',
                    mainBorrowerRelation: '',
                    maritalStatus: '',
                    education: '',
                    censusAddress: '',
                    // 有无当地社保
                    localSocialFlag: '',
                    familyHouseNum: '',
                    localHouseFlag: '',
                    localYear: '',
                    homeProvince: '',
                    homeCity: '',
                    homeCounty: '',
                    homeAddress: '',
                    familyMonthCashOut: '',
                    companyName: '',
                    deptName: '',
                    clientJobyears: '',
                    companyProvince: '',
                    companyCity: '',
                    companyCounty: '',
                    companyAddress: '',
                    monthIncome: '',
                    companyTelephone: '',
                    mobile: '',
                    socProPaybase: ''
                }
            };
        },
        created() {
            this.isPartner = /^\/apply\/partner/.test(this.$route.fullPath);
            C.Native.setHeader({
                fixed: true,
                title: this.isPartner ? C.T.PARTNER_DETAIL : C.T.GUARANTOR_DETAIL,
                titleCallback: ()=> {
                    C.UI.loading();
                    $.ajax({
                        url: C.Api('GET_PARTNER_OR_GUARANTOR_INFO', 'json'),
                        type: 'get',
                        success: (res)=> {
                            C.UI.stopLoading();
                            if (res.flag === C.Flag.SUCCESS) {
                                for (let key in res.data) {
                                    this.info[key] = this.info[key] || res.data[key];
                                }
                            }
                        }
                    });
                },
                rightText: '保存',
                rightCallback: ()=> {
                    this.$refs.partnerDetail.save();
                }
            });
        },
        mounted() {
            this.$nextTick(()=> {
                this.paramData = {
                    partnerGuarantorId: this.$route.params.id
                };
                this.render();
            });
        },
        computed: {},
        methods: {
            render() {
                C.UI.loading();
                $.ajax({
                    url: C.Api('GET_PARTNER_OR_GUARANTOR_INFO'),
                    data: this.paramData,
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            for (let key in res.data) {
                                this.info[key] = res.data[key];
                            }
                            this.info['localSocialFlag'] = res.data['localSocialFlag'] || C.Constant.A7_1;
                            this.info['localHouseFlag'] = res.data['localHouseFlag'] || C.Constant.A7_0;
                        }
                    }
                });
            },
            save() {
                let param = $.extend(true, this.info, this.paramData);
                C.UI.loading();
                $.ajax({
                    url: C.Api('UPDATE_PARTNER_OR_GUARANTOR_INFO'),
                    data: param,
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            C.Native.tip('保存成功');
                            this.$router.go(-1);
                        }
                    }
                });
            }
        },
        components: {
            partnerDetail
        }
    };
</script>
<style scoped lang="scss">
</style>
