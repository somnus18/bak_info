<template>
    <div class="apply-typein">
        <m-cell v-model=applyInfo.orderInfo.orderNo :textName="'订单号'" disabled noBorder>
        </m-cell>
        <m-cell v-model=applyInfo.orderInfo.barcode :textName="'KB码'" disabled noBorder>
        </m-cell>
        <m-cell v-model="applyInfo.orderInfo.clientName" :textName="'主借款人'" disabled setHeight>
        </m-cell>
        <div class="cell-other">
            <p><span>贷款相关人信息</span>
                <a class="fr btn-01" @click="isShow = true" v-show="!anotherInputFlag">转他人录入</a></p>
            <p v-show="anotherInputFlag">
                <span>录入人手机号:</span>
                <span class="input">{{applyInfo.anotherInputMobile}}</span>
                <span :class="[toClick.flag?'co-icon-dis':'co-icon']" @click="changeMobile"
                      v-show="applyInfo.submitMark != '1'"></span>
                <send-msg class="fr" :to-click="toClick" @click-button="sendMsg"
                          v-show="applyInfo.submitMark != '1'"></send-msg>
            </p>
        </div>
        <m-cell v-model="percent.identityCheckRate" :disabled="anotherInputFlag || canCheck" :type="'select'"
                @select-input="skipTo('identity')" class="orange nbg"
                v-if="applyInfo.rateInfo.identityCheckRate">
            <span class="mgl-2" slot="name-icon">所有相关人基础信息</span>
            <span class="pd-16"></span>
        </m-cell>
        <m-cell v-model="percent.mainBorrowerRate" :type="'select'"
                @select-input="skipTo('masterBorrower')" class="orange nbg" :disabled=anotherInputFlag
                v-if="applyInfo.rateInfo.mainBorrowerRate">
            <span class="mgl-2" slot="name-icon">主借款人详细信息</span>
            <span class="pd-16"></span>
        </m-cell>
        <m-cell v-model="percent.spouseRate" :type="'select'"
                @select-input="skipTo('masterSpouse')" class="orange nbg" :disabled=anotherInputFlag
                v-if="applyInfo.rateInfo.spouseRate">
            <span class="mgl-2" slot="name-icon">主借款人配偶详细信息</span>
            <span class="pd-16"></span>
        </m-cell>
        <m-cell v-model="percent.partnerRate" :type="'select'"
                @select-input="skipTo('partnerList')" class="orange nbg" :disabled=anotherInputFlag
                v-if="applyInfo.rateInfo.partnerRate">
            <span class="mgl-2" slot="name-icon">共同借款人详细信息</span>
            <span class="pd-16"></span>
        </m-cell>
        <m-cell v-model="percent.guarantorRate" :type="'select'"
                @select-input="skipTo('guarantorList')" class="orange nbg" :disabled=anotherInputFlag
                v-if="applyInfo.rateInfo.guarantorRate">
            <span class="mgl-2" slot="name-icon">个人保证人详细信息</span>
            <span class="pd-16"></span>
        </m-cell>
        <m-cell v-model="percent.collateralRate" class="pd10 orange" :type="'select'"
                @select-input="skipTo('pledgeList')">
            <span slot="name-icon">抵押物信息</span>
        </m-cell>
        <m-cell v-model="percent.loanRate" class="pd10 orange" :type="'select'"
                @select-input="skipTo('loanInfo')">
            <span slot="name-icon">贷款信息</span>
        </m-cell>

        <div class="zxsq">
            <div :class="classObject" @click="changeStatus()">
                <p><span></span>线上征信授权</p>
                <p class="warn"><i></i>如未选择,则必须待客户经理线下征信授权后提交审批</p>
            </div>
            <!--扫描上传默认为选中,且不可修改-->
            <!--<div class="dis checked">-->
            <!--<p><span></span>扫描上传</p>-->
            <!--</div>-->
        </div>
        <input-mobile :isShow="isShow" :mobile="applyInfo.anotherInputMobile" @ok="sendToOther"
                      v-show="isShow"></input-mobile>
        <div class="submit">
            <!--<m-button @click-button="submit"></m-button>-->
            <div @click="submit" class="btn" :class="{'btn-disabled': applyInfo.submitMark != '1'}">提交</div>
        </div>
    </div>
</template>
<style lang="scss" scoped rel="stylesheet/scss">
    .apply-typein {
        .pd-16 {
            padding: .16rem;
        }
        .cell-other {
            background: white;
            padding: .2rem .3rem;
            p {
                clear: both;
                height: .5rem;
                line-height: .45rem;
                margin: 5px 0;
                span {
                    margin-right: .3rem;
                    vertical-align: text-top;
                }
                .co-icon {
                    height: .2rem;
                    width: .2rem;
                    padding: .1rem .3rem;
                    background: url('../../../assets/images/m/icons/icon_alter@2x.png') center center/100% auto no-repeat;
                    -webkit-background-size: .55rem auto;
                    background-size: .55rem auto;
                }
                .co-icon-dis {
                    height: .2rem;
                    width: .2rem;
                    padding: .1rem .3rem;
                    background: url('../../../assets/images/m/icons/icon_alter_dis@2x.png') center center/100% auto no-repeat;
                    -webkit-background-size: .55rem auto;
                    background-size: .55rem auto;
                }
            }
        }
        .zxsq {
            margin: .1rem 0;
            background: white;
            padding: .2rem .3rem;
            color: #999;
            div {
                padding: .1rem 0 .1rem .6rem;
                position: relative;
            }
            .warn {
                font-size: .24rem;
                color: #999;
                i {
                    display: inline-block;
                    width: .2rem;
                    height: .2rem;
                    background-size: 100%;
                    margin-right: .1rem;
                }
            }
            p {
                margin: .1rem 0;
                span {
                    position: absolute;
                    border: 1px solid #999;
                    border-radius: 3px;
                    left: 0rem;
                    width: .4rem;
                    height: .4rem;
                    &:before {
                        display: none;
                        position: absolute;
                        content: '';
                        width: .1rem;
                        height: .2rem;
                        top: .02rem;
                        left: .1rem;
                        border-bottom: 2px solid;
                        border-right: 2px solid;
                        transform: rotate(45deg);
                    }
                }
                i {
                    background: url(../../../assets/images/m/icons/icon_-_dis@2x.png) no-repeat;
                    background-size: 100%;
                }
            }
            .checked {
                color: #666;
                span {
                    border-color: #26a2ff;
                    &:before {
                        display: block;
                        border-color: #26a2ff;
                    }
                }
                i {
                    background: url(../../../assets/images/m/icons/icon_-@2x.png) no-repeat;
                    background-size: 100%;
                }
            }
            .dis {
                color: #999;
                span {
                    border-color: #999;
                    &:before {
                        border-color: #999;
                    }
                }
            }
        }

        .submit {
            background: white;
            box-sizing: content-box;
            padding: .4rem 0rem;
            height: .8rem;
            line-height: .8rem;
            text-align: center;
            margin-top: .25rem;
        }
        .nbg {
            background: #f2f2f2;
        }
        .mgl-2 {
            position: relative;
            left: .6rem;
        }
        .btn-01 {
            border: 1px solid #26a2ff;
            text-decoration: none;
            color: #26a2ff;
            border-radius: 5px;
            padding: 0 .1rem;
        }
        .pd10 {
            margin-top: .1rem;
            padding: .1rem 0;
        }
    }
</style>
<script>
    import mCell from 'components/cell/cell';
    import mCircle from 'components/circle/circle';
    import mSearch from 'components/search/search';
    import mButton from 'components/button/button';
    import sendMsg from 'components/sendMsg/sendMsg';
    import inputMobile from 'components/dialog/index-input';

    export default{
        components: {
            mCell,
            mCircle,
            mSearch,
            mButton,
            sendMsg,
            inputMobile
        },
        data() {
            return {
                isShow: false,
                toClick: {
                    flag: false
                },
                onlineCreditFlag: '0',
                tip: {
                    '002': '请联系客户准备申请材料',
                    '001': '请联系客户进行线上征信授权、准备申请材料'
                },
                flag: true,
                applyInfo: {
                    // '0': 自己录入,'1':转他人录入
                    anotherInputFlag: '0',
                    anotherInputMobile: '',
                    submitMark: '',
                    onlineCreditCheckStatus: '00',
                    scanUploadMark: '',
                    orderInfo: {
                        orderId: '',
                        orderNo: '',
                        barcode: '',
                        clientName: '',
                        propMask: ''
                    },
                    rateInfo: {
                        identityCheckRate: 0,
                        mainBorrowerRate: 0,
                        spouseRate: 0,
                        partnerRate: 0,
                        guarantorRate: 0,
                        houseRate: 0,
                        loanRate: 0,
                        loanRate2: 0,
                        collateralRate: 0
                    }
                }
            };
        },
        computed: {
            percent() {
                return {
                    identityCheckRate: this.applyInfo.rateInfo.identityCheckRate + '%',
                    mainBorrowerRate: this.applyInfo.rateInfo.mainBorrowerRate + '%',
                    spouseRate: this.applyInfo.rateInfo.spouseRate + '%',
                    partnerRate: this.applyInfo.rateInfo.partnerRate + '%',
                    guarantorRate: this.applyInfo.rateInfo.guarantorRate + '%',
                    collateralRate: this.applyInfo.rateInfo.collateralRate + '%',
                    houseRate: this.applyInfo.rateInfo.houseRate + '%',
                    loanRate: this.applyInfo.rateInfo.loanRate + '%',
                    loanRate2: this.applyInfo.rateInfo.loanRate2 + '%'
                };
            },
            anotherInputFlag() {
                return this.applyInfo.anotherInputFlag === '1'; // 1: 转他人录入, 0: 自己录入
            },
            // 线上征信授权是否可选 true:可选
            canSelect() {
                return this.applyInfo.onlineCreditCheckStatus === '00';
            },
            // 所有相关人信息是否可查看 true:可查看
            canCheck() {
                return this.applyInfo.onlineCreditCheckStatus === '01';
            },
            classObject() {
                return {
                    'checked': this.onlineCreditFlag === '1',
                    'dis': this.applyInfo.onlineCreditCheckStatus !== '00'
                };
            }
        },
        created() {
            C.Native.setHeader({
                title: C.T.APPLY_INFO,
                leftCallback: ()=> {
                    this.back();
                }
            });
        },
        mounted() {
            this.$nextTick(()=> {
                this.orderId = C.Utils.data(C.DK.ORDER_ID);
                this.render();
            });
        },
        methods: {
            render() {
                C.UI.loading();
                $.ajax({
                    url: C.Api('APPLY_INFO'),
                    data: {
                        orderId: this.orderId
                    },
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            this.applyInfo = res.data;
                            // 用于单位电话自动出房产所在地的"区号"
                            C.Utils.data(C.DK.HOUSE_CITY, res.data.houseCity);
                            if (this.applyInfo.onlineCreditCheckStatus === '01') {
                                this.onlineCreditFlag = '1';
                            } else if (this.applyInfo.onlineCreditCheckStatus === '02') {
                                this.onlineCreditFlag = '0';
                            }
                        }
                    }
                });
            },
            changeMobile() {
                if (!this.toClick.flag) {
                    this.isShow = true;
                }
            },
            changeStatus() {
                if (this.applyInfo.onlineCreditCheckStatus !== '00') return;
                this.onlineCreditFlag = this.onlineCreditFlag === '1' ? '0' : '1';
            },
            sendToOther(val) {
                this.isShow = false;
                let r = C.Validator.MobileNo(val);
                if (r.result) {
                    C.UI.loading();
                    $.ajax({
                        url: C.Api('ANOTHER_UPDATE_MOBILE'),
                        data: {
                            orderId: this.orderId,
                            mobile: val,
                            sendMessageFlag: '0'
                        },
                        success: (res)=> {
                            C.UI.stopLoading();
                            if (res.flag === C.Flag.SUCCESS) {
                                this.toClick.flag = true;
                                this.render();
                            }
                        }
                    });
                } else {
                    C.Native.tip(r.error);
                }
            },
            sendMsg() {
                C.UI.loading();
                $.ajax({
                    url: C.Api('ANOTHER_REPEAT_MSG'),
                    data: {
                        orderId: this.orderId
                    },
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            this.toClick.flag = true;
                            this.render();
                        }
                    }
                });
            },
            skipTo(path) {
                this.$router.push({
                    name: path
                });
            },
            submit() {
                if (this.applyInfo.submitMark !== '1' || !this.flag) return;
                this.flag = false;
                C.UI.loading();
                $.ajax({
                    url: C.Api('SUBMIT_APPLY_INFO'),
                    data: {
                        orderId: this.orderId,
                        onlineCreditFlag: this.onlineCreditFlag
//                        scanUploadFlag: '1' // 默认为选中状态,且不可修改
                    },
                    success: (res)=> {
                        C.UI.stopLoading();
                        this.flag = true;
                        if (res.flag === C.Flag.SUCCESS) {
                            C.UI.success({
                                title: '提交成功',
                                okText: '确定',
                                content: this.tip[res.data.interviewType],
                                onlyBtn: true,
                                ok: ()=> {
                                    this.$router.go(-2);
                                }
                            });
                        }
                    }
                });
            },
            back() {
                // 创建订单页面
                if (history.length === 1 || C.Utils.getParameter('type') === 'create') {
                    this.$router.push({
                        path: 'list/pending'
                    });
                } else {
                    this.$router.go(-1);
                }
            }
        }

    };
</script>
