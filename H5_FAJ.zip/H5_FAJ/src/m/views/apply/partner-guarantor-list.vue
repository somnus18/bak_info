<template>
    <section class="partner-list">
        <partner-list v-for="item in list" :key="item.id" :item="item"
                      @goDetail="goDetail(item.partnerGuarantorId)"></partner-list>
    </section>
</template>
<script type="text/ecmascript-6">
    import partnerList from 'src/components/partner-guarantor/list';
    export default {
        name: 'm-partner-list',
        data() {
            return {
                list: []
            };
        },
        created() {
            this.isPartner = /^\/apply\/partner/.test(this.$route.fullPath);
            C.Native.setHeader({
                title: this.isPartner ? C.T.PARTNER_LIST : C.T.GUARANTOR_LIST
            });
        },
        mounted() {
            this.$nextTick(()=> {
                this.orderId = C.Utils.data(C.DK.ORDER_ID);
                this.render();
            });
        },
        computed: {},
        methods: {
            render() {
                C.UI.loading();
                $.ajax({
                    url: C.Api('GET_PARTNER_OR_GUARANTOR_LIST'),
                    data: {
                        borrowerType: this.isPartner ? '01' : '02',
                        orderId: this.orderId,
                        listType: '01'
                    },
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            this.list = res.data.userList;
                        }
                    }
                });
            },
            goDetail(id) {
                let _ut = C.Utils.getParameter('_ut');
                this.$router.push((this.isPartner ? 'partner/' : 'guarantor/') + id + (_ut && '?_ut=' + _ut));
            }
        },
        components: {
            partnerList
        }
    };
</script>
<style scoped lang="scss">
</style>
