<template>
    <section class="pledge-list">
        <pledge-list v-for="item in list" :key="item.id" :item="item" @goDetail="goDetail(item.collateralId)"></pledge-list>
    </section>
</template>
<script type="text/ecmascript-6">
    import pledgeList from 'src/components/pledge/list';
    export default {
        name: 'm-pledge-list',
        data() {
            return {
                list: []
            };
        },
        created() {
            C.Native.setHeader({
                title: C.T.PLEDGE_LIST
            });
        },
        mounted() {
            this.$nextTick(()=> {
                this.orderId = C.Utils.data(C.DK.ORDER_ID);
                this.render();
            });
        },
        computed: {},
        methods: {
            render() {
                C.UI.loading();
                $.ajax({
                    url: C.Api('SHOW_COLLATERAL_LIST'),
                    data: {
                        orderId: this.orderId,
                        listType: '01'
                    },
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            this.list = res.data.collateralList;
                        }
                    }
                });
            },
            goDetail(id) {
                this.$router.push('pledge/' + id);
            }
        },
        components: {
            pledgeList
        }
    };
</script>
<style scoped lang="scss">
</style>
