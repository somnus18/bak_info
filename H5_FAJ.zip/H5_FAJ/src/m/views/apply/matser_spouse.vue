<template>
    <section>
        <master-spouse :info='info' @save='save' ref='spouse' :isShowBtn=false :btnName="'保存'"></master-spouse>
    </section>
</template>
<script>
import masterSpouse from 'components/master-borrower/spouse';
export default {
    name: 'masterBorrower',
    data() {
        return {
            info: {},
            orderId: ''
        };
    },
    created() {
        this.orderId = C.Utils.data(C.DK.ORDER_ID);
        C.Native.setHeader({
            title: C.T.MASTER_SPOUSE,
            fixed: true,
            rightText: '保存',
            rightCallback: ()=> {
                this.$refs.spouse.clickEvent();
            },
            // mock数据填写,生产无效
            titleCallback: ()=> {
                // let key, key1, i, key2;
                C.UI.loading();
                $.ajax({
                    url: C.Api('GET_SPOUSE_INFO', 'json'),
                    type: 'get',
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            for (let key in this.info) {
                                if (!this.info[key]) {
                                    this.info[key] = res.data[key];
                                }
                            }
                        }
                    }
                });
            }
        });
    },
    mounted() {
        this.$nextTick(()=> {
            this.getSpouseInfo();
        });
    },
    components: {
        masterSpouse
    },
    methods: {
        getSpouseInfo() {
            C.UI.loading();
            $.ajax({
                url: C.Api('GET_SPOUSE_INFO'),
                data: {
                    orderId: this.orderId
                },
                success: (res)=> {
                    C.UI.stopLoading();
                    if (res.flag === C.Flag.SUCCESS) {
                        this.info = res.data;
                    }
                }
            });
        },
        save(info) {
            if (typeof info === 'object') {
                info.orderId = this.orderId;
            }
            C.UI.loading();
            $.ajax({
                url: C.Api('UPDATE_SPOUSE_INFO'),
                data: info,
                success: (res)=> {
                    C.UI.stopLoading();
                    if (res.flag === C.Flag.SUCCESS) {
                        C.Native.tip('保存成功');
                        this.$router.go(-1);
                    }
                }
            });
        }
    }
};
</script>
<style lang="scss" scoped>
</style>
