<template>
    <div class="loanInfo">
        <loan-info :info="info" :isToView=false ref="lif" @save="save"></loan-info>
    </div>
</template>
<style>
</style>
<script>
    import loanInfo from '@/components/loan-info/detail.vue';
    export default{
        data() {
            return {
                info: {
                    submitType: '',
                    loanId: '',
                    orderId: '',
                    buildingName: '',
                    loanVariety: '',
                    bizApplyAmount: '',
                    publicReserveApplyAmount: '',
                    loanLimit: '',
                    loanPurposeType: '',
                    repaymentType: '',
                    repaymentPeriod: ''
                }
            };
        },
        created() {
            let info = this.info;
            C.Native.setHeader({
                fixed: true,
                title: C.T.LOAN_INFO,
                rightText: '保存',
                rightCallback: ()=> {
                    this.$refs.lif.save(info);
                }
            });
        },
        mounted() {
            this.$nextTick(()=> {
                this.info.orderId = C.Utils.data(C.DK.ORDER_ID);
                this.render();
            });
        },
        methods: {
            render() {
                $.ajax({
                    url: C.Api('SHOW_LOAN_INFO'),
                    data: {
                        orderId: this.info.orderId
                    },
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            for (let key in res.data) {
                                this.info[key] = res.data[key] === null ? this.info[key] : res.data[key];
                            }
                            !this.info.loanPurposeType && (this.info.loanPurposeType = '102');
                            !this.info.repaymentType && (this.info.repaymentType = '1');
                            !this.info.repaymentPeriod && (this.info.repaymentPeriod = '1');
                            this.info.submitType = '01';
                        }
                    }
                });
            },
            save(param) {
                $.ajax({
                    url: C.Api('UPLOAD_LOAN_INFO'),
                    data: param,
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            C.Native.tip('保存成功');
                            this.$router.go(-1);
                        }
                    }
                });
            }
        },
        components: {
            loanInfo
        }
    };
</script>
