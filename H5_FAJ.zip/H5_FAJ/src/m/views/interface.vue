<template>
    <section class="interface">
        <a class="interface-btn" @click="forward">登陆</a>
        <div class="host-container"><input type="text" v-model="ipUrl" placeholder="请输入10.180.230.36:8880"/><span class="interface-btn host" @click="goHost">域名</span><p style="color:#999;font-size: .25rem">* 渠道app专用,跳转至我的进件页面</p></div>
        <div @click="loadingBegin">显示loading,3s后关闭loading</div>
        <div @click="loadingBeginWithText">显示loading(带文案),3s后关闭loading</div>
        <div @click="tip">提示tip</div>
        <div @click="forward">在当前WebView开启新页面</div>
        <div @click="ajax">ajax请求后台</div>
        <div @click="statusBarSwitch">状态栏</div>
        <div @click="showSinglePicker">选择器showSinglePicker</div>
        <div @click="datePicker">日期选择器</div>
        <div @click="dateTimePicker">日期加时间选择器</div>
        <div @click="tokenTimeOut">Native的tokenTimeOut方法</div>
        <div @click="viewImage">Native的viewImage方法</div>
    </section>
</template>
<script type="text/ecmascript-6">
    export default {
        name: 'interface',
        created() {
            C.Native.setHeader({
                title: C.T.INTERFACE
            });
        },
        mounted() {
            C.UI.stopLoading();
            this.token = (C.Utils.data(C.DK.APP_USER_LOGIN_INFO) || {}).token || (C.Utils.data(C.DK.USER_LOGIN_INFO) || {}).token;
        },
        data() {
            return {
                isShowHeader: true,
                ipUrl: '172.31.86.25:8880'
            };
        },
        methods: {
            loadingBegin() {
                C.UI.loading();
                setTimeout(()=> {
                    // 3s去掉loading
                    C.UI.stopLoading();
                }, 3000);
            },
            loadingBeginWithText() {
                C.UI.loading('我是提示文案');
                setTimeout(()=> {
                    // 3s去掉loading
                    C.UI.stopLoading();
                }, 3000);
            },
            tip() {
                C.Native.tip('我是tip提示文案');
            },
            forward() {
                C.Native.forward({
                    url: 'index.html#/login'
                });
            },
            ajax() {
                $.ajax({
                    url: 'http://iqsz-l2066:8011/mtg2/user/login.do', // location.origin + '/user/login.do',
                    data: {
                        phone: '13724218888'
                    },
                    type: 'post',
                    success(res) {
                        if (res.flag === C.Flag.SUCCESS) {
                            C.debug.log(res);
                        }
                    }
                });
            },
            statusBarSwitch() {
                this.isShowHeader = !this.isShowHeader;
                C.Native.setHeader({
                    isShowHeader: this.isShowHeader
                });
            },
            showSinglePicker() {
                C.Native.showSinglePicker({
                    data: [
                        {value: '北京', key: '001'},
                        {value: '天津', key: '002'},
                        {value: '南京', key: '003'},
                        {value: '重庆', key: '004'},
                        {value: '深圳', key: '005'},
                        {value: '上海', key: '006'},
                        {value: '长沙', key: '007'},
                        {value: '广州', key: '008'},
                        {value: '厦门', key: '009'},
                        {value: '中山', key: '010'},
                        {value: '珠海', key: '011'},
                        {value: '南昌', key: '012'}
                    ],
                    title: '所在城市',
                    callback(res) {
                        C.debug.log(res);
                        C.Native.tip('showSinglePicker' + res.msg);
                    }
                });
            },
            datePicker() {
                C.Native.showDatePicker({
                    title: '预约时间',
                    callback(res) {
                        C.debug.log(res);
                        C.Native.tip('showDatePicker' + res.msg);
                    }
                });
            },
            dateTimePicker() {
                C.Native.showDateTimePicker({
                    title: '出生日期',
                    callback(res) {
                        C.debug.log(res);
                        C.Native.tip('showDatePicker' + res.msg);
                    }
                });
            },
            tokenTimeOut() {
                C.Native.tokenTimeOut('登陆超时,请重新登录');
            },
            goHost() {
                C.Native.forward({
                    url: 'http://' + this.ipUrl + '/index.html#/my?token=' + (C.Utils.getParameter('token') || C.Utils.data(C.DK.APP_USER_LOGIN_INFO).token)
                });
            },
            viewImage() {
                let imgList = [
                    {
                        imgUrl: 'https://test-papc-gs.pingan.com.cn:8843/stg3/mtg2/common/showImage/thumb_c9eae0daf09e4d85aa4c4d653e2cb997-EQY-COyqFKuC6l.jpeg?token=' + this.token,
                        imgId: 'c9eae0daf09e4d85aa4c4d653e2cb997-EQY-COyqFKuC6l.jpeg'
                    },
                    {
                        imgUrl: 'https://test-papc-gs.pingan.com.cn:8843/stg3/mtg2/common/showImage/thumb_c9eae0daf09e4d85aa4c4d653e2cb997-EQY-COyqFKuC6l.jpeg?token=' + this.token,
                        imgId: 'c9eae0daf09e4d85aa4c4d653e2cb997-EQY-COyqFKuC6l.jpeg'
                    },
                    {
                        imgUrl: 'https://test-papc-gs.pingan.com.cn:8843/stg3/mtg2/common/showImage/thumb_c9eae0daf09e4d85aa4c4d653e2cb997-EQY-COyqFKuC6l.jpeg?token=' + this.token,
                        imgId: 'c9eae0daf09e4d85aa4c4d653e2cb997-EQY-COyqFKuC6l.jpeg'
                    },
                    {
                        imgUrl: 'https://test-papc-gs.pingan.com.cn:8843/stg3/mtg2/common/showImage/thumb_c9eae0daf09e4d85aa4c4d653e2cb997-EQY-COyqFKuC6l.jpeg?token=' + this.token,
                        imgId: 'c9eae0daf09e4d85aa4c4d653e2cb997-EQY-COyqFKuC6l.jpeg'
                    }
                ];
                C.Native.viewImage({
                    imgId: imgList[0].imgId,
                    imgUrl: imgList[0].imgUrl,
                    title: '身份材料证明',
                    imgList: imgList,
                    deletable: 'Y',
                    delete: (res)=> {
                        let item = res.data.item;
                        imgList.forEach((element, index)=> {
                            if (element.imgId === item.imgId) {
                                imgList.splice(index, 1);
                            }
                        });
                        C.Native.isImageDeleted({
                            imgId: item.imgId,
                            isDeleted: 'Y'
                        });
                    }
                });
            }
        },
        components: {
        }
    };
</script>
<style scoped>
    .interface-btn{
        min-width: 80px;
        border-radius: 4px;
        font-size: 18px;
        line-height: 40px;
        height: 40px;
        border: none;
        padding: 0 10px;
        margin-bottom: 10px;
        display: inline-block;
        background-color: #07c756;
        color: #fff;
        text-align: center;
    }
    input{
        width: 80%;
        line-height: 40px;
        height: 40px;
        font-size: 18px;
    }
    .host-container{
        border: 1px solid #f05b23;
    }
    .host{
        min-width: 1rem;
        padding: 0 .2rem !important;
    }
    section.interface {
        padding: 20px;
        font-size: 20px;
    }
    section.interface div {
        color: #f60;
        padding: 10px 5px;
    }
</style>
