<template>
    <section class="verify">
        <div class="container">
            <header>
                <h2 class="title">房贷客户信息填写</h2>
                <p><i></i>请输入主借款人证件号,验证登录后,真实填写客户信息</p>
            </header>
            <div class="user-box">
                <div class="user-box-in">
                    <input class="ipt1" type="text" placeholder="请输入主借款人证件号码" v-model="mainBorrowerCardNo">
                    <i class="empty-input-icon" v-if="mainBorrowerCardNo" @click="clear('mainBorrowerCardNo')"></i>
                </div>
            </div>
            <div class="btn-bottom">
                <div class="btn" :class="[isValid ? '' : 'btn-disabled']" @click="login">验证</div>
            </div>
        </div>
        <div class="whiteZone"></div>
        <footer>
            <p>版权所有&copy;中国平安保险（集团）股份有限公司</p>
            <p>ICP许可证号 粤ICP备06118290号</p>
        </footer>
    </section>
</template>
<script type="text/ecmascript-6">
    export default {
        name: 'sub-login',
        data() {
            return {
                mainBorrowerCardNo: ''
            };
        },
        created() {
            C.Native.setHeader({
                isShowHeader: false,
                title: C.T.LOGIN
            });
            C.UI.stopLoading();
        },
        mounted() {
            this.$nextTick(()=> {
                this.initHeight();
                let getQueryMap = C.Utils.getQueryMap();
                getQueryMap.userType = C.Constant.USER_TYPE;
                this.orderId = getQueryMap.orderId;
                C.Utils.data(C.DK.SUB_USER_LOGIN_INFO, getQueryMap);
            });
        },
        computed: {
            isValid() {
                return this.mainBorrowerCardNo;
            }
        },
        methods: {
            initHeight() {
                let // 页面的高
                    pageHeight = parseInt($(window).height()),
                    // 表单的高
                    formHeight = parseInt($('.container').height()),
                    // 底部的高
                    footerHeight = parseInt($('footer').height()),
                    // 空白区域的高
                    whiteZoneHeight = pageHeight - formHeight - footerHeight;
                $('.whiteZone').css('height', whiteZoneHeight);
            },
            login() {
                if (!this.mainBorrowerCardNo) {
                    return;
                }
                let checkIdNo = C.Validator.idNo(this.mainBorrowerCardNo); // C.Constant['34_Ind01']
                if (!checkIdNo.result) {
                    C.Native.tip(checkIdNo.error);
                    return;
                }
                C.UI.loading();
                $.ajax({
                    url: C.Api('ANOTHER_LOGIN'),
                    data: {
                        mainBorrowerCardNo: this.mainBorrowerCardNo,
                        orderId: this.orderId,
                        _userType: C.Constant.USER_TYPE
                    },
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            this.$router.push('entry');
                        }
                    }
                });
            },
            clear(dataKey) {
                this[dataKey] = '';
            }
        }
    };
</script>
<style scoped lang="scss">
    .verify{
        width: 100%;
        height: 100%;
        background: #fff;
        .container{
            width: 100%;
            background: #fff;
            padding-top: 30%;
        }
        header{
            text-align: center;

            .title {
                font-size: .48rem;
                color: #333;
                margin-bottom: .48rem;
            }
            p {
                color: #999;
                font-size: .24rem;
                i{
                    display: inline-block;
                    width: .24rem;
                    height: .24rem;
                    margin-right: .1rem;
                    background: url(../../../assets/images/m/icons/icon_warn_s@2x.png);
                    background-size: 100%;
                }
            }
        }
        .user-box{
            padding:21% .8rem 0 .8rem;
            display: -webkit-box;
        }
        .user-box-in{
            position: relative;
            display: block;
            height: .9rem;
            line-height: .9rem;
            background: #f0f0f0;
            width:100%;
        }
        .ipt1 {
            width: 80%;
            height: 0.4rem;
            display: inline-block;
            font-size: 0.3rem;
            background: #f0f0f0;
            margin-left:0.24rem;
            text-align: center;
            &::-webkit-input-placeholder{
                color: #e7e7e7;
            }
        }
        .btn-bottom{
            padding:1.12rem 0 0;
            .btn{
                width: 78%;
            }
        }
        .empty-input-icon {
            position: absolute;
            top: .05rem;
            right: .2rem;
            display: inline-block;
            width: .8rem;
            height: .8rem;
            line-height: .8rem;
            background: url("../../../assets/images/app/icons/icon_name_del@3x.png") center no-repeat;
            -webkit-background-size: 100%;
            background-size: 100%;
        }
        footer{
            text-align: center;
            font-size: .2rem;
            color:#ccc;
            padding-bottom: .4rem;
        }
    }

</style>
