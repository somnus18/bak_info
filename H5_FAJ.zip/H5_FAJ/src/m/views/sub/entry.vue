<template>
    <div class="apply-typein">
        <m-cell v-model=applyInfo.orderInfo.orderNo :textName="'订单号'" :disabled=true :noBorder=true>
        </m-cell>
        <m-cell v-model=applyInfo.orderInfo.barcode :textName="'KB码'" :disabled=true :noBorder=true>
        </m-cell>
        <m-cell v-model="applyInfo.orderInfo.clientName" :textName="'主借款人'" :disabled=true>
        </m-cell>
        <!--这里可以放icon-->

        <m-cell :disabled=true :noBorder="true">
            <span slot="name-icon">贷款相关人信息</span>
        </m-cell>
        <m-cell v-model="percent.identityCheckRate" :disabled="anotherInputFlag || canCheck" :type="'select'" :placeholder="''"
                @select-input="skipTo('identity')" class="orange nbg"
                v-if="applyInfo.rateInfo.identityCheckRate">
            <span class="mgl-2" slot="name-icon">所有相关人基础信息</span>
            <span class="pd-16"></span>
        </m-cell>
        <m-cell v-model="percent.mainBorrowerRate" :type="'select'" :placeholder="''"
                @select-input="skipTo('masterBorrower')" class="orange nbg" :disabled=anotherInputFlag
                v-if="applyInfo.rateInfo.mainBorrowerRate">
            <span class="mgl-2" slot="name-icon">主借款人详细信息</span>
        </m-cell>
        <m-cell v-model="percent.spouseRate" :type="'select'" :placeholder="''"
                @select-input="skipTo('masterSpouse')" class="orange nbg" :disabled=anotherInputFlag
                v-if="applyInfo.rateInfo.spouseRate">
            <span class="mgl-2" slot="name-icon">主借款人配偶详细信息</span>
        </m-cell>
        <m-cell v-model="percent.partnerRate" :type="'select'" :placeholder="''"
                @select-input="skipTo('partnerList')" class="orange nbg" :disabled=anotherInputFlag
                v-if="applyInfo.rateInfo.partnerRate">
            <span class="mgl-2" slot="name-icon">共同借款人详细信息</span>
        </m-cell>
        <m-cell v-model="percent.guarantorRate" :type="'select'" :placeholder="''"
                @select-input="skipTo('guarantorList')" class="orange nbg" :disabled=anotherInputFlag
                v-if="applyInfo.rateInfo.guarantorRate">
            <span class="mgl-2" slot="name-icon">个人保证人详细信息</span>
        </m-cell>
        <div class="submit">
            <div @click="submit" class="btn" :class="{'btn-disabled': applyInfo.anotherInputSubmitMark != '1'}">提交</div>
        </div>
    </div>
</template>
<style lang="scss" scoped rel="stylesheet/scss">
    .apply-typein {
        .pd-16 {
            padding: .16rem;
        }
        .cell-other {
            .input {
                width: 2.2rem;
                font-size: .32rem;
            }
            .co-icon {
                padding: 0 .2rem;
            }
        }
        .submit {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: white;
            box-sizing: content-box;
            padding: .23rem 0;
            height: .8rem;
            line-height: .8rem;
            text-align: center;
            margin-top: .25rem;
            .btn {
                width: 54%;
                height: .84rem;
                line-height: .84rem;
                border-radius: .42rem;
            }
        }
        .nbg {
            background: #f2f2f2;
        }
        .mgl-2 {
            position: relative;
            left: .6rem;
        }
    }
</style>
<script type="text/ecmascript-6">
    import mCell from 'components/cell/cell';

    export default{
        components: {
            mCell
        },
        data() {
            return {
                applyInfo: {
                    anotherInputFlag: '',
                    anotherInputSubmitMark: '0',
                    onlineCreditCheckStatus: '00',
                    orderInfo: {
                        orderId: '',
                        orderNo: '',
                        barcode: '',
                        clientName: ''
                    },
                    rateInfo: {
                        identityCheckRate: 0,
                        mainBorrowerRate: 0,
                        spouseRate: 0,
                        partnerRate: 0,
                        guarantorRate: 0
                    }
                }
            };
        },
        computed: {
            percent() {
                return {
                    identityCheckRate: this.applyInfo.rateInfo.identityCheckRate + '%',
                    mainBorrowerRate: this.applyInfo.rateInfo.mainBorrowerRate + '%',
                    spouseRate: this.applyInfo.rateInfo.spouseRate + '%',
                    partnerRate: this.applyInfo.rateInfo.partnerRate + '%',
                    guarantorRate: this.applyInfo.rateInfo.guarantorRate + '%'
                };
            },
            anotherInputFlag() {
                return this.applyInfo.anotherInputFlag !== '1';
            },
            // 所有相关人信息是否可查看 true:可查看
            canCheck() {
                return this.applyInfo.onlineCreditCheckStatus === '01';
            }
        },
        created() {
            C.Native.setHeader({
                isBack: false,
                title: C.T.APPLY_INFO
            });
        },
        mounted() {
            this.$nextTick(()=> {
                this._userType = C.Constant.USER_TYPE;
                this.orderId = (C.Utils.data(C.DK.SUB_USER_LOGIN_INFO) || {}).orderId;
                this.render();
            });
            window.addEventListener('resize', ()=> {
                this.initHeight();
            }, false);
        },
        methods: {
            render() {
                C.UI.loading();
                $.ajax({
                    url: C.Api('APPLY_INFO'),
                    data: {
                        orderId: this.orderId,
                        _userType: this._userType
                    },
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            this.applyInfo = res.data;
                            // 用于单位电话自动出房产所在地的"区号"
                            C.Utils.data(C.DK.HOUSE_CITY, res.data.houseCity);
                        }
                    }
                });
            },
            skipTo(path) {
                this.$router.push({
                    name: path, query: {_ut: this._userType}
                });
            },
            submit() {
                if (this.applyInfo.anotherInputSubmitMark !== '1') return;
                C.UI.loading();
                $.ajax({
                    url: C.Api('SUBMIT_PERSON_INFO'),
                    data: {
                        orderId: this.orderId,
                        _userType: this._userType
                    },
                    success: (res)=> {
                        C.UI.stopLoading();
                        if (res.flag === C.Flag.SUCCESS) {
                            C.UI.success({
                                title: '提交成功',
                                okText: '确认',
                                ok: ()=> {
                                    C.Native.forward({
                                        url: 'index.html#/failure'
                                    });
                                }
                            });
                        }
                    }
                });
            }
        }
    };
</script>
