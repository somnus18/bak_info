<template>
    <section class="failure">
        <div class="tip"><span></span>此链接已失效!</div>
    </section>
</template>
<script type="text/ecmascript-6">
    export default {
        name: 'failure',
        data() {
            return {};
        },
        created() {
            C.Native.setHeader({
                isShowHeader: false,
                title: C.T.FAILURE
            });
            C.UI.stopLoading();
        },
        mounted() {
        },
        computed: {},
        methods: {
        }
    };
</script>
<style scoped lang="scss">
.failure{
    .tip {
        width: 100%;
        height: 100%;
        padding-top: 65%;
        font-size: .32rem;
        color: #666;
        text-align: center;
        span{
            display: block;
            text-align: center;
            margin: .2rem auto;
            width: 0.88rem;
            height: 0.88rem;
            background: url('../../../assets/images/m/icons/icon_expire@2x.png') no-repeat;
            background-size: 100%;
        }
    }
}
</style>
