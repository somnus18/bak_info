/**
 * @Author : zhangjunli001@pingan.com.cn
 * @Date   : 2016-05-05
 * @Time   : 11:20:32
 *
 * @Description: 我的任务
 */
/* global define: false */

define(['zepto', 'C', 'view', 'scrollView'], function($, C, View, scrollView) {

    'use strict';

    var Page = View.extend(_.extend(scrollView, {


        // 事件
        events: {
            // 用户Id获取焦点
            'focus .js_ipt': 'inputFocus',
            // 查看更多事件
            'tap .more': 'getMore',
            // 宅e贷
            'tap .js_e': 'zhaiEDai',
            // 按揭
            'tap .js_an': 'mortgage',
            // 二手房
            'tap .js_er': 'secondHouse',
            // 任务选择
            'tap .js_ul li': 'chooseTask',
            // 任务处理
            'tap #customerZhai li': 'handleTask',
            'tap #customerAn li': 'handleTask',
            'tap #customerEr li': 'handleTask',
            // 关闭暂停任务弹框
            'tap .js_stop': 'closeStopLeayer'
        },
        // 区域指定
        el: 'body',
        // 宅e贷列表
        custZhaiList: $('#customerZhai'),
        custAnList: $('#customerAn'),
        custErList: $('#customerEr'),
        // 用户列表模板
        custTpl: _.template($('#listTpl').html()),
        // 每页显示条数
        account: 20,
        // 保存前一页数据
        objectInfo: {},
        // 保存第一页数据
        objFirst: [],
        // 防重标示
        isPost: false,
        // 判断滑动刷新的范围
        isBoll: true,
        // 宅e贷
        zhai: '4',        //orderType
        zhaiLi: $('.js_e'),
        // 按揭
        an: '3',          //orderType
        anLi: $('.js_an'),
        // 二手房
        er: '2',          //orderType
        erLi: $('.js_er'),
        // 滑动显示刷新效果框
        reload: $('.js_reload'),
        // 暂无任务
        noTask: $('.js_noTask'),
        // 任务状态
        taskStatus: {
            '1': '待处理',
            '2': '待预约',
            '3': '已超时',
            '4': '新任务',
            '9': '已暂停'
        },
        // 初始化
        initialize: function() {
            var self = this,
                code = null;
            C.Native.setHeader({
                title: '我的任务',
                leftCallback: function() {
                    C.Native.back();
                }
            });
            self.index = 0;
            self.clickType = self.zhai;
            code = C.Utils.data(C.Constant.DataKey.ELSE_TASK_STATUS);
            if (code) {
                $('.js_ul').find('li[data-code="' + code + '"]').addClass('active').siblings().removeClass('active');
                $('#rep-list').find('ul[data-code="' + code + '"]').show().siblings().hide();
                C.Utils.data(C.Constant.DataKey.ELSE_TASK_STATUS, null);
                self.clickType = code;
                self.getData(code);
            } else {
                self.render();
            }
        },
        //下拉刷新
        pullDownActionBase: function() {
            var self = this;
            if (self.isLoading) return;
            self.isLoading = "down";
            self.index = 0;
            self.getData(self.clickType, true);
        },
        //上拉加载
        pullUpActionBase: function() {
            var self = this;
            if (self.isLoading) return;
            self.isLoading = "up";
            self.getData(self.clickType, true);
        },
        /**
         * 页面渲染
         */
        render: function() {
            var self = this;
            self.custZhaiList.show();
            self.getData(self.zhai);
        },
        /**
         * @param type '按揭3  宅e贷 4    二手房2
         */
        getData: function(type, do_action) {
            var self = this,
                page = null,
                data = null,
                datas = [],
                noTask = $('.js_noTask');
            page = self.index + 1;
            if (self.isPost) return;
            self.isPost = true;
            C.UI.loading();

            //隐藏无任务提示
            noTask.hide();

            $.ajax({
                url: C.Api('CUSTOMER_INFORMATION'),
                data: {
                    page: page,
                    pageSize: self.account,
                    orderType: type
                },
                type: 'get',
                //是否上拉或下拉刷新任务列表
                has_action_refresh: do_action,
                success: function(res) {
                    self.isPost = false;
                    if (res.flag == C.Flag.SUCCESS) {
                        data = res.data;
                        if (data.length) {
                            noTask.hide();
                            datas = C.removeRepeatData(data,self.objectInfo,datas,page, 'subtask', true);   // 去除重复数据之后保存的数组
                            if (!datas.length) {
                                delete self.isLoading;
                            } else {
                                self.getInfo(datas, type);
                            }
                            self.objectInfo = datas;
                            self.index++;
                        } else {
                            if (page == 1) {
                                self.firstPageFormat(type);
                            } else {
                                C.Native.tip('没有更多数据');
                            }
                        }
                    } else {
                        page == 1 && !do_action && self.firstPageFormat(type);
                    }
                    delete self.isLoading;
                    C.UI.stopLoading();
                    self.refreshScroll();
                    //安装iScroll组件
                    self.installScroll();
                },
                complete: function(res) {
                    self.isPost = false;
                    if (self.hasInitScroll) self.refreshScroll();
                    C.Native.loadingFinish();
                    delete self.isLoading;
                },
                error: function(xhr, errorType, errorMsg) {
                    self.isPost = false;
                    if (self.hasInitScroll) self.refreshScroll();
                    C.Native.loadingFinish();
                    delete self.isLoading;
                    if (page == 1 && !do_action) {
                        noTask.show();
                    }
                    self.installScroll();
                }
            });
        },
        // 清空任务列表 显示暂无任务
        firstPageFormat: function (type) {
            var self = this;
            switch(type){
                case self.zhai:
                    self.custZhaiList.empty();
                    break;
                case self.an:
                    self.custAnList.empty();
                    break;
                case self.er:
                    self.custErList.empty();
                    break;
            }
            $('.js_noTask').show();
        },
        /**
         * 允许iScroll
         */
        installScroll: function() {
            var self = this;
            if (!self.hasInitScroll) {
                // 动态改变列表的高度
                var scrollContainerH = $('.layout').height();
                var headHeight = window.innerHeight - $('header').height() - $('.tab').height();
                if (scrollContainerH < headHeight)
                    scrollContainerH = headHeight;
                self.install(scrollContainerH);
                self.hasInitScroll = true;
            }
        },
        /**
         * 公共取值
         */
        getInfo: function($el, type) {
            var arrInfo = [],
                self = this;
            $.each($el, function(index, item) {
                // taskStatus==1 custStatus存在的话 说明任务已开始，显示处理中，否则是待处理状态
                item.stageName = self.taskStatus[item.taskStatus];
                item.redStyle = true;
                if (item.taskStatus == '1') {
                    if (item.custStatus) {
                        item.stageName = '处理中';
                    }
                    item.redStyle = false;
                }
                item.subtask = item.subtask || '';
                item.prdType = item.productType;
                item.productType = C.Constant.BUSINESS_LINE_NAME[item.productType];
                item.appointDate = item.appointDate ? C.Utils.parseDateFormat(item.appointDate, 'MM月dd日') : '';
                item.appointTime = item.appointTime ? item.appointTime.split(':')[0] + ':' + item.appointTime.split(':')[1] : '';
                item.custMobile = item.custMobile ? C.Utils.formatMobileNo(item.custMobile) : '';
                arrInfo.push(self.custTpl(item));
            });
            if (self.isLoading == 'up') {
                switch(type){
                    case self.zhai:
                        self.custZhaiList.append(arrInfo.join(''));
                        break;
                    case self.an:
                        self.custAnList.append(arrInfo.join(''));
                        break;
                    case self.er:
                        self.custErList.append(arrInfo.join(''));
                        break;
                }
            } else {
                switch(type){
                    case self.zhai:
                        self.custZhaiList.html(arrInfo.join(''));
                        break;
                    case self.an:
                        self.custAnList.html(arrInfo.join(''));
                        break;
                    case self.er:
                        self.custErList.html(arrInfo.join(''));
                    break;
                }
            }
            delete self.isLoading;
        },
        /**
         * 任务选择
         */
        chooseTask: function(e) {
            $(e.currentTarget).addClass('active').siblings().removeClass('active');
        },
        /**
         *
         * @param e 当前类型是宅e贷  按揭   二手房
         * @param t   类型  宅e贷 4    按揭 3   二手房  2
         */
        connType: function(e, t) {
            var self = this;
            e.show().siblings('ul').hide();
            if (self.custZhaiList.css('display') == 'block') {
                self.clickType = self.zhai;
            } else if (self.custAnList.css('display') == 'block') {
                self.clickType = self.an;
            } else {
                self.clickType = self.er;
            }
            self.index = 0;
            self.getData(t);
        },
        /**
         * 宅e贷
         */
        zhaiEDai: function() {
            var self = this;
            self.connType(self.custZhaiList, self.zhai);
        },
        /**
         * 按揭
         */
        mortgage: function() {
            var self = this;
            self.connType(self.custAnList, self.an);
        },
        /**
         * 二手房
         */
        secondHouse: function() {
            var self = this;
            self.connType(self.custErList, self.er);
        },
        closeStopLeayer: function () {
            $('#stop-task').addClass('dn');
        },
        /**
         * 任务处理
         */
        handleTask: function(e) {
            var curr = $(e.currentTarget),
                code = $('.js_ul').find('li.active').data('code');
            if (curr.attr('data-code') == 9) {
                $('#stop-task').removeClass('dn');
                return;
            }
            C.Utils.data(C.Constant.DataKey.DETAIL_TASKID, curr.data('id'));
            C.Utils.data(C.Constant.DataKey.DETAIL_CITYID, curr.data('cityid'));
            C.Utils.data(C.Constant.DataKey.DETAIL_STAGEID, curr.data('stageid'));
            C.Utils.data(C.Constant.DataKey.DETAIL_PRODUCTTYPE, curr.data('prdtype'));
            C.Utils.data(C.Constant.DataKey.SUB_TASK_CONTENT, curr.data('subtask'));  // 子任务名称
            C.Native.forward({
                url: 'task_detail.html',
                data: {
                    data: code
                }
            });
        }
    }));

    $(function() {
        new Page({
            el: $('body')[0]
        });
        $$.EventListener.onBack = function() {
            location.reload();
        }
    })
});
