define(['zepto', 'C', 'view'], function($, C,View) {

    var Page = View.extend(_.extend({

        events:{
            'tap #back': 'back',
        },

        initialize: function() {
            var self = this;
            C.Native.setHeader({
                title: '平安RO',
                leftCallback: function() {
                    C.Native.back();
                }
            });
        },

        back: function() {
            C.Native.back();
        }

    }));

    $(function(){
        new Page({
            el: $('body')[0]
        });
    })
});
