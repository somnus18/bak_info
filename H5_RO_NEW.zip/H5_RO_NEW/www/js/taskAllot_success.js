
define(['zepto', 'C', 'view'], function($, C,View) {

    'use strict';

    var Page = View.extend(_.extend({

        // 事件
        events:{
            // 返回首页
            'tap .btn-mid': 'back'
        },


        // 初始化
        initialize: function() {
            C.Native.setHeader({
                title: '任务分配成功',
                leftCallback: function() {
                    C.Native.back({
                        url:'task_center.html'
                    });
                }
            });
            C.UI.stopLoading();
        },

        back: function() {
            C.Native.back({
                url:'task_center.html'
            });
        }

    }));

    $(function(){
        new Page({
            el: $('body')[0]
        });
        $$.EventListener.onBack = function() {
            location.reload();
        }
    })
});
