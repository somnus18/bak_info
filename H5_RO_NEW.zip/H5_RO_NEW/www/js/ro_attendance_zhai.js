/**
 * @Author : ex-zhangjunli001@pingan.com.cn
 * @Date   : 2016-09-15
 * @Time   : 10:10:00
 * @Description: 考勤
 */
/* global define: false */

define([
    'zepto',
    'C',
    'view',
    "underscore",
    'base64'
], function ($,
             C,
             View,
             _) {

    'use strict';

    var Page = View.extend(_.extend({
        //事件对应及方法
        events: {
            'tap .js_btn_cancel': 'closeBtn',
            'tap #work-btn': 'workBtn',
            'tap #house-list-ul li': 'chooseHouse',
            'tap #sure-house': 'submitHouse',
            'tap #sure-leave-work-btn': 'sureLeaveWorkBtn',
            'tap #choose-reason': 'chooseReason'
        },
        //将数据临时保存
        dataParam: {},
        //工作状态码
        statecode: '',
        //设备ID
        deviceId: '',
        isPost: false, // 防重复提交标示
        //用户打卡模板
        workInfoTpl: _.template($('#js_workTemp').html()),
        // 房管局列表
        houseListTpl: _.template($('#tpl-house-list').html()),
        //打卡展示
        dataInfo: $('#js_work_box'),
        // 原因列表
        reasonList: [],
        isHasOrderNeed: false,
        getHdId: '', // 房管局Id
        //初始化
        initialize: function () {
            var self = this;
            C.Native.setHeader({
                title: '考勤',
                leftCallback: function () {
                    C.Native.back();
                }
            });
            self.render();
        },
        formatAjax: function (json) {
            var self = this;
            if (self.isPost) return;
            self.isPost = true;
            C.UI.loading();
            $.ajax({
                url: json.url,
                type: json.type || 'get',
                data: json.data || {},
                success: function (res) {
                    self.isPost = false;
                    if (res.flag == C.Flag.SUCCESS) {
                        json.callback(res.data);
                        C.UI.stopLoading();
                    } else {
                        C.Native.tip(res.msg);
                        C.UI.stopLoading();
                    }
                },
                error: function (xhr, errorType, error) {
                    self.isPost = false;
                    C.UI.stopLoading();
                }
            });
        },
        //页面渲染view
        render: function () {
            var self = this,
                json = {
                    url: C.Api('RO_ATTENDANCE_STATE_ZHAI')
                };
            var callback = function (data) {
                self.getHdId = data.hdId;
                self.goView(data);
            };
            json.callback = callback;
            self.formatAjax(json);
        },
        // 页面状态交互，statecode 为‘0’时，为打上班卡；为‘1’时，为打下班卡;
        goView: function (data) {
            var self = this,
                myDate = new Date();
            var currentTime = C.Utils.parseDateFormat(myDate, 'MM月dd号'),
                curHour = C.Utils.parseDateFormat(myDate, 'hh:mm'),
                obj = {
                    signDate: currentTime,
                    signHour: curHour
                };
            obj.signed = data.signed;
            obj.hdName = data.hdName || '';
            self.dataInfo.html(self.workInfoTpl(obj));
        },
        // 我已上班|我已离开
        workBtn: function (e) {
            var signed = $(e.currentTarget).attr('data-signed');
            if (signed == 0) {
                this.getHouseList(); // 获取房管局列表并展示
            } else {
                this.canLeaveWork();  // 调用接口判断用户离开的时候是否有未捞单
            }
        },
        // 关闭弹框
        closeLeayer: function (curr) {
            curr.closest('section').addClass('dn')
        },
        //点击按钮事件(上下班)
        goConfirm: function (e) {
            this.closeLeayer($(e.currentTarget));
        },
        // ‘取消’ ||‘x’ 掉按钮窗口
        closeBtn: function (e) {
            this.closeLeayer($(e.currentTarget));
        },
        // 获取接口房管局列表数据
        getHouseList: function () {
            var self = this,
                json = {
                    url: C.Api('GET_HOUSE_LIST')
                };
            var callback = function (data) {
                // 调用安卓展示的房管局列表
                if (App.IS_ANDROID) {
                    self.getAndroidHdId(data);
                } else {
                    $('#sure-house').addClass('btn-gray');
                    $('#house-list-ul').html(self.houseListTpl({data: data}));
                    $('#house-list').removeClass('dn');
                }
            };
            json.callback = callback;
            self.formatAjax(json);
        },
        // 获取安卓的房管局Id
        getAndroidHdId: function (data) {
            var self = this;
            C.Native.showHdSelectList({
                data: data,
                callback: function (res) {
                    self.submitHouseAjax({hdId: res.hdId});  // 提交选中的房管局
                }
            });
        },
        // 选择房管局
        chooseHouse: function (e) {
            var curr = $(e.currentTarget);
            curr.addClass('active').siblings().removeClass('active');
            $('#sure-house').removeClass('btn-gray');
        },
        // 提交选中的房管局
        submitHouse: function () {
            var hdId = $('#house-list-ul').find('li.active').attr('data-id');
            if (!hdId) {
                C.Native.tip('需要选择一家房管局,请选择');
                return;
            }
            this.submitHouseAjax({hdId: hdId});
        },
        // 提交选中的房管局
        submitHouseAjax: function (data) {
            var json = {
                    url: C.Api('SUBMIT_HOUSE_LIST'),
                    data: data
                };
            var callback = function (data) {
                C.Native.tip('提交成功');
                // self.sucBackAttence();
                $('#house-list').addClass('dn');
                location.reload();  // 刷新当前页面
            };
            json.callback = callback;
            this.formatAjax(json);
        },
        // 点击我要离开，判断是否有后续未捞单
        canLeaveWork: function () {
            var self = this,
                json = {
                    url: C.Api('CAN_LEAVE_WORK'),
                    data: {hdId: this.getHdId}
                };
            var callback = function (data) {
                // data.data.length 存在 说明有后续待处理任务
                if (data.length) {
                    // 有任务未捞单 需要填写原因
                    $('#have-order').removeClass('dn');
                    self.isHasOrderNeed = true;
                    self.reasonList = data;  // 原因列表
                } else {
                    self.isHasOrderNeed = false;
                }
                $('#leave-work').removeClass('dn'); // 离开
            };
            json.callback = callback;
            this.formatAjax(json);
        },
        // 选择离开原因
        chooseReason: function (e) {
            var self = this,
                backReason = this.reasonList,
                newReason = [],
                defaultValue = '',
                reasonEl = $(e.currentTarget).find('span').eq(0);
            for (var i in backReason) {
                var tmpObj = {
                    key: backReason[i]['reasonId'],
                    value: backReason[i]['reason']
                };
                newReason.push(tmpObj);
            }
            var key = reasonEl.data('key'),
                text = reasonEl.text();
            if (key && text) {
                defaultValue = {
                    value: text,
                    key: key
                }
            }
            C.Native.showPicker({
                defaultValue: defaultValue,
                data: newReason,
                title: '选择原因',
                callback: function (res) {
                    if (res.code == '0') {
                        reasonEl.text(res.selectResult.value).data('key', res.selectResult.key);
                        if (res.selectResult.key == C.Constant.OTHER_REASON_TYPE) {
                            // 选择其他的话,需要填写原因
                            $('#text-area').removeClass('dn');
                            self.otherReason = true;
                        } else {
                            $('#text-area').addClass('dn');
                            self.otherReason = false;
                        }
                    }
                }
            });
        },
        // 确定离开
        sureLeaveWorkBtn: function () {
            var self = this,
                leaveReason = $('#choose-reason').find('span').eq(0).data('key') || '',
                otherReason = $.trim($('#text-area').val()) || '',
                json = {
                    url: C.Api('LEAVE_FROM_WORK'),
                    data: {
                        reasonId: leaveReason,
                        reason: otherReason
                    },
                    type: 'post'
                };
            var callback = function (data) {
                self.sucBackAttence('leave'); // 跳转成功
            };
            json.callback = callback;
            if (self.isHasOrderNeed && !leaveReason) {
                C.Native.tip('您还未选择离开原因,请选择');
                return;
            }
            if (self.otherReason && !otherReason) {
                C.Native.tip('请输入其他原因');
                return;
            }
            this.formatAjax(json);
        },
        // 跳转成功
        sucBackAttence: function (type) {
            C.Native.forward({
                url: 'work_attence_suc.html?type=' + type
            });
        }
    }));
    $(function () {
        new Page({
            el: $('body')[0]
        });
    })
});
