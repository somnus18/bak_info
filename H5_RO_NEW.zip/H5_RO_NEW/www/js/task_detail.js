/**
 * @Author : linzequan958@pingan.com.cn
 * @Date   : 2016-04-26
 * @Time   : 16:14:14
 *
 * @Description: 任务详情
 */
/* global define: false */
define(['zepto', 'C', 'view', 'imglazyload'], function ($, C, View) {

    'use strict';

    var Page = View.extend(_.extend({

        // 页面全局变量
        _G: {
            taskDetailInfo: {},     // 任务详情信息
            nodelistPosition: {     // 任务节点位置信息
                lastX: 0,
                changeX: 0
            },
            showOverDueFocus: false, // 是否强制显示逾期浮层
            canOrderTime:''   //可预约时间段
        },

        //保存等待客户和客户到达的全局变量
        cust: {
            preStageId: '', // 虚拟节点的stageId
            btnName: '',    // 虚拟节点的按钮名称
            overTime: '',   // 是否超时  true超时 false没有超时
            lastStage: '',   // 最后一个节点是不是并行节点  true 是
            stageId: ''   // 切换节点的stageId
        },
        // 当前节点
        curStageId: {},
        // 处理人的类型 RO联络人1  RO专员2
        taskInfoType: '2',
        // 业务类型
        // 服务器时间
        objTime: {},
        // 判断是不是点击提交过节点并回退
        backTrue: '',
        // 最后一个节点是不是并行节点的状态，true是并行节点 false 不是并行节点
        stageLastState: true,
        // 选择日期
        chooseDate: $('.js_modifyPopDate'),
        // 选择时间
        chooseTime: $('.js_modifyPopTime'),
        // 回退原因
        backReasonIpt: $('.js_backReasonText'),
        // 包裹时间气泡的容器
        timePage: $('.js_taskTimeTip'),
        // 包裹回退原因气泡的容器
        backReasonPage: $('.js_backReasonTip'),
        // 节点ul
        stageUl: $('.js_nodelist'),
        // 包裹预约时间的容器
        appointFrame: $('.js_changeTime'),
        // 底部按钮的容器
        bottomBtnFrame: $('.js_fixedEvent'),
        // 底部更多详情
        bottomDetail: $('.js_detailBottom'),
        // 确认stageName
        sureStageName: $('.js_sureResult'),
        // 浮层处理dialog
        layerDealDialog: $('.js_dealLeayer'),
        // 逾期任务浮层
        overTimeLayer: $('.js_overdueLeayer'),
        // 回执号
        receiptIdIpt: $('.js_receiptIdIpt'),
        // 他证号
        cardIdIpt: $('.js_cardIdIpt'),
        // 预约时间
        modiTime: $('.js_modifyTimeLeayer'),
        // 他证时间
        cardIdChoTime: $('.js_cardIdTime'),
        // 回执框
        HandleUp: $('.js_receiptId'),
        // 预计时间
        estimateChoTime: $('.js_estimateTime'),
        // 宅e贷的节点处理框
        zhaiRMCHAND: $('.js_zhaiHandle'),
        // 按揭新的节点处理框
        annewLeayer: $('.js_estimateTimeLeayer'),
        // 宅e贷节点
        // 如果是他证 RMCupload_4 和回执 HandleUpload_4 的节点 走他证和回执节点的接口提交
        RMCupload: 'RMCupload_4', //他证 不允许回退
        HandleUpload: 'HandleUpload_4', // 回执
        HandleUploadBack: 'HandleUpload_4_C', // 回执异常办结的处理
        RMCTypeId: 'LJ81',      //他证图片类型 ID
        // 按揭新
        Transfer: 'TransferManagement', //过户办理
        Mortgage: 'MortgageManagement', //抵押办理
        // 按揭新新
        Mortgage_7: 'MortgageManagement_7', //抵押办理
        // 防重的变量
        isPost: false,
        // 获取列表存贮的本地用户数据
        orderId: C.Utils.data(C.Constant.DataKey.DETAIL_TASKID),                // 订单号
        cityId: C.Utils.data(C.Constant.DataKey.DETAIL_CITYID),                // 城市编码
        stageId: C.Utils.data(C.Constant.DataKey.DETAIL_STAGEID),               // 节点ID
        productType: C.Utils.data(C.Constant.DataKey.DETAIL_PRODUCTTYPE),           // 产品类型
        subCont: C.Utils.data(C.Constant.DataKey.SUB_TASK_CONTENT),  // 子任务订单id

        // 渲染模板结构
        frame_nodelist: _.template($('#tpl-nodelist').html()),                 // 任务节点列表
        frame_nodelist_er: _.template($('#tpl-nodelist-er').html()),              // 二手房任务节点列表
        frame_taskTimeTip: _.template($('#tpl-taskTimeTip').html()),              // 任务未开始时间气泡提醒
        frame_taskTimeWaitTip: _.template($('#tpl-taskTimeWaitTip').html()),          // 任务时间待定气泡提醒
        frame_taskTimeWaitedTip: _.template($('#tpl-taskTimeWaitedTip').html()),        // 任务时间逾期气泡提醒
        frame_backReasonTip: _.template($('#tpl-backReasonTip').html()),        // 任务回退原因提醒
        frame_detailTop: _.template($('#tpl-detailTop').html()),                // 任务详情头部信息
        frame_detailTimeAppoint: _.template($('#tpl-detailTimeAppoint').html()),        // 任务详情头部时间信息
        frame_detailBottom: _.template($('#tpl-detailBottom').html()),             // 二手房任务详情底部更多信息
        frame_detailAnBottom: _.template($('#tpl-detailAnBottom').html()),           // 按揭任务详情底部更多信息
        frame_detailZhaiBottom: _.template($('#tpl-detailZhaiBottom').html()),       //宅e贷任务详情底部更多信息
        frame_detailAnNewBottom: _.template($('#tpl-detailAnNewBottom').html()),       //按揭（新）详情底部更多信息
        frame_detailAnNewNewBottom: _.template($('#tpl-detailAnNewNewBottom').html()),       //按揭（新）详情底部更多信息
        frame_photoArea: _.template($('#tpl-photoArea').html()),                // 图片区域图片
        btn_fixedBtn: _.template($('#fixedTpl').html()),                     // 底部按钮事件处理
        btn_fixedFinishBtn: _.template($('#fixedFinishTpl').html()),               // 底部按钮事件处理
        affect_task: _.template($('#affectTask-tpl').html()),               // 受影响任务列表

        // 事件绑定
        events: {
            'tap .js_moreBtn': 'changeDetailMore',
            'tap .js_showPhotoBtn': 'changePhotoArea',
            'tap .js_modifyTime': 'getCanOrderTime',
            'tap .js_closeTimeLeayer': 'hideModifyTime',
            'tap .js_closeEstimateTimeLeayer': 'hideEstimateTime',
            'tap .js_node': 'changeNode',
            'tap .js_appointTime': 'appointTime',
            'tap .js_stepBtn': 'dealStep',
            'tap .js_abnormalBtn': 'showAbnormal',
            'tap .js_prevImg': 'prevImg',
            'tap .js_choosePopDate': 'modifyPopDate',
            'tap .js_choosePopTime': 'modifyPopTime',
            'tap .js_backType': 'chooseBackType',
            'tap .js_backReason': 'chooseBackReason',
            'tap .js_closeAbnormalLeayer': 'hideAbnormalLeayer',
            'tap .js_sureAbnoremal': 'sureAbnoremal',
            'tap .js_closeDealLeayer': 'hideCloseDealLeayer',
            'tap .js_closeTaskChange': 'closeTaskChange',
            'tap .js_sureDeal': 'sureDeal',
            'tap .js_closeOverdueLeayer': 'closeOverdueLeayer',
            'tap .js_sureOverdue': 'sureOverdue',
            'tap .js_effectNode': 'gotoEffectNode',
            'tap .js_doCall': 'doCall',
            'tap .js_noTimeAppoint': 'noTimeAppoint',
            'tap .js_sureClose': 'noTimeAppoint',
            'tap .js_guide': 'guideDetail',
            'tap .js_plaConfirm': 'closeConfirmPlace',
            'tap .js_plaClose': 'closeConfirmPlace',
            'tap #iconClose': 'clearDateText'
        },

        // 数据请求公用方法
        requestData: function (json, sType, eType) {
            var self = this,
                allot_text = '';
            if (self.isPost) {
                return;
            }
            self.isPost = true;
            if (!sType) {
                C.UI.loading();
            }
            $.ajax({
                url: json.api,
                type: 'post',
                data: json.data,
                timeout: 30000,
                success: function (data) {
                    self.isPost = false;
                    if (!eType) {
                        C.UI.stopLoading();
                    }
                    if (data.flag == C.Flag.SUCCESS) {
                        json.callback(data);
                    } else if(data.flag == C.Flag.TASK_CHANGE) {
                        // 后端返回异常之后提示异常信息 并关闭loading
                        allot_text = data.msg || '当前任务已被改派他人或办结';
                        $('#task_alloat').text(allot_text);
                        $('.js_changeLeayer').removeClass('dn');
                        C.UI.stopLoading();
                    } else {
                        C.Native.tip(data.msg);
                    }
                },
                error: function (xhr, errorType, error) {
                    self.isPost = false;
                    C.UI.stopLoading();
                    json.errorCall();
                }
            });
        },

        // 初始化
        initialize: function () {
            var self = this,
                url = null,
                code = C.Utils.getParameter('data');
            if (code) {
                C.Utils.data(C.Constant.DataKey.ELSE_TASK_STATUS, code);
                url = 'mytask.html'
            } else {
                C.Utils.data(C.Constant.DataKey.ELSE_TASK_STATUS, null);
                url = 'home.html'
            }
            C.Native.setHeader({
                title: '任务详情',
                leftCallback: function () {
                    C.Native.back({
                        url: url
                    });
                }
            });
            self.render();
        },
        // 渲染页面
        render: function () {
            var self = this,
                orderId = self.orderId,
                cityId = self.cityId,
                stageId = self.stageId,
                productType = self.productType,
                json = {
                    api: C.Api('GET_TASKINFO'),
                    data: {
                        orderId: orderId,
                        cityId: cityId,
                        stageId: stageId,
                        productType: productType,
                        taskInfoType: self.taskInfoType
                    }
                };
            productType == 4 && (json.data.taskContent = self.subCont);   // 宅e贷订单增加入参
            var callback = function (data) {
                self._G.taskDetailInfo = data.data;
                //避免gs端不传节点补录信息
                self._G.taskDetailInfo.stageInputInfo = self._G.taskDetailInfo.stageInputInfo  || {};
                // 保存服务器时间
                self.objTime.time = data.time;
                // 渲染时间气泡
                self.renderTaskTimeTip();
                // 渲染回退原因气泡
                self.renderBackReasonTip();
                // 渲染任务节点信息
                self.renderNodelist();
                // 渲染详情头部信息
                self.renderDetailTop();
                // 渲染详情底部更多信息
                self.renderDetailBottom();
                // 渲染图片区域数据
                self.renderPhotoArea();
                // 渲染底部按钮
                self.renderBottomBtn();
                // 渲染二手房首次进入时的引导
                self.renderGuider();
                // 本地保存用户登录的状态，用于识别第一次进入页面判断
                if (self._G.taskDetailInfo.productType == '1') {
                    C.Utils.data(C.Constant.DataKey.ENTER_STATE, 'true');
                }
                // 注册懒加载图片
                $('.js_img_lazy_div').imglazyload();
            };
            var errorCall = function () {
            };
            json.callback = callback;
            json.errorCall = errorCall;
            self.requestData(json);
        },
        // 去除fileInfo中的重复数据
        removeRepeatData: function(data, type){
            var dataInfo = [], array = [],
                arr = [], handStageId = '';
            handStageId = (this.stageId == this.HandleUploadBack) ? this.HandleUpload : this.stageId;
            dataInfo = $.extend(dataInfo,data);
            for (var i = 0; i < dataInfo.length; i++) {
                if (dataInfo[i]['stageId'] == handStageId) {
                    array.push(dataInfo[i]);
                }
            }
            // type=true 针对宅e贷订单处理
            type && (dataInfo = array);
            dataInfo = _.sortBy(dataInfo,'fileId');
            for(var i=0;i<dataInfo.length;i++){
                var repeatTrue = true;
                if(!_.isEmpty(dataInfo[i+1]) && dataInfo[i].fileId == dataInfo[i+1].fileId && dataInfo[i].page == dataInfo[i+1].page){
                        repeatTrue = false;
                    }
                if(repeatTrue){
                    arr.push(dataInfo[i]);
                }
            }
            return arr;
        },
        // 过户办理节点和抵押办理节点判断
        isTransferMortgage: function(stageId){
            if (stageId == this.Transfer || stageId == this.Mortgage || stageId == this.Mortgage_7){
                return true;
            }
            return false;
        },
        /**
         * 毫秒数转换成时分秒
         */
        getSeconds: function (time) {
            var s = time % 60,
                h = parseInt(time / 3600),
                m = parseInt((time - h * 3600) / 60);
            s = s < 10 ? '0' + s : s;
            h = h < 10 ? '0' + h : h;
            m = m < 10 ? '0' + m : m;
            return h + ':' + m + ':' + s;
        },
        // 渲染任务节点信息
        // 1.橙色表示被选中 org
        // 2.第一个时钟的，是还未开始   有预约时间
        // 3.第二个感叹号，是逾期 或者超时
        // 4.第四个勾是完成  对勾 是完成
        // 5.第五个没有icon，还未开始且未填写预约时间的节点
        // 二手房才是这样的大小
        renderNodelist: function () {
            var self = this,
                detail = self._G.taskDetailInfo,
                stageId = detail.stageId,  // 当前节点
                stageInfo = detail.stageInfo,               // 节点数据信息
                index = null,         // 当前节点的索引值
                curWeight = null,    // 当前节点的权重
                lastStageWeight = null;   // 最后一个节点的权重
            // 判断任务类型，确定是否需要滑动节点进度条
            // 渲染任务节点信息
            if (self.productType == C.Constant.BUSINESS_LINE.er) {
                // 二手房业务
                // 渲染任务节点信息
                self.stageUl.html(self.frame_nodelist_er(detail));
            } else {
                // 按揭和宅E贷业务
                // 渲染任务节点信息
                self.stageUl.parent().addClass('step-sm');
                self.stageUl.html(self.frame_nodelist(detail));
            }
            // 二手房，按揭新 按揭新新 节点大于4个可以滑动
            if (C.Constant.CANMOVESTAGE[self.productType] && stageInfo > 4) {
                self.moveNodelist();
            }
            //  定义li的高度，和ul一样，用来更改向上的箭头的样式
            self.stageUl.find('li').css('height', self.stageUl.height());
            // 宅e贷 按揭新 二手房可以滑动
            if (C.Constant.CANMOVESTAGE[self.productType] && (stageInfo.length > 4)) {
                // 按揭新绑定滑动任务进度节点事件
                self.moveNodelist();
            }
            // 判断当前活动节点之前节点样式
            // 判断等待客户和客户到达两个节点是否都为0，是的话直接渲染对应的这两个节点
            if (stageInfo[0]['stageTaskStatus'] == 0) {
                self.stageUl.find('li').eq(0).addClass('active active-wait active-arrow');
                // 虚拟节点的stageId
                self.cust.preStageId = stageInfo[0]['stageId'];
            } else if (stageInfo[1]['stageTaskStatus'] == 0) {
                self.stageUl.find('li').eq(0).addClass('finish');
                self.stageUl.find('li').eq(1).addClass('active active-wait active-arrow');
                // 虚拟节点的stageId
                self.cust.preStageId = stageInfo[1]['stageId'];
            } else {
                self.cust.preStageId = null;
                var info = self.getStageInfo(stageId, detail.appointInfo);
                for (var i = 0; i < stageInfo.length; i++) {
                    if (stageInfo[i].stageId == stageId) {
                        index = i;
                        if (info.havaAppointTime == 1) {
                            if (info.appointTime && info.appointDate) {
                                if ($('.js_dataState').data('code') == '2') {
                                    // 任务逾期
                                    self.stageUl.find('li').eq(i).addClass('active active-dh active-arrow');
                                    // 小于一小时 1   大于一小时 3
                                } else {
                                    self.stageUl.find('li').eq(i).addClass('active active-wait active-arrow');
                                }
                            } else {
                                // 需要有预约时间但是没有填写预约时间
                                self.stageUl.find('li').eq(i).addClass('active active-org active-arrow');
                            }
                        } else {
                            // TODO 没有预约时间且不需要预约时间的状态
                            self.stageUl.find('li').eq(i).addClass('active-arrow js_noState active active-wait');
                        }
                        if (C.Constant.CANMOVESTAGE[self.productType] && (stageInfo.length > 4)) {
                            // 当前节点应该显示应该显示的位置
                            var le = self.stageUl.find('li').eq(i).width();
                            self.stageUl.css('left', -le * (i - 1));
                            self._G.nodelistPosition.lastX = parseInt(self.stageUl.css('left'));
                        }
                    }
                }
                curWeight = self.stageUl.find('li').eq(index).data('weight');
                lastStageWeight = self.stageUl.find('li').eq(stageInfo.length - 1).data('weight');
                // 判断是否并行节点，渲染并行节点
                self.stageUl.find('li').each(function () {
                    var state = $(this).data('state');
                    // 如果是二手房、按揭新
                    if (self.productType == C.Constant.BUSINESS_LINE.er || self.productType == C.Constant.BUSINESS_LINE.anew) {
                        // 当前节点的权重等于其他节点的权重 为并行节点
                        if ($(this).data('weight') == curWeight) {
                            if (state == '0' && $(this).hasClass('active-org') || (state == '2')) {
                                $(this).removeClass('active-wait');
                            } else {
                                $(this).addClass('active-wait');
                            }
                        }
                    }
                    if (state == '1') {
                        $(this).addClass('finish').removeClass('active-wait');
                    }
                });
                // 如果当前节点的weight小于最后一个节点的权重  说明最后一个节点不是并行节点
                if (curWeight < lastStageWeight) {
                    self.stageLastState = false;
                }
            }
        },
        // 渲染任务头部信息
        renderDetailTop: function () {
            var self = this,
                detail = self._G.taskDetailInfo,            // 任务详情信息
                res = detail.detail,                        // 渲染页面数据
                stageId = detail.stageId,                   // 当前节点
                appointInfo = detail.appointInfo;           // 节点数据信息
            // 获取当前预约时间
            res.appointDate = '';
            res.appointTime = '';
            for (var i in detail.appointInfo) {
                if (detail.appointInfo[i]['stageId'] == stageId) {
                    res.appointDate = self.formatTimeType(detail.appointInfo[i]['appointDate'], 'spDate');
                    res.appointTime = self.formatTimeType(detail.appointInfo[i]['appointTime'], 'time');
                }
            }
            res.businessLine = C.Constant.BUSINESS_LINE_NAME[detail.productType]; // 业务线名称
            res.custName = res.custName || ''; // 用户名
            res.custPhone = res.custPhone? C.Utils.formatMobileNo(res.custPhone) : '';  // 电话
            res.houseDeptAddress = res.houseDeptAddress || '';  // 地址
            res.houseDeptName = res.houseDeptName || '';
            res.custGender = res.custGender || '';
            res.havaAppointTime = false;   // 有没有预约时间
            // 是否需要显示预约时间 true 需要 false 不需要
            res.showAppoint = true;
            // 判断是否有预约时间
            for (var i in appointInfo) {
                if (appointInfo[i].stageId == stageId) {
                    if (appointInfo[i]['havaAppointTime'] == '1') {
                        if (res.appointDate && res.appointTime) {
                            res.havaAppointTime = true;
                        }
                    } else {
                        // 不需要填写预约时间和修改预约时间
                        res.showAppoint = false;
                    }
                }
            }
            // 渲染用户的预约时间
            self.appointFrame.html(self.frame_detailTimeAppoint(res));
            // 宅e贷 并且roIsNew == 1 是新的订单 隐藏修改时间的按钮
            (detail.productType == 4) && (detail.roIsNew == 1) && $('.js_modifyTime').hide();
            //  渲染用户信息
            $('.js_detailTop').append(self.frame_detailTop(res));
        },

        // 渲染任务底部更多信息
        renderDetailBottom: function () {
            var self = this,
                detail = self._G.taskDetailInfo,            // 任务详情信息
                res = detail.detail;                        // 渲染页面数据
            res.orderId = detail.orderId;
            if (detail.productType == C.Constant.BUSINESS_LINE.er) {
                // 渲染二手房数据
                res.productType = '二手房';
                self.bottomDetail.html(self.frame_detailBottom(res));
            } else if (self.productType == C.Constant.BUSINESS_LINE.a) {
                // 渲染按揭数据
                // 没有共有产权人的时候 默认展示一个共有产权人
                if (!res.ownerList.length) {
                    res.ownerList = [{
                        ownerName: '',
                        ownerRatio: '',
                        ownerIdType: '',
                        ownerIdNo: ''
                    }];
                }
                res.ownLegTh = res.ownerList.length || '';
                self.bottomDetail.html(self.frame_detailAnBottom(res));
            } else if(self.productType == C.Constant.BUSINESS_LINE.zed){
                // 渲染宅e贷数据
                // 宅e贷的用户名和用户UM账号取的是detail同级的数据
                res.custService = res.custService || '';
                res.custServiceName = res.custServiceName || '';
                res.storeName = res.storeName || '';
                res.custName = res.custName || '';
                res.buildedYearDs = res.buildedYearDs || '';
                res.orderId = res.orderId || '';
                res.custPhone = res.custPhone || '';
                res.ownerName = res.ownerName || '';
                res.address = res.address || '';
                res.houseArea = res.houseArea || '';
                res.landSource = res.landSource || '';
                res.houseBuildedYear = res.houseBuildedYear || '';
                res.isPledge = res.isPledge || '';
                res.buildedYearDs = res.buildedYearDs || '';
                res.firstObligeeName = res.firstObligeeName || '';
                res.houseProperties = res.houseProperties || '';
                res.creFigure = res.creFigure || '';
                self.bottomDetail.html(self.frame_detailZhaiBottom(res));
            } else if(self.productType == C.Constant.BUSINESS_LINE.anew){
                // 渲染按揭（新）数据
                if (!res.arrivedStoreInfo.length) {
                    res.arrivedStoreInfo = [{
                        custName: '',
                        custPhone: '',
                        idType: '',
                        idCode: '',
                        relation: ''
                    }];
                }else{
                    $.each(res.arrivedStoreInfo,function(index,item){
                        res.arrivedStoreInfo[index].custPhone
                            = C.Utils.formatMobileNo(item.custPhone);
                    });
                }
                res.referralMobile = res.referralMobile ? C.Utils.formatMobileNo(res.referralMobile) : '';
                res.evaluationCompany = res.evaluationCompany || '';
                res.applyAmount = res.applyAmount || '';
                res.bankKinds = res.bankKinds || '';
                res.applyKinds = res.applyKinds || '';
                res.getCustomerWay = res.getCustomerWay || '';
                self.bottomDetail.html(self.frame_detailAnNewBottom(res));
            } else if (self.productType == C.Constant.AN_NEW_TYPE) {
                // 按揭新新的底部展示
                res.bankApplyCode = res.bankApplyCode || '';
                res.bizApplyAmount = res.bizApplyAmount || '';
                res.houseStore = res.houseStore || '';
                res.referralName = res.referralName || '';
                res.loanVariety = res.loanVariety || '';
                res.bargainPrice = res.bargainPrice || '';
                res.loanPlan = res.loanPlan || '';
                res.pubkicReserveApplyAmount = res.pubkicReserveApplyAmount || '';
                res.isAppointInsure = res.isAppointInsure || '';
                res.mortgageInsuranceLiability = res.mortgageInsuranceLiability || '';
                res.houseCertificateRegion = res.houseCertificateRegion || '';
                res.custName = res.custName || '';
                res.custCardType = res.custCardType || '';
                res.custCardId = res.custCardId || '';
                res.pawnList = res.pawnList || [];
                if (!res.pawnList.length) {
                    res.pawnList = [{
                        houseAddress: '',
                        estateType: '',
                        warrantCode: '',
                        houseArea: ''
                    }];
                }
                self.bottomDetail.html(self.frame_detailAnNewNewBottom(res));
            }
        },

        // 显示或隐藏更多详情
        changeDetailMore: function () {
            var el = $('.js_detailMore');
            if (el.hasClass('d-show')) {
                el.removeClass('d-show');
            } else {
                el.addClass('d-show');
            }
        },

        // 渲染图片区域数据
        renderPhotoArea: function () {
            var self = this,
                detail = self._G.taskDetailInfo,
                fileInfoData = self.removeRepeatData(detail.fileInfo); // 获取fileInfo的数据 做去重处理
            $('.js_photoNum').text('共' + fileInfoData.length + '张');
            $('.js_photoArea').html(self.frame_photoArea({fileInfo:fileInfoData}));
        },

        // 渲染底部按钮
        renderBottomBtn: function () {
            var self = this,
                detail = self._G.taskDetailInfo,
                fileStepTrue = false,  // 文件的步长是否存在 false不存在
                stageId = detail.stageId,  // 当前节点
                appointInfo = detail.appointInfo,     // 当前预约时间的节点
                stageInfo = detail.stageInfo;               // 节点数据信息
            // 渲染等待客户和客户到达
            if (stageInfo[0]['stageTaskStatus'] == 0) {
                $('.js_stepBtn').text(stageInfo[0].buttonName).attr('data-step', '3');
                // 在伪节点 和 他证 的时候不能异常处理 btn-no-click
                $('.js_abnormalBtn').addClass('btn-no-click');
                self.cust.btnName = stageInfo[0].buttonName;
            } else if (stageInfo[1]['stageTaskStatus'] == 0) {
                $('.js_stepBtn').text(stageInfo[1].buttonName).attr('data-step', '4');
                // 在伪节点的时候不能异常处理
                $('.js_abnormalBtn').addClass('btn-no-click');
                self.cust.btnName = stageInfo[1].buttonName;
            } else {
                // 他证上传节点
                if (stageId == self.RMCupload) {
                    $('.js_abnormalBtn').addClass('borderColor');
                }

                self.cust.btnName = null;
                $('.js_abnormalBtn').removeClass('btn-no-click');
                for (var i = 0; i < appointInfo.length; i++) {
                    if (appointInfo[i].stageId == stageId && appointInfo[i].step) {
                        fileStepTrue = true;
                    }
                }
                for (var j = 0; j < stageInfo.length; j++) {
                    if (stageInfo[j].stageId == stageId) {
                        if (self.isTransferMortgage(stageId) || stageInfo[j]['hasFileFlag'] == '0' || !fileStepTrue) {
                            $('.js_stepBtn').text(stageInfo[j].buttonName).attr('data-step', '1');
                        } else {
                            $('.js_stepBtn').text('文件上传').attr('data-step', '2');
                        }
                    }
                }
            }
        },

        // 渲染回退原因气泡，仅当前节点需要显示
        renderBackReasonTip: function(isHiden){
            var self = this,
                detail = self._G.taskDetailInfo,
                currStageId = detail.stageId,
                stageInfo = self.getStageInfo(currStageId, detail.stageInfo),
                backStageReason = stageInfo.backStageReason,
                backStageUserId = stageInfo.backStageUserId,
                stageTaskStatus = stageInfo.stageTaskStatus; //节点完成状态

            //未完成任务有回退原因、处理UM，显示回退原因，无回退原因不显示
            if( isHiden || !(backStageReason && backStageUserId) || stageTaskStatus == '1' ){
                self.backReasonPage.removeClass('task-time').html('');
            }else{
                var obj = {
                    backStageReason: backStageReason,
                    backStageUserId: backStageUserId
                };
                self.backReasonPage.removeClass('dn').addClass('task-time').html(self.frame_backReasonTip(obj));
            }

        },

        // 渲染时间气泡
        renderTaskTimeTip: function () {
            var self = this,
                detail = self._G.taskDetailInfo,
                currStageId = detail.stageId;  // 当前节点,
            // 调用本地时间和服务器时间，做对比，渲染时间气泡
            self.formatLocalTime(currStageId);
        },

        /**
         * 格式化时间
         */
        formatLocalTime: function (currStageId) {
            var self = this,
                appTime = null,
                time = null,
                timeObj = {},
                detail = self._G.taskDetailInfo,
                nowDateTime = self.objTime.time,
                stageInfo = self.getStageInfo(currStageId, detail.stageInfo),
                appointInfo = self.getStageInfo(currStageId, detail.appointInfo);
            if (appointInfo.havaAppointTime == '1') {
                if (appointInfo.appointTime && appointInfo.appointDate) {
                    appTime = new Date(appointInfo.appointDate.replace(/-/g, '/') + ' ' + appointInfo.appointTime).getTime();
                    appTime = parseInt((appTime - nowDateTime) / 1000);
                    if (appTime > 0) {
                        self.cust.overTime = false;
                        // 小于一小时 提示预约时间
                        if (appTime < 3600) {
                            time = self.getSeconds(appTime);
                            timeObj = {time: time, code: '1'};
                            self.timePage.removeClass('dn').addClass('task-time').html(self.frame_taskTimeTip(timeObj));
                        } else {
                            // 大于一小时
                            self.timePage.removeClass('task-time').attr('data-code', '3').html('');
                        }
                        // 用户更改完时间之后，只要获取到的时间大于0，说明用户更改了时间
                        C.Utils.data(C.Constant.DataKey.DETAIL_OVER_TIME, null);
                    } else {
                        // 逾期的任务
                        self.cust.overTime = true;
                        time = self.getSeconds(-appTime);
                        timeObj = {time: time, code: '2'};
                        self.timePage.removeClass('dn').addClass('task-time').html(self.frame_taskTimeWaitedTip(timeObj));
                    }
                } else {
                    self.cust.overTime = false;
                    // !self.cust.lastStage 的话 说明还不是最后一个节点，切换节点的时候最后一个节点不切换气泡提醒
                    if (!self.cust.lastStage) {
                        self.timePage.removeClass('dn').addClass('task-time').html(self.frame_taskTimeWaitTip({stageName: stageInfo.stageName}));
                    }
                }
            } else {
                self.cust.overTime = false;
                self.timePage.removeClass('task-time').html('');
            }
        },
        /**
         * 渲染二手房提示操作
         */
        renderGuider: function () {
            // 渲染当前节点客户操作指引
            var self = this,
                currStg = null,
                detail = self._G.taskDetailInfo,
                stageId = self.cust.preStageId || detail.stageId,   // 当前节点
                stageInfo = detail.stageInfo;    // 节点信息
            if (!C.Utils.data(C.Constant.DataKey.ENTER_STATE) && detail.productType == '1') {
                currStg = self.stageUl.find('li[data-code=' + stageId + ']');
                if (stageId == stageInfo[0]['stageId']) {
                    currStg.next().addClass('guide-li').prepend('<div class="guide-cir"> <div class="guide-inner"></div> </div>');
                } else {
                    currStg.addClass('guide-li').prepend('<div class="guide-cir"> <div class="guide-inner"></div> </div>');
                }
                $('.js_guideShow').removeClass('dn');
            }
        },
        /**
         * 关闭二手房提示操作
         */
        guideDetail: function () {
            var self = this,
                curStg = '',
                detail = self._G.taskDetailInfo,
                stageId = detail.stageId;  // 当前节点
            curStg = self.stageUl.find('li[data-code="' + stageId + '"]');
            $('.guide-cir').remove();
            curStg.removeClass('guide-li');
            $('.js_guideShow').addClass('dn');
        },
        // 渲染受影响任务列表
        renderAffectedList: function () {
            var self = this,
                detail = self._G.taskDetailInfo,
                stageId = detail.stageId,  // 当前节点
                cityId = self.cityId,    // 城市id
                orderId = self.orderId,  // 订单号
                productType = self.productType,     //业务类型
                json = {
                    api: C.Api('AFFECT_TASK'),
                    data: {
                        stageId: stageId,
                        productType: productType,
                        cityId: cityId,
                        orderId: orderId
                    }
                };
            var callback = function (data) {
                var data = data.data;
                // 如果无后续列表，正常处理
                if (data.length) {
                    // 已逾期
                    self.overTimeLayer.removeClass('dn');
                    $('html,body').addClass('ovfHiden');
                    self.formatAffectData(data);
                } else {
                    self.submitDeal();
                }
            };
            var errorCall = function (res) {
                // C.Native.tip(res.msg);
            };
            json.callback = callback;
            json.errorCall = errorCall;
            self.requestData(json);
        },

        /**
         * 格式化时间格式
         */
        formatTimeType: function (time, type) {
            if (!time) {
                return '';
            } else {
                if (type == 'time') {
                    time = time.split(':');
                    return time[0] + ':' + time[1];
                } else if (type == 'date') {
                    time = time.split('-');
                    return time[0] + '年' + time[1] + '月' + time[2] + '日';
                } else if (type == 'pasTime') {
                    time = time.split(':');
                    time[0] = parseInt(time[0]) < 10 ? '0' + parseInt(time[0]) : time[0];
                    return time[0] + ':' + time[1] + ':00';
                } else {
                    return time.split('-')
                }
            }
        },
        /**
         * 格式化受影响列表数据
         */
        formatAffectData: function (data) {
            var self = this,
                $html = [];
            $.each(data, function (index, item) {
                item.prdType = C.Constant.BUSINESS_LINE_NAME[item.productType];   // 业务线名称
                item.appointDate = item.appointDate ? C.Utils.parseDateFormat(item.appointDate, 'MM月dd日') : '';
                item.appointTime = self.formatTimeType(item.appointTime, 'time');
                $html.push(self.affect_task(item));
            });
            $('.js_affectTask').html($html.join(''));
        },
        // 显示或隐藏图片区域
        changePhotoArea: function (e) {
            var el = $('.js_photoArea'),
                btnEl = $(e.currentTarget);
            if (el.hasClass('dn')) {
                el.removeClass('dn');
                btnEl.text('隐藏全部');
            } else {
                el.addClass('dn');
                btnEl.text('查看全部');
            }
        },

        commShowModifyTime: function (curr, $el1, $el2, $el3) {
            var self = this,
                detail = self._G.taskDetailInfo,
                stageId = self.cust.stageId || detail.stageId,    // 当前节点或者切换的节点
                showDate = C.Utils.parseDateFormat(new Date(), 'yyyy-MM-dd'), // 保存当前的时间
                showTime = self.formatTime(),
                stageDetail = detail.detail;
            if (self.cust.preStageId) {
                stageId = detail.stageId;
            }
            if (!(curr && curr.hasClass('borderColor')) || !curr) {
                var info = self.getStageInfo(stageId, detail.appointInfo);
                // 有预约时间的时候直接显示预约时间
                if (info.appointDate && info.appointTime) {
                    showDate = info.appointDate.split('-');
                    showTime = info.appointTime.split(':');
                } else {
                    // 没有预约时间显示本地的时间
                    showDate = showDate.split('-');
                    showTime = showTime.split(':');
                }
                // 如果是按揭新的过户节点或是抵押节点
                if($el1.hasClass('js_estimateTime')){
                    var estimateTime = [];

                    if(stageId == self.Transfer){
                        //如果预约产证时间存在
                        if(stageDetail.propeCardRegTime){
                            estimateTime = stageDetail.propeCardRegTime.split('-');
                            $el1.data({'c1': estimateTime[0], 'c2': estimateTime[1], 'c3': estimateTime[2]}).text(estimateTime[0] + '年' + estimateTime[1] + '月' + estimateTime[2] + '日');
                        }else{
                            $el1.html('<span class="changeColor">请选择时间</span>').data({'c1':'','c2':'','c3':''});
                        }
                    }else if(stageId == self.Mortgage || stageId == self.Mortgage_7){
                        //如果预约他证时间存在
                        if(stageDetail.otherCardRegTime){
                            estimateTime = stageDetail.otherCardRegTime.split('-');
                            $el1.data({'c1': estimateTime[0], 'c2': estimateTime[1], 'c3': estimateTime[2]}).text(estimateTime[0] + '年' + estimateTime[1] + '月' + estimateTime[2] + '日');
                        }else{
                            $el1.html('<span class="changeColor">请选择时间</span>').data({'c1':'','c2':'','c3':''});
                        }
                    }
                }
                // 预约时间
                else {
                    // 调用native选择时间方法时，传入参数，直接显示
                    $el1.data({'c1': showDate[0], 'c2': showDate[1], 'c3': showDate[2]}).text(showDate[0] + '年' + showDate[1] + '月' + showDate[2] + '日');
                }
                if (!!$el2) {
                    $el2.data({'c1': showTime[0], 'c2': showTime[1]}).text(showTime[0] + ':' + showTime[1]);
                }
                $el3.removeClass('dn');
                $('html,body').addClass('ovfHiden');
            }
        },

        //获取可预约时间段
        getCanOrderTime: function(e){
            var self = this,
                detail = self._G.taskDetailInfo;
            if(self._G.canOrderTime){
                self.showModifyTime(e);
            }else{
                var cityId = self.cityId,    // 城市id
                    orderId = self.orderId,  // 订单号
                    productType = self.productType, //业务类型
                    stageId = self.cust.stageId || detail.stageId,    // 当前节点或者切换的节点
                json = {
                    api: C.Api('GET_ORDER_TIME'),
                    data: {
                        stageId: stageId,
                        cityId: cityId,
                        orderId: orderId,
                        productType: productType
                    }
                };
                var callback = function (data) {
                    var res = data.data,
                        canOrderTime = res.appointmentTimeRange;
                    self._G.canOrderTime = canOrderTime;

                    //显示更改预约时间弹窗
                    self.showModifyTime(e);
                };
                var errorCall = function (data) {
                };
                json.callback = callback;
                json.errorCall = errorCall;
                self.requestData(json);
            }
        },

        // 显示预计时间浮层
        showEstimateTime: function () {
            var self = this,
                curr = null,
                $el1 = self.estimateChoTime,
                $el2 = null,
                $el3 = self.annewLeayer;
            self.commShowModifyTime(curr, $el1, $el2, $el3);
        },

        // 隐藏预计时间浮层
        hideEstimateTime: function () {
            this.annewLeayer.addClass('dn');
            $('html,body').removeClass('ovfHiden');
        },


        // 显示修改预约时间浮层
        showModifyTime: function (e) {
            var self = this,
                curr = $(e.currentTarget),
                $el1 = self.chooseDate,
                $el2 = self.chooseTime,
                $el3 = self.modiTime;
            self.commShowModifyTime(curr, $el1, $el2, $el3);
        },

        // 隐藏修改预约时间浮层
        hideModifyTime: function () {
            $('.js_modifyTimeLeayer').addClass('dn');
            $('html,body').removeClass('ovfHiden');
        },
        /**
         * 返回当前日期的时间
         */
        formatTime: function () {
            var minute = Math.ceil(new Date().getMinutes() / 10) * 10, hour = new Date().getHours();
            minute = minute == 60 ? '00' : minute.toString();
            hour = minute == '00' && hour == 23 ? '00' : (minute == '00' ? (hour + 1).toString() : hour.toString());
            var showHour = hour.length == 2 ? hour : '0' + hour, showMinute = minute.length == 2 ? minute : '0' + minute;
            return showHour + ':' + showMinute;
        },
        // 隐藏任务异常处理
        hideAbnormalLeayer: function () {
            $('.js_abnormalLeayer').addClass('dn');
            $('html,body').removeClass('ovfHiden');
        },

        // 移动节点进度条
        moveNodelist: function () {
            var self = this;
            $('body').delegate('.js_nodelist', 'touchstart', function (e) {
                self._G.nodelistPosition.startX = e.targetTouches[0].clientX;
                self._G.nodelistPosition.startY = e.targetTouches[0].clientY;
            });
            $('body').delegate('.js_nodelist', 'touchmove', function (e) {
                e.preventDefault();
                var nodesWidth = parseFloat(self.stageUl.find('li').eq(0).css('width')) * self.stageUl.find('li').length,
                    changeX = self._G.nodelistPosition.lastX + e.targetTouches[0].clientX - self._G.nodelistPosition.startX;
                if (0 - changeX <= 0) {
                    self._G.nodelistPosition.changeX = 0;
                } else if (0 - changeX + parseFloat(self.stageUl.css('width')) >= nodesWidth) {
                    self._G.nodelistPosition.changeX = 0 - (nodesWidth - parseFloat(self.stageUl.css('width')));
                } else {
                    self._G.nodelistPosition.changeX = changeX;
                }
                self.stageUl.css('left', self._G.nodelistPosition.changeX);
            });
            $('body').delegate('.js_nodelist', 'touchend', function (e) {
                self._G.nodelistPosition.lastX = self._G.nodelistPosition.changeX;
            });
        },

        // 切换节点
        changeNode: function (e) {
            var self = this,
                detail = self._G.taskDetailInfo,
                el = $(e.currentTarget),
                stageId = el.data('code'),
                stageInfo = self.getStageInfo(stageId, detail.stageInfo),
                res = {};
            // 最后一个不是并行节点的节点点击时候不让气泡提醒
            self.cust.lastStage = false;
            // 如果是客户等待和客户到达，渲染的时间是当前节点的预约时间
            if (stageInfo.isVirtualStage == '1') {
                stageId = detail.stageId;
            }
            // 获取预约信息
            var appointInfo = self.getStageInfo(stageId, detail.appointInfo);
            res.appointDate = self.formatTimeType(appointInfo.appointDate, 'spDate');
            res.appointTime = self.formatTimeType(appointInfo.appointTime, 'time');
            res.havaAppointTime = false;
            res.showAppoint = true;
            if (appointInfo.stageId == stageId) {
                if (appointInfo.havaAppointTime == '1') {
                    if (res.appointDate && res.appointTime) {
                        // 需要有预约时间
                        res.havaAppointTime = true;
                    }
                } else {
                    // 不需要填写预约时间和修改预约时间
                    res.showAppoint = false;
                }
            }
            // 点击最后一个节点的时候，提示客户请完成之前的节点
            var curState = el.data('state'),
            // 最后一个节点
                lastNodeStage = detail.stageInfo[detail.stageInfo.length - 1];
            if (self.productType == C.Constant.BUSINESS_LINE.er && curState == '0' && lastNodeStage['stageId'] == el.data('code') && !self.stageLastState && !el.hasClass('active')) {
                $('.js_clickFinish').text('开始' + lastNodeStage['stageName'] + '任务前请确保其他节点已经全部完成');
                $('.js_placePrimary').removeClass('dn');
                // 最后一个节点不是并行节点时候点击气泡也不提醒
                self.cust.lastStage = true;
            }
            // 判断是否可点击
            if (el.hasClass('finish')) {
                // 渲染当前节点的气泡状态
                self.formatLocalTime(stageId);
                //渲染回退原因，非当前节点不需要显示
                self.renderBackReasonTip(true);

                // 已完成节点查看 按钮置灰不可点击
                el.addClass('active active-arrow').siblings().removeClass('active active-arrow');
                self.bottomBtnFrame.html(self.btn_fixedFinishBtn({buttonName: stageInfo.buttonName}));
                self.appointFrame.html(self.frame_detailTimeAppoint(res));
                self.timePage.removeClass('task-time').html('');
                $('.js_modifyTime').addClass('borderColor');
            } else if (el.hasClass('active-wait') || el.hasClass('active-org') || el.hasClass('active-dh') || el.hasClass('js_noState')) {
                // 保存当前切换节点的stageId 节点步骤处理的时候判断是不是切换了节点
                self.cust.stageId = el.data('code');

                // 渲染当前节点的气泡状态
                self.formatLocalTime(stageId);
                //渲染回退原因，非当前节点不需要显示
                self.renderBackReasonTip(stageId != detail.stageId);

                self.stageUl.find('li').removeClass('active active-arrow');
                if (res.showAppoint) {
                    if (self.cust.overTime) {
                        // 判断是否超时
                        el.addClass('active active-dh active-arrow');
                    } else {
                        if (!res.havaAppointTime) {
                            el.addClass('active active-arrow active-org').removeClass('active-wait');
                        } else {
                            el.addClass('active active-arrow active-wait');
                        }
                    }
                } else {
                    el.addClass('active-arrow active');
                }
                // 渲染底部按钮
                self.bottomBtnFrame.html(self.btn_fixedBtn());
                // 取消按钮置灰
                $('.js_modifyTime').removeClass('borderColor');
                if (self.backTrue == el.data('code')) {
                    // 如果是回退的，用全局定义的变量作对比，成功了，就显示文件上传
                    $('.js_stepBtn').text('文件上传').attr('data-step', '2');
                } else {
                    // 当前的并行节点
                    self.appointFrame.html(self.frame_detailTimeAppoint(res));
                    // 没有步长的话，走对话框提示确定下一步
                    if (!appointInfo.step) {
                        if (stageInfo.stageId == el.data('code')) {
                            $('.js_stepBtn').text(stageInfo.buttonName).attr('data-step', '1');
                        }
                    } else {
                        $('.js_stepBtn').text('文件上传').attr('data-step', '2');
                    }
                }
                if(self.isTransferMortgage(el.data('code'))){
                    $('.js_stepBtn').text(stageInfo.buttonName).attr('data-step', '1');
                }
            }
            // 宅e贷订单隐藏修改时间按钮
            detail.productType == 4 && $('.js_modifyTime').hide();
            if (el.siblings('li.active-org')) {
                el.siblings('li.active-org').addClass('active-wait').removeClass('active-org');
            }
            // 伪节点不能回退操作
            if (stageInfo.isVirtualStage == '1') {
                $('.js_abnormalBtn').addClass('btn-no-click');
            }
            // 他证节点不可回退操作
            if (stageId == self.RMCupload && el.hasClass('active')) {
                $('.js_abnormalBtn').addClass('borderColor');
            }
            // 二手房 按揭新 按揭新新可以滑动
            if (C.Constant.CANMOVESTAGE[self.productType] && detail.stageInfo.length > 4) {
                self._G.nodelistPosition.lastX = parseInt(self.stageUl.css('left'));
                self.moveNodelist();
            }
        },

        /**
         * 关闭未开始的节点
         */
        closeConfirmPlace: function () {
            $('.js_placePrimary').addClass('dn');
        },
        // 提交预约时间
        appointTime: function () {
            var self = this,
                taskId = C.Utils.data(C.Constant.DataKey.DETAIL_TASKID),    // 任务id
                detail = self._G.taskDetailInfo,                          // 任务详细信息
                appointmentDate = C.Utils.parseDateFormat(self.chooseDate.text(), 'yyyy-MM-dd'),       // 预约日期
                appointmentTime = self.formatTimeType(self.chooseTime.text(), 'pasTime'),      // 预约时间
                stageId = self.cust.stageId || detail.stageId;          // 节点id

            var json = {
                api: C.Api('ORDER_TIME'),
                data: {
                    appointmentDate: appointmentDate,                // 预约日期
                    appointmentTime: appointmentTime,                // 预约时间
                    appointmentType: '1',                // 预约类型。0表示立即预约，不传预约时间。1表示有预约时间
                    orderId: taskId,                    // 订单任务id
                    stageId: stageId,     // 订单任务节点id
                    productType: detail.productType// 订单任务业务类型
                }
            };
            var callback = function (data) {
                if (self.cust.preStageId) {
                    stageId = detail.stageId;
                } else {
                    stageId = self.cust.stageId || detail.stageId;
                }
                C.Utils.data(C.Constant.DataKey.DETAIL_STAGEID, stageId);
                location.reload();
            };
            var errorCall = function () {
                C.Native.tip('提交出错');
            };
            json.callback = callback;
            json.errorCall = errorCall;
            self.requestData(json);
        },

        // 判断是否有受影响列表
        dealStep: function () {
            // 根据节点步骤判断是否文件上传
            var self = this,
                detail = self._G.taskDetailInfo,
                firstStageStatus = detail.stageInfo[0]['stageTaskStatus'];
            // 判断是否逾期 $('.js_dataState').data('code') == '2'
            if (($('.js_dataState').data('code') == '2') && !self._G.showOverDueFocus && $('.js_stepBtn').data('step') != '2' ) {
                // 渲染受影响任务列表
                self.renderAffectedList();
            } else {
                self.submitDeal();
            }
        },
        /**
         * 节点提交显示dialog
         */
        submitDeal: function () {
            var self = this,
                detail = self._G.taskDetailInfo,
                stageId = self.cust.stageId || detail.stageId,  // 当前节点
                appointInfo = self.getStageInfo(stageId, detail.appointInfo),
                stageInfo = self.getStageInfo(stageId, detail.stageInfo);
            // 等待客户
            if ($('.js_stepBtn').data('step') == '3') {
                $('.js_sureDeal').text('确定');
                self.sureStageName.text('确认' + self.cust.btnName);
                self.dealStepOne();
            } else if ($('.js_stepBtn').data('step') == '4') {
                $('.js_sureDeal').text('确定');
                self.sureStageName.text('确认客户资料齐全可以' + self.cust.btnName);
                self.dealStepOne();
            } else {
                self.sureStageName.text('确认' + stageInfo.stageName + '处理完成');

                // 在过户和回执上传节点的时候
                if (self.isTransferMortgage(stageId)) {
                    if (stageId == self.Transfer) {
                        $('.js_estimatePRD').removeClass('dn').siblings().eq(0).addClass('dn');
                    }else{
                        $('.js_estimateRMC').removeClass('dn').siblings().eq(0).addClass('dn');
                    }
                }
                //  判断是否需要有预约时间 有了的话，判断时间是否存在不存在，不存在，让客户填写预约时间，存在，直接处理
                if (appointInfo.havaAppointTime == '1') {
                    if ((appointInfo.appointDate && appointInfo.appointTime) || ($('.js_hasDate').text() && $('.js_hasTime').text())) {
                        // 节点处理
                        self.stageHandle();
                    } else {
                        // 没有预约时间，提示用户填写预约时间
                        self.hasNoAppoint();
                    }
                } else {
                    self.stageHandle();
                }
            }
        },
        /**
         * 节点处理
         */
        stageHandle: function () {
            var self = this;
            if ($('.js_stepBtn').data('step') == '2') {
                // 文件上传
                $('.js_sureDeal').text('确定并上传文件');
                self.dealStepTwo();
                self.timePage.removeClass('task-time').html('');
            } else {
                // 其他操作
                $('.js_sureDeal').text('确定');
                self.dealStepOne();
            }
        },

        // 节点处理步骤一
        dealStepOne: function () {
            var self = this,
                detail = self._G.taskDetailInfo,
                stageId = self.cust.preStageId || self.cust.stageId || detail.stageId;  // 当前节点
            if(self.isTransferMortgage(stageId)){
                self.showEstimateTime();
            }else{
                self.showDealLeayer();
            }
        },

        /**
         * 没有填写预约时间
         */
        hasNoAppoint: function () {
            $('.js_emptyTimeLeayer').removeClass('dn');
        },
        /**
         * 没有预约时间确定
         */
        noTimeAppoint: function () {
            $('.js_emptyTimeLeayer').addClass('dn');
        },
        // 节点处理步骤二——文件上传
        dealStepTwo: function () {
            var self = this,
                detail = self._G.taskDetailInfo,
                stageId = self.cust.stageId || detail.stageId,  // 当前节点
                cityId = self.cityId,
                orderId = self.orderId,
                fileConfig = detail.fileConfig,
                fileList = new Array(),
                fileTypes = new Array(),
                fileInfo = detail.fileInfo,
                productType = detail.productType,
                stageInputInfo = self._G.taskDetailInfo.stageInputInfo || {},
                stageInfo = self.getStageInfo(stageId, detail.stageInfo),
                configStageId = stageId,  // 保存节点Id
                data = {
                    orderId: orderId,
                    stageId: stageId,
                    productType: productType,
                    cityId: cityId
                };
            fileInfo = (productType == C.Constant.BUSINESS_LINE.zed) ? self.removeRepeatData(fileInfo, true) : fileInfo; // 针对宅e贷做图片去重
            stageId = ((productType == C.Constant.BUSINESS_LINE.zed) && (stageId == this.HandleUploadBack)) ? this.HandleUpload : stageId; // 宅e贷的产调节点是虚拟节点需要用回执节点的节点Id查找照片和配置
            if (stageInfo.stageTaskStatus == '0') {
                for (var i = 0; i < fileInfo.length; i++) {
                    if (fileInfo[i].stageId == stageId) {
                        var obj = {};
                        obj.fileUrl = fileInfo[i].fileUrl;
                        obj.fileId = fileInfo[i].fileId;
                        obj.page = fileInfo[i].page;
                        obj.fileTypeId = fileInfo[i].fileTypeId;
                        fileList.push(obj);
                    }
                }
            }
            for (var i = 0; i < fileConfig.length; i++) {
                if (fileConfig[i]['stageId'] == configStageId) {

                    var obj = {
                        fileType: fileConfig[i]['fileTypeName'],
                        fileTypeId: fileConfig[i]['fileTypeId'],
                        need: fileConfig[i]['isNeed']
                    };
                    var objFile = [];
                    for (var j in fileList) {
                        if (fileList[j]['fileTypeId'] == obj.fileTypeId) {
                            delete fileList[j]['fileTypeId'];
                            objFile.push(fileList[j]);
                        }
                    }
                    obj.fileList = objFile;
                    fileTypes.push(obj);
                }
            }
            data.types = fileTypes;
            if(productType == C.Constant.BUSINESS_LINE.zed) {
                data.stageInputInfo = {
                    receiptId: stageInputInfo.receiptId? stageInputInfo.receiptId : '',
                    cardId: stageInputInfo.cardId?stageInputInfo.cardId: '',
                    cardRegisterTime: stageInputInfo.cardRegisterTime?stageInputInfo.cardRegisterTime: ''
                };
                data.loanInfo = {
                    loanConditionList: detail.detail.loanConditionList,
                    loanConditionType: detail.detail.loanConditionType,
                    loanCondition: detail.detail.loanCondition
                };
                data.nextAppointInfo = detail.nextAppointInfo || {};
                data.roIsNew = detail.roIsNew;  // 0 旧的订单 1 新的订单
                data.taskContent = stageInfo.taskContent || ''; // 切换后节点的taskContent
                C.Utils.data(C.Constant.DataKey.IS_RO_NEW, detail.roIsNew);  // 保存校验是否是存量订单
                C.Native.upLoadImageE(data);   // 宅e贷节点
            } else {
                C.Native.upLoadImage(data);
            }
        },

        // 显示异常处理浮层
        showAbnormal: function (e) {
            var self = this,
                curr = $(e.currentTarget),
                detail = self._G.taskDetailInfo,
                productType = detail.productType,
                orderId = self.orderId,
                stageId = self.cust.stageId || detail.stageId;  // 当前节点;
            if (curr.hasClass('borderColor')) {
                return;
            }
            if (!curr.hasClass('btn-no-click')) {
                $('.js_abnormalLeayer').removeClass('dn');
                $('.btn-ilb .active').css('width', '85%');
                $('html,body').addClass('ovfHiden');
                // 请求后台异常原因
                var json = {
                        api: C.Api('GET_REASON_LIST'),
                        data: {
                            stageId: stageId,
                            orderId: orderId,
                            productType: productType
                        }
                    };
                var callback = function (data) {
                    data = data.data;
                    C.Utils.data(C.Constant.DataKey.DETAIL_BACK_REASON, data);
                    if (data.length) {
                        var reasonId = data[0]['reasonId'],
                            reasonContent = data[0]['reasonContent'];
                        $('.js_backReasonText').attr('data-key', reasonId).html(reasonContent);
                    }
                };
                var errorCall = function () {
                };
                json.callback = callback;
                json.errorCall = errorCall;
                self.requestData(json);
            } else {
                C.Native.tip('等待客户和客户到达不能回退操作');
            }
        },

        // 预览图片
        prevImg: function (e) {
            var el = $(e.currentTarget).children('img');
            C.Native.previewImage(el.attr('src'), el.attr('data-fileid'), el.attr('data-page'));
        },

        // 修改浮层预约日期   outDate 1 不可以选择之前的日期  0 可以选择之前的日期
        modifyPopDate: function (e) {
            var self = this,
                isReserve = !($(e.currentTarget).hasClass('js_cardIdTime') || $(e.currentTarget).hasClass('js_estimateTime')),
                defaultValue = '',
                curr  = !isReserve ? $(e.currentTarget):$(e.currentTarget).find('span').eq(0),
                outDate = !isReserve ? '0' : '1',
                text = curr.text(),
                c1 = curr.data('c1'),
                c2 = curr.data('c2'),
                c3 = curr.data('c3');
            if (text && c1 && c2 && c3) {
                defaultValue = {
                    c1: c1,
                    c2: c2,
                    c3: c3
                }
            }
            C.Native.selectDateTime({
                defaultValue: defaultValue,
                title: '选择日期',
                type: 'date',
                timeRange: self._G.canOrderTime || '',
                outDate: outDate,
                callback: function (res) {
                    if (res.code == '0') {
                        curr.text(res.selectResult.c1 + '年' + res.selectResult.c2 + '月' + res.selectResult.c3 + '日').data({'c1':res.selectResult.c1,'c2':res.selectResult.c2,'c3':res.selectResult.c3});
                    }
                }
            })
        },
        // 清除他证登记日期
        clearDateText: function(e){
            var curr = $(e.currentTarget).siblings();
            curr.html('<span class="changeColor">请选择时间</span>').data({'c1':'','c2':'','c3':''});
        },
        // 修改浮层预约时间
        modifyPopTime: function (e) {
            var self = this,
                defaultValue = '',
                currTime = null,
                $el = $(e.currentTarget).find('span').eq(0),
                text = $el.text(),
                c1 = $el.data('c1'),
                c2 = $el.data('c2');
            if (text && c1 && c2) {
                defaultValue = {
                    c1: c1,
                    c2: c2
                }
            }
            if (!defaultValue) {
                currTime = self.formatTime().split(':');
                defaultValue = {
                    c1: currTime[0],
                    c2: currTime[1]
                }
            }
            C.Native.selectDateTime({
                defaultValue: defaultValue,
                title: '选择时间',
                type: 'time',
                timeRange: self._G.canOrderTime,
                callback: function (res) {
                    if (res.code == '0') {
                        $el.text(res.selectResult.c1 + ':' + res.selectResult.c2).data({'c1': res.selectResult.c1,'c2': res.selectResult.c2});
                    }
                }
            })
        },

        // 选择任务异常处理退回类型
        chooseBackType: function (e) {
            var self = this,
                showDate = C.Utils.parseDateFormat(new Date(), 'yyyy-MM-dd'), // 保存当前的时间
                showTime = self.formatTime();
            $(e.currentTarget).addClass('active').siblings().removeClass('active');
            // 回退类型为回退门店的时候 data-type= backShopSubmit，隐藏，否则显示
            if (($('.js_backType.active').data('type')) == 'backShopSubmit') {
                $('.js_showOrHide').addClass('dn');
            } else {
                showDate = showDate.split('-');
                showTime = showTime.split(':');
                // 调用native选择时间方法时，传入参数，直接显示
                self.chooseDate.data({'c1': showDate[0], 'c2': showDate[1], 'c3': showDate[2]}).text(showDate[0] + '年' + showDate[1] + '月' + showDate[2] + '日');
                self.chooseTime.data({'c1': showTime[0], 'c2': showTime[1]}).text(showTime[0] + ':' + showTime[1]);
                $('.js_showOrHide').removeClass('dn');
            }
        },

        // 选择任务异常处理退回原因
        chooseBackReason: function (e) {
            var self = this,
                backReason = C.Utils.data(C.Constant.DataKey.DETAIL_BACK_REASON),
                newReason = new Array(),
                defaultValue = '';
            for (var i in backReason) {
                var tmpObj = {
                    key: backReason[i]['reasonId'],
                    value: backReason[i]['reasonContent']
                };
                newReason.push(tmpObj);
            }
            var key = self.backReasonIpt.data('key'),
                text = self.backReasonIpt.text();
            if (key && text) {
                defaultValue = {
                    value: text,
                    key: key
                }
            }
            C.Native.showPicker({
                defaultValue: defaultValue,
                data: newReason,
                title: '选择原因',
                callback: function (res) {
                    if (res.code == '0') {
                        self.backReasonIpt.text(res.selectResult.value).data('key', res.selectResult.key);
                    }
                }
            });
        },

        // 异常任务处理提交
        sureAbnoremal: function () {
            var self = this,
                cityId = self.cityId,    // 城市id
                detail = self._G.taskDetailInfo,                            // 任务详情信息
                handleType = $('.js_backType.active').data('type'),        // 回退类型
                orderId = self.orderId, // 订单id
                reasonId = self.backReasonIpt.data('key'),           // 回退原因id
                reasonContent = self.backReasonIpt.text(),           // 回退原因内容
                appointmentDate = C.Utils.parseDateFormat(self.chooseDate.text(), 'yyyy-MM-dd'),       // 预约日期
                appointmentTime = self.formatTimeType(self.chooseTime.text(), 'pasTime'),       // 预约时间
                fileTypeId = detail.fileInfo,           // 保存图片信息
                fileAry = new Array(),
                stageId = self.cust.stageId || detail.stageId, // 当前节点
                clearHandleInfo = '';
            if (stageId == self.HandleUploadBack) {
                stageId = self.HandleUpload;  // 如果是HandleUpload_4_C 的话  用 HandleUpload_4 上传
                clearHandleInfo = self.HandleUploadBack; // 保存需要被赋值的回执上传节点供清除本地照片使用
            }
            var json = {
                api: C.Api('SUBMIT_UNDONE_TASK'),
                data: {
                    productType: detail.productType,
                    orderId: orderId,
                    stageId: stageId,
                    handleType: handleType,
                    reasonId: reasonId,
                    appointmentDate: appointmentDate || '',  // 选择时间和日期后用全局的变量保存
                    appointmentTime: appointmentTime || '',
                    reasonContent: reasonContent,
                    cityId: cityId
                }
            };
            if (!reasonContent) {
                C.Native.tip('回退原因不能为空');
                return;
            }
            for (var i in fileTypeId) {
                if (fileTypeId[i]['stageId'] == stageId) {
                    fileAry.push(fileTypeId[i]);
                }
            }
            // 提供给native 清除本地的图片
            var fileObj = {
                orderId: orderId,
                stageId: clearHandleInfo || stageId,
                fileTypeId: fileTypeId
            };
            var callback = function (data) {
                data = data.data || {};
                var businessCode = data.businessCode,
                    businessMegs = data.businessMegs;
                // 如果ro离职的话 businessCode=0 提示信息
                if (handleType == 'backHeadmanSubmit' && businessCode == '0') {
                    C.Native.tip(businessMegs);
                } else {
                    C.Native.clearCache(fileObj);   // 清除Native保存的照片
                    C.Utils.data(C.Constant.DataKey.DETAIL_STAGEID, stageId);
                    C.Native.tip('操作成功');
                    C.Native.back({
                        url: 'home.html'
                    });
                }
            };
            var errorCall = function (res) {
                // C.Native.tip(res.msg);
            };
            json.callback = callback;
            json.errorCall = errorCall;
            self.requestData(json);
        },

        // 显示处理确认层
        showDealLeayer: function () {
            this.layerDealDialog.removeClass('dn');
            $('html,body').removeClass('ovfHiden');
        },

        // 隐藏处理确认层
        hideCloseDealLeayer: function () {
            this.layerDealDialog.addClass('dn');
            $('html,body').removeClass('ovfHiden');
        },
        // 浮层处理节点
        sureDeal: function () {
            var self = this,
                fileList = new Array(),
                taskId = self.orderId,
                cityId = self.cityId,
                detail = self._G.taskDetailInfo,
                // 取当前节点活动节点的stageId self.cust.preStageId(虚拟节点的stageId)
                stageId = self.cust.preStageId || self.cust.stageId || detail.stageId,
                curStageInfo = self.getStageInfo(stageId, detail.stageInfo),
                stepName = self.cust.btnName || curStageInfo['stageName'],
                appointInfo = self.getStageInfo(stageId, detail.appointInfo),
                productType = detail.productType,
                estimateChoseTime = self.estimateChoTime.text()!='请选择时间' ? C.Utils.parseDateFormat(self.estimateChoTime.text(), 'yyyy-MM-dd'):'',  //预计时间
                fileInfo = self.getStageInfo(stageId, detail.fileInfo);

            var json = {
                    api: C.Api('SUBMIT_TASK_STAGE'),
                    data: {
                        orderId: taskId,
                        stageId: stageId,
                        productType: productType,
                        stepName: stepName,
                        cityId: cityId
                    }
                };

            // 如果是过户TransferManagement或抵押MortgageManagement的节点 走按揭新预计时间接口提交
            var json3 = {
                api: C.Api('ANEW_STAGE_SUBMIT'),
                data: {
                    orderId: taskId,
                    stageId: stageId,
                    productType: productType,
                    type: stageId == self.Transfer? '1' : '2'
                }
            };

            var regTimeInfo = stageId == self.Transfer? { propeCardRegTime: estimateChoseTime } :{otherCardRegTime: estimateChoseTime};
            $.extend(json3.data,regTimeInfo);

            if (curStageInfo.stageTaskStatus == '0') {
                for (var i = 0; i < fileInfo.length; i++) {
                    if (fileInfo[i].stageId == stageId) {
                        var obj = {};
                        obj.fileTypeId = fileInfo[i].fileTypeId;
                        obj.fileId = fileInfo[i].fileId;
                        fileList.push(obj);
                    }
                }
            }
            var json1 = {
                api: C.Api('SUBMIT_STAGE'),
                data: {
                    orderId: taskId,
                    stageId: stageId,
                    productType: productType,
                    cityId: cityId,
                    fileList: fileList
                }
            };
            var callback = function (data) {
                // 隐藏后续任务列表
                self.closeOverdueLeayer();
                if (curStageInfo.isVirtualStage == '1') {
                    if (curStageInfo.stageId == 'waitCust') {
                        stageId = detail.stageId;
                    } else {
                        stageId = detail.stageInfo[2]['stageId'];
                    }
                    // 如果是在等待客户和客户到达节点的话，点击确定，重新加载页面
                    location.reload();
                } else {
                    self.backTrue = stageId;
                    // 如果不是过户办理节点的话
                    if(!self.isTransferMortgage(stageId)){
                        // 隐藏处理浮层
                        self.hideCloseDealLeayer();
                        $('.js_stepBtn').text('文件上传').attr('data-step', '2');
                        self.timePage.removeClass('task-time').html('');
                    }
                    // 文件上传
                    self.dealStepTwo();
                }
                // 保存当前节点作为下一个虚拟节点的入参
                C.Utils.data(C.Constant.DataKey.DETAIL_STAGEID, stageId);
            };
            var errorCall = function () {
            };
            var callback1 = function (data) {
                // 隐藏后续任务列表
                self.closeOverdueLeayer();
                // 隐藏处理浮层
                self.hideCloseDealLeayer();
                // 保存当前节点作为下一个虚拟节点的入参
                //  C.Utils.data(C.Constant.DataKey.DETAIL_STAGEID, stageId);
                var taskStatus = data.data.taskStatus,
                    isRoStage = data.data.isRoStage,  // 下一个节点是否是客服正在处理的节点
                    stageInfo = data.data.stageInfo;
                // 不需要文件上传的，直接到提交成功的界面
                C.Native.forward({
                    data: {
                        cityId: cityId,
                        orderId: taskId,
                        productType: productType,
                        taskStatus: taskStatus,
                        isRoStage: isRoStage,
                        stageInfo: JSON.stringify(stageInfo)
                    },
                    url: 'detail-suc.html'
                });
                if(App.IS_LOCAL){
                    C.Native.forward({
                        url: 'detail-suc.html?cistId='+cityId+'&orderId='+orderId+'&productType='+productType+'&taskStatus='+taskStatus+'&isRoStage='+isRoStage+'&stageInfo='+JSON.stringify(stageInfo)
                    });
                }

            };
            var errorCall1 = function () {
            };

            var callback3 = function(data){
                // 手动加入预计时间
                if(stageId == self.Transfer){
                    self._G.taskDetailInfo.detail.propeCardRegTime = estimateChoseTime;
                }else if(stageId == self.Mortgage || stageId == self.Mortgage_7){
                    self._G.taskDetailInfo.detail.otherCardRegTime = estimateChoseTime;
                }

                if (curStageInfo.hasFileFlag == '1') {
                    // 需要上传文件的调用节点步骤提交
                    self.requestData(json, true, false);
                } else {
                    // 不需要上传文件的调用节点文件信息提交
                    self.requestData(json1, true, false);
                }
            };
            var errorCall3 = function(){
            };

            json.callback = callback;
            json.errorCall = errorCall;
            json1.callback = callback1;
            json1.errorCall = errorCall1;
            json3.callback = callback3;
            json3.errorCall = errorCall3;

            // 如果是过户办理和抵押办理的节点 走过户、抵押的接口提交
            if(self.isTransferMortgage(stageId)){
                self.requestData(json3, false, true);
            } else {
                // 当前节点是否需要上传文件hasFileFlag：1 上传  0 不需要上传 伪节点走节点步骤提交
                if (curStageInfo.hasFileFlag == '1' || curStageInfo.isVirtualStage == '1') {
                    // 走节点步骤提交
                    self.requestData(json);
                } else {
                    // 走节点信息提交
                    var zhaiData = {
                        loanConditionType: detail.detail.loanConditionType,
                        loanCondition: detail.detail.loanCondition,
                        appointTime: appointInfo.appointTime,
                        appointDay: appointInfo.appointDate,
                        taskContent: curStageInfo.taskContent
                    };
                    if (productType == C.Constant.BUSINESS_LINE.zed) {
                        json1.api = C.Api('ZHAI_FILE_SUBMIT');
                        $.extend(json1.data, zhaiData);
                    }
                    self.requestData(json1);
                }
            }
         },

        // 根据节点ID获取节点信息
        getStageInfo: function (id, stageList) {
            var res = {};
            for (var i in stageList) {
                if (stageList[i]['stageId'] == id) {
                    res = stageList[i];
                }
            }
            return res;
        },

        // 隐藏逾期浮层
        closeOverdueLeayer: function () {
            this.overTimeLayer.addClass('dn');
            $('html,body').removeClass('ovfHiden');
        },

        //关闭任务被改派提示框
        closeTaskChange: function(){
            var self = this,
                url = null,
                code = C.Utils.getParameter('data');
            if (code) {
                C.Utils.data(C.Constant.DataKey.ELSE_TASK_STATUS, code);
                url = 'mytask.html'
            } else {
                C.Utils.data(C.Constant.DataKey.ELSE_TASK_STATUS, null);
                url = 'home.html'
            }

            C.Native.back({
                url: url
            });
        },

        // 逾期任务确认并继续
        sureOverdue: function () {
            var self = this,
                detail = self._G.taskDetailInfo,
            // 取当前节点活动节点的stageId self.cust.preStageId(虚拟节点的stageId)
                stageId = self.cust.preStageId || self.cust.stageId || detail.stageId;
            // 如果节点是过户或者办押
            if (self.isTransferMortgage(stageId)) {
                // 关闭逾期列表对话框
                self.overTimeLayer.addClass('dn');

                //通过节点显示对应文字
                if (stageId == self.Transfer) {
                    $('.js_estimatePRD').removeClass('dn').siblings().eq(0).addClass('dn');
                }else{
                    $('.js_estimateRMC').removeClass('dn').siblings().eq(0).addClass('dn');
                }
                // 过户或者办押的对话框打开
                self.showEstimateTime();
            } else {
                self.sureDeal();
            }
        },

        // 跳转至受影响任务
        gotoEffectNode: function (e) {
            var taskId = $(e.currentTarget).data('id'),
                cityId = $(e.currentTarget).data('cityid'),
                stageId = $(e.currentTarget).data('stageid'),
                productType = $(e.currentTarget).data('producttype');
            C.Utils.data(C.Constant.DataKey.DETAIL_TASKID, taskId);
            C.Utils.data(C.Constant.DataKey.DETAIL_CITYID, cityId);
            C.Utils.data(C.Constant.DataKey.DETAIL_STAGEID, stageId);
            C.Utils.data(C.Constant.DataKey.DETAIL_PRODUCTTYPE, productType);
            C.Native.forwardInCurPage({
                url: 'task_detail.html'
            });
        },

        // 拨打电话
        doCall: function (e) {
            var phone = e.currentTarget.innerText;
            C.Native.call(C.Utils.removeSpace(phone));
        }
    }));

    $(function () {
        new Page({
            el: $('html,body')[0]
        });
        $$.EventListener.onBack = function () {
            if(C.Utils.data(C.Constant.DataKey.DETAIL_PRODUCTTYPE) == '4' || C.Utils.data(C.Constant.DataKey.SUCCESS_BACK)){
                C.Utils.data(C.Constant.DataKey.SUCCESS_BACK,false);
                location.reload();
            }
        }
    })
});
