/*
 *
 * By jinmengjie107 2016-04-29
 *
 */
define(['zepto', 'C', 'view', 'iscroll'], function ($, C, View) {
    'use strict';
    //垂直滚动
    var VScrollView = {
        ScrollEle: '',
        ScrollOptions: {
            hScroll: false, //是否水平滚动
            hScrollbar: false,
            vScroll: true, //是否垂直滚动
            vScrollbar: false,
            bounce: true, //是否超过实际位置反弹
            bounceLock: false, //当内容少于滚动是否可以反弹，这个实际用处不大
            lockDirection: true, //当水平滚动和垂直滚动同时生效时，当拖动开始是否锁定另一边的拖动
            topOffset: 0, //起始位置
            //momentum: true, //动量效果，拖动惯性
            checkDOMChanges: false, //是否自动检测内容变化
            zoom: false, //默认是否放大
            hideScrollbar: true, //是否隐藏滚动条
            //            useTransform: true, //是否使用CSS形变
            //            useTransition: false, //是否使用CSS变换
            wheelAction: 'scroll', //鼠标滚动行为（还可以是zoom）
            onRefresh: null, //refresh 的回调，关于自身何时调用refresh 后面会继续谈到
            onBeforeScrollStart: function(e) { //开始滚动前的时间回调，默认是阻止浏览器默认行为
                var target = e.target;
                while (target.nodeType != 1) target = target.parentNode;
                if (target.tagName != 'SELECT' && target.tagName != 'INPUT' && target.tagName != 'TEXTAREA' && target.tagName != 'BUTTON') {
                    e.preventDefault();
                }
            },
            onScrollStart: null, //开始滚动的回调
            onBeforeScrollMove: null, //在内容移动前的回调
            onScrollMove: null, //内容移动的回调
            onBeforeScrollEnd: null, //在滚动结束前的回调
            onScrollEnd: null, //在滚动完成后的回调
            onTouchEnd: null, //手离开屏幕后的回调
            onDestroy: null, //销毁实例的回调
            onZoomStart: null,
            onZoom: null,
            onZoomEnd: null
        },
        initScroll: function(opt) {
            var $this = this,
                newOpt = {},
                newOpt = $.extend({}, this.ScrollOptions, opt),
                el = (typeof this.ScrollEle === "string") ? $(this.ScrollEle).get(0) : this.ScrollEle;
            if(!iScroll){ return; }
            $this.Scroll = new iScroll(el, newOpt);
            $this.refreshScroll();
            return $this;
        },
        refreshScroll: function() {
            this.Scroll.refresh();
        }
    };
    //水平滚动
    var HScrollView = $.extend({}, VScrollView, {
        ScrollOptions: $.extend({}, VScrollView.ScrollOptions, {
            hScroll: true,
            vScroll: false,
            bounceLock: false,
            lockDirection: true
        })
    });

    var scrollView = $.extend({}, VScrollView, {
        install: function(h){
            var $this = this, $tabCon = $('.js-tab-con'),$wrapper = $('.js-panel');
            var height = h ? h+'PX' : '100%';
            $this.$el = $tabCon;

            $this.Scroll && $this.Scroll.destroy();
            if (h) {
                $wrapper.css({ "height":height });
                // $this.ScrollEle = $tabCon.get(0);
            } else {
                $wrapper.css({ "height":height, "width":"100%", "position":"absolute" });
                // $this.ScrollEle = $tabCon.get(0);
            }
            $this.ScrollEle = $wrapper.get(0);
            $this.ScrollOptions && _.isFunction($this.ScrollOptions) && ($this.ScrollOptions = $this.ScrollOptions.call($this));
            $this.initScroll.call($this);
            $this.refreshScroll();

            //$this.currentViewOpts = $.extend({}, $this, opt);
        },
        /* -------- 滚动属性 --------- */
        pullDownActionBase: function() {
            var $this = this;
            //$this.currentViewOpts.pullDownAction();
        },
        pullUpActionBase: function() {
            var $this = this;
            //$this.currentViewOpts.pullUpAction();
        },
        refreshScroll: function() {
            var $this = this;
            if(!$this.Scroll) return;
            $this.Scroll.refresh();
        },
        ScrollOptions: function() {
            var $this = this;
            var newOpt = $.extend({}, VScrollView.ScrollOptions);
            var pullDownEl = $('#pullDown',$this.$el);
            var pullDownOffset = pullDownEl.height();
            var pullUpEl = $('#pullUp',$this.$el);
            var pullUpOffset = pullUpEl.height();
            newOpt.topOffset = pullDownOffset;
            newOpt.onRefresh = function() {
                if (pullDownEl.hasClass('virtual')) {
                    pullDownEl.removeAttr('class');
                    pullDownEl.hide();
                } else if (pullUpEl.hasClass('virtual')) {
                    // console.log(this.maxScrollY,'=VIEW==>',pullUpOffset,'===onRefresh   >>',this.y);
                    pullUpEl.removeAttr('class');
                    pullUpEl.hide();
                }
            };
            newOpt.onScrollStart = function() {};
            newOpt.onScrollMove = function() {
                if (this.y > pullUpOffset && !pullDownEl.hasClass('virtual') && !pullUpEl.hasClass('virtual')) {
                    pullDownEl.show();
                    pullDownEl.attr('class', 'virtual');
                    this.minScrollY = 0;
                }else if (this.y < pullUpOffset && pullDownEl.hasClass('virtual')) {
                    pullDownEl.hide();
                    pullDownEl.removeAttr('class');
                    this.minScrollY = -pullDownOffset;
                }else if (this.y < (this.maxScrollY - 5) && !pullUpEl.hasClass('virtual') && !pullDownEl.hasClass('virtual')) {
                    pullUpEl.attr('class', 'virtual');
                    pullUpEl.show();
                }else if (this.y > (this.maxScrollY + 5) && pullUpEl.hasClass('virtual')) {
                    pullUpEl.removeAttr('class');
                    pullUpEl.hide();
                }
            };
            newOpt.onScrollEnd = function() {
                if(pullDownEl.hasClass('virtual')) {
                    $this.pullDownActionBase.call($this);
                } else if (pullUpEl.hasClass('virtual')) {
                    $this.pullUpActionBase.call($this);
                }
            };
            return newOpt;
        }

    });

    return scrollView;

});
