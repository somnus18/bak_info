/**
 * Created by zhangjunli on 17/9/11.
 */

define(['zepto', 'C', 'view'], function ($, C, View) {
    'use strict';
    var Page = View.extend(_.extend({
        el: 'body',
        isPost: false, // 防重复提交
        orderId: '',   // 订单Id
        houseArray: [], // 房管局列表
        serverTime: '', // 服务器时间
        events: {
            'tap #select-house': 'selectHouse',
            'tap #js_doCall': 'doCall',
            'tap #select-date': 'selectDate',
            'tap #select-time': 'selectTime',
            'tap #submit': 'submit'
        },
        initialize: function () {
            var codes = C.Utils.getParameter('codes') || '';
            C.Native.setHeader({
                title: '待预约详情',
                leftCallback: function () {
                    C.Native.back();
                }
            });
            codes && C.Utils.data(C.Constant.DataKey.WAIT_STATUS, codes);   // 保存
            this.stageId = C.Utils.data(C.Constant.DataKey.DETAIL_STAGEID);               // 节点ID
            this.orderId = C.Utils.data(C.Constant.DataKey.DETAIL_TASKID);                // 订单号
            this.cityId = C.Utils.data(C.Constant.DataKey.DETAIL_CITYID);                // 城市编码
            this.productType = C.Utils.data(C.Constant.DataKey.DETAIL_PRODUCTTYPE);
            this.render();
        },
        // 格式化ajax调用
        formatAjax: function (json) {
            var self = this;
            if (self.isPost) return;
            self.isPost = true;
            C.UI.loading();
            $.ajax({
                url: json.url,
                type: json.type || 'get',
                data: json.data || {},
                success: function (res) {
                    self.isPost = false;
                    if (res.flag == C.Flag.SUCCESS) {
                        json.callback(res);
                        C.UI.stopLoading();
                    } else {
                        C.Native.tip(res.msg);
                        C.UI.stopLoading();
                    }
                },
                error: function (xhr, errorType, error) {
                    self.isPost = false;
                    C.UI.stopLoading();
                }
            });
        },
        render: function () {
            var self = this,
                json = {
                    url: C.Api('GET_WAIT_APPOINT'),
                    data: {
                        orderId: self.orderId,
                        cityId: self.cityId,
                        productType: self.productType
                    }
                };
            var callback = function (res) {
                res.data.type = C.Constant.WAIT_TYPE[res.data.appointItems] || '办押';
                self.houseArray = res.data.housBureauList;
                self.serverTime = res.time;
                res.data.custPhone = res.data.custPhone ? C.Utils.formatMobileNo(res.data.custPhone) : '';
                res.data.heightSm = res.data.address.length > 12 ? 'length': '';
                $('#js_detailBottom').html(_.template($('#tpl-wait-appoint').html())(res.data));
            };
            json.callback = callback;
            self.formatAjax(json);
        },
        // 拨打电话
        doCall: function (e) {
            var phone = $(e.currentTarget).find('span').eq(0).text();
            console.log(phone);
            if (!phone) return;
            C.Native.call(C.Utils.removeSpace(phone));
        },
        // 选择房管局
        selectHouse: function (e) {
            var houseArray = this.houseArray,
                newArray = [],
                defaultValue = '',
                houseEl = $(e.currentTarget).find('span').eq(0);
            for (var i in houseArray) {
                var tmpObj = {
                    key: houseArray[i]['hdId'],
                    value: houseArray[i]['hdName']
                };
                newArray.push(tmpObj);
            }
            var key = houseEl.data('key'),
                text = houseEl.text();
            if (key && text) {
                defaultValue = {
                    value: text,
                    key: key
                }
            }
            C.Native.showPicker({
                defaultValue: defaultValue,
                data: newArray,
                title: '选择房管局',
                callback: function (res) {
                    if (res.code == '0') {
                        houseEl.text(res.selectResult.value).data('key', res.selectResult.key).removeClass('gray');
                        if(res.selectResult.value.length > 9){
                            houseEl.attr('id', 'sm-height');  // 长度过长 更改行高
                        } else {
                            houseEl.attr('id', '');  // 长度过长 更改行高
                        }
                    }
                }
            });
        },
        // 选择日期
        selectDate: function (e) {
            var defaultValue = '',
                curr  = $(e.currentTarget).find('span').eq(0),
                outDate = '1', // 不可选择之前的日期
                text = curr.text(),
                c1 = curr.data('c1'),
                c2 = curr.data('c2'),
                c3 = curr.data('c3');
            if (text && c1 && c2 && c3) {
                defaultValue = {
                    c1: c1,
                    c2: c2,
                    c3: c3
                }
            }
            C.Native.selectDateTime({
                defaultValue: defaultValue,
                title: '选择日期',
                type: 'date',
                timeRange: '', // 可预约时间段
                outDate: outDate,
                callback: function (res) {
                    if (res.code == '0') {
                        curr.text(res.selectResult.c1 + '年' + res.selectResult.c2 + '月' + res.selectResult.c3 + '日').data({'c1':res.selectResult.c1,'c2':res.selectResult.c2,'c3':res.selectResult.c3}).removeClass('gray');
                    }
                }
            })
        },
        getCanOrderTimes: function (curr) {
            var self = this,
                json = {
                    url: C.Api('GET_ORDER_TIME'),
                    data: {
                        stageId: self.stageId,
                        cityId: self.cityId,
                        orderId: self.orderId,
                        productType: self.productType
                    }
                };
            var callback = function (data) {
                self.canOrderTime = data.data.appointmentTimeRange;
                self.selectNativeTime(curr);
            }
            json.callback = callback;
            self.formatAjax(json);
        },
        // 选择时间
        selectTime: function (e) {
            var curr = $(e.currentTarget);
            // 如果预约时间存在,直接修改时间,否则,调用接口
            if (this.canOrderTime) {
                this.selectNativeTime(curr);
            } else {
                this.getCanOrderTimes(curr);
            }
        },
        // 调用native时间选择器
        selectNativeTime: function (curr) {
            var self = this,
                defaultValue = '',
                currTime = '',
                $el = curr.find('span').eq(0),
                text = $el.text(),
                c1 = $el.data('c1'),
                c2 = $el.data('c2');
            if (text && c1 && c2) {
                defaultValue = {
                    c1: c1,
                    c2: c2
                }
            }
            if (!defaultValue) {
                currTime = C.Utils.formatTime().split(':');
                defaultValue = {
                    c1: currTime[0],
                    c2: currTime[1]
                }
            }
            C.Native.selectDateTime({
                defaultValue: defaultValue,
                title: '选择时间',
                type: 'time',
                timeRange: self.canOrderTime,
                callback: function (res) {
                    if (res.code == '0') {
                        $el.text(res.selectResult.c1 + ':' + res.selectResult.c2).data({'c1': res.selectResult.c1,'c2': res.selectResult.c2}).removeClass('gray');
                    }
                }
            })
        },
        // 获取两位数的值
        getSecondNum: function (data) {
            if (!data) return '';
            data = data + '';
            return ('00' + data).slice(data.length);
        },
        // 获取年月日的日期以---形式 日期加14
        getDateFormat: function (date, num) {
            if (!date) return '';
            num = num ? num : 0;
            date = new Date(+date);
            date.setDate(date.getDate() + num);
            return date.getFullYear() + '-' + this.getSecondNum(date.getMonth() + 1) + '-' + this.getSecondNum(date.getDate());
        },
        // 获取时分 以: 分割
        getTimeFormat: function (time) {
            if (!time) return '';
            time = new Date(+time);
            return this.getSecondNum(time.getHours()) + ':' + this.getSecondNum(time.getMinutes());
        },
        // 校验参数 获取提交的param
        getSbumitParam: function () {
            var houseEl = $('#select-house').find('span').eq(0),
                houseId = houseEl.data('key'),
                houseName = '',
                date = $('#select-date').find('span').eq(0).text(),
                time = $('#select-time').find('span').eq(0).text(),
                nowDate = this.getDateFormat(this.serverTime, 14),
                msg = '';
            houseId && (houseName = houseEl.text());
            date = date == '请选择' ? '' : C.Utils.parseDateFormat(date);
            time = time == '请选择' ? '' : time;
            if (!houseName) {
                msg = '请选择房管局';
            } else if (!date) {
                msg = '请选择日期';
            } else if (date > nowDate) {
                msg = '请选择两个星期之内的日期';
            } else if (!time) {
                msg = '请选择时间'
            }
            if (msg) {
                C.Native.tip(msg);
                return;
            }
            return {
                hdId: houseId,
                hdName: houseName,
                appointmentDate: date,
                appointmentTime: time,
                orderId: this.orderId,
                productType: this.productType,
                cityId: this.cityId
            }
        },
        // 提交
        submit: function () {
            var result = this.getSbumitParam(), json;
            if (!result) return;
            json = {
                url: C.Api('SUBMIT_WAIT_APPOINT'),
                data: result,
                type: 'post'
            };
            var callback = function (data) {
                C.Native.tip('提交成功');
                C.Native.back(); // 成功返回
            };
            json.callback = callback;
            this.formatAjax(json);
        }
    }));

    $(function () {
        new Page({
            el: $('body')[0]
        });
    })
});
