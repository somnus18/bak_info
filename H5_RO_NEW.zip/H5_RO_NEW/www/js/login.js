/*!
 * login登录页
 * 处理登录及登录跳转逻辑
 * @author 周一平
 * @history 2015-6-23 add
 */
define(["zepto","C",'libs/jsencrypt'],function($,C,JSEncrypt){
    function accountLogin(callback){
        var RSAENCRYPT = new JSEncrypt();
        // RSAENCRYPT.setPublicKey("-----BEGIN PUBLIC KEY-----\nMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDwHQU77tsMBNbKnzVd+OZeINs7\nrPgGdV8owrau1Ox9a5axrJ2nak3dDQiD9Zt/UfkckZhqFYhDmzxYOgkYDmoP4fTM\neqIwY4e0m4+WDTF6Ef74tEW2SeNwUVqBtcKD+DGEx9QTaWjOLu+wIw4f4gRuuro2\n7oSctyNJfiJ625C32QIDAQAB\n-----END PUBLIC KEY-----");
        RSAENCRYPT.setPublicKey("-----BEGIN PUBLIC KEY-----\nMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCeabYScyccBwY6ieOcVkz/8RwQZSRQxpaVf+rIv3/k9+yxxBtKeK9F8yP3JDTZCr2mYXNlgdBU0OfX6472JrrQaHx5HF6pEjcVUzX34QsfoD+Z4e4zczktg1DEhVo2B7S3p7Rn9VPTTDfVB4s3x0sSge3goqRm1gwJCLaCZqeK+QIDAQAB\n-----END PUBLIC KEY-----");
        C.rsaEncrypt = function(text){
            return RSAENCRYPT.encrypt(text);
        };
        var paramData = {
            userId:C.rsaEncrypt($('#mobile').val()),
            password:C.rsaEncrypt($('#password').val()),//加密address:%E4%B8%AD%E5%9B%BD%E5%B9%BF%E4%B8%9C%E7%9C%81%E6%B7%B1%E5%9C%B3%E5%B8%82%E7%A6%8F%E7%94%B0%E5%8C%BA%E5%85%AB%E5%8D%A6%E4%BA%94%E8%A1%9711%E5%8F%B7,
            nativeType:'H5L',
            ticket: 'yangzongyuan===',
            versionsDate: '2017-01-19'
        };
        $.ajax({
            url: C.Api('PLUGIN_LOGIN'),
            type: "post",
            data: paramData,
            success: function(res){
                if(res && res.flag == '1'){
                    $("#showinfo").html(JSON.stringify(res.data));
                    C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO,res.data);
                    callback(res);
                }else{
                    C.UI.error({content:res.msg})
                }
            }
        });
    }

    $(function(){
        C.UI.loading();
        var redirectURL = decodeURIComponent(C.Utils.getParameter("redirectURL") || "home.html");
        var flag = C.Utils.getParameter("flag");
        $("#login").on('click',function(){
            var mobile = $("#mobile").val();
            var password = $("#password").val();
            if(mobile && password){
                accountLogin(function(data){
                    if(flag != "false"){
                        location.href = redirectURL;
                        console.log(data);
                    }
                });
            }
        });
        {

        }

        $("#main").show();
    })
});
