/**
 * @Author : ex-qingqi@pingan.com.cn
 * @Date   : 2016-03-23
 * @Time   : 15:10:00
 * @Modify : ex-tongwei001@pingan.comcn
 * 
 * @Description: 设置
 */
/* global define: false */

define([
    'zepto',
    'C',
    'view',
    'underscore'], function ($,
                             C,
                             View,
                             _) {

    'use strict';
    var Page = View.extend(_.extend({

        events: {
            'tap #back': 'back'
        },

        initialize: function () {
            var self = this;
            C.Native.setHeader({
                title       : '版本信息',
                leftCallback: function () {
                    C.Native.back();
                }
            });
            self.render();
        },
        render    : function () {
            C.Native.getVersionInfo(function (res) {
                if (res) {
                    C.Native.loadingFinish();
                    $('#versionNum').html(res.versionNum);
                }
            })
        }
    }));

    $(function () {
        new Page({
            el: $('body')[0]
        });
    })
});