/**
 * @Author : jinmengjie107
 * @Description: update fail
 */

define(['zepto', 'C', 'view'], function ($, C, View) {
    'use strict';
    var Page = View.extend(_.extend({
        events: {
            'tap #re_submit': 'reSubmit',
            'tap #back_detail': 'returnDetail'
        },

        initialize: function () {
            C.Native.setHeader({
                title: '',
                leftCallback: function () {
                    C.Native.back({
                        url: 'task_detail.html'
                    });
                }
            });
            var _this = this, failReason = C.Utils.getParameter('msg') || '';
            failReason = decodeURIComponent(failReason);
            _this.stageId = C.Utils.getParameter('stageId');
            _this.orderId = C.Utils.getParameter('orderId');
            _this.productType = C.Utils.getParameter('productType');
            _this.cityId = C.Utils.getParameter('cityId') || C.Utils.data(C.Constant.DataKey.DETAIL_CITYID);
            $('#fail_reason').text(failReason);
            C.Native.loadingFinish();
        },

        reSubmit: function () {
            var _this = this;
            C.UI.loading();
            C.Native.repeatUpload({
                orderId: _this.orderId,
                nodeId: _this.stageId,
                productType: _this.productType,
                cityId: _this.cityId
            });
        },

        returnDetail: function () {
            var _this = this;
            C.Native.back({
                url: 'task_detail.html'
            });
        }
    }));

    $(function () {
        new Page({
            el: $('body')[0]
        });
    })
});
