/**
 * @Author : zhangjunli001@pingan.com.cn
 * @Date   : 2017-10-10
 * @Time   : 10:20:32
 *
 * @Description: 任务中心
 */
/* global define: false */

define(['zepto', 'C', 'view', 'scrollView'], function($, C, View, scrollView) {

    'use strict';

    var Page = View.extend(_.extend(scrollView, {

        // 分配任务列表模板
        taskList_template: _.template($('#listTpl').html()),
        // 页面显示条数
        account: 20,
        // 待分配标示
        waitAlow: 5,
        // 已分配标示
        waitedAlow: 6,
        // 防重标示
        isPost: false,

        waitUl: $('#custWait'), // 待分配列表的ul
        waitedUl: $('#custWaited'), // 已分配列表的ul
        noTask: $('.js_noTask'), //无任务提示
        ulTabEl: $('.js_ul'),    // 标题的ul元素
        newUlEl: $('#new_li'), // 新增的ul tab框父元素
        divEl: $('#rep-list'), // 列表容器的父元素


        // 事件
        events: {
            // 任务选择
            'tap .js_ul li': 'taskChoose_tap',
            'tap #new_li li': 'taskChoose_tap',
            // 分配任务处理
            'tap .task ul li': 'handleTask_tap'
        },

        // 初始化
        initialize: function () {
            var self = this, isZhai = false,
                code = C.Utils.data(C.Constant.DataKey.WAIT_STATUS);
            self.index = 0;
            self.firstPageData = {};
            self.page = 1;
            self.beginIndex = 1;
            self.getRORCStatus(isZhai);
            self.setHeader();
            if (!!code) {
                $('#js_task_center').find('li[data-code="' + code + '"]').addClass('active').siblings().removeClass('active').parent().siblings().find('li').removeClass('active');
                // self.divEl.find('ul[data-code="' + code + '"]').show().siblings().hide();
                self.showUl(code, true);   // 显示的列表父元素
                C.Utils.data(C.Constant.DataKey.WAIT_STATUS, null);
                // 如果是5或者7 应该刷新第一页数据，最新任务数量应该也刷新
                if (code == '5' || code == '7' || code == '9') {
                    self.type = self.waitAlow = code; // 记录上次点击的第一个tab位置
                    self.render();
                } else {
                    self.waitedAlow = self.type = code; // 记录上次点击的第二个tab位置
                    self.getData(code);
                }
            } else {
                // 新增
                // 按揭待预约订单
                self.waitAlow = self.type = '9';
                self.divEl.find('ul').eq(0).attr('data-code', '9');
                self.render();
            }
        },

        //头部信息
        setHeader: function () {
            C.Native.setHeader({
                title: '任务中心',
                leftCallback: function () {
                    C.Native.back();
                }
            });
        },
        // 获取角色状态
        getRORCStatus: function (isZhai) {
            var self = this;
            if (C.Utils.data(C.Constant.DataKey.USER_RO_MAM)) {
                isZhai && (self.type = self.waitAlow = '7'); // 抵押副理待分配
                self.ulTabEl.find('li').eq(0).attr('data-code', '7');
                self.ulTabEl.find('li').eq(1).attr('data-code', '8');
            } else {
                isZhai && (self.type = self.waitAlow = '5'); // 专员待分配
                self.ulTabEl.find('li').eq(0).attr('data-code', '5');
                self.ulTabEl.find('li').eq(1).attr('data-code', '6');
            }
        },
        //渲染页面
        render: function () {
            this.getNewMsgTask();
        },

        //下拉刷新self.isBoll
        pullDownActionBase: function () {
            var self = this;
            if (self.isLoading) return;
            self.isLoading = "down";
            self.index = 0;
            self.beginIndex = 1;
            // 待分配列表 下拉最新消息任务数接口也调用   否则只刷新已分配列表
            self.type == self.waitAlow ? self.getNewMsgTask(true) : self.getData(self.type, true);
            self.refreshScroll();
        },
        //上拉加载
        pullUpActionBase: function () {
            var self = this;
            if (self.isLoading) return;
            self.isLoading = "up";
            self.beginIndex = 1;
            self.getData(self.type, true);
            self.refreshScroll();
        },

        //获取任务列表数据
        getData: function (type, do_action) {
            var self = this,
                datas = [],
                data = '',
                url = '',
                removeId = 'subtask',
                isNeedRemove = true,
                page = self.index + 1;
            if (self.isPost) return;
            self.isPost = true;
            if (self.beginIndex == 1) {
                C.Native.loadingBegin();
            }
            data = {
                page: page,
                pageSize: self.account
            };
            if (type == 4) {
                // 宅e贷订单
                url = C.Api('GET_ZHAI_ORDER_LIST');
                removeId = 'subtaskId'; // 宅e贷订单用subtaskId做去重
                isNeedRemove = false;
            } else {
                url = C.Api('CUSTOMER_INFORMATION');
                data.orderType = type;
            }
            $.ajax({
                url: url,
                data: data,
                type: 'get',
                //是否上拉或下拉刷新任务列表
                has_action_refresh: do_action,
                success: function (res) {
                    var data = res.data || [];
                    self.isPost = false;
                    if (res.flag == C.Flag.SUCCESS) {
                        //隐藏无任务提示
                        self.noTask.hide();
                        if (data.length) {
                            // 刷新第一页信息
                            datas = C.removeRepeatData(data, self.firstPageData, datas, page, removeId, isNeedRemove);   // 去除重复数据之后保存的数组
                            if (datas.length) {
                                self.getInfo(datas, type);
                            } else {
                                if (self.hasInitScroll) self.refreshScroll();
                            }
                            self.firstPageData = datas;
                            self.index++;
                        } else {
                            if (page == 1) {
                                //页面无任务时显示
                                self.noTask.show();
                                type == self.waitAlow ? self.waitUl.empty() : self.waitedUl.empty();
                            } else {
                                C.Native.tip('暂无更多数据!');
                            }

                        }
                    } else {
                        if (page == 1) {
                            //页面无任务时显示
                            self.noTask.show();
                            type == self.waitAlow ? self.waitUl.empty() : self.waitedUl.empty();
                        }
                    }
                    C.Native.loadingFinish();
                    self.refreshScroll();
                    self.initiScroll();
                    delete self.isLoading;
                },
                error: function (xhr, errorType, errorMsg) {
                    C.UI.stopLoading();
                    if (self.hasInitScroll) self.refreshScroll();
                    self.isPost = false;
                    delete self.isLoading;
                    if (self.page == 1 && !do_action) {
                        //页面无数据时显示
                        self.noTask.show();
                    }
                    self.initiScroll();
                }
            });
        },
        /**
         * 初始化iScroll组件
         */
        initiScroll: function () {
            var self = this;
            if (!self.hasInitScroll) {
                // 动态改变列表的高度
                var scrollContainerH = $('.layout').height();
                var headHeight = window.innerHeight - $('header').height() - $('.task-center').height();
                if (scrollContainerH < headHeight)
                    scrollContainerH = headHeight;
                self.install(scrollContainerH);
                self.hasInitScroll = true;
            }
        },
        //获取待分配任务总数
        getNewMsgTask: function (isDown) {
            var self = this;
            if (self.isPost) return;
            self.isPost = true;
            C.UI.loading();
            $.ajax({
                url: C.Api('RO_NEWMESSAGE_NUM'),
                data: {
                    whoAmI: '4'
                },
                type: 'get',
                success: function (res) {
                    self.beginIndex++;
                    self.isPost = false;
                    if (res.flag == C.Flag.SUCCESS) {
                        if (res.data.allotCount > 0) {
                            $('#wait-num').text(res.data.allotCount).show();
                        } else {
                            $('#wait-num').text('').hide();
                        }
                        if (res.data.appointChargeCount > 0) {
                            $('#order-num').text(res.data.appointChargeCount).show();
                        } else {
                            $('#order-num').text('').hide();
                        }
                        self.getData(self.waitAlow, isDown);
                    }
                },
                error: function () {
                    delete self.isLoading;
                    C.UI.stopLoading();
                }
            });
        },

        //公共取值
        getInfo: function ($el, type) {
            var arrInfo = [],
                self = this;
            $.each($el, function (index, item) {
                item.timeDate = item.appointDate;
                item.time = item.appointTime;
                item.handUserName = item.handUserName || '';
                item.handleUser = item.handleUser || '';
                item.frontStageId = item.frontStageId || '';
                item.custMobile = C.Utils.formatMobileNo(item.custMobile);
                item.prdName = C.Constant.BUSINESS_LINE_NAME[item.productType];
                item.appointDate = C.Utils.parseDateFormat(item.appointDate, 'MM月dd日');
                item.appointTime = item.appointTime ? item.appointTime.split(':')[0] + ':' + item.appointTime.split(':')[1] : '';
                item.isNewZhai = type == 4 ? 'isNew' : '';  // 判断是否是宅e贷订单列表
                item.isAnNew = type == 9 ? 'isAn' : '';  // 判断是否是按揭的待预约订单
                item.subCont = item.taskContent || item.subtask || '';
                item.subId = item.subtaskId || '';
                item.taskContentName = item.taskContentName || '';
                // 待分配 和 宅e贷订单
                if (type == 5 || type == 7) {
                    item.color = '1';
                } else {
                    item.color = 'c-green';
                }
                arrInfo.push(self.taskList_template(item));
            });
            if (self.isLoading == 'up') {
                (type == 5 || type == 7 || type == 9) ? self.waitUl.append(arrInfo.join('')) : self.waitedUl.append(arrInfo.join(''));
            } else {
                (type == 5 || type == 7 || type == 9) ? self.waitUl.html(arrInfo.join('')) : self.waitedUl.html(arrInfo.join(''));
            }
        },

        //任务类型选择
        taskChoose_tap: function (e) {
            var curr = $(e.currentTarget),
                status = curr.attr('data-code');
            if (status == 4 && !C.Utils.data(C.Constant.DataKey.USER_RO_MAM)) {
                C.Native.tip('你没有操作权限');
                return;
            }
            curr.addClass('active').siblings().removeClass('active').parent().siblings().find('li').removeClass('active');
            this.showUl(status);
        },
        // 列表ul显示的问题
        showUl: function (status, isShow) {
            var self = this;
            switch (status) {
                case '9':
                case '5':
                case '7':
                    self.divEl.find('ul').eq(0).attr('data-code', status).show().siblings().hide();
                    if (!isShow) {
                        self.waitAlow = self.type = status;
                        self.commList(self.waitAlow, true); // 刷新最新任务数量
                    }
                    break;
                case '4':
                case '6':
                case '8':
                    self.divEl.find('ul').eq(1).attr('data-code', status).show().siblings().hide();
                    if (!isShow) {
                        self.waitedAlow = self.type = status;
                        self.commList(self.waitedAlow);
                    }
                    break;
            }
        },
        //待分配和分配列表显示
        commList: function (type, isTwo) {
            this.index = 0;
            this.beginIndex = 1;
            isTwo ? this.getNewMsgTask() : this.getData(type);
        },
        //任务处理
        handleTask_tap: function (e) {
            var curr = $(e.currentTarget),
                codes = $('#js_task_center').find('li.active').attr('data-code'),
                self = this,
                orderId = self.type;
            //orderid任务id
            C.Utils.data(C.Constant.DataKey.DETAIL_TASKID, curr.data('id'));
            //cityId
            C.Utils.data(C.Constant.DataKey.DETAIL_CITYID, curr.data('cityid'));
            //节点id
            C.Utils.data(C.Constant.DataKey.DETAIL_STAGEID, curr.data('stageid'));
            //产品类型
            C.Utils.data(C.Constant.DataKey.DETAIL_PRODUCTTYPE, curr.data('prdtype'));
            C.Utils.data(C.Constant.DataKey.DETAIL_TEL, curr.data('custmobile'));
            C.Utils.data(C.Constant.DataKey.DETAIL_NAME, curr.data('custname'));
            C.Utils.data(C.Constant.DataKey.DETAIL_ADDRESS, curr.data('address'));
            C.Utils.data(C.Constant.DataKey.DETAIL_GENDER, curr.data('gender'));
            C.Utils.data(C.Constant.DataKey.DETAIL_DATE, curr.data('timedate'));
            C.Utils.data(C.Constant.DataKey.DETAIL_TIME, curr.data('time'));
            C.Utils.data(C.Constant.DataKey.DETAIL_STATUS, curr.data('status'));
            C.Utils.data(C.Constant.DataKey.HAND_USER, curr.data('user'));
            C.Utils.data(C.Constant.DataKey.HAND_USER_NAME, curr.data('username'));
            C.Utils.data(C.Constant.DataKey.SUB_TASK_CONTENT, curr.data('subcont'));  // 子任务名称
            C.Utils.data(C.Constant.DataKey.SUB_TASK_ID, curr.data('subid'));  // 子任务名称
            // 按揭新的订单
            if (codes == '9') {
                C.Native.forward({
                    url: 'wait_appoint.html',
                    data: {
                        codes: codes
                    }
                });
            } else {
                C.Native.forward({
                    // code用于详情页面判断是分配任务还是完成
                    url: 'taskAllot_detail.html',
                    data: {
                        orderId: orderId,
                        codes: codes
                    }
                });
            }
        }
    }));

    $(function() {
        new Page({
            el: $('body')[0]
        });
        $$.EventListener.onBack = function() {
            location.reload();
        }
    })
});
