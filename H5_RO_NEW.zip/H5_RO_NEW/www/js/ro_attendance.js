/**
 * @Author : ex-qingqi@pingan.com.cn
 * @Date   : 2016-04-08
 * @Time   : 10:10:00
 * @Modify : ex-tongwei001@pingan.com.cn
 * @Description: 考勤
 */
/* global define: false */

define([
	'zepto',
	'C',
	'view',
	"underscore",
	'base64'
], function ($,
             C,
             View,
             _,
             base64) {

	'use strict';

	var Page = View.extend(_.extend({
		//事件对应及方法
		events    : {
			'tap .js_workAtt'    : 'goConfirm',
			'tap .js_btn_confirm': 'submit',
			'tap .close'         : 'closeBtn',
			'tap .js_btn_cancel' : 'closeBtn',
			'tap .js_goback'     : 'goConfirm'
		},
		//将数据临时保存
		dataParam : {},
		//工作状态码
		statecode : '',
		//设备ID
		deviceId  : '',
		//用户上班打卡模板
		workInfo  : _.template($('#js_workTemp').html()),
		//用户下班打卡模板
		goBackInfo: _.template($('#js_backhome').html()),
		//打卡展示
		dataInfo  : $('#js_work_box'),
		//初始化
		initialize: function () {
			var self = this;
			C.Native.setHeader({
				title       : '考勤',
				leftCallback: function () {
					C.Native.back();
				}
			});
			self.render();
		},
		//页面渲染view
		render    : function () {
			var self = this;
			C.Native.getDeviceId(function (res) {
				self.deviceId = res.DeviceId;
			})
			//请求状态码
			self.stagteAjax();
		},
		//页面状态交互，statecode 为‘0’时，为打上班卡；为‘1’时，为打下班卡;为'2'时，为已打下班卡
		stagteAjax: function () {
			var self = this;
			C.Native.loadingBegin();
			$.ajax({
				url    : C.Api('RO_ATTENDANCE_STATE'),
				type   : 'get',
				success: function (res) {
					if (res && res.flag == C.Flag.SUCCESS) {
						C.Native.loadingFinish();
						self.statecode = res.data.status;
						self.goView(self.statecode);
					}
				},
				error  : function () {
					C.Native.loadingFinish();
				}
			});
		},
		//页面渲染
		goView    : function (statecode) {
			var self   = this,
			    myDate = new Date();
			var currentTime = C.Utils.parseDateFormat(myDate, 'MM月dd号'),
			    curHour     = C.Utils.parseDateFormat(myDate, 'hh:mm'),
			    curSecond   = C.Utils.parseDateFormat(myDate, 'ss');
			var obj = {
				signDate  : currentTime,
				signHour  : curHour,
				signSecond: curSecond,
				signCity  : '',
				signPlace : ''
			};
			//显示loading
			var opt = {
				msg: '定位中...'
			};
			C.Native.loadingBegin(opt);
			C.Native.getLBS(function (res) {
				//删除loading
				C.Native.loadingFinish();

				if (res.code == 0) {
					obj.signCity = res.city;
					obj.signPlace = res.addrStr;
				} else {
					C.Native.tip('定位失败');
					obj.signCity = "未知城市";
					obj.signPlace = '未知地理位置'
				}

				self.dataParam = obj;
				if (statecode == 0) {
					self.dataInfo.html(self.workInfo(self.dataParam));
				} else if (statecode == 1) {
					self.dataInfo.html(self.goBackInfo(self.dataParam));
				} else if (statecode == 2) {
					self.dataInfo.html(self.goBackInfo(self.dataParam));
					$('.js_goback').addClass('btn-gray-full').removeClass('js_goback');
				}
			});

		},
		//提交地址至后台
		submit    : function () {
			var self    = this,
			    subData = {};
			//显示loading
			var opt = {
				msg: '定位中...'
			};
			C.Native.loadingBegin(opt);
			C.Native.getLBS(function (res) {
				//删除loading
				C.Native.loadingFinish();
				subData = {
					deviceId : self.deviceId,
					signType : self.statecode + 1,
					longitude: res.longitude,
					latitude : res.latitude,
					//address  : $.base64.encode(res.addrStr)
					address  : res.addrStr
				}
				$.ajax({
					url    : C.Api('RO_ATTENDANCE_SUBMIT'),
					type   : 'post',
					data   : subData,
					success: function (res) {
						if (res.flag == C.Flag.SUCCESS) {
							//重新加载页面，获取页面状态码
							window.location.reload();
						}
					},
					error  : function () {
						C.Native.tip('提交失败!');
					}
				})
			});

		},
		//点击按钮事件(上下班)
		goConfirm : function () {
			$('.leayer').removeClass('dn');
		},
		// ‘取消’ ||‘x’ 掉按钮窗口
		closeBtn  : function () {
			$('.leayer').addClass('dn');
		}

	}));
	$(function () {
		new Page({
			el: $('body')[0]
		});
	})
});
