define(['zepto', 'C', "view"], function ($, C, View) {
    var Page = View.extend(_.extend({
        events    : {
            "tap #main-part": "toMain"
        },
        initialize: function () {
            var _this = this;
            C.Native.setHeader({
                title       : "iLoan",
                leftCallback: function () {
                    C.Native.back();
                }
            });
            C.UI.stopLoading();
        },

        toMain: function () {
            var _this = this;
            // C.Native.getUserInfo(function(data){
            //     C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO,data);
            var param = {
                cityName: "深圳市"
            };
            $.ajax({
                url    : C.Api("QUERY_USER_APPLY_STATE"),
                type   : "post",
                data   : param,
                success: function (res) {
                    if (res.flag == "1" && res.data) {
                        var data = res.data;
                        if (data.resultCode == "1") {
                            //数据缓存
                            if (data.productType) {
                                C.Utils.data(C.Constant.DataKey.PRODUCT_TYPE, data.productType)
                            }
                            if (data.applNo) {
                                C.Utils.data(C.Constant.DataKey.ILOANAPPLYNO, data.applNo)
                            }
                            if (data.billDate) {
                                C.Utils.data(C.Constant.DataKey.ILOAN_BILLDAY, data.billDate)
                            }
                            if (data.custNo) {
                                C.Utils.data(C.Constant.DataKey.ILOAN_CUSTNO, data.custNo)
                            }
                            switch (data.subProcessCode) {
                                case "AU":
                                    if (data.realNameAuth == "0") {
                                        C.Native.forward({
                                            url: "iloan_production_index.html"
                                        })
                                    } else {
                                        C.Native.forward({
                                            url: "credit_info_list.html"
                                        })
                                    }
                                    break;
                                case "AM":
                                case "AF":
                                case "AC":
                                case "AY":
                                case "AP":
                                    C.Native.forward({
                                        url: "credit_info_list.html"
                                    })
                                    break;
                                case "XX":
                                    // TODO: tip
                                    C.Native.tip(data.resultMsg);
                                    break;
                                case "RJ":
                                    C.Native.forward({
                                        url: "credit_fail_result.html"
                                    });
                                    break;
                                default:
                                    // TODO: 非授信环节申请状态处理
                                    C.Native.forward({
                                        url: "shaw_account.html"
                                    })
                                    break;
                            }
                        } else {
                            C.Native.tip(data.resultMsg);
                        }
                    }
                }
            })
            // });
        }
    }));
    $(function () {
        new Page({
            el: $("body")[0]
        });
    })
});
