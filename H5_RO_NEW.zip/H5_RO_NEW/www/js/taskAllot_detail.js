/**
 * @Author : linzequan958@pingan.com.cn
 * @Date   : 2016-04-26
 * @Time   : 16:14:14
 *
 * @Description: 任务详情
 */
/* global define: false */
define(['zepto', 'C', 'view', 'imglazyload'], function($, C, View) {

    'use strict';

    var Page = View.extend(_.extend({

        // 页面全局变量
        _G: {
            taskDetailInfo: {}, // 任务详情信息
            nodelistPosition: { // 任务节点位置信息
                lastX: 0,
                changeX: 0
            },
            time: '', //系统时间戳,
            isPost: false
        },

        // 包裹预约时间的容器
        appointFrame: $('.js_changeTime'),
        // 渲染模板结构
        frame_nodelist: _.template($('#tpl-nodelist').html()), // 任务节点列表
        frame_nodelist_er: _.template($('#tpl-nodelist-er').html()), // 二手房任务节点列表
        frame_taskTimeTip: _.template($('#tpl-taskTimeTip').html()), // 头部用户信息设置
        frame_backReasonTip: _.template($('#tpl-backReasonTip').html()),
        frame_detailTop: _.template($('#tpl-detailTop').html()),                // 任务详情头部信息
        frame_detailTimeAppoint: _.template($('#tpl-detailTimeAppoint').html()), // 任务详情头部时间信息
        frame_detailAnBottom: _.template($('#tpl-detailAnBottom').html()), // 按揭任务详情底部更多信息
        frame_detailBottom: _.template($('#tpl-detailBottom').html()), // 二手房任务详情底部更多信息
        frame_detailAnNewBottom: _.template($('#tpl-detailAnNewBottom').html()),    //按揭（新）详情底部更多信息
        frame_detailAnNewNewBottom: _.template($('#tpl-detailAnNewNewBottom').html()),       //按揭（新）详情底部更多信息
        frame_photoArea: _.template($('#tpl-photoArea').html()), // 图片区域图片
        frame_attacheList: _.template($('#tpl-attacheList').html()), // 专员列表
        frame_detailZhaiBottom: _.template($('#tpl-detailZhaiBottom').html()), //宅e贷任务详情底部更多信息

        // 获取列表存贮的本地用户数据
        orderId: C.Utils.data(C.Constant.DataKey.DETAIL_TASKID), // 订单号
        cityId: C.Utils.data(C.Constant.DataKey.DETAIL_CITYID), // 城市编码
        stageId: C.Utils.data(C.Constant.DataKey.DETAIL_STAGEID), // 节点ID
        userId: C.Utils.data(C.Constant.DataKey.USER_ID), // 用户id
        productType: C.Utils.data(C.Constant.DataKey.DETAIL_PRODUCTTYPE), // 产品类型
        status: C.Utils.data(C.Constant.DataKey.DETAIL_STATUS), // 任务状态
        subCont: C.Utils.data(C.Constant.DataKey.SUB_TASK_CONTENT),  // 子任务订单taskContent
        subId: C.Utils.data(C.Constant.DataKey.SUB_TASK_ID),  // 子任务订单ID

        // 底部更多详情
        bottomDetail: $('.js_detailBottom'),
        stageUl: $('.js_nodelist'), // 节点ul
        // 事件绑定
        events: {
            //查看更多详情图标
            'tap .js_moreBtn': 'changeDetailMore',
            //查看照片详情
            'tap .js_showPhotoBtn': 'changePhotoArea',
            //切换节点
            'tap .js_node': 'changeNode',
            //分配任务
            'tap .js_stepBtn': 'dealTask',
            //预览图片
            'tap .js_prevImg': 'prevImg',
            //选择任务专员
            'tap .scroll ul li': 'choseAttendance',
            //关闭专员列表页
            'tap .js_closeAtt': 'colseAttList',
            //分配任务确定按钮
            'tap .js_attacheSubBtn': 'attacheSubBtn',
            //分配任务取消按钮
            'tap .js_attacheCleBtn': 'attacheCleBtn',
            //拨打电话
            'tap .js_doCall': 'doCall'
        },

        // 数据请求公用方法
        requestData: function(json) {
            var self = this;
            if (self._G.isPost) {
                return;
            }
            self._G.isPost = true;
            C.Native.loadingBegin();
            $.ajax({
                url: json.api,
                type: 'post',
                data: json.data,
                timeout: json.timeout ? json.timeout : 30000,
                success: function(data) {
                    C.Native.loadingFinish();
                    self._G.isPost = false;
                    if (data.flag == C.Flag.SUCCESS) {
                        json.callback(data);
                    }
                },
                error: function(xhr, errorType, error) {
                    self._G.isPost = false;
                    C.Native.loadingFinish();
                    json.errorCall();
                }
            });
        },

        // 初始化
        initialize: function() {
            var self = this,
                codes = C.Utils.getParameter('codes') || '',
                queryOrderType = C.Utils.getParameter('orderId');
            C.Native.setHeader({
                title: '任务分配详情',
                leftCallback: function() {
                    C.Native.back();
                }
            });
            if(!!codes){
                C.Utils.data(C.Constant.DataKey.WAIT_STATUS, codes);
            }
            self.taskInfoType = (queryOrderType == C.Constant.BUSINESS_LINE.w || queryOrderType == C.Constant.BUSINESS_LINE.mw) ? '1' : '3';
            self.render();
        },

        // 渲染页面
        render: function() {
            var self = this,
                taskId = self.orderId,
                stageId = self.stageId,
                cityId = self.cityId,
                productType = self.productType,
                taskInfoType = self.taskInfoType,
                json = {
                    api: C.Api('GET_TASKINFO'),
                    data: {
                        orderId: taskId,
                        cityId: cityId,
                        stageId: stageId,
                        productType: productType,
                        taskInfoType: taskInfoType
                    }
                };
            productType == 4 && (json.data.taskContent = self.subCont);   // 宅e贷订单增加入参
            var callback = function(data) {
                self._G.taskDetailInfo = data.data;
                self._G.time = data.time;
                // 渲染任务节点信息
                self.renderNodelist();
                // 渲染用户信息详情
                self.renderUserDetail();
                // 渲染回退原因气泡
                self.renderBackReasonTip();
                // 渲染详情头部信息
                self.renderDetailTop();
                // 渲染详情底部更多信息
                self.renderDetailBottom();
                // 渲染图片区域数据
                self.renderPhotoArea();
                // 渲染底部按钮
                self.renderBottomBtn();
                // 注册懒加载图片
                $('.js_img_lazy_div').imglazyload();
            };

            var errorCall = function() {

            };
            json.errorCall = errorCall;
            json.callback = callback;
            self.requestData(json);
        },

        // 渲染任务节点信息
        renderNodelist: function() {
            var self = this,
                detail = self._G.taskDetailInfo,
                stageId, // 当前节点
                stageInfo = detail.stageInfo, // 节点数据信息
                parallel = true, // 是否并行节点结束
                flag,
                orderType = detail.productType;

            // 判断任务类型，确定是否需要滑动节点进度条
            if (orderType == C.Constant.BUSINESS_LINE.er) {
                // 二手房业务
                // 渲染任务节点信息
                self.stageUl.html(self.frame_nodelist_er(detail));
            } else {
                // 按揭、按揭新、宅E贷业务
                // 渲染任务节点信息
                self.stageUl.parent().addClass('step-sm');
                self.stageUl.html(self.frame_nodelist(detail));
            }
            // 二手房 按揭新 按揭新新可以滑动
            if (C.Constant.CANMOVESTAGE[self.productType] && stageInfo.length > 4) {
                self._G.nodelistPosition.lastX = parseInt(self.stageUl.css('left'));
                self.moveNodelist();
            }
            //  定义li的高度，和ul一样，用来更改向上的箭头的样式
            self.stageUl.find('li').css('height', self.stageUl.height());
            if (stageInfo[0]['stageTaskStatus'] == 0) {
                self.stageUl.find('li').eq(0).addClass('active active-wait active-arrow');
            } else if (stageInfo[1]['stageTaskStatus'] == 0) {
                self.stageUl.find('li').eq(0).addClass('finish');
                self.stageUl.find('li').eq(1).addClass('active active-wait active-arrow');
            } else {
                self.stageUl.find('li').eq(0).addClass('finish');
                self.stageUl.find('li').eq(1).addClass('finish');
                for (var i = 2; i < stageInfo.length; i++) {
                    if (stageInfo[i].stageTaskStatus == 0) {
                        self.custStageId = stageInfo[i].stageId;
                        if (self.checkStatus()) {
                            self.stageUl.find('li').eq(i).addClass('active-dh active active-arrow')
                        } else {
                            self.stageUl.find('li').eq(i).addClass('active-wait active active-arrow')
                        }
                        break;
                    } else if (stageInfo[i].stageTaskStatus == 1) {
                        self.stageUl.find('li').eq(i).addClass('finish');
                    }
                }
                flag = i;
                //二手房订单
                if (C.Constant.CANMOVESTAGE[self.productType] && (stageInfo.length > 4)) {
                    var le = self.stageUl.find('li').eq(flag).width();
                    self.stageUl.css('left', -le * (flag - 1));
                    self._G.nodelistPosition.lastX = parseInt(self.stageUl.css('left'));
                }
                // 判断是否并行节点，并渲染并行节点
                for (var i = flag + 1; i < stageInfo.length; i++) {
                    if (!!parallel && stageInfo[i].weight == stageInfo[i - 1].weight) {
                        if (self.stageUl.find('li').eq(i).data('status') == '1') {
                            self.stageUl.find('li').eq(i).addClass('finish');
                        } else {
                            (self.stageUl.find('li').eq(i).data('status') != '2') && (self.stageUl.find('li').eq(i).addClass('active-wait'));
                        }
                    } else {
                        parallel = false;
                    }
                }
            }
        },

        //判断预约时间是否逾期
        checkStatus: function() {
            var self = this,
                detail = self._G.taskDetailInfo,
                currStageId = self.custStageId,
                appTime = null,
                nowDateTime = self._G.time,
                appointInfo = self.getStageInfo(currStageId, detail.appointInfo);
            if (appointInfo.havaAppointTime == '1' && appointInfo.appointTime && appointInfo.appointDate) {
                appTime = new Date(appointInfo.appointDate.replace(/-/g, '/') + ' ' + appointInfo.appointTime).getTime();
                appTime = parseInt((appTime - nowDateTime) / 1000);
                if (appTime > 0) {
                    return false;
                } else {
                    return true;
                }
            } else {
                return false;
            }
        },

        //渲染头部详细信息
        renderUserDetail: function() {
            var self = this,
                detail = self._G.taskDetailInfo,
                status = self.status,
                user = C.Utils.data(C.Constant.DataKey.HAND_USER),
                username = C.Utils.data(C.Constant.DataKey.HAND_USER_NAME);
            if (user && username) {
                detail.handleUserName = username;
                detail.handleUser = user;
                if (status == '1' && (detail.productType != 4)) {
                    $('.js_userInfo').addClass('wwc');
                } else {
                    $('.js_userInfo').addClass('jxz');
                }
                $('.js_userInfo').html(self.frame_taskTimeTip(detail));
                $('.js_userInfo').removeClass('dn');
            }
        },

        // 渲染回退原因气泡，仅当前节点需要显示
        renderBackReasonTip: function(isHiden){
            var self = this,
                detail = self._G.taskDetailInfo,
                currStageId = detail.stageId,
                stageInfo = self.getStageInfo(currStageId, detail.stageInfo),
                backStageReason = stageInfo.backStageReason,
                backStageUserId = stageInfo.backStageUserId,
                stageTaskStatus = stageInfo.stageTaskStatus; //节点完成状态

            //未完成任务有回退原因、处理UM，显示回退原因，无回退原因不显示
            if( isHiden || !(backStageReason && backStageUserId) || stageTaskStatus == '1' ){
                $('.js_backReasonTip').removeClass('task-time').html('');
            }else{
                var obj = {
                    backStageReason: backStageReason,
                    backStageUserId: backStageUserId
                };
                $('.js_backReasonTip').removeClass('dn').addClass('task-time').html(self.frame_backReasonTip(obj));
            }
        },

        // 渲染任务头部信息
        renderDetailTop: function () {
            var self = this,
                detail = self._G.taskDetailInfo,            // 任务详情信息
                res = detail.detail,                        // 渲染页面数据
                stageId = detail.stageId,                   // 当前节点
                appointInfo = detail.appointInfo,           // 节点数据信息
                date = C.Utils.data(C.Constant.DataKey.DETAIL_DATE),
                time = C.Utils.data(C.Constant.DataKey.DETAIL_TIME);
            for (var i in appointInfo) {
                if (appointInfo[i]['stageId'] == stageId && appointInfo[i]['havaAppointTime'] == '1'){
                // if (appointInfo[i]['havaAppointTime'] == '1'){
                    if (date && time) {
                        self.appointDate = date;
                        res.appointDate = self.formatTimeType(date, 'spDate');
                        res.appointTime = self.formatTimeType(time, 'time');
                        res.havaAppointTime = true;
                        res.showAppoint = true;
                        break;
                    } else {
                        res.havaAppointTime = false;
                        res.showAppoint = true;
                        break;
                    }
                } else {
                    res.havaAppointTime = false;
                    res.showAppoint = false;
                }
            }

            res.businessLine = C.Constant.BUSINESS_LINE_NAME[detail.productType]; // 业务线名称
            res.custName = res.custName || ''; // 用户名
            res.custPhone = res.custPhone? C.Utils.formatMobileNo(res.custPhone) : '';  // 电话
            res.houseDeptAddress = res.houseDeptAddress || '';  // 地址
            res.custGender = res.custGender || '';
            res.houseDeptName = res.houseDeptName || '';

            // 渲染用户的预约时间
            self.appointFrame.html(self.frame_detailTimeAppoint(res));
            //  渲染用户信息
            $('.js_detailTop').append(self.frame_detailTop(res));
        },

        // 渲染任务底部更多信息
        renderDetailBottom: function() {
            var self = this,
                detail = self._G.taskDetailInfo,            // 任务详情信息
                res = detail.detail;                        // 渲染页面数据
            res.orderId = detail.orderId;
            if (detail.productType == C.Constant.BUSINESS_LINE.er) {
                // 渲染二手房数据
                res.productType = '二手房';
                self.bottomDetail.html(self.frame_detailBottom(res));
            } else if (self.productType == C.Constant.BUSINESS_LINE.a) {
                // 渲染按揭数据
                // 没有共有产权人的时候 默认展示一个共有产权人
                if (!res.ownerList.length) {
                    res.ownerList = [{
                        ownerName: '',
                        ownerRatio: '',
                        ownerIdType: '',
                        ownerIdNo: ''
                    }];
                }
                res.ownLegTh = res.ownerList.length || '';
                self.bottomDetail.html(self.frame_detailAnBottom(res));
            } else if(self.productType == C.Constant.BUSINESS_LINE.zed){
                // 渲染宅e贷数据
                // 宅e贷的用户名和用户UM账号取的是detail同级的数据
                res.custService = res.custService || '';
                res.custServiceName = res.custServiceName || '';
                res.storeName = res.storeName || '';
                res.custName = res.custName || '';
                res.buildedYearDs = res.buildedYearDs || '';
                res.orderId = res.orderId || '';
                res.custPhone = res.custPhone || '';
                res.ownerName = res.ownerName || '';
                res.address = res.address || '';
                res.houseArea = res.houseArea || '';
                res.landSource = res.landSource || '';
                res.houseBuildedYear = res.houseBuildedYear || '';
                res.isPledge = res.isPledge || '';
                res.firstObligeeName = res.firstObligeeName || '';
                res.buildedYearDs = res.buildedYearDs || '';
                res.houseProperties = res.houseProperties || '';
                res.creFigure = res.creFigure || '';
                self.bottomDetail.html(self.frame_detailZhaiBottom(res));
            } else if(self.productType == C.Constant.BUSINESS_LINE.anew){
                // 渲染按揭（新）数据
                if (!res.arrivedStoreInfo.length) {
                    res.arrivedStoreInfo = [{
                        custName: '',
                        custPhone: '',
                        idType: '',
                        idCode: '',
                        relation: '',
                    }];
                }else{
                    $.each(res.arrivedStoreInfo,function(index,item){
                        res.arrivedStoreInfo[index].custPhone
                            = C.Utils.formatMobileNo(item.custPhone);
                    });
                }
                res.referralMobile = res.referralMobile ? C.Utils.formatMobileNo(res.referralMobile) : '';
                res.evaluationCompany = res.evaluationCompany || '';
                res.applyAmount = res.applyAmount || '';
                res.bankKinds = res.bankKinds || '';
                res.applyKinds = res.applyKinds || '';
                res.getCustomerWay = res.getCustomerWay || '';
                self.bottomDetail.html(self.frame_detailAnNewBottom(res));
            }  else if (self.productType == C.Constant.AN_NEW_TYPE) {
                // 按揭新新的底部展示
                res.bankApplyCode = res.bankApplyCode || '';
                res.bizApplyAmount = res.bizApplyAmount || '';
                res.houseStore = res.houseStore || '';
                res.referralName = res.referralName || '';
                res.loanVariety = res.loanVariety || '';
                res.bargainPrice = res.bargainPrice || '';
                res.loanPlan = res.loanPlan || '';
                res.pubkicReserveApplyAmount = res.pubkicReserveApplyAmount || '';
                res.isAppointInsure = res.isAppointInsure || '';
                res.mortgageInsuranceLiability = res.mortgageInsuranceLiability || '';
                res.houseCertificateRegion = res.houseCertificateRegion || '';
                res.custName = res.custName || '';
                res.custCardType = res.custCardType || '';
                res.custCardId = res.custCardId || '';
                res.pawnList = res.pawnList || [];
                if (!res.pawnList.length) {
                    res.pawnList = [{
                        houseAddress: '',
                        estateType: '',
                        warrantCode: '',
                        houseArea: ''
                    }];
                }
                self.bottomDetail.html(self.frame_detailAnNewNewBottom(res));
            }
        },

        // 根据节点ID获取节点信息
        getStageInfo: function(id, stageList) {
            var res = {};
            for (var i in stageList) {
                if (stageList[i]['stageId'] == id) {
                    res = stageList[i];
                }
            }
            return res;
        },

        // 显示或隐藏更多详情
        changeDetailMore: function() {
            var el = $('.js_detailMore');
            if (el.hasClass('d-show')) {
                el.removeClass('d-show');
            } else {
                el.addClass('d-show');
            }
        },
        // 去除fileInfo中的重复数据
        removeRepeatData: function(data, type){
            var dataInfo = [],
                arr = [];
            dataInfo = $.extend(dataInfo,data);
            dataInfo = _.sortBy(dataInfo,'fileId');
            for(var i=0;i<dataInfo.length;i++){
                var repeatTrue = true;
                if (type) {
                    if(!_.isEmpty(dataInfo[i+1]) && dataInfo[i].fileId == dataInfo[i+1].fileId && dataInfo[i].page == dataInfo[i+1].page && dataInfo[i]['stageId'] == dataInfo[i+1]['stageId']){
                        repeatTrue = false;
                    }
                } else {
                    if(!_.isEmpty(dataInfo[i+1]) && dataInfo[i].fileId == dataInfo[i+1].fileId && dataInfo[i].page == dataInfo[i+1].page){
                        repeatTrue = false;
                    }
                }
                if(repeatTrue){
                    arr.push(dataInfo[i]);
                }
            }
            return arr;
        },
        // 渲染图片区域数据
        renderPhotoArea: function () {
            var self = this,
                detail = self._G.taskDetailInfo,
                fileInfoData = self.removeRepeatData(detail.fileInfo); // 获取fileInfo的数据 做去重处理
            $('.js_photoNum').text('共' + fileInfoData.length + '张');
            $('.js_photoArea').html(self.frame_photoArea({fileInfo:fileInfoData}));
        },
        // 渲染底部按钮
        renderBottomBtn: function() {
            var value = this.taskInfoType;
            C.Utils.data(C.Constant.DataKey.DETAIL_TYPE, value);
            //代表已分配任务入口
            if (value == '1') {
                $('.js_stepBtn').text('分配任务');
            } else {
                $('.js_stepBtn').text('改派他人');
            }
        },

        // 显示或隐藏图片区域
        changePhotoArea: function() {
            var el = $('.js_photoArea'),
                btnEl = $('.js_showPhotoBtn');
            if (el.hasClass('dn')) {
                el.removeClass('dn');
                btnEl.text('隐藏全部');
            } else {
                el.addClass('dn');
                btnEl.text('查看全部');
            }
        },

        // 移动节点进度条
        moveNodelist: function() {
            var self = this;
            $('body').delegate('.step', 'touchstart', function(e) {
                self._G.nodelistPosition.startX = e.targetTouches[0].clientX;
                self._G.nodelistPosition.startY = e.targetTouches[0].clientY;
            });
            $('body').delegate('.step', 'touchmove', function(e) {
                e.preventDefault();
                var nodesWidth = parseInt(self.stageUl.find('li').eq(0).css('width')) * self.stageUl.find('li').length,
                    changeX = self._G.nodelistPosition.lastX + e.targetTouches[0].clientX - self._G.nodelistPosition.startX;
                if (0 - changeX <= 0) {
                    self._G.nodelistPosition.changeX = 0;
                } else if (0 - changeX + parseInt(self.stageUl.css('width')) >= nodesWidth) {
                    self._G.nodelistPosition.changeX = 0 - (nodesWidth - parseInt(self.stageUl.css('width')) + 15);
                } else {
                    self._G.nodelistPosition.changeX = changeX;
                }
                self.stageUl.css('left', self._G.nodelistPosition.changeX);
            });
            $('body').delegate('.step', 'touchend', function(e) {
                self._G.nodelistPosition.lastX = self._G.nodelistPosition.changeX;
            });
        },

        /**
         * 格式化时间格式
         */
        formatTimeType: function(time, type) {
            if (!time) {
                return '';
            } else {
                if (type == 'time') {
                    time = time.split(':');
                    return time[0] + ':' + time[1];
                } else if (type == 'date') {
                    time = time.split('-');
                    return time[0] + '年' + time[1] + '月' + time[2] + '日';
                } else if (type == 'pasTime') {
                    time = time.split(':');
                    time[0] = parseInt(time[0]) < 10 ? '0' + parseInt(time[0]) : time[0];
                    return time[0] + ':' + time[1] + ':00';
                } else {
                    return time.split('-')
                }
            }
        },

        // 切换节点
        changeNode: function(e) {
            var self = this,
                detail = self._G.taskDetailInfo,
                el = $(e.currentTarget),
                stageId = el.data('code'),
                status = el.data('status'),
                res = detail.detail,
                appointInfo;
            if (this.taskInfoType == '1') return; // 分配任务不允许切换节点
            el.removeClass('js_node').siblings().addClass('js_node');
            // 判断是否可点击，无状态节点不可点击
            if (!el.attr('class')) return;
            if (el.hasClass('active-wait') || el.hasClass('active-dh') || el.hasClass('finish')) {
                self.stageUl.find('li').removeClass('active active-arrow');
                el.addClass('active active-arrow');
                self._G.nodelistPosition.lastX = parseInt(self.stageUl.css('left'));
                //渲染回退原因，非当前节点不需要显示
                self.renderBackReasonTip(detail.stageId != stageId || el.hasClass('finish'));
            }

            // 如果是客户等待和客户到达，渲染的时间是stageInfo[2]的预约时间
            if (stageId == 'waitCust' || stageId == 'custArrived') {
                stageId = detail.stageInfo[2]['stageId'];
            }
            appointInfo = self.getStageInfo(stageId, detail.appointInfo);
            res.appointDate = appointInfo.appointDate ? self.formatTimeType(appointInfo.appointDate, 'spDate') : '';
            res.appointTime = appointInfo.appointTime ? self.formatTimeType(appointInfo.appointTime, 'time') : '';
            if (appointInfo.stageId == stageId && appointInfo.havaAppointTime == '1') {
                if (res.appointDate && res.appointTime) {
                    res.havaAppointTime = true;
                    res.showAppoint = true;
                } else {
                    res.havaAppointTime = false;
                    res.showAppoint = true;
                }
            } else {
                res.havaAppointTime = false;
                res.showAppoint = false;
            }
            self.appointFrame.html(self.frame_detailTimeAppoint(res));
            // 切换节点可以滑动
            if (C.Constant.CANMOVESTAGE[self.productType] && (detail.stageInfo.length > 4)) {
                self._G.nodelistPosition.lastX = parseInt(self.stageUl.css('left'));
                self.moveNodelist();
            }
        },

        //专员列表
        dealTask: function() {
            if(this.status == '0'){
                C.Native.tip('当前节点不是RO节点，不可改派');
                return;
            }
            this._G.taskDetailInfo.roUserId = '';
            var self = this,
                detail = self._G.taskDetailInfo,            // 任务详情信息
                stageId = detail.stageId,                   // 当前节点
                appointDate = C.Utils.data(C.Constant.DataKey.DETAIL_DATE) || '',//预约时间，格式YYYY-MM-DD
                json = {
                    api: C.Api('TASK_ATTACHELIST'),
                    data: {
                        stageId: stageId,
                        orderId: C.Utils.data(C.Constant.DataKey.DETAIL_TASKID), //订单id
                        productType: C.Utils.data(C.Constant.DataKey.DETAIL_PRODUCTTYPE), //产品类型
                        stageTime: appointDate,
                        cityId: C.Utils.data(C.Constant.DataKey.DETAIL_CITYID)
                    },
                    //获取专员列表超时时间2min
                    timeout : 2 * 60 * 1000
                };
            var callback = function(res) {
                if (res.data.length > 0) {
                    var data = res.data;
                    for(var i in data) {
                        data[i].stageTime = C.Utils.parseDateFormat(appointDate, 'MM月dd日'); // 使用的是列表的时间
                    }
                    // 安卓手机，滑动专员列表会卡顿，所以使用Native方法
                    if(App.IS_ANDROID) {
                        C.Native.taskAllot({
                            data: data,
                            callback: function(res) {
                                self._G.taskDetailInfo.roUserId = res.roUserId;
                                self.attacheSubBtn();   // 点击确定
                            }
                        });
                    } else {
                        for(var i=0;i<data.length;i++){
                            if(data[i].handleFlag == '1'){
                                data[i]['active']=true;
                                break;
                            }
                        }
                        $('.assignment').html(self.frame_attacheList({data:data}));
                        $('.js_attendanceLeayer').removeClass('dn');
                        //防止页面滚动
                        $('html,body').addClass('ovfHiden');
                        for (var i = 0; i < res.data.length; i++) {
                            if (res.data[i].handleFlag == 1) {
                                $('.js_attacheSubBtn').removeClass('btn-gray');
                                self._G.taskDetailInfo.roUserId = res.data[i].roUserId;
                                return;
                            } else {
                                $('.js_attacheSubBtn').addClass('btn-gray');
                            }
                        }
                    }
                } else {
                    C.Native.tip('暂无可分配的专员');
                }
            };
            var errorCall = function() {};
            json.errorCall = errorCall;
            json.callback = callback;
            self.requestData(json);
        },

        // 预览图片
        prevImg: function(e) {
            var el = $(e.currentTarget).children('img');
            C.Native.previewImage(el.attr('src'), el.attr('data-fileid'), el.attr('data-page'));
        },

        //选择专员
        choseAttendance: function(e) {
            var el = $(e.currentTarget);
            this._G.taskDetailInfo.roUserId = el.attr('data-id');
            el.addClass('active').siblings().removeClass('active');
            $('.js_attacheSubBtn').removeClass('btn-gray');
        },

        //分配任务确定按钮
        attacheSubBtn: function() {
            var self = this,
                type = self.taskInfoType;
            var json = {
                api: C.Api('TALLOT_TASK'),
                data: {
                    roUserId: '', //处理人
                    orderId: C.Utils.data(C.Constant.DataKey.DETAIL_TASKID), //订单id
                    productType: C.Utils.data(C.Constant.DataKey.DETAIL_PRODUCTTYPE), //订单产品类型
                    stageId: C.Utils.data(C.Constant.DataKey.DETAIL_STAGEID), //当前节点
                }
            };
            if (!self._G.taskDetailInfo.roUserId) {
                return;
            }
            //改派任务
            if (type != 1) {
                json.api = C.Api('CHANGE_TASK');
                json.data.cityId = C.Utils.data(C.Constant.DataKey.DETAIL_CITYID);
                (self.productType = 4) && (json.data.subtaskId = self.subId);
            }
            var callback = function(data) {
                data = data.data || {};
                var businessCode = data.businessCode,
                    businessMegs = data.businessMegs,
                    code = data.code,
                    msg = data.msg;
                // 只有在改派任务的时候才会有businessCode businessMegs
                // businessCode = 0 是客服节点 此时提示 businessMegs 否则是ro节点
                if (businessCode == '0') {
                    C.Native.tip(businessMegs);
                } else {
                    //任务分配成功 code:0  失败 code: 1
                    if (code == '0') {
                        C.Native.forward({
                            url: 'taskAllot_success.html'
                        });
                    } else {
                        C.Utils.data(C.Constant.DataKey.ALLOT_BAD_REASON, msg);
                        C.Native.forward({
                            url: 'taskAllot_fail.html'
                        });
                    }
                }
            };
            var errorCall = function(err) {
                //产品类型
                err = err || {};
                C.Utils.data(C.Constant.DataKey.ALLOT_BAD_REASON, err.msg || '系统繁忙');
                C.Native.forward({
                    url: 'taskAllot_fail.html'
                });
            };
            json.errorCall = errorCall;
            json.callback = callback;

            var rsaData = {
                roUserId: this._G.taskDetailInfo.roUserId, //处理人
            }

            C.rsaEncrypt(rsaData,function(data){
                //处理人
                json.data.roUserId = data.roUserId;

                self.requestData(json);
            });
            if(App.IS_LOCAL){
                json.data.roUserId = self._G.taskDetailInfo.roUserId;
                self.requestData(json);
            }
        },

        //分配任务取消按钮
        attacheCleBtn: function() {
            $('.js_attendanceLeayer').addClass('dn');
            $('html,body').removeClass('ovfHiden');
        },

        //关闭专员列表
        colseAttList: function() {
            $('.js_attendanceLeayer').addClass('dn');
            $('html,body').removeClass('ovfHiden');
        },

        // 拨打电话
        doCall: function (e) {
            var phone = e.currentTarget.innerText;
            C.Native.call(C.Utils.removeSpace(phone));
        }
    }));

    $(function() {
        new Page({
            el: $('body')[0]
        });
        $$.EventListener.onBack = function() {
            location.reload();
        }
    })
});
