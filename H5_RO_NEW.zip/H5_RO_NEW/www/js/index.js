define([
    'zepto',
    'C',
    'view',
    'underscore'
], function (
    $,
    C,
    View,
    _)
{

    'use strict';

    var Page = View.extend(_.extend({

        events: {
            'tap #openNewPage'         : 'openNewPage',
            'tap #openNewPageInCurPage': 'openNewPageInCurPage',
            'tap #loadingBegin'        : 'loadingBegin',
            'tap #loadingBeginWithText': 'loadingBeginWithText',
            'tap #loadingFinish'       : 'loadingFinish',
            'tap #tip'                 : 'tip',
            'tap #getDeviceId'         : 'getDeviceId',
            'tap #getDeviceInfo'       : 'getDeviceInfo',
            'tap #log'                 : 'log',
            'tap #getPhoto'            : 'getPhoto',
            'tap #sendEmail'           : 'sendEmail',
            'tap #call'                : 'call',
            'tap #getGestureStatus'    : 'getGestureStatus',
            'tap #saveGestureStatus'   : 'saveGestureStatus',
            'tap #checkGesture'        : 'checkGesture',
            'tap #setGesture'          : 'setGesture',
            'tap #getLBS'              : 'getLBS',
            'tap #getInfo'             : 'getUserInfo',
            'tap #more'                : 'more',
            'tap #home'                : 'home',
            'tap #search'              : 'search',
            'tap #token'               : 'token',
            'tap #attendance'          : 'attendance',
            'tap #picker'              : 'picker',
            'tap #reupload'            : 'reupload'
        },

        initialize: function () {
            var self = this;
            C.Native.setHeader({
                title: '平安RO'
            });
        },

        openNewPage: function () {
            C.Native.forward({
                url: 'test.html'
            });
        },

        openNewPageInCurPage: function () {
            C.Native.forwardInCurPage({
                url: 'test.html'
            });
        },

        loadingBegin: function () {
            C.Native.loadingBegin();
        },

        loadingBeginWithText: function () {
            var opt = {
                msg: '我是提示文案'
            };
            C.Native.loadingBegin(opt);
        },

        loadingFinish: function () {
            C.Native.loadingFinish();
        },

        tip: function () {
            C.Native.tip('我是tip提示文案');
        },

        getDeviceId: function () {
            C.Native.getDeviceId(function (res) {
                C.Native.tip(JSON.stringify(res));
            });
        },

        getDeviceInfo: function () {
            C.Native.getDeviceInfo(function (res) {
                C.Native.tip(JSON.stringify(res));
            });
        },

        log: function () {
            C.Native.log('我是log记录文案');
        },

        getPhoto: function () {
            C.Native.getPhoto(function (res) {
                C.Native.tip(JSON.stringify(res));
                $('.js_getPhoto').attr('src', res.path);
            });
        },

        sendEmail: function () {
            C.Native.sendEmail('', '', '');
        },

        call             : function () {
            C.Native.call('');
        },
        getGestureStatus : function () {
            var status = 0;
            C.Native.getGestureStatus(status, function (res) {
                C.Native.tip(JSON.stringify(res));
            })
        },
        saveGestureStatus: function () {
            C.Native.saveGestureStatus(function (res) {
                C.Native.tip(JSON.stringify(res));
            })
        },
        checkGesture     : function () {
            C.Native.checkGesture(function (res) {
                C.Native.tip(JSON.stringify(res));
            })
        },
        setGesture       : function () {
            C.Native.setGesture(function (res) {
                C.Native.tip(JSON.stringify(res));
            })
        },
        getLBS           : function () {
            C.Native.getLBS(function (res) {
                C.Native.tip(JSON.stringify(res));
            });
        },
        getUserInfo      : function () {
            C.Native.getUserInfo(function (res) {
                C.Native.tip(JSON.stringify(res));
            });
        },
        home             : function () {
            C.Native.forward({
                url: 'home.html'
            });
        },
        more             : function () {
            C.Native.forward({
                url: 'task_more.html'
            });
        },
        search           : function () {
            C.Native.forward({
                url: 'search.html'
            });
        },
        picker           : function () {
            $.ajax({
                url    : C.Api('APPOINT_TIME'),
                type   : 'get',
                data   : {},
                success: function (res) {
                    if (res.flag == C.Flag.SUCCESS) {
                        var obj     = {};
                        obj.hours   = {'data': res.hours, 'isCyclic': 'Y'};
                        obj.minutes = {'data': res.minutes, 'isCyclic': 'Y'};
                        obj.title   = '选择时间';
                        C.Native.showPicker(obj.hours, obj.minutes, '', obj.title, function (res) {
                            C.Native.tip(JSON.stringify(res));
                        });
                    }
                }
            });
        },
        /**
         *跳转至考勤页面
         */
        attendance       : function () {
            C.Native.forward({
                url: 'ro_attendance.html'
            });
        },
        /**
         * 获取最新任物数
         */
        getNum           : function (num) {
            C.Native.tip(num);
        },
        /**
         * token失效
         */
        token            : function () {
            C.Native.tokenNotEffect();
        },
        /**重新提交**/
        reupload: function(){
            C.Native.repeatUpload({
                orderId: '0001',
                nodeId: '000002',
                productType: 'zed',
                cityId: 'shenzhen'
            });
        }
    }));

    $(function () {
        var page                = new Page({
            el: $('body')[0]
        });
        $$.EventListener.getNum = page.getNum;
    })
});
