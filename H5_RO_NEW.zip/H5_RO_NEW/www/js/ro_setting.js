/**
 * @Author : ex-qingqi@pingan.com.cn
 * @Date   : 2016-03-23
 * @Time   : 15:10:00
 * @Modify : ex-tongwei001@pangan.com.cn
 *
 * @Description: 设置
 */
/* global define: false */

define([
	'zepto',
	'C',
	'view',
	'underscore',
	'trampolines'], function ($,
                             C,
                             View,
                             _) {

	'use strict';

	var Page = View.extend(_.extend({

		//事件对应方法
		events        : {
			'tap .js_switch'        : 'switchBtn',
			'tap #js_forgetPassword': 'forgetPassword',
			'tap #js_version'       : 'getVersionInfo',
			'tap .btn-confirm'      : 'confirmCancel',
			'tap .close'            : 'confirmCancel',
			'tap #js_rePassword'    : 'rePassword'
		},
		switchStatu: $('.js_switch input'),   // 开关状态
		notSupport: $('.js_proDlg'),   // 不支持电脑修改密码弹框
		passConfirm: $('.js_passConfirm'),   // 密码验证弹框
		rePaswd: $('#js_rePassword'),  // 修改收拾密码条
		//初始化
		initialize    : function () {
			var self = this;
			C.Native.setHeader({
				title       : '设置',
				leftCallback: function () {
					C.Native.back();
				}
			});
			C.Native.getGestureStatus(function(res){
				if(res.status == '1'){
					self.commonSwitch('checked','disabled');
					self.rePaswd.removeClass('dn');
				}else{
					self.commonSwitch('disabled','checked');
					self.rePaswd.addClass('dn');
				}
			});
			if(App.IS_LOCAL){
				var res = {status:1};
				if(res.status == '1'){
					self.commonSwitch('checked','disabled');
					self.rePaswd.removeClass('dn');
				}else{
					self.commonSwitch('disabled','checked');
					self.rePaswd.addClass('dn');
				}
			}
			C.Native.loadingFinish();
		},
		// 开关公共逻辑
		commonSwitch: function(dType,cType){
			this.switchStatu.attr(dType,true).removeAttr(cType);
		},
		// 校验开关是否打开
		confirmSwitch: function(type){
			// 校验开关是否打开 0 开 1 关
			C.Native.checkGesture(function(res){
				if(res.code == '1'){
					// 设置手势密码页面
					C.Native.setGesture(type,function (res) {
						// 设置成功了打开开关 0 成功
						if(res.code == '0'){
							// 保存开关状态
							C.Native.saveGestureStatus('1');
							location.reload();
						}else{
							C.Native.saveGestureStatus('0');
						}
					});
				}else{
					C.Native.saveGestureStatus('0');
				}
			});
		},
		//切换开关功能提示
		switchBtn        : function () {
			var self = this;
			// 开关打开的时候 调用检验开关打开
			if(!self.switchStatu.attr('checked')){
				self.confirmSwitch('0');
			}else{
				C.Native.saveGestureStatus('0');
				location.reload();
			}
		},
		//提示密码不能修改及其按钮对应事件
		forgetPassword: function () {
			this.notSupport.removeClass('dn');
		},
		// 关闭弹框
		confirmCancel : function () {
			this.notSupport.addClass('dn');
		},
		//版本信息
		getVersionInfo: function () {
			C.Native.forward({
				url: 'version.html'
			})
		},

		// 修改手势密码
		rePassword: function() {
			//this.passConfirm.removeClass('dn');
			this.confirmSwitch('1');
		}
	}));
	$(function () {
		new Page({
			el: $('body')[0]
		});
		$$.EventListener.onBack = function () {
			location.reload();
		}
	})
});
