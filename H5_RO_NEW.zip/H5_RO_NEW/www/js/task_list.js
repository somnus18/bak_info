/**
 * @Author : zhangjunli001@pingan.com.cn
 * @Date   : 2016-05-05
 * @Time   : 11:20:32
 *
 * @Description: 我的任务
 */
/* global define: false */

define(['zepto', 'C', 'view', 'scrollView'], function ($, C, View, scrollView) {

    'use strict';

    var Page = View.extend(_.extend(scrollView, {


        // 事件
        events: {
            'tap .js_third': 'callPhone',
            'tap .js_modify_time': 'modifyTime',
            'tap #close': 'closeDialog',
            'tap #cancel': 'closeDialog',
            'tap #orderDate': 'modifyPopDate',
            'tap #orderTime': 'modifyPopTime',
            'tap #sure': 'sureModifyTime',
            'tap #modifyReason': 'chooseModifyReason',
            'tap .js_box': 'chooseLi',
            'tap #getTask': 'getTask',
            'tap #sure-task': 'reloadTask'
        },
        // 区域指定
        el: 'body',
        // 用户列表模板
        custTpl: _.template($('#listTpl').html()),
        // 每页显示条数
        account: 20,
        // account: 2,
        // 保存前一页数据
        objectInfo: {},
        // 保存第一页数据
        objFirst: [],
        // 防重标示
        isPost: false,
        // 判断滑动刷新的范围
        isBoll: true,
        // 模板的父元素
        ulParentEl: $('#ul_parent'),
        // 初始化
        initialize: function () {
            var self = this;
            C.Native.setHeader({
                title: '任务清单',
                leftCallback: function () {
                    C.Native.back();
                }
            });
            self.getHdId = C.Utils.getParameter('hdId') || '';
            self.reasonData = {};  // 修改原因的时候获取的返参
            self.index = 0;
            self.render();
        },
        //下拉刷新
        pullDownActionBase: function () {
            var self = this;
            if (self.isLoading) return;
            self.isLoading = "down";
            self.index = 0;
            self.getData(true);
        },
        //上拉加载
        pullUpActionBase: function () {
            var self = this;
            if (self.isLoading) return;
            self.isLoading = "up";
            self.getData(true);
        },
        /**
         * 页面渲染
         */
        render: function () {
            var self = this;
            self.getData();
        },
        /**
         * @param type '按揭3  宅e贷 4    二手房2
         */
        getData: function (do_action) {
            var self = this,
                page = null,
                data = null,
                datas = [],
                noTask = $('#js_noTask');
            page = self.index + 1;
            if (self.isPost) return;
            self.isPost = true;
            C.UI.loading();
            $.ajax({
                url: C.Api('GET_ORDER_TASK_LIST'),
                data: {
                    page: page,
                    pageSize: self.account,
                    hdId: self.getHdId
                },
                type: 'get',
                //是否上拉或下拉刷新任务列表
                has_action_refresh: do_action,
                success: function (res) {
                    self.isPost = false;
                    if (res.flag == C.Flag.SUCCESS) {
                        $('#getTask').removeClass('no-click');
                        data = res.data;
                        //隐藏无任务提示
                        noTask.hide();
                        if (data.length) {
                            datas = C.removeRepeatData(data, self.objectInfo, datas, page, 'subtaskId', false);   // 去除重复数据之后保存的数组
                            if (!datas.length) {
                                delete self.isLoading;
                            } else {
                                self.getInfo(datas);
                            }
                            $('#getTask').parent().removeClass('dn');
                            self.objectInfo = datas;
                            self.index++;
                        } else {
                            if (page == 1) {
                                self.emptyList();   // 清空任务列表，显示暂无任务
                                $('#getTask').addClass('no-click');
                            } else {
                                C.Native.tip('没有更多数据');
                            }
                        }
                    } else {
                        page == 1 && !do_action && self.emptyList();
                    }
                    delete self.isLoading;
                    C.UI.stopLoading();
                    delete self.isLoading;
                    self.refreshScroll();
                    //安装iScroll组件
                    self.installScroll();
                },
                error: function (xhr, errorType, errorMsg) {
                    self.isPost = false;
                    if (self.hasInitScroll) self.refreshScroll();
                    C.Native.loadingFinish();
                    delete self.isLoading;
                    if (page == 1 && !do_action) {
                        noTask.show();
                        $('#getTask').addClass('no-click');
                    }
                    self.installScroll();
                }
            });
        },
        /**
         * 允许iScroll
         */
        installScroll: function () {
            var self = this;
            if (!self.hasInitScroll) {
                // 动态改变列表的高度
                var scrollContainerH = $('.layout').height();
                var headHeight = window.innerHeight - $('header').height() - $('.tab').height();
                if (scrollContainerH < headHeight)
                    scrollContainerH = headHeight;
                self.install(scrollContainerH);
                self.hasInitScroll = true;
            }
        },
        /**
         * 公共取值
         */
        getInfo: function ($el) {
            var arrInfo = [],
                self = this;
            $.each($el, function (index, item) {
                item.prdTypeName = C.Constant.BUSINESS_LINE_NAME[item.productType];
                item.appointDate = new Date().getFullYear() + '-' + (new Date().getMonth() + 1) + '-' + (new Date().getDate());
                item.formatDate = item.appointDate ? C.Utils.parseDateFormat(item.appointDate, 'MM月dd日') : '';
                item.formatTime = item.appointTime ? item.appointTime.split(':')[0] + ':' + item.appointTime.split(':')[1] : '';
                item.custMobile = item.custPhone ? C.Utils.formatMobileNo(item.custPhone) : '';
                arrInfo.push(self.custTpl(item));
            });
            if (self.isLoading == 'up') {
                self.ulParentEl.append(arrInfo.join(''));
            } else {
                self.ulParentEl.html(arrInfo.join(''));
            }
            delete self.isLoading;
        },
        // 清空列表显示暂无任务图标
        emptyList: function () {
            this.ulParentEl.empty();
            $('#js_noTask').show();
        },
        // 拨打电话
        callPhone: function (e) {
            C.Native.call($(e.currentTarget).attr('data-phone'));
        },
        /**
         * 返回当前日期的时间
         */
        formatTime: function () {
            var minute = Math.ceil(new Date().getMinutes() / 10) * 10, hour = new Date().getHours();
            minute = minute == 60 ? '00' : minute.toString();
            hour = minute == '00' && hour == 23 ? '00' : (minute == '00' ? (hour + 1).toString() : hour.toString());
            var showHour = hour.length == 2 ? hour : '0' + hour,
                showMinute = minute.length == 2 ? minute : '0' + minute;
            return showHour + ':' + showMinute;
        },
        // 弹框数据的格式化
        formatModifyTime: function (curr) {
            var getDate = curr.data('date'),
                getTime = curr.data('time'),
                nowDate = C.Utils.parseDateFormat(new Date(), 'yyyy-MM-dd'),
                nowTime = this.formatTime();
            if (getDate && getTime) {
                nowDate = getDate;
                nowTime = getTime;
            }
            if (nowTime > this.reasonData['workTimeEnd']) {
                nowTime = this.reasonData['workTimeEnd'];
            } else if (nowTime < this.reasonData['workTimeBegin']) {
                nowTime = this.reasonData['workTimeBegin'];
            }
            nowDate = nowDate.split('-');
            nowTime = nowTime.split(':');
            $('#orderDate').find('span').eq(0).html(nowDate[0] + '年' + nowDate[1] + '月' + nowDate[2] + '日').data({
                'c1': nowDate[0],
                'c2': nowDate[1],
                'c3': nowDate[2]
            });
            $('#orderTime').find('span').eq(0).html(nowTime[0] + ':' + nowTime[1]).data({
                'c1': nowTime[0],
                'c2': nowTime[1]
            });
        },
        // 修改时间打开预约时间的浮层
        modifyTime: function (e) {
            var curr = $(e.currentTarget);
            this.subtaskId = curr.closest('li').attr('data-id');
            this.productType = curr.closest('li').attr('data-prdtype');
            this.orderId = curr.closest('li').attr('data-orderid');
            this.hdId = curr.closest('li').attr('data-hdid');
            this.getReasonList($(e.currentTarget).find('div').eq(0));
        },
        // 关闭浮层的dialog
        closeDialog: function () {
            $('#leayerDialog').addClass('dn');
        },
        // 提交修改时间的参数
        getModifyParam: function () {
            var appointTime = $('#orderTime').find('span').eq(0).text(),
                appointDate = C.Utils.parseDateFormat($('#orderDate').find('span').eq(0).text(), 'yyyy-MM-dd'),
                reasonId = $('#modifyReason').find('span').eq(0).data('key'),
                otherReason = $.trim($('#text-area').val()) || '';
            return {
                appointTime: appointTime,
                appointDay: appointDate,
                reasonId: reasonId,
                productType: this.productType,
                orderId: this.orderId,
                subtaskId: this.subtaskId,
                otherReason: otherReason
            }
        },
        // 确认修改
        sureModifyTime: function () {
            var self = this,
                resultData = self.getModifyParam();
            if (!resultData.reasonId) {
                C.Native.tip('需选择修改原因,请选择');
                return;
            }
            if (self.hasOtherReason && !resultData.otherReason) {
                C.Native.tip('请输入其他原因');
                return;
            }
            if (self.isPost) return;
            self.isPost = true;
            C.UI.loading();
            $.ajax({
                url: C.Api('SUBMIT_MODIFY_TIME'),
                data: resultData,
                type: 'post',
                success: function (res) {
                    self.isPost = false;
                    if (res.flag == C.Flag.SUCCESS) {
                        self.closeDialog();   // 关闭浮层弹框
                        C.UI.stopLoading();
                        location.reload(); // 修改成功之后刷新当前列表
                    }
                }
            })
        },
        // 修改浮层预约日期
        modifyPopDate: function (e) {
            var defaultValue = '',
                curr = $(e.currentTarget).find('span').eq(0),
                outDate = '1', // 不可选择之前的日期
                text = curr.text(),
                c1 = curr.data('c1'),
                c2 = curr.data('c2'),
                c3 = curr.data('c3');
            if (text && c1 && c2 && c3) {
                defaultValue = {
                    c1: c1,
                    c2: c2,
                    c3: c3
                }
            }
            C.Native.selectDateTime({
                defaultValue: defaultValue,
                title: '选择日期',
                type: 'date',
                timeRange: '', // 可预约时间段
                outDate: outDate,
                callback: function (res) {
                    if (res.code == '0') {
                        curr.text(res.selectResult.c1 + '年' + res.selectResult.c2 + '月' + res.selectResult.c3 + '日').data({
                            'c1': res.selectResult.c1,
                            'c2': res.selectResult.c2,
                            'c3': res.selectResult.c3
                        });
                    }
                }
            })
        },
        // 修改浮层预约时间
        modifyPopTime: function (e) {
            var defaultValue = '',
                rangeTime = this.reasonData['workTimeBegin'] + '-' + this.reasonData['workTimeEnd'],
                currTime = null,
                $el = $(e.currentTarget).find('span').eq(0),
                text = $el.text(),
                c1 = $el.data('c1'),
                c2 = $el.data('c2');
            if (text && c1 && c2) {
                defaultValue = {
                    c1: c1,
                    c2: c2
                }
            }
            if (!defaultValue) {
                currTime = this.formatTime().split(':');
                defaultValue = {
                    c1: currTime[0],
                    c2: currTime[1]
                }
            }
            C.Native.selectDateTime({
                defaultValue: defaultValue,
                title: '选择时间',
                type: 'time',
                outDate: '',
                timeRange: rangeTime,
                callback: function (res) {
                    if (res.code == '0') {
                        $el.text(res.selectResult.c1 + ':' + res.selectResult.c2).data({
                            'c1': res.selectResult.c1,
                            'c2': res.selectResult.c2
                        });
                    }
                }
            })
        },
        // 获取原因列表
        getReasonList: function (curr) {
            var self = this;
            if (self.isPost) return;
            self.isPost = true;
            C.UI.loading();
            $.ajax({
                url: C.Api('GET_MODIFY_REASON'),
                data: {hdId: self.hdId},
                type: 'get',
                success: function (res) {
                    self.isPost = false;
                    if (res.flag == C.Flag.SUCCESS) {
                        self.reasonData = res.data;  // 返回的原因数据
                        self.formatModifyTime(curr);
                        $('#leayerDialog').removeClass('dn');
                        C.UI.stopLoading();
                    }
                }
            });
        },
        // 选择修改原因
        chooseModifyReason: function (e) {
            var self = this,
                backReason = this.reasonData['reasonList'],
                newReason = new Array(),
                defaultValue = '',
                reasonEl = $(e.currentTarget).find('span').eq(0);
            for (var i in backReason) {
                var tmpObj = {
                    key: backReason[i]['reasonId'],
                    value: backReason[i]['reason']
                };
                newReason.push(tmpObj);
            }
            var key = reasonEl.data('key'),
                text = reasonEl.text();
            if (key && text) {
                defaultValue = {
                    value: text,
                    key: key
                }
            }
            C.Native.showPicker({
                defaultValue: defaultValue,
                data: newReason,
                title: '选择原因',
                callback: function (res) {
                    if (res.code == '0') {
                        reasonEl.text(res.selectResult.value).data('key', res.selectResult.key);
                        if (res.selectResult.key == '5') {
                            $('.text-area').removeClass('dn');
                            self.hasOtherReason = true;
                        } else {
                            $('.text-area').addClass('dn');
                            self.hasOtherReason = false;
                        }
                    }
                }
            });
        },
        // 选取任务
        chooseLi: function (e) {
            var curr = $(e.currentTarget).find('div');
            if (curr.hasClass('icon-ck-check')) {
                curr.removeClass('icon-ck-check').addClass('icon-sck-check');
            } else {
                curr.addClass('icon-ck-check').removeClass('icon-sck-check');
            }
        },
        // 获取任务
        getTask: function (e) {
            if ($(e.currentTarget).hasClass('no-click')) return;
            var self = this, arr = [];
            $('li').each(function () {
                if ($(this).find('div').hasClass('icon-sck-check')) {
                    arr.push($(this).data('id'));
                }
            });
            if (!arr.length) {
                C.Native.tip('请勾选任务');
                return;
            }
            if (self.isPost) return;
            self.isPost = true;
            C.UI.loading();
            $.ajax({
                url: C.Api('SUBMIT_GET_TASK_LIST'),
                data: {
                    subtaskIds: arr.join(','),
                    hdId: self.getHdId
                },
                type: 'post',
                success: function (res) {
                    self.isPost = false;
                    if (res.flag == C.Flag.SUCCESS) {
                        C.Native.tip('获取任务清单成功');
                        C.UI.stopLoading();
                        location.reload();
                    } else {
                        $('#fail-msg').text(res.msg);
                        $('#fail-task').removeClass('dn');
                        C.UI.stopLoading();
                    }
                }
            });
        },
        reloadTask: function () {
            // 失败刷新当前页面
            location.reload();
            $('#fail-task').addClass('dn');
        }
    }));

    $(function () {
        new Page({
            el: $('body')[0]
        });
    })
});
