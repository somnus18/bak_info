/**
 * @Author : ex-qingqi@pingan.com.cn
 * @Date   : 2016-04-25
 * @Time   : 13:20:00
 *
 * @Description: 我的名片
 */
/* global define: false */

define(['zepto', 'C', 'view'], function($, C,View) {

    var Page = View.extend(_.extend({

        events:{
            'tap #back': 'back'
        },
        initialize: function() {
            var self = this;
            C.Native.setHeader({
                title: '我的名片',
                leftCallback: function() {
                    C.Native.back();
                }
            });
            self.render();
        },
        render: function() {
            //调用native方法，取值渲染
            C.Native.getUserInfo(function (res) {
               var dataParam={
                    userName:res.userName,
                    userUm:res.userId,
                    storeName:res.storeName,
                    headPhoto:res.headPhoto || 'images/pic.jpg'
                };
                $('#js_my_card').html(_.template($('#cardTemp').html())(dataParam));
                C.Native.loadingFinish();
            });
            //本地模拟数据接收
            if(App.IS_LOCAL){
                $.ajax({
                    url: C.Api('RO_MYACARD'),
                    type:'get',
                    success: function (res) {
                        if(res.flag== C.Flag.SUCCESS){
                            console.log(res.msg );
                            $('#js_my_card').html(_.template($('#cardTempl').html())(res.data))
                        }
                    }
                });
            }
        }
    }));

    $(function(){
        new Page({
            el: $('body')[0]
        });
    })
});
