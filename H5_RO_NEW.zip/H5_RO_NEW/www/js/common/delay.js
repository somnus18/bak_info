/**
 * Created by EX-LEIXUDONG001 on 2015/8/10.
 */
 define(["zepto"], function($) {
    var loopObj = {
        timer: null,
        timerWrap: null
    }
    $.fn.saveTipWordOne = function(params) {
        var params = $.extend({
            str: '正在保存'
            ,isSave: true
            ,isSetGray: true //this 区域是否置灰
        }, params);
        var thisDom = $(this);
            text = thisDom.text(),
            htl = '&nbsp;<span id="point_no" style="display: inline-block;">...</span>',
            txt = '';
        thisDom.text(params.str);
        if(params.isSave){
            thisDom.append(htl);
            $('#point_no').html('');
            loopObj.timerWrap  = setInterval(function(){
                window.clearInterval(loopObj.timer);
                loopObj.timer = setInterval(function(){
                    if(txt.length > 3){
                        txt = '';
                    };
                    txt += '.';
                },500);
                $('#point_no').text(txt);
            },1000);

        }else{
            thisDom.attr('disabled',null)
                .removeClass('btn_default_gray')
                .removeAttr('style')
                .find('span[id="point_no"]').remove();
            window.clearInterval(loopObj.timer);
            window.clearInterval(loopObj.timerWrap);
        }
        if(params.isSetGray){
            thisDom.addClass('btn_default_gray')
            thisDom.attr('disabled',true).css({"opacity" : 1})
        }
    }
});
