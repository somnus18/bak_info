/*!
 * talking 模块常量
 * @module talkingdata
 * @author 周一平
 * @history 2015-6-10 add
 */
define([], function() {
    var TD = {
        Label: {
        },
        Event: {
        }
    }
    return TD;
});
