define(["js/common/utils"], function(Utils) {
    var App = window.App || {};
    var defaultCallback = function(){};
    return {
        /**
         * 新开webview开启新页面
         * @param options 对象 {title:"",url:""}
         * .url 字符串 跳转的链接
         * .defaultCallback 函数 function(){} 请求处理
         * 跳转参数
         */
        forward: function (options) {
            var data = options.data,
                url = options.url;
            if (data) {
                data = $.param(data);
                if (url.indexOf('?') > -1) {
                    url += '&' + data;
                } else {
                    url += '?' + data;
                }
            }
            // 本地开发浏览器环境
            if (App.IS_LOCAL) {
                location.href = url;
                return;
            }
            // 过滤param
            if (url && url.indexOf('?') > -1) {
                var param = [],
                    urlHost = url.split('?')[0],
                    urlData = Utils.getQueryMap(url);
                for (var key in urlData) {
                    var tmp = '';
                    try {
                        tmp = decodeURIComponent(urlData[key]);
                    } catch (e) {
                        tmp = urlData[key];
                    }
                    param.push(key + '=' + encodeURIComponent(tmp));
                }
                url = urlHost + '?' + param.join('&');
            }
            url = url.replace(/(%2F)/ig, '/');
            App.call('forwardToNewPage', url, options.callback || '');
        },


        /**
         * 在当前webview开启新页面
         * @param options 对象 {title:"",url:""}
         * .url 字符串 跳转的链接
         * .defaultCallback 函数 function(){} 请求处理
         * 跳转参数
         */
        forwardInCurPage: function (options) {
            var data = options.data,
                url = options.url;
            if (data) {
                data = $.param(data);
                if (url.indexOf('?') > -1) {
                    url += '&' + data;
                } else {
                    url += '?' + data;
                }
            }
            // 本地开发浏览器环境
            if (App.IS_LOCAL) {
                location.href = url;
                return;
            }
            if (url && url.indexOf('?') > -1) {
                var param = [],
                    urlHost = url.split('?')[0],
                    urlData = utils.getQueryMap(url);
                for (var key in urlData) {
                    var tmp = '';
                    try {
                        tmp = decodeURIComponent(urlData[key]);
                    } catch (e) {
                        tmp = urlData[key];
                    }
                    param.push(key + '=' + encodeURIComponent(tmp));
                }
                url = urlHost + '?' + param.join('&');
            }
            url = url.replace(/(%2F)/ig, '/');
            App.call('forwardInCurPage', url, options.callback || '');
        },

        /**
         * 页面返回
         * @param options {url:""}
         * .url back返回的url,为空默认返回上一个页面,
         * .data 返回后Native调用C.Service.onback()事件, 并将参数data传递给onback方法
         *                如果返回到流程开始的的页面,需要传页面名字,如"info_loan.html"
         * .defaultCallback 函数 function(){} 请求处理
         */
        back: function (options) {
            var options = options || {},
                url = '',
                data = '';
            if (options && options.url) {
                url = options.url;
                if (!(/^https*:\/\//.test(url))) {
                    url = url;
                }
            }
            if (options && options.data) {
                data = options.data;
            }
            // 本地开发浏览器环境
            if (App.IS_LOCAL) {
                location.href = url;
                return;
            }
            App.call('back', url || '', data || '', options.callback || '');
        },


        /**
         * 模块间跳转
         */
        forwardModule: function (options) {
            var data = options.data,
                url = options.url,
                moduleName = options.moduleName;
            if (data) {
                data = $.param(data);
                if (url.indexOf('?') > -1) {
                    url += '&' + data;
                } else {
                    url += '?' + data;
                }
            }
            // 本地开发浏览器环境
            if (App.IS_LOCAL) {
                location.href = url;
                return;
            }
            // 过滤param
            if (url && url.indexOf('?') > -1) {
                var param = [],
                    urlHost = url.split('?')[0],
                    urlData = Utils.getQueryMap(url);
                for (var key in urlData) {
                    var tmp = '';
                    try {
                        tmp = decodeURIComponent(urlData[key]);
                    } catch (e) {
                        tmp = urlData[key];
                    }
                    param.push(key + '=' + encodeURIComponent(tmp));
                }
                url = urlHost + '?' + param.join('&');
            }
            url = url.replace(/(%2F)/ig, '/');
            App.call('forwardModule', moduleName, url, options.callback || '');
        },


        /**
         * 设置头部信息
         * @param options {title:"标题",isBack:true,leftCallback:function(){},isClose:true,closeCallback:function(){}}
         * .title 字符串 设置头部标题
         * .isBack 布尔值 是否有返回图标
         * .leftCallback function(){} 函数 设置左边回调
         * .rightText 布尔值 是否有关闭图标
         * .rightIcon  function(){} 函数 设置右边回调
         * .rightCallback function(){} 函数 设置右边回调
         * .data 扩展数据 Json格式  如：isFullScreen(是否全屏)
         */
        setHeader: function (options) {
            var leftCallback = options.leftCallback || '',
                rightCallback = options.rightCallback || '';
            if (typeof options.isBack == 'undefined') {
                options.isBack = true;
            }
            App.call('setHeader', options.title || '', !!options.isBack, leftCallback, options.rightText, options.rightIcon || '', rightCallback, options.data || '');
        },


        /**
         * 发送HTTP请求
         * @import jQuery|Zepto
         * @param options 对象{type:"get",data:{},successCallBack:function(res){},failCallBack:function(res){}}
         * @param .data JSON对象 请求入参
         * @param .type 字符串 请求方式，默认get
         * @param .success 函数 function(){} 请求成功处理
         * @param .error  函数 function(){} 请求失败处理
         */
        request: function (options) {
            var data = options.data || {},
                param = [],
                type = options.type || 'get';
            if (data && typeof data == 'object') {
                for (var key in data) {
                    try {
                        param.push(key + '=' + decodeURIComponent(data[key]));
                    } catch (e) {
                        param.push(key + '=' + data[key]);
                    }
                }
                data = param.join('&');
            }
            App.call('request', options.url, type, options.headers || '', data, options.success, options.error);
        },


        /**
         * 显示加载动画 C.UI.loading();
         * options.msg 当不允许取消加载动画时 提示信息
         */
        loadingBegin: function (options) {
            var msg = '';
            if (options) {
                msg = options.msg;
            }
            App.call('loadingBegin', msg);
        },

        /**
         * 关闭加载动画 C.UI.stopLoading();
         */
        loadingFinish: function () {
            App.call('loadingFinish');
        },


        /**
         * 提示
         * .text 字符串 C.Native.tipf('提示内容');
         */
        tip: function (text) {
            var text = text || '';
            // 本地开发浏览器环境
            if (App.IS_LOCAL) {
                alert(text);
            }
            App.call('tip', text);
        },


        /**
         * 设备ID，使用TalkingData的方式获取
         */
        getDeviceId: function (callback) {
            App.call('getDeviceId', callback || defaultCallback);
        },


        /**
         * 一些手机信息 如手机版本 厂商 MAC等
         * */
        getDeviceInfo: function (callback) {
            App.call('getDeviceInfo', callback || defaultCallback)
        },


        /**
         * 本地打印日志
         * .text 字符串 C.Native.log('日志内容');
         */
        log: function (text) {
            var text = text || '';
            App.call('log', text);
        },


        /**
         * TalkingData
         * options 对象 {eventId: '', eventLable: '', jsonData: ''}
         */
        TDOnEven: function (options) {
            App.call('TDOnEven', options.eventId || '', options.eventLable || '', options.jsonData || '');
        },


        getPhoto: function (callback) {
            App.call('getPhoto', callback || defaultCallback);
        },

        sendEmail: function (addressee, subject, text) {
            App.call('sendEmail', addressee || '', subject || '', text || '');
        },


        call: function (phoneNumber) {
            App.call('call', phoneNumber || '');
        },
        //读取手势开关状态
        getGestureStatus: function (callback) {
            App.call('getGestureStatus', callback || defaultCallback);
        },
        //保存手势开关状态
        saveGestureStatus: function (status, callback) {
            App.call('saveGestureStatus', status || 0, callback || defaultCallback);
        },
        //调起手势密码校验
        checkGesture: function (callback) {
            App.call('checkGesture', callback || defaultCallback);
        },
        //调起手势密码设置 gesType  0:设置手势密码  1:重设手势密码
        setGesture: function (gesType,callback) {
            App.call('setGesture',gesType || '', callback || defaultCallback);
        },
        /**
         * 获取位置信息
         * callback {
            code: 0             // 错误码。0获取成功，1获取失败
            msg: '获取定位操作提示'
            longitude: ''       // 经度
            latitude: ''        // 纬度
            name: ‘’            // 位置名称
        }
         */
        getLBS: function (callback) {
            App.call('getLBS', callback || defaultCallback);
        },

        // APP版本信息
        getVersionInfo: function (callback) {
            App.call('getVersionInfo', callback || defaultCallback);
        },

        // 显示Webview头部
        show: function () {
            App.call('show');
        },

        // 隐藏Webview头部
        hide: function () {
            App.call('hide');
        },

        // 获取用户信息
        getUserInfo: function (callback) {
            App.call('getUserInfo', callback || defaultCallback);
        },

        // 选择器
        showPicker: function (options) {
            App.call('showPicker', options.defaultValue || '', options.data, options.title || '', options.callback || defaultCallback);
        },

        // 日期/时间选择器
        selectDateTime: function(options) {
            App.call('selectDateTime', options.defaultValue || '', options.title || '', options.type || '',options.outDate || '',options.timeRange || '', options.callback || defaultCallback);
        },

        // token失效
        tokenNotEffect: function () {
            App.call('tokenNotEffect');
        },

        // 图片预览
        previewImage: function (url, fileId, page) {
            App.call('previewImage', url, fileId, page);
        },

        // 上传图片页面
        upLoadImage: function (option) {
            App.call('upLoadImage', option);
        },

        // 上传图片页面(宅e贷)
        upLoadImageE: function (option) {
            App.call('upLoadImageE', option);
        },

        // 获取缓存数据
        getData: function (key, callback) {
            App.call('getData', key, callback || defaultCallback);
        },

        // 缓存数据
        saveData: function (key, value) {
            App.call('saveData', key || '', value || '');
        },

        // 重新提交确认节点任务
        repeatUpload: function (options) {
            App.call('repeatUpload', options.orderId, options.nodeId, options.productType, options.cityId);
        },

	    /**
         * 保存时间戳(毫秒值)
         * @param millisecond
         */
        saveTimestamp:function (millisecond) {
            App.call('saveTimestamp', millisecond || Date.now());
        },

        /**
         * 清除本地缓存文件
         * 入参： orderId
                  stageId
                  fileTypeId
         */
        clearCache: function(options){
            App.call('clearCache', options.orderId || '',options.stageId || '',options.fileTypeId || '');
        },

        /**
         * 清除主页未读消息数量显示
         */
        clearMsgNum:function () {
            App.call('clearMsgNum');
        },

	    /**
	     * 跳转至登录界面
         */
        gotoLogin:function (flag) {
            App.call('gotoLogin',flag);
        },

        /**
         * 开始轮巡
         */
        startPolling: function(){
            App.call('startPolling');
        },

        /**
         * rsa加密
         */
        rsaByNative: function(option){
            App.call('rsaByNative',option.param,option.type,option.callback || defaultCallback);
        },
        /**
         * 专员列表
         */
        taskAllot: function(option) {
            App.call('taskAllot', option.data || {}, option.callback || defaultCallback);
        },
        /**
         * @param option data [{"address":"北京一环","hdName":"你好","hdId":"1231"}],  如果有默认选中 多一个参数 mSelectId
         *  出参  {“hdId“:”1231”}
         */
        showHdSelectList: function (option) {
            App.call('showHdSelectList', option.data || [], option.callback || defaultCallback);
        }
    }
});
