(function(window,undefined) {
    window.$$ = {extend: function(n,o){for(var i in o)o.hasOwnProperty(i)&&(n[i]=o[i])}};
    /**
     * ro模块Native组件方法列表
     * */
    var roMethodList = {
	    'forwardToNewPage' : 'BusinessJump',
	    'forwardInCurPage' : 'BusinessJump',
	    'back'             : 'BusinessJump',
	    'forwardModule'    : 'BusinessJump',
	    'setHeader'        : 'Header',
	    'request'          : 'HttpPlugin',
	    'loadingBegin'     : 'BusinessCommon',
	    'loadingFinish'    : 'BusinessCommon',
	    'tip'              : 'BusinessCommon',
	    'getDeviceId'      : 'BusinessCommon',
	    'getDeviceInfo'    : 'BusinessCommon',
	    'log'              : 'BusinessCommon',
	    'TDOnEven'         : 'BusinessCommon',
	    'getPhoto'         : 'Photo',
	    'sendEmail'        : 'Email',
	    'call'             : 'Phone',
	    'getGestureStatus' : 'Gesture',
	    'saveGestureStatus': 'Gesture',
	    'checkGesture'     : 'Gesture',
	    'setGesture'       : 'Gesture',
	    'getLBS'           : 'Location',
	    'getVersionInfo'   : 'AppInfo',
	    'show'             : 'Header',
	    'hide'             : 'Header',
	    'getUserInfo'      : 'UserInfo',
	    'showPicker'       : 'Picker',
	    'selectDateTime'   : 'Picker',
        'taskAllot'        : 'Picker',
	    'tokenNotEffect'   : 'BusinessCommon',
	    'saveData'         : 'BusinessCommon',
	    'getData'          : 'BusinessCommon',
	    'upLoadImage'      : 'Task',
        'upLoadImageE'     : 'Task',
	    'previewImage'     : 'Task',
	    'repeatUpload'     : 'Task',
	    'showHdSelectList' : 'Task',
	    'saveTimestamp'    : 'BusinessCommon',
	    'clearMsgNum'      : 'BusinessCommon',
	    'gotoLogin'        : 'BusinessCommon',
	    'clearCache'       : 'Task',
        'startPolling'     : 'BusinessCommon',
        'rsaByNative'      : 'BusinessCommon'
    };
    var App = window.App = window.$$.platformAdapter = {},
        slice = Array.prototype.slice;

    /**
     * 常量定义
     */
    var ua = navigator.userAgent.toUpperCase();
    // 当前环境是否为Android平台
    App.IS_ANDROID = ua.indexOf('ANDROID') != -1;
    // 当前环境是否为IOS平台
    App.IS_IOS = ua.indexOf('IPHONE OS') != -1;
    // 当前环境是否为WP平台
    App.IS_WP = ua.indexOf('WINDOWS') != -1 && ua.indexOf('PHONE') != -1;
    // 当前环境是否为本地开发浏览器环境
    App.IS_LOCAL = (location.hostname=="localhost");

    var toString = Object.prototype.toString;

    //=======================Native ro App 相关开始================================

    var slice = Array.prototype.slice,
        count = 0,
        loop = function () {
        };

     function errHandler(error) {
        switch (error.code) {
            case '001':
                App.call('tip', '网络异常，请更换网络环境并重试');
                break;
            case '002':
                App.call('tip', '没有连接网络');
                break;
            case '003':
                App.call('tip', '网络超时');
                break;
            case '004':
                App.call('tip', '服务器发生异常');
                break;
            default:
                App.call('tip', '未知错误');
                break;
        }
    }
    /**
     * 调用一个Native方法
     * @param {String} name 方法名称
     */
     $$.extend(App, {
        /**
         * @private
         * 回调函数集
         */
        _handlers: {},
        /**
         * 调用Native方法
         * @param method
         */
        call:function(method) {
            var self = this;
            if (App.IS_WP) {
                return;
            }

            var args = slice.call(arguments, 1),
                arg = null,
                callback = null,
                hasCallbackFlag = false,
                handlers = {};
            var handlersErrorCallback = function (arg) {

                return function (error) {
                    arg.apply(window, slice.call(arguments, 1));
                    if(error)
                    {
                        //TODO: 统一处理入口
                        errHandler(error);
                    }
                };

            };
            /*
             *请注意！！！！！！！！！arg参数（字符串）安卓和IOS需要单独处理。
             *ios不需要加""号。
             *安卓需要加""号。
             */
            // 参数内容处理
            for (var i = 0, len = args.length; i < len; i++) {
                arg = args[i];
                arg = arg || '';
                // 函数型参数转换
                if (toString.call(arg) == '[object Function]') {
                    callback = method + '_' + count++;
                    handlers = App._handlers;
                    //platformAdapter._handlers[callback] = arg;
                    handlers[callback] = handlersErrorCallback(arg);
                    arg = callback;
                } else if (toString.call(arg) == '[object Object]') {
                    arg = JSON.stringify(arg);
                } else if (toString.call(arg) == '[object Array]') {
                    arg = JSON.stringify(arg);
                }

                if (App.IS_ANDROID) {
                    arg = arg.toString().replace(/\|/g, '||');
                    arg = '"' + arg + '"';
                }
                args[i] = arg;
            }


            if (App.IS_ANDROID) {
                var getParameter = function (param) {
                    var reg = new RegExp('[&,?]' + param + '=([^\\&]*)', 'i');
                    var value = reg.exec(location.search);
                    return value ? value[1] : '';
                }
                if (roMethodList[method]) {
                    method = roMethodList[method] + '.' + method;
                }
                prompt('call://' + method + '(' + args.join('|') + ')');
            } else {
                var businessClass = window[roMethodList[method]];
                try {
                    if (businessClass && businessClass[method]) {
                        businessClass[method].apply(businessClass, args);
                    } else {
                        window.YDIOS[method].apply(window.YDIOS, args);
                    }
                } catch (e) {
                    // error
                }
            }
        },
        callback: function (method) {
            var args = slice.call(arguments, 1),
                handlers = App._handlers,
                callback = null;
            callback = handlers[method];
            if (callback && toString.call(callback) == '[object Function]') {
                callback.apply(window, args);
            }
        }
    });
    window.__callback = $$.platformAdapter.callback;

}(window));

