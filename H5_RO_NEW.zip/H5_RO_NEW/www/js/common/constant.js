/*!
 * constant 模块常量
 * @module constant
 * @author 周一平
 * @history 2015-6-10 add
 */
define([
	"js/common/flag",
	"js/common/env"
], function (Flag,
             EnvJson) {

	/* 平安付配置项 */
	var Env        = EnvJson.ssEnv,
	    PAPAY_ENV  = EnvJson.pafEnv,
	    Change_Url,
	    phoneOauth_Url,
	    PAPAY_HOST,
	    PAPAY_AUTH,
	    PAPAY_APP_ID,
	    PAPAY_SECRET,
	    PAPAY_BIND_CARD,
	    PAPAY_BIND_YQB,
	    PAPAY_GET_YQB_ACCOUNT,
	    DEBUG_MODE = true;
	if (Env == "PRODUCTION") {
		DEBUG_MODE = false;
		PAPAY_ENV  = "PRD";
		Change_Url = "http://txt.pingan.com.cn/static/paem/public/publicForward.html"; //绑卡中转生产环境地址
		phoneOauth_Url = "https://eloan.pingan.com.cn/credit/xiaoanlogin/";
	} else {
		DEBUG_MODE     = true;
		Change_Url     = "http://nts-tms-dmzstg1.pingan.com.cn:9027/html-dev/paem_public/publicForward.html";
		phoneOauth_Url = "https://114.141.178.31:12443/credit/xiaoanlogin/";
	}
	switch (PAPAY_ENV) {
		case "STG1":
			PAPAY_HOST            = "https://test-www.stg.1qianbao.com";
			PAPAY_AUTH            = "900000001493 33c6e8446a6c43a5adcf224e7e7a8d6f";
			PAPAY_APP_ID          = "900000001493";
			PAPAY_SECRET          = "33c6e8446a6c43a5adcf224e7e7a8d6f";
			PAPAY_BIND_CARD       = "https://test-www.stg.1qianbao.com/common-bindcard/enterview";
			PAPAY_BIND_YQB        = "https://test-www.stg.1qianbao.com/auth";
			PAPAY_GET_YQB_ACCOUNT = "https://test-www.stg.1qianbao.com/token/user";
			break;
		case "STG2":
			PAPAY_HOST            = "https://test2-www.stg.1qianbao.com:7443";
			PAPAY_AUTH            = "900000009498 596ff9657dfb419c85e52eac931207b3";
			PAPAY_APP_ID          = "900000009498";
			PAPAY_SECRET          = "596ff9657dfb419c85e52eac931207b3";
			PAPAY_BIND_CARD       = "https://test2-www.stg.1qianbao.com:7443/common-bindcard/enterview";
			PAPAY_BIND_YQB        = "https://test2-www.stg.1qianbao.com:7443/auth";
			PAPAY_GET_YQB_ACCOUNT = "https://test2-www.stg.1qianbao.com:7443/token/user";
			break;
		case "STG3":
			PAPAY_HOST            = "https://test2-www.stg.1qianbao.com:7443";
			PAPAY_AUTH            = "900000009498 596ff9657dfb419c85e52eac931207b3";
			PAPAY_APP_ID          = "900000009498";
			PAPAY_SECRET          = "596ff9657dfb419c85e52eac931207b3";
			PAPAY_BIND_CARD       = "https://test2-www.stg.1qianbao.com:7443/common-bindcard/enterview";
			PAPAY_BIND_YQB        = "https://test2-www.stg.1qianbao.com:7443/auth";
			PAPAY_GET_YQB_ACCOUNT = "https://test2-www.stg.1qianbao.com:7443/token/user";
			break;
		case "PRD":
			PAPAY_HOST            = "http://www.1qianbao.com";
			PAPAY_AUTH            = "900000004158 2c147337721348908d69fbf4145dd50d";
			PAPAY_APP_ID          = "900000004158";
			PAPAY_SECRET          = "2c147337721348908d69fbf4145dd50d";
			PAPAY_BIND_CARD       = "https://1qianbao.com/common-bindcard/enterview";
			PAPAY_BIND_YQB        = "https://1qianbao.com/auth";
			PAPAY_GET_YQB_ACCOUNT = "https://1qianbao.com/token/user";
			break;
		default:
			PAPAY_HOST            = "http://www.1qianbao.com";
			PAPAY_AUTH            = "900000004158 2c147337721348908d69fbf4145dd50d";
			PAPAY_APP_ID          = "900000004158";
			PAPAY_SECRET          = "2c147337721348908d69fbf4145dd50d";
			PAPAY_BIND_CARD       = "https://1qianbao.com/common-bindcard/enterview";
			PAPAY_BIND_YQB        = "https://1qianbao.com/auth";
			PAPAY_GET_YQB_ACCOUNT = "https://1qianbao.com/token/user";
			break;
	}

	var Constant = {
		Flag                 : Flag,
		DataKey              : {
			// 用户登录数据
			USER_LOGIN_INFO   : 'RO_USER_LOGIN_INFO',
			// 任务详情ID
			DETAIL_TASKID     : 'RO_DETAIL_TASKDETAILID',
			// 任务详情cityId
			DETAIL_CITYID     : 'RO_DETAIL_CITYID',
			// 任务详情节点id
			DETAIL_STAGEID    : 'RO_DETAIL_TASKID',
			// 任务产品类型
			DETAIL_PRODUCTTYPE: 'RO_DETAIL_PRODUCTTYPE',
			// 任务类型
			DETAIL_TYPE   	  : 'RO_DETAIL_TYPE',
			// 任务详情信息
			TASK_DETAIL_INFO  : 'RO_TASK_DETAIL_INFO',
			// 任务异常处理原因
			DETAIL_BACK_REASON: 'RO_DETAIL_BACK_REASON',
			// 分配任务异常原因
			ALLOT_BAD_REASON  : 'RO_ALLOT_BAD_REASON',
			// 用户登录ID
			USER_ID           : 'RO_USER_ID',
			// 任务超时状态
			DETAIL_OVER_TIME  : 'RO_DETAIL_OVER_TIME',
			// 任务详情节点信息
			DETAIL_STAGE_INFO : 'RO_DETAIL_STAGE_INFO',

			// 用户电话
			DETAIL_TEL     : 'RO_DETAIL_TEL',
			// 用户名字
			DETAIL_NAME    : 'RO_DETAIL_NAME',
			// 用户地址
			DETAIL_ADDRESS : 'RO_DETAIL_ADDRESS',
			// 用户性别
			DETAIL_GENDER  : 'RO_DETAIL_GENDER',
			// 用于用户第一次进入二手房详情页，给与用户指导的状态
			ENTER_STATE    : 'RO_ENTER_STATE',
			// 任务节点时间
			DETAIL_DATE    : 'RO_DETAIL_DATE',
			// 任务节点时间
			DETAIL_TIME    : 'RO_DETAIL_TIME',
			//消息数量
			MESSAGE_COUNT  : 'RO_MESSAGE_COUNT',
			//消息状态
			MESSAGE_ISREAD : 'RO_MESSAGE_ISREAD',
			//消息ID
			MESSAGE_MSGID  : 'RO_MESSAGE_MSGID',
			//消息类型
			MESSAGE_MSGTYPE: 'RO_MESSAGE_MSGTYPE',
			//任务状态
			DETAIL_STATUS  : 'RO_DETAIL_STATUS',
			// 保存业务线的状态
			ELSE_TASK_STATUS: 'RO_ELSE_TASK_STATUS',

			//处理人
			HAND_USER  : 'RO_HAND_USER',
			// 处理人名字
			HAND_USER_NAME: 'RO_HAND_USER_NAME',
			// 抵押副理
			USER_RO_MAM: 'RO_USER_RO_MAM',
			// 待分配列表的状态
			WAIT_STATUS: 'RO_WAIT_STATUS',
			// 成功返回详情的刷新标示
			SUCCESS_BACK: 'RO_SUCCESS_BACK',
			// 待分配任务子任务Id
            SUB_TASK_CONTENT: 'RO_SUB_TASK_CONTENT',
			// 任务中心的子任务ID
			SUB_TASK_ID: 'RO_SUB_TASK_ID',
			// 是否是存量订单
			IS_RO_NEW: 'RO_IS_RO_NEW'

		},
		// 页面标题设置
		TITLE                : {
			PAEM: '平安房交所'
		},
		// 是否需要调试
		DEBUG_MODE           : DEBUG_MODE,
		/**
		 * 配置模块名称
		 * */
		MODULE_NAME          : {
			home: "paehome",
			ro  : "ro"
		},
		index_page           : "index.html",
		// 平安付请求头授权码
		PAPAY_AUTH           : PAPAY_AUTH,
		// 平安付地址
		PAPAY_HOST           : PAPAY_HOST,
		// 平安付APP ID
		PAPAY_APP_ID         : PAPAY_APP_ID,
		// 平安付密钥
		PAPAY_SECRET         : PAPAY_SECRET,
		// 平安付绑卡
		PAPAY_BIND_CARD      : PAPAY_BIND_CARD,
		// 平安付绑定壹钱包
		PAPAY_BIND_YQB       : PAPAY_BIND_YQB,
		// 平安付换取壹钱包账号
		PAPAY_GET_YQB_ACCOUNT: PAPAY_GET_YQB_ACCOUNT,
		// 绑卡公共跳转地址
		Change_Url           : Change_Url,
		// 手机运营商认证地址
		phoneOauth_Url       : phoneOauth_Url,

		// 业务线配置
		BUSINESS_LINE        : {
			er : 1,         // 二手房
			a  : 2,         // 按揭
			zed: 4,     // 宅e贷
			anew: 6,		//按揭(新)
			w  : 5,       //待分配
			wd : 6,       // 已分配
			mw : 7,     //抵押副理待分配
			mwd: 8       // 抵押副理已分配
		},
		// 业务线名称配置
		BUSINESS_LINE_NAME   : {
			1: '二手房',
			2: '按揭',
			4: '宅e贷',
			6: '按揭(新)',
			7: '按揭(新)'
		},
		USER_ROLE			: {
			RO: 'R_PA017_PAPC_MC',
			MAM: 'R_PA017_PAPC_MAM'
		},
        // 按揭新待预约事项
        WAIT_TYPE: {
            1: '办押'
        },
		AN_NEW_TYPE: '7',
		OTHER_REASON_TYPE: '6',
		CANMOVESTAGE: {
			1: '二手房',
			6: '按揭新',
			4: '宅e贷',
            7: '按揭新新'
		}
	};
	return Constant;
});
