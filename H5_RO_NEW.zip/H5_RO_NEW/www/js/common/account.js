/*!
 * account模块 common子模块
 * 专门处理登录等相关模块
 * @module account
 * @author 周一平
 * @history 2015-6-10 add
 */
 define([
    "zepto",
    "js/common/env",
    "js/common/utils",
    "js/common/ui",
    "js/common/native",
    "js/common/api",
    "js/common/flag",
    "js/common/constant"
    ],function(
    $,
    Env,
    Utils,
    UI,
    Native,
    Api,
    Flag,
    Constant
    ){
    var Account = function(){};
    // 登录 退出 是否登录

    Account.prototype = {
        Flag: $.extend(Flag, {

        }),
        isLogin: function() {
            return !!Utils.data(Constant.DataKey.USER_LOGIN_INFO);
        },
        logout: function() {
            $.each([
                Constant.DataKey.USER_LOGIN_INFO,
                Constant.DataKey.USER_LOAN_INFO
            ], function(i, item) {
                Utils.data(item, null);
            })
        }
    }
    return new Account();
});
