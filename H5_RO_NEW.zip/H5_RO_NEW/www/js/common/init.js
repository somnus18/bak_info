/*!
 * 初始化 common子模块
 * @module init
 * @author 周一平
 * @history 2015-6-10 add
 */
define([
    "zepto",
    "js/common/env",
    "js/common/flag",
    "js/common/constant",
    "js/common/utils",
    "js/common/ui",
    "js/common/native",
    "js/common/account",
    "js/common/api",
    'js/common/debug',
], function ($, EnvJson, Flag, Constant, Utils, UI, Native, account, Api, debug) {
    return function () {

        window.onerror = function(msg,url,line,column){
            debug.error('msg:'+msg+'<br>url:'+url+',line:'+line+',line:'+line+',column:'+column);
        };

        var Env = EnvJson.ssEnv;

        //备份扩展ajax方法
        var _ajax = $.ajax,
            _ajaxExt = {
                /**在各自的业务逻辑里做错误这里做统一处理了
                 * comment by:ex-tongwei@pingan.com.cn
                 */
                error: function (xhr, errorType, errorMsg,opt) {
                    if(opt && opt.has_action_refresh)
                    {//如果是手动请求，是否上拉或下拉刷新任务列表
                        if (Env != 'DEVELOPMENT') {
                            Native.tip("刷新失败，请重试。");
                        } else {
                            UI.error({
                                content: "任务刷新失败！状态码："+errorType+" 错误信息："+errorMsg
                            });
                        }
                    }else{
                        var str = "";
                        if(!navigator.onLine || errorType === 'timeout')
                        {
                            str = "网络连接超时，请更换网络！";
                        }else{
                            str = "网络错误，请稍后再试！";
                        }
                        if (Env != 'DEVELOPMENT') {
                            Native.tip(str);
                        } else {
                            UI.error({
                                content: str
                            });
                        }
                    }
                },
                success: function (res) {
                    if (res && res.flag != Flag.SUCCESS) {
                        if (res.flag == Flag.FAIL || res.flag == Flag.REFRESH_CODE) {
                            //当判断状态码为2或9时，需自动调起native接口进行跳转到登录页
                            Native.gotoLogin(res.flag);
                        } else if (res.flag == Flag.LOGIN_TIMEOUT || res.flag == Flag.ERROR) {
                            // 登录超时的时候跳转到登录页
                            account.logout();
                            if (Env != 'DEVELOPMENT') {
                                // Utils.data(Constant.DataKey.USER_LOGIN_INFO, null);
                                Native.tip(res.msg);
                            } else {
                                var url = "login.html?redirectURL=" + encodeURIComponent(location.href);
                                UI.error({
                                    content: res.msg,
                                    ok     : function () {
                                        location.href = url;
                                    }
                                });
                            }
                        } else {
                            var code = res.flag;
                            // 集合内的code值不提示
                            var whiteCode = ["53"];

                            if (res.msg && ($.inArray(String(code), whiteCode) == -1)) {
                                if (Env != 'DEVELOPMENT') {
                                    if (res.msg && res.msg != "失败") {
                                        Native.tip(res.msg);
                                    }
                                } else {
                                    UI.error({
                                        content: res.msg
                                    });
                                }
                            }
                        }
                    }
                }
            };

        //重写扩展ajax方法
        $.ajax = function (opt) {
            //备份opt中error和success方法
            var fn = {
                error: opt.error || function (XMLHttpRequest, textStatus, errorThrown) {
                },
                success: opt.success,
                complete: opt.complete || function (XHR, TS) {
                }
            }

            //扩展增强处理
            var _opt = $.extend(opt, {
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    //执行自定义方法之后  再执行扩展方法
                    fn.error(XMLHttpRequest, textStatus, errorThrown);
                   // _ajaxExt.error(XMLHttpRequest, textStatus, errorThrown, opt);
                    debug.error('xtm error', opt.url);
                },
                success: function (data) {
                    fn.success(data);
                    _ajaxExt.success(data);
                },
                complete: function (XHR, TS) {
                    fn.complete(XHR, TS);
                    if(XHR.responseText) {
                        var res = JSON.parse(XHR.responseText);
                        debug.log(JSON.parse(Utils.escape(JSON.stringify(res))));
                        //_ajaxExt.complete(XHR, TS);
                    }
                },
                dataType: 'json',
                cache: false,
                data: opt.data || {},
                type: opt.type || 'get',
                timeout: 30000 //设置请求超时时间为30秒
            });
            if (App.IS_LOCAL) {
                var loginInfo = Utils.data(Constant.DataKey.USER_LOGIN_INFO),
                    defaultParams = {};
                if(!_opt.data['userId'] && !!loginInfo) {
                    defaultParams.userId = loginInfo.userId || '';
                }
                if(!_opt.data['token'] && !!loginInfo) {
                    defaultParams.token = loginInfo.token || '';
                }
                defaultParams.hv = Utils.getYearHourDate();
                $.extend(_opt.data, defaultParams);
                _ajax(_opt);
            } else {
                Native.getUserInfo(function (res) {
                    Native.rsaByNative({
                         param: {data:res.userId},
                         type: '1',
                         callback: function(data){
                            $.extend(_opt.data, {
                                userId: data.data,
                                token: res.token,
                                hv: Utils.getYearHourDate()
                            });
                            Native.request(_opt);
                         }
                     });
                });
            }
        };
    }
});
