/*!
 * 环境变量，是Common模块的一部分
 * @module env
 * @require js/common/env 根据环境变量返回API
 */
define([
	"js/common/env",
	"js/common/constant"
], function (envJson, Constant) {
	var env    = envJson.ssEnv;
	var prefix = "";
	switch (env) {
		case "DEVELOPMENT" :
			prefix = "http://test-papc-gs.pingan.com.cn:8080/ro/";
			break;
		case "TEST":
		case "STG1":
			//prefix = "http://test-papc-gs.pingan.com.cn:8080/ro/";
			prefix = "https://test-papc-gs.pingan.com.cn:8843/ro/";
			break;
		case "STG2":
            prefix = "https://test-papc-gs.pingan.com.cn:8843/stg2/ro/";
            break;
		case "STG3":
			//prefix = "http://test-papc-gs.pingan.com.cn:8080/stg2/ro/";
			prefix = "https://test-papc-gs.pingan.com.cn:8843/stg3/ro/";
			break;
		default:
			prefix = "https://papc-gs.pingan.com.cn/ro/";
	}

	var api = env == "DEVELOPMENT" ? {
		// 本地开发环境模拟JSON
		PLUGIN_LOGIN           : prefix + 'login/doLogin',
		// 房交所客户信息
		CUSTOMER_INFORMATION   : 'data/home.json',
		// 我的任务
		// TASK_MORE              : 'data/mytask.json',
		// 分配任务
		// TASK_CENTER            : 'data/task_center.json',
		// 任务预约详情
		TASK_DETAIL            : 'data/taskAllot_detail.json',
		// 任务模糊查找
		TASK_SEARCH            : 'data/search.json',
		// 预约时间选择
		APPOINT_TIME           : 'data/time_sel.json',
		// 测试
		TEST                   : 'data/test.json',
		//消息中心列表
		RO_MESSAGE             : 'data/messageInfo.json',
		//详细消息
		RO_MESSAGE_DETAIL      : 'data/messageDetail.json',
		//消息数目获取
		RO_NEWMESSAGE_NUM      : 'data/notesNum.json',
		//我的名片
		RO_MYACARD             : 'data/mycard.json',
		//考勤显示状态码
		RO_ATTENDANCE_STATE    : 'data/attendance.json',
		// 宅e贷打卡记录
		RO_ATTENDANCE_STATE_ZHAI    : 'data/attendance_zhai.json',
		//考勤提交
		RO_ATTENDANCE_SUBMIT   : 'data/submitAttendance.json',
		// 宅e贷提交
		RO_ATTENDANCE_SUBMIT_ZHAI   : 'data/submitAttendanceZhai.json',
		// 分配任务
		DIRECTOR               : 'data/director.json',
		// 任务详情
		GET_TASKINFO           : 'data/getTaskinfo.json',
		// 任务分配专员列表
		TASK_ATTACHELIST       : 'data/task_attacheList.json',
		// 分配任务
		TALLOT_TASK            : 'data/allotTask.json',
        //改派任务
        CHANGE_TASK            : 'assign/allotTask.json',
		// 获取异常任务原因
		GET_REASON_LIST        : 'data/getReasonList.json',
		// 异常任务处理提交
		SUBMIT_UNDONE_TASK     : 'data/submitUndoneTask.json',
		// 提交预约时间
		SUBMIT_APPOINTMENT_TIME: 'data/submitAppointTime.json',
		// 订单任务节点步骤提交
		SUBMIT_TASK_STAGE      : 'data/submitTaskStage.json',
		// 节点任务（不需要上传文件）
		SUBMIT_STAGE           : 'data/test.json',
		// 获取可分配时间段
        GET_ORDER_TIME		   : 'data/getOrderTime.json',
		// 受影响人物列表
        AFFECT_TASK			   : 'data/affectTask.json',
        // 获取待预约任务详情展示
        GET_WAIT_APPOINT       : 'data/wait_appoint.json',
        // 提交待预约详情订单
        SUBMIT_WAIT_APPOINT    : 'data/submit_wait_appoint.json',
		// 获取可预约任务列表
		GET_ORDER_TASK_LIST    : 'data/task_list.json',
		// 提交可预约任务修改时间
		SUBMIT_MODIFY_TIME     : 'data/test.json',
		// 提交获取的任务列表
		SUBMIT_GET_TASK_LIST   : 'data/test.json',
		// 获取房管局列表
		GET_HOUSE_LIST         : 'data/house_list.json',
		// 宅e贷获取任务
		ZHAI_GET_TASK		   : 'data/get_task.json',
		// 确认我要离开
        LEAVE_FROM_WORK		   : 'data/leave_work.json',
		// 我已离开是否有任务未捞单
		CAN_LEAVE_WORK		   : 'data/canLeaveWork.json',
		// 提交房管局打卡
        SUBMIT_HOUSE_LIST	   : 'data/test.json',
		// 任务中心获取宅e贷订单
		GET_ZHAI_ORDER_LIST	   : 'data/getZhaiOrder.json',
        // 宅e贷文件信息节点提交
        ZHAI_FILE_SUBMIT       : 'data/test.json',
        // 宅e贷修改时间浮层原因
        GET_MODIFY_REASON      : 'data/getModifyReason.json'
	} : {
		PLUGIN_LOGIN           : 'login/doLogin.do',
		// 本地存放房交所客户信息
		CUSTOMER_INFORMATION   : 'task/getTaskList.do',
		// 任务模糊查找
		TASK_SEARCH            : 'task/searchTask.do',
		// 任务详情
		GET_TASKINFO           : 'task/getTaskinfo.do',
		// 提交预约时间
		ORDER_TIME             : 'task/submitAppointTime.do',
		// 考勤提交
		RO_ATTENDANCE_SUBMIT   : 'attendance/attendanceSubmit.do',
		// 消息数目获取
		RO_NEWMESSAGE_NUM      : 'msg/getNewMsg.do',
		// 考勤显示状态码
		RO_ATTENDANCE_STATE    : 'attendance/getSigninStatus.do',
		// 消息中心列表
		RO_MESSAGE             : 'msg/getMsgList.do',
		// 详细消息
		RO_MESSAGE_DETAIL      : 'msg/getMsgInfo.do',
		// 订单任务节点步骤提交
		SUBMIT_TASK_STAGE      : 'task/submitTaskStage.do',
		// 任务分配专员列表
		TASK_ATTACHELIST       : 'assign/getAttacheList.do',
		// 分配任务
		TALLOT_TASK            : 'assign/submitAssignTask.do',
		//改派任务
		CHANGE_TASK            : 'assign/submitReassignTask.do',
		// 获取异常任务原因
		GET_REASON_LIST        : 'task/getReasonList.do',
		// 宅e贷修改时间浮层原因
		GET_MODIFY_REASON      : 'zhdisph/getAppointReasonInfo.do',
		// 异常任务处理提交
		SUBMIT_UNDONE_TASK     : 'task/submitUndoneTask.do',
		// 节点任务（不需要上传文件）
		SUBMIT_STAGE           : 'task/submitTaskStageFileInfo.do',
		// 当天受影响任务
		AFFECT_TASK            : 'task/getLaterTaskList.do',
		// 宅e贷证件号节点提交
		ZHAI_STAGE_SUBMIT	   : 'task/credentConfigureSubmit.do',
		//获取可预约时间段
		GET_ORDER_TIME		   : 'task/appointmentTimeList.do',
		// 按揭新预计时间节点提交
		ANEW_STAGE_SUBMIT	   : 'task/additionalRecordingInfo.do',
		// 登录获取ticket
		GET_TICKET             : 'login/getTicket.do',
        // 获取待预约任务详情展示
        GET_WAIT_APPOINT       : 'task/getAppiontTaskinfo.do',
        // 提交待预约详情订单
        SUBMIT_WAIT_APPOINT    : 'task/submitAppiontTaskinfo.do',
        // 提交房管局打卡
        SUBMIT_HOUSE_LIST	   : 'zhdisph/submitHdClockInfo.do',
        // 获取房管局列表
        GET_HOUSE_LIST         : 'zhdisph/getHdSelectList.do',
        // 宅e贷打卡记录
        RO_ATTENDANCE_STATE_ZHAI    : 'zhdisph/getHdClockInfo.do',
        // 获取可预约任务列表
        GET_ORDER_TASK_LIST    : 'zhdisph/getHdNofishingList.do',
        // 提交获取的任务列表
        SUBMIT_GET_TASK_LIST   : 'zhdisph/submitHdNofishingList.do',
        // 任务中心获取宅e贷订单
        GET_ZHAI_ORDER_LIST	   : 'zhdisph/getZedTaskList.do',
		// 宅e贷文件信息节点提交
		ZHAI_FILE_SUBMIT	   : 'zhdisph/submitZedTaskStageFileInfo.do',
        // 我已离开是否有任务未捞单
        CAN_LEAVE_WORK		   : 'zhdisph/getHdNofishingStateInfo.do',
        // 确认我要离开
        LEAVE_FROM_WORK		   : 'zhdisph/submitLeaveInfo.do',
        // 提交可预约任务修改时间
        SUBMIT_MODIFY_TIME     : 'zhdisph/submitAppointReasonInfo.do'
	};

	var getUrl = function (name) {
		return env == "DEVELOPMENT" ? (api[name]) : (prefix + api[name]);
	};

	return getUrl;
});
