/**
 * @Author : ex-qingqi@pingan.com.cn
 * @Date   : 2016-03-25
 * @Time   : 14:10:00
 *
 * @Description: 消息中心
 */
/* global define: false */

define(['zepto', 'C', 'view', 'scrollView'], function ($, C, View, scrollView) {

    'use strict';
    var Page = View.extend(_.extend(scrollView, {

        // 每页显示条数
        account: 10,
        // 防重标示
        isPost: false,
        // 新公告提示(后续可以添加消息、邮件)
        newsNots: $('.js_newNots'),
        //刷新，初始化标记
        isBoll: true,
        //保留刷新后的数据
        reloadList: {},
        //保存前一页的数据
        lastInfoList: {},
        // 消息列表模板
        notsTpl: _.template($('#js_message_box').html()),
        //信息列表
        notsList: $('#js_notes_info'),
        //事件及对应方法
        events: {
            'tap .js_email': 'nothingTip',
            'tap .js_message': 'nothingTip',
            'tap .noticeBox': 'detailInfo'
        },
        //初始化
        initialize: function () {
            var self = this;
            C.Native.setHeader({
                title: '消息中心',
                leftCallback: function () {
                    C.Native.back();
                    C.Native.clearMsgNum();
                }
            });
            self.index = 1;
            self.addIndex = 0;
            self.render();
        },
        //渲染
        render: function () {
            this.getNotesNum();
        },
        //下拉刷新
        pullDownActionBase: function () {
            var self = this;
            if (self.isLoading)return;
            self.isLoading = 'down';
            self.index = 1;
            self.addIndex=0;
            //页面加载方法
            self.getNotesNum(true);
			self.refreshScroll();
        },
        //上拉加载
        pullUpActionBase: function () {
            var self = this;
            if (self.isLoading)return;
            self.isLoading = 'up';
            self.addIndex=0;
            //页面上拉加载方法
            self.ajaxMessage(true);
			self.refreshScroll();
        },
        //获取最新消息提示
        getNotesNum: function (do_action) {
            var whoAmI = 3, self = this;
            C.Native.loadingBegin();
            $.ajax({
                url: C.Api('RO_NEWMESSAGE_NUM'),
                type: 'get',
                data: {
                    whoAmI: whoAmI
                },
                success: function (res) {
                    if(res.flag == C.Flag.SUCCESS){
                        self.addIndex ++;
                        var noticeCount = res.data.noticeCount;
                        if (noticeCount != 0) {
                            $('.js_notesNum').addClass('cirle-num').html(noticeCount)
                        } else {
                            $('.js_notesNum').removeClass('cirle-num')
                        }
                        self.ajaxMessage(do_action);
                    }
                },
                error: function(){
                    delete self.isLoading;
                    C.UI.stopLoading();
                }
            })
        },
        /*
         *获取后台数据
         */
        ajaxMessage: function (do_action) {
            var self = this,
                data = null,
                datas = [],
                page = null;
            page = self.index;
            if (self.isPost) return;
            self.isPost = true;
            if(self.addIndex == 0){
                C.Native.loadingBegin();
            }
            $.ajax({
                url: C.Api('RO_MESSAGE'),
                type: 'get',
                data: {
                    type: 2,
                    page: page,
                    pageSize: self.account
                },
                //是否上拉或下拉刷新任务列表
                has_action_refresh:do_action,
                success: function (res) {
                    self.isPost = false;
                    if (res && res.flag == C.Flag.SUCCESS) {
                        data = res.data;
                        if (data.length > 0) {
                            datas = C.removeRepeatData(data,self.firstPageData,datas,page, 'msgId');   // 去除重复数据之后保存的数组
							if(!datas.length){
								delete self.isLoading;
							}else{
								self.getDataList(datas);
							}
                            self.firstPageData = datas;
                            self.index++;
                        } else {
                            if(page == 1) {
                                self.notsList.empty();
                                $('.no-task').removeClass('dn');
                            } else {
                                C.Native.tip('暂无更多数据!');
                            }
                        }
                    }
                    delete self.isLoading;
                    self.installScroll();
                    self.refreshScroll();
                    C.UI.stopLoading();
                },
                complete: function (res) {
                    //删除加载图标
                    if(self.hasInitScroll) self.refreshScroll();
                    C.UI.stopLoading();
                    self.isPost = false;
                    delete self.isLoading;
                },
                error: function () {
                    self.isPost = false;
                    delete self.isLoading;
                    //首次进入时，如果没有任务，则提示
                    if (page == 1 && !do_action) {
                        $('.no-task').removeClass('dn');
                    }
                    if(self.hasInitScroll) self.refreshScroll();
                    self.installScroll();
                    C.UI.stopLoading();
                }
            })
        },
        /**
         * 允许iScroll
         */
        installScroll:function()
        {
            var self = this;
            if (!self.hasInitScroll) {
                // 动态改变列表的高度
                var scrollContainerH = $('.layout').height();
                var headHeight = window.innerHeight - $('header').height() - $('.tab').height();
                if (scrollContainerH < headHeight)
                    scrollContainerH = headHeight;
                self.install(scrollContainerH);
                self.hasInitScroll = true;
            }
        },
        //公共取值
        getDataList: function ($el) {
            var objAry = [],
                self = this;
            $.each($el, function (index, item) {
                objAry.push(self.notsTpl(item));
            });
            if (self.isLoading == 'up') {
                self.notsList.append(objAry.join(''));
            } else {
                self.notsList.html(objAry.join(''));
            }
            delete self.isLoading;
        },
        //切换tab标题事件
        nothingTip: function () {
            C.Native.tip('敬请期待！');
        },
        //详细信息
        detailInfo: function (e) {
            var self = this, $target = $(e.currentTarget),
                isRead = $target.attr('data-isRead'),
                msgId = $target.attr('data-msgId'),
                msgType = $target.attr('data-msgType'),
				readType=isRead;
            if (isRead == 0) {
				$target.attr('data-isRead',1);
                $target.find('div .red-dot').removeClass('red-dot');
            }
            C.Utils.data(C.Constant.DataKey.MESSAGE_ISREAD, readType);
            C.Utils.data(C.Constant.DataKey.MESSAGE_MSGID, msgId);
            C.Utils.data(C.Constant.DataKey.MESSAGE_MSGTYPE, msgType);
            C.Native.forward({
                // code用于详情页面判断是分配任务还是完成
                url: 'message_detail.html'
            });
        }
    }));

    $(function () {
        new Page({
            el: $('body')[0]
        });
        $$.EventListener.onBack = function () {
            var count = C.Utils.data(C.Constant.DataKey.MESSAGE_COUNT);
            if (count != 0) {
                $('.js_notesNum').html(count)
            } else {
                $('.js_notesNum').removeClass('cirle-num').html('');
            }
        }
    })
});
