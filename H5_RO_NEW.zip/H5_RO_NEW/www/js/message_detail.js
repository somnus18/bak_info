define(['zepto', 'C', 'view'], function($, C,View) {

    'use strict';
    var Page = View.extend(_.extend({

        //信息模板
        notesTpl:_.template($('#js_notesTpl').html()),
        //消息主体
        notesBox:$("#js_notesBox"),
        // 初始化
        initialize: function() {
            var self = this;
            C.Native.setHeader({
                title: '消息详情',
                leftCallback: function() {
                    C.Native.back();
                }
            });
            self.render();
        },
        // 渲染
        render: function() {
            var self=this;
            self.getDetails();
        },
        //数据获取
        getData: function (data) {
            var self=this,whoAmI= 3,noticeCount;
            $.ajax({
                url: C.Api('RO_NEWMESSAGE_NUM'),
                type:'post',
                data:{
                    whoAmI:whoAmI
                },
                success: function (res) {
                    C.UI.stopLoading();
                    if(res.flag == C.Flag.SUCCESS){
                        noticeCount=C.Utils.data(C.Constant.DataKey.MESSAGE_COUNT,res.data.noticeCount);
                        self.notesBox.html(self.notesTpl(data));
                    }
                },
                error:function(res){
                    C.UI.stopLoading();
                    //C.Native.tip(res.msg)
                }
            })
        },
        getDetails:function(){
            var self = this;
            C.UI.loading();
            $.ajax({
                url: C.Api('RO_MESSAGE_DETAIL'),
                data: {
                    isRead: C.Utils.data(C.Constant.DataKey.MESSAGE_ISREAD),
                    msgId: C.Utils.data(C.Constant.DataKey.MESSAGE_MSGID),
                    msgType: C.Utils.data(C.Constant.DataKey.MESSAGE_MSGTYPE)
                },
                type: 'get',
                success: function (res) {
                    if (res.flag == C.Flag.SUCCESS) {
                        self.getData(res.data);
                    }
                },
                error:function(){
                    C.UI.stopLoading();
                    //C.Native.tip(res.msg)
                }
            });
        }
    }));
    $(function(){
        new Page({
            el: $('body')[0]
        });
    })
});
