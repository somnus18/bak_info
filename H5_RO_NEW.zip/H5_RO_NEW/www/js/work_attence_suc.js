/**
 * @Author : zhangjunli001
 * @Description: 打卡成功页面
 */

define(['zepto', 'C', 'view'], function ($, C, View) {
    'use strict';
    var Page = View.extend(_.extend({
        // 页面全局变量
        events: {
            'tap #back_to_home': 'backHome'
        },

        initialize: function () {
            var _this = this,
                type = C.Utils.getParameter('type') || '';
            C.Native.setHeader({
                title: '',
                leftCallback: function () {
                    _this.backHome();
                }
            });
            type && $('#title').text('您已经成功离开');
            C.Native.loadingFinish();
        },
        /**返回首页**/
        backHome: function () {
            C.Native.back({
                url: 'home.html'
            })
        }

    }));

    $(function () {
        new Page({
            el: $('body')[0]
        });
    })
});
