/**
 * @Author : jinmengjie107
 * @Description: update fail
 */

define(['zepto', 'C', 'view'], function ($, C, View) {
    'use strict';
    var Page = View.extend(_.extend({
        // 页面全局变量
        _G: {
            canOrderTime:''    //可预约时间段
        },

        //请求状态标识
        isPost:false,

        events: {
            'tap #order_btn': 'openOrderPart',
            'tap #immediate_btn': 'orderTime',
            'tap .icon-close': 'cancelOrder',
            'tap #cancel_btn': 'cancelOrder',
            'tap #sure_btn': 'orderTime',
            'tap #select_order_date': 'selectDate',
            'tap #select_order_time': 'selectTime',
            'tap #back_to_mainpage': 'backToIndex'
        },

        initialize: function () {
            var _this = this, data = {};
            C.Native.setHeader({
                title: '',
                leftCallback: function () {
                    C.Native.back({
                        url: 'home.html'
                    });
                }
            });
            _this.dateDom = $('#order_date');
            _this.timeDom = $('#order_time');
            _this.orderPartDom = $('#order_time_part');
            _this.stageInfo = decodeURIComponent(C.Utils.getParameter('stageInfo'));
            _this.stageName = "";
            _this.stageId = "";
            if (!!_this.stageInfo && (typeof _this.stageInfo == "string")) {
                _this.stageInfo = JSON.parse(_this.stageInfo);
                //取第一个节点
                if (_this.stageInfo.length) {
                    _this.stageName = _this.stageInfo[0].stageName;
                    _this.stageId = _this.stageInfo[0].stageId;
                }
                C.Utils.data(C.Constant.DataKey.DETAIL_STAGEID, _this.stageId);
            }
            _this.cityId = C.Utils.getParameter('cityId');                // 城市编码
            _this.taskStatus = C.Utils.getParameter('taskStatus');
            _this.orderId = C.Utils.getParameter('orderId');
            _this.productType = C.Utils.getParameter('productType');
            _this.isRoStage = C.Utils.getParameter('isRoStage');
            _this.oldZhaiOrder = (C.Utils.data(C.Constant.DataKey.IS_RO_NEW) == 1) && (_this.productType == C.Constant.BUSINESS_LINE.zed); // false是旧订单,true是新的宅e贷订单
            data.taskStatus = _this.taskStatus;
            data.stageName = _this.stageName || '';
            data.isRoStage = _this.isRoStage;
            var html = _.template($('#content-tpl').html(), {data: data});
            $('#main_content').html(html);
            if (_this.oldZhaiOrder) {
                $('#order_btn').hide();
                $('#immediate_btn').text('返回首页');
            }
            C.Native.loadingFinish();
        },

        // 数据请求公用方法
        requestData: function (json, sType, eType) {
            var self = this;
            if (self.isPost) {
                return;
            }
            self.isPost = true;
            if (!sType) {
                C.UI.loading();
            }
            $.ajax({
                url: json.api,
                type: 'post',
                data: json.data,
                timeout: 30000,
                success: function (data) {
                    self.isPost = false;
                    if (!eType) {
                        C.UI.stopLoading();
                    }
                    if (data.flag == C.Flag.SUCCESS) {
                        json.callback(data);
                    } else {
                        // 后端返回异常之后提示异常信息 并关闭loading
                        C.Native.tip(data.msg);
                        C.UI.stopLoading();
                    }
                },
                error: function (xhr, errorType, error) {
                    self.isPost = false;
                    C.UI.stopLoading();
                    json.errorCall();
                }
            });
        },

        /**打开预约时间**/
        openOrderPart: function () {
            var _this = this;
            if(_this.isRoStage != '1') {
                C.Native.tip('流程已扭转至客服处理,请等候！');
                C.Native.back({
                    url: 'home.html'
                });
            }else{
                if(_this._G.canOrderTime){
                    //显示更改预约时间弹窗
                    var showDate = C.Utils.parseDateFormat(new Date(), 'yyyy年MM月dd日'),
                    showTime = _this.formatTime();
                    _this.dateDom.text(showDate);
                    _this.timeDom.text(showTime);
                    _this.orderPartDom.show();
                }else{
                    var cityId = _this.cityId,    // 城市id
                        orderId = _this.orderId,  // 订单号
                        productType = _this.productType, //业务类型
                        json = {
                            api: C.Api('GET_ORDER_TIME'),
                            data: {
                                cityId: cityId,
                                orderId: orderId,
                                productType: productType,
                            }
                        };
                    var callback = function (data) {
                        //保存可预约时间段
                        var res = data.data,
                            canOrderTime = res.appointmentTimeRange;
                        _this._G.canOrderTime = canOrderTime;

                        //显示更改预约时间弹窗
                        var showDate = C.Utils.parseDateFormat(new Date(), 'yyyy年MM月dd日'),
                        showTime = _this.formatTime();
                        _this.dateDom.text(showDate);
                        _this.timeDom.text(showTime);
                        _this.orderPartDom.show();
                    };
                    var errorCall = function (data) {
                    };
                    json.callback = callback;
                    json.errorCall = errorCall;
                    _this.requestData(json);
                }
            }
        },

        formatTime: function () {
            var minute = Math.ceil(new Date().getMinutes() / 10) * 10, hour = new Date().getHours();
            minute = minute == 60 ? '00' : minute.toString();
            hour = minute == '00' && hour == 23 ? '00' : (minute == '00' ? (hour + 1).toString() : hour.toString());
            var showHour = hour.length == 2 ? hour : '0' + hour, showMinute = minute.length == 2 ? minute : '0' + minute;
            return showHour + ':' + showMinute;
        },
        /**预约时间**/
        orderTime: function (e) {
            var _this = this, $target = $(e.currentTarget), param = {};
            // 如果是宅e贷订单直接返回详情
            if (_this.oldZhaiOrder) {
                C.Native.back({
                    url: 'home.html'
                });
                return;
            }
            if(_this.isRoStage == '1'){
                if ($target.attr('id') == 'sure_btn') {
                    //预约时间
                    param.appointmentDate = C.Utils.parseDateFormat(_this.dateDom.text(), 'yyyy-MM-dd');
                    param.appointmentTime = _this.timeDom.text();
                    param.appointmentType = '1';
                } else {
                    //立即预约
                    param.appointmentDate = '';
                    param.appointmentTime = '';
                    param.appointmentType = '0';
                }
                param.orderId = _this.orderId;
                param.stageId = _this.stageId;
                param.productType = _this.productType;

                var json = {
                    api: C.Api('ORDER_TIME'),
                    data: param
                };
                var callback = function (data) {
                    C.Utils.data(C.Constant.DataKey.SUCCESS_BACK,true);
                    C.Native.back({
                        url: 'task_detail.html'
                    });
                };
                var errorCall = function (data) {
                };
                json.callback = callback;
                json.errorCall = errorCall;
                _this.requestData(json);
            } else {
                C.Native.tip('流程已扭转至客服处理,请等候！');
                C.Native.back({
                    url: 'home.html'
                });
            }
        },

        //调用native控件选择日期  outDate 1 不可以选择之前的日期  0 可以选择之前的日期
        selectDate: function () {
            var _this = this, defaultData = {};
            var defaultText = _this.dateDom.text();
            defaultText = C.Utils.parseDateFormat(defaultText, 'yyyy-MM-dd');
            var defaultArray = defaultText.split('-');
            defaultData = {
                c1: defaultArray[0],
                c2: defaultArray[1],
                c3: defaultArray[2]
            };
            C.Native.selectDateTime({
                defaultValue: defaultData,
                title: '选择日期',
                type: 'date',
                outDate: '1',
                callback: function (data) {
                    console.log(data);
                    if (data.code == '0') {
                        var showDateText = data.selectResult.c1 + '年' + data.selectResult.c2 + '月' + data.selectResult.c3 + '日';
                        _this.dateDom.text(showDateText);
                    }
                }
            })
        },
        //调用native控件选择时间
        selectTime: function () {
            var _this = this, defaultData = {};
            var defaultArray = _this.timeDom.text().split(':');
            defaultData = {
                c1: defaultArray[0],
                c2: defaultArray[1]
            };
            C.Native.selectDateTime({
                defaultValue: defaultData,
                title: '选择时间',
                type: 'time',
                timeRange: _this._G.canOrderTime,
                callback: function (data) {
                    console.log(data);
                    if (data.code == '0') {
                        var showTimeText = data.selectResult.c1 + ':' + data.selectResult.c2;
                        _this.timeDom.text(showTimeText);
                    }
                }
            })

        },

        /**取消预约**/
        cancelOrder: function () {
            var _this = this;
            _this.orderPartDom.hide();
        },

        /**返回首页**/
        backToIndex: function () {
            C.Native.back({
                url: 'home.html'
            })
        }

    }));

    $(function () {
        new Page({
            el: $('body')[0]
        });
    })
});
