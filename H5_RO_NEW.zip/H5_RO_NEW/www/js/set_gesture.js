/**
 * @Author : ex-tongwei001@pingan.com.cn
 * @Date   : 16/5/12
 * @Description: 手势密码
 */
define([
    'zepto',
    'C',
    'view',
    "underscore"
], function ($,
             C,
             View,
             _) {

    'use strict';

    var Page = View.extend(_.extend({

        events    : {
            'touchstart #container': 'touchstart',
            'touchmove #container' : 'touchmove',
            'touchend #container'  : 'touchend',
            'tap #updatePassword'  : 'updatePassword'
        },
        pswObj    : {},
        lastPoint : [],
        touchFlag : false,
        container : $('#container'),
        ctx       : container.getContext('2d'),
        chooseType: 3,//3行3列

        //初始化
        initialize     : function () {
            var self = this;
            C.Native.setHeader({
                title       : '手势密码',
                leftCallback: function () {
                    C.Native.back();
                }
            });
            C.Native.loadingFinish();

            //开始渲染canvas
            self.render();
        },
        render         : function () {
            var self = this;
            //阻止上层事件
            $(document).on('touchmove', function (e) {
                e.preventDefault();
            }, false);
            //初始化数据
            C.Native.getData('passwordxx', function (res) {
                if (!!res) {
                    self.pswObj = {step: 2, spssword: JSON.parse(res)};
                }
            });

            self.makeState();
            self.createCircle();
        },
        drawCle        : function (x, y) { // 初始化解锁密码面板
            var self             = this;
            self.ctx.strokeStyle = '#CFE6FF';
            self.ctx.lineWidth   = 2;
            self.ctx.beginPath();
            self.ctx.arc(x, y, self.r, 0, Math.PI * 2, true);
            self.ctx.closePath();
            self.ctx.stroke();
        },
        drawPoint      : function () { // 初始化圆心
            var self = this;
            for (var i = 0; i < self.lastPoint.length; i++) {
                self.ctx.fillStyle = '#CFE6FF';
                self.ctx.beginPath();
                self.ctx.arc(self.lastPoint[i].x, self.lastPoint[i].y, self.r / 2, 0, Math.PI * 2, true);
                self.ctx.closePath();
                self.ctx.fill();
            }
        },
        drawStatusPoint: function (type) { // 初始化状态线条
            var self = this;
            for (var i = 0; i < self.lastPoint.length; i++) {
                self.ctx.strokeStyle = type;
                self.ctx.beginPath();
                self.ctx.arc(self.lastPoint[i].x, self.lastPoint[i].y, self.r, 0, Math.PI * 2, true);
                self.ctx.closePath();
                self.ctx.stroke();
            }
        },
        drawLine       : function (po, lastPoint) {// 解锁轨迹
            var self = this;
            self.ctx.beginPath();
            self.ctx.lineWidth = 3;
            self.ctx.moveTo(self.lastPoint[0].x, self.lastPoint[0].y);
            console.log(self.lastPoint.length);
            for (var i = 1; i < self.lastPoint.length; i++) {
                self.ctx.lineTo(self.lastPoint[i].x, self.lastPoint[i].y);
            }
            self.ctx.lineTo(po.x, po.y);
            self.ctx.stroke();
            self.ctx.closePath();

        },
        createCircle   : function () {// 创建解锁点的坐标，根据canvas的大小来平均分配半径
            var self       = this;
            var n          = self.chooseType;
            var count      = 0;
            self.r         = self.ctx.canvas.width / (2 + 4 * n);// 公式计算
            self.lastPoint = [];
            self.arr       = [];
            self.restPoint = [];
            var r          = self.r;
            for (var i = 0; i < n; i++) {
                for (var j = 0; j < n; j++) {
                    count++;
                    var obj = {
                        x    : j * 4 * r + 3 * r,
                        y    : i * 4 * r + 3 * r,
                        index: count
                    };
                    self.arr.push(obj);
                    self.restPoint.push(obj);
                }
            }
            self.ctx.clearRect(0, 0, self.ctx.canvas.width, self.ctx.canvas.height);
            for (var i = 0; i < self.arr.length; i++) {
                self.drawCle(self.arr[i].x, self.arr[i].y);
            }
        },
        getPosition    : function (e) {// 获取touch点相对于canvas的坐标
            var rect = e.currentTarget.getBoundingClientRect();
            var po   = {
                x: e.touches[0].clientX - rect.left,
                y: e.touches[0].clientY - rect.top
            };
            return po;
        },
        update         : function (po) {// 核心变换方法在touchmove时候调用
            var self = this;
            self.ctx.clearRect(0, 0, self.ctx.canvas.width, self.ctx.canvas.height);

            for (var i = 0; i < self.arr.length; i++) { // 每帧先把面板画出来
                self.drawCle(self.arr[i].x, self.arr[i].y);
            }

            self.drawPoint(self.lastPoint);// 每帧花轨迹
            self.drawLine(po, self.lastPoint);// 每帧画圆心

            for (var i = 0; i < self.restPoint.length; i++) {
                if (Math.abs(po.x - self.restPoint[i].x) < self.r && Math.abs(po.y - self.restPoint[i].y) < self.r) {
                    self.drawPoint(self.restPoint[i].x, self.restPoint[i].y);
                    self.lastPoint.push(self.restPoint[i]);
                    self.restPoint.splice(i, 1);
                    break;
                }
            }

        },
        checkPass      : function (psw1, psw2) {// 检测密码
            var p1 = '',
                p2 = '';
            for (var i = 0; i < psw1.length; i++) {
                p1 += psw1[i].index + psw1[i].index;
            }
            for (var i = 0; i < psw2.length; i++) {
                p2 += psw2[i].index + psw2[i].index;
            }
            return p1 === p2;
        },
        storePass      : function (psw) {// touchend结束之后对密码和状态的处理
            var self = this;
            if (self.pswObj.step == 1) {
                if (self.checkPass(self.pswObj.fpassword, psw)) {
                    self.pswObj.step      = 2;
                    self.pswObj.spassword = psw;
                    $('#title').innerHTML = '密码保存成功';
                    self.drawStatusPoint('#2CFF26');
                    C.Native.saveData('passwordxx', JSON.stringify(self.pswObj.spassword));
                    C.Native.saveData('chooseType', self.chooseType);
                } else {
                    $('#title').innerHTML = '两次不一致，重新输入';
                    self.drawStatusPoint('red');
                    delete self.pswObj.step;
                }
            } else if (self.pswObj.step == 2) {
                if (self.checkPass(self.pswObj.spassword, psw)) {
                    $('#title').innerHTML = '解锁成功';
                    self.drawStatusPoint('#2CFF26');
                } else {
                    self.drawStatusPoint('red');
                    $('#title').innerHTML = '解锁失败';
                }
            } else {
                self.pswObj.step      = 1;
                self.pswObj.fpassword = psw;
                $('#title').innerHTML = '再次输入';
            }

        },
        //设置密码状态
        makeState      : function () {
            var self = this;
            if (self.pswObj.step == 2) {
                $('#updatePassword').removeClass('dn');
                $('#title').innerHTML = '请解锁';
            } else if (self.pswObj.step == 1) {
                $('#updatePassword').addClass('dn');
            } else {
                $('#updatePassword').addClass('dn');
            }
        },
        //重新来过
        reset          : function () {
            var self = this;
            self.makeState();
            self.createCircle();
        },
        /**
         * 事件绑定
         * @param e
         */
        touchstart     : function (e) {
            var self = this;
            e.preventDefault();// 某些android 的 touchmove不宜触发 所以增加此行代码
            var po = self.getPosition(e);
            console.log(po);
            for (var i = 0; i < self.arr.length; i++) {
                if (Math.abs(po.x - self.arr[i].x) < self.r && Math.abs(po.y - self.arr[i].y) < self.r) {

                    self.touchFlag = true;
                    self.drawPoint(self.arr[i].x, self.arr[i].y);
                    self.lastPoint.push(self.arr[i]);
                    self.restPoint.splice(i, 1);
                    break;
                }
            }
        },
        touchmove      : function (e) {
            var self = this;
            if (self.touchFlag) {
                self.update(self.getPosition(e));
            }
        },
        touchend       : function (e) {
            var self = this;
            if (self.touchFlag) {
                self.touchFlag = false;
                self.storePass(self.lastPoint);
                setTimeout(function () {
                    self.reset();
                }, 300);
            }
        },
        //重新设置手势密码
        updatePassword : function () {
            var self = this;
            C.Native.saveData('passwordxx', '');
            C.Native.saveData('chooseType', '');
            self.pswObj           = {};
            $('#title').innerHTML = '绘制解锁图案';
            self.reset();
        },

    }));
    $(function () {
        new Page({
            el: $('body')[0]
        });
    })
});