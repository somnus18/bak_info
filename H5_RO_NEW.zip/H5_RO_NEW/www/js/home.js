/**
 * @Author : zhangjunli001@pingan.com.cn
 * @Date   : 2016-05-05
 * @Time   : 19:20:32
 *
 * @Description: 首页信息
 */
/* global define: false */

define(['zepto', 'C', 'view', 'scrollView'], function ($, C, View, scrollView) {

    'use strict';

    var Page = View.extend(_.extend(scrollView, {
        // 事件
        events: {
            // 用户Id获取焦点
            'focus .js_ipt': 'inputFocus',
            // 查看更多事件
            'tap .js_more': 'getMore',
            // 点击增加
            'tap .js_add': 'addMore',
            // 处理每一项任务
            'tap #customerInfo li': 'handleTask',
            // 新消息处理
            'tap .js_newTask': 'newTask',
            // 打卡
            'tap .js_clock': 'clockCard',
            // 取消
            'tap .js_cancel': 'cancelBtn',
            // 确认
            'tap .js_confirm': 'confirmBtn',
            // 删除首页的入口
            'tap .red-del': 'btnDel',
            // 添加下方的框到首页
            'tap .js_footE li': 'delBel',
            // 关闭任务暂停弹框
            'tap .js_stop': 'closeStopLeayer'
        },
        // 区域指定
        el: 'body',
        // 打卡提示
        cardTip: $('.js_goodCard'),
        // 用户列表
        custList: $('#customerInfo'),
        // 用户列表模板
        custTpl: _.template($('#listTpl').html()),
        // 底部自定义快捷方式模板
        frame_quickBtn: _.template($('#quickBtnTpl').html()),
        // 底部自定义快捷方式弹窗浮层模板
        frame_quickBtnPopTpl: _.template($('#quickBtnPopTpl').html()),
        // 底部自定义未添加快捷方式弹窗浮层模板
        frame_quickUnaddBtnTpl: _.template($('#quickUnaddBtnTpl').html()),
        // 每页显示条数
        account: 20,
        // 防重标示
        isPost: false,
        // 新消息提示
        newsTip: $('.js_newTask'),
        // 增加浮动的页面
        addPage: $('.js_addMore'),
        // 查看更多
        more: $('.js_more'),
        // 没有任务
        noTask: $('.js_noTask'),
        // 快捷入口按钮配置
        quickBtnConfig: {
            mycard: {
                name: '我的名片',
                icon: 'icon-mycard',
                eventCode: 'mycard'
            },
            set: {
                name: '设置',
                icon: 'icon-set',
                eventCode: 'set'
            },
            calendar: {
                name: '任务日历',
                icon: 'icon-calendar',
                eventCode: 'calendar'
            }
        },

        // 任务状态
        taskStatus: {
            '1': '待处理',
            '2': '待预约',
            '3': '已超时',
            '4': '新任务',
            '9': '已暂停'
        },
        // 查询的类型 1 首页
        home: 1,
        // 首页固定显示的个数
        btnIndex: 5,
        // 初始化
        initialize: function () {
            var self = this;
            C.Native.setHeader({
                title: '房交所RO系统',
                leftCallback: function () {
                    C.Native.back();
                }
            });
            self.obj = {};
            self.firstPageData = {};
            self.index = 0;
            self.isRo = '';
            // 我的任务页面进入详情时候的参数返回的时候本地存贮清空
            C.Utils.data(C.Constant.DataKey.ELSE_TASK_STATUS, null);
            // 清除保存的待分配状态
            C.Utils.data(C.Constant.DataKey.WAIT_STATUS,null);
            // 获取用户信息
            C.Native.getUserInfo(function (res) {
                self.obj.userName = res.userName || '未知';
                self.obj.userId = res.userId;
                // 如果是抵押副理的角色的话
                // "role":"R_PA017_PAPC_MAM,R_PA017_PAPC_MC"
                if(res.role.indexOf(C.Constant.USER_ROLE.MAM) > -1){
                    C.Utils.data(C.Constant.DataKey.USER_RO_MAM,res.role);
                }else{
                    C.Utils.data(C.Constant.DataKey.USER_RO_MAM,null);
                }
                // 角色 R_PA017_PAPC_MC 外勤抵押专员，isRc == '1？联络人:专员   外勤抵押副理，R_PA017_PAPC_MC 外勤抵押专员
                self.obj.role = (res.role == C.Constant.USER_ROLE.RO && res.isRc == '0');
                self.cardTip.html(_.template($('#cardTpl').html())(self.obj));
                self.isRo = (res.role.indexOf(C.Constant.USER_ROLE.RO)!=-1); // 判断是否是ro角色
                // 如果是ro角色的话,
                self.btnIndex = self.isRo ? self.btnIndex : self.btnIndex - 1;
                self.render();
                self.renderQuickBtn();
            });
        },
        // 渲染底部自定义快捷入口
        renderQuickBtn: function () {
            var self = this,
                data = new Array();
            // 读取Native存储里的按钮配置
            C.Native.getData(self.obj.userId, function (res) {
                if (!!res) {
                    var btnArr = res.split('|');
                    for (var i in btnArr) {
                        if (!!self.quickBtnConfig[btnArr[i]]) {
                            data.push(self.quickBtnConfig[btnArr[i]]);
                        }
                    }
                }
                $('.js_fotter').html(self.frame_quickBtn({data: data}));
                // 根据用户角色，任务分配按钮隐藏或者显示
                // 角色 R_PA017_PAPC_MC 外勤抵押专员，isRc == '1？联络人:专员   外勤抵押副理，R_PA017_PAPC_MC 外勤抵押专员
                self.obj.role? $('.js_allot').parent().hide() : $('.js_allot').parent().show();
                self.isRo ? $('#order_list').show():$('#order_list').hide(); // ro角色显示任务清单按钮，否则隐藏
                // 对底部的每个图标调用事件
                self.forwardPage();
            });
        },
        //下拉刷新
        pullDownActionBase: function () {
            var self = this;
            if (self.isLoading) {
                $('#pullUp').hide();
                return;
            }
            self.isLoading = "down";
            self.index = 0;
            self.newsTip.hide();
            self.getData(true);
        },
        //上拉加载
        pullUpActionBase: function () {
            var self = this;
            if (self.isLoading) {
                $('#pullDown').hide();
                return;
            }
            self.isLoading = "up";
            self.getData(true);
        },
        /**
         * 页面渲染
         */
        render: function () {
            var self = this;
            self.getData(false);
        },
        /**
         * 数据加载
         */
        getData: function (do_action) {
            var self = this,
                page = null,
                time = null,
                datas = [],
                data = null;
            page = self.index + 1;
            if (self.isPost) {
                return;
            }
            self.isPost = true;
            C.UI.loading();
            $.ajax({
                url: C.Api('CUSTOMER_INFORMATION'),
                data: {
                    page: page,
                    pageSize: self.account,
                    orderType: self.home
                },
                type: 'get',
                ////是否上拉或下拉刷新任务列表
                has_action_refresh: do_action,
                success: function (res) {
                    C.UI.stopLoading();
                    self.isPost = false;
                    if (res.flag == C.Flag.SUCCESS) {
                        data = res.data;
                        if (data.length) {
                            time = data[0]['timeShow'] || '';
                            if (time) {
                                C.Native.saveTimestamp(time);
                            }
                            self.noTask.hide();
                            self.more.show();
                            datas = C.removeRepeatData(data,self.firstPageData,datas,page, 'subtask', true);   // 去除重复数据之后保存的数组
                            if (!datas.length) {
                                delete self.isLoading;
                            } else {
                                self.getDataList(datas);
                            }
                            self.firstPageData = datas;
                            self.index++;
                        } else {
                            if (page == 1) {
                                self.firstPageFormat();
                            } else {
                                C.Native.tip('没有更多数据');
                            }
                        }
                        //安装iScroll
                        self.installScroll();
                    } else {
                        page == 1 && !do_action && self.firstPageFormat();
                    }
                    // 初始化的时候开启native的轮巡
                    if(!do_action){
                        self.newsTip.hide();
                        C.Native.startPolling();
                    }
                    delete self.isLoading;
                    self.refreshScroll();
                },
                complete: function (res) {
                    //请求成功之后就要刷新列表,不管有没有数据
                    if (self.hasInitScroll) self.refreshScroll();
                    self.isPost = false;
                    C.UI.stopLoading();
                    delete self.isLoading;
                },
                /**
                 * 错误回调函数
                 * @param xhr XMLHttpRequest
                 * @param errorType 错误类型 // type: "timeout", "error", "abort", "parsererror"
                 * @param errorMsg 错误信息
                 */
                error: function (xhr, errorType, errorMsg) {
                    if (page == 1 && !do_action) {
                        self.noTask.show();
                        self.more.hide();
                    }
                    self.installScroll();
                    // 初始化的时候开启native的轮巡
                    if(!do_action){
                        C.Native.startPolling();
                    }
                    if (self.hasInitScroll) self.refreshScroll();
                    self.isPost = false;
                    C.UI.stopLoading();
                    delete self.isLoading;
                }
            });
        },
        /**
         * 允许iScroll
         */
        installScroll: function () {
            var self = this;
            if (!self.hasInitScroll) {
                // 动态改变列表的高度
                var scrollContainerH = $('.layout').height();
                self.install(scrollContainerH);
                self.hasInitScroll = true;
            }
        },
        // 清空列表 展示暂无任务
        firstPageFormat: function () {
            this.custList.empty();
            this.noTask.show();
            this.more.hide();
        },
        /**
         * 刷新数据
         */
        getDataList: function ($el) {
            var self = this, objAry = [];
            $.each($el, function (index, item) {
                // taskStatus==1 custStatus存在的话 说明任务已开始，显示处理中，否则是待处理状态
                item.stageName = self.taskStatus[item.taskStatus];
                item.redStyle = true;
                if (item.taskStatus == '1') {
                    if (item.custStatus) {
                        item.stageName = '处理中';
                    }
                    item.redStyle = false;
                }
                item.subtask = item.subtask || '';
                item.prdName = C.Constant.BUSINESS_LINE_NAME[item.productType];
                item.appointDate = item.appointDate ? C.Utils.parseDateFormat(item.appointDate, 'MM月dd日') : '';
                item.appointTime = item.appointTime ? item.appointTime.split(':')[0] + ':' + item.appointTime.split(':')[1] : '';
                item.custMobile = item.custMobile ? C.Utils.formatMobileNo(item.custMobile) : '';
                objAry.push(self.custTpl(item));
            });
            if (self.isLoading == 'up') {
                self.custList.append(objAry.join(''));
            } else {
                self.custList.html(objAry.join(''));
            }
            delete self.isLoading;
        },
        /**
         * 公共入口跳转
         */
        forwardPage: function () {
            var footer = $('.js_fotter'),
                self = this;
            footer.find('span[data-code="set"]').bind('tap', function () {
                C.Native.forward({url: 'ro_setting.html'});
            });
            footer.find('span[data-code="book"]').bind('tap', function () {
                C.Native.tip('敬请期待！');
            });
            footer.find('span[data-code="kpi"]').bind('tap', function () {
                C.Native.tip('敬请期待！');
            });
            footer.find('span[data-code="allot"]').bind('tap', function () {
                C.Native.forward({url: 'task_center.html'});
            });
            footer.find('span[data-code="notice"]').bind('tap', function () {
                C.Native.forward({url: 'ro_message.html'});
            });
            footer.find('span[data-code="calendar"]').bind('tap', function () {
                C.Native.tip('敬请期待！');
            });
            footer.find('span[data-code="mycard"]').bind('tap', function () {
                C.Native.forward({url: 'myCard.html'});
            });
            footer.find('span[data-code="list"]').bind('tap', function () {
                self.getTaskList();
            });
        },
        /**
         * 新消息处理
         */
        newTask: function () {
            var self = this;
            self.newsTip.hide();
            self.index = 0;
            self.isLoading = 'down';
            self.getData();
        },
        /**
         * 获取更多
         */
        getMore: function () {
            C.Native.forward({
                url: 'mytask.html'
            });
        },
        closeStopLeayer: function () {
            $('#stop-task').addClass('dn');
        },
        /**
         * 跳转到我的任务页面
         */
        handleTask: function (e) {
            var curr = $(e.currentTarget);
            if (curr.attr('data-code') == 9) {
                $('#stop-task').removeClass('dn');
                return;
            }
            C.Utils.data(C.Constant.DataKey.DETAIL_TASKID, curr.data('id'));
            C.Utils.data(C.Constant.DataKey.DETAIL_CITYID, curr.data('cityid'));
            C.Utils.data(C.Constant.DataKey.DETAIL_STAGEID, curr.data('stageid'));
            C.Utils.data(C.Constant.DataKey.DETAIL_PRODUCTTYPE, curr.data('prdtype'));
            C.Utils.data(C.Constant.DataKey.DETAIL_OVER_TIME, curr.data('overtime'));
            C.Utils.data(C.Constant.DataKey.SUB_TASK_CONTENT, curr.data('subtask'));  // 子任务名称
            C.Native.forward({
                url: 'task_detail.html'
            });
        },
        /**
         * 获取最新任务数
         */
        getNum: function (num, account) {
            num = parseInt(num) || '';
            account = parseInt(account) || '';
            if (num) {
                $('.js_newTask').show();
                $('.js_newTask').find('span.num').html(num);
            }
            if (account) {
                $('.js_allot').html('<span class="icon-num">' + account + '</span>');
            }
        },
        /**
         * 打卡
         */
        clockCard: function () {
            C.Native.forward({
                // url: 'ro_attendance.html'
                url: 'ro_attendance_zhai.html'
            });
        },
        /**
         * 显示的空框个数和是否显示任务分配
         */
        allotBtnNum: function (btnAry) {
            var self = this,
                allotTrue = true,
                isRoRole = false,
                obj = {},
                liLength = null;
            // self.obj.role ：true 专员
            if (self.obj.role) {
                liLength = self.btnIndex - 1 + btnAry.length;
                allotTrue = true;
            } else {
                liLength = self.btnIndex + btnAry.length;
                allotTrue = false;
            }
            if (self.isRo) {
                isRoRole = true;
            }
            obj.liLength = liLength;
            obj.allotTrue = allotTrue;
            obj.isRoRole = isRoRole;
            return obj;
        },
        /**
         * 点击增加
         */
        addMore: function () {
            var self = this,
                btnAry = [],
                obj = null,
                addCodeAry = [],
                codeArr = [],
                unAddNodes = [],
                unAddArr = [];
            addCodeAry = self.commJudge($('.js_fotter li'), 'add', btnAry, codeArr);
            // 获取首页显示的data值
            codeArr = addCodeAry.codeArr;
            // 保存首页显示的节点
            btnAry = addCodeAry.nodesAry;
            // 将配置项里的入口进行遍历，如果不存在code数组里面，则表示待添--加状态
            for (var i in self.quickBtnConfig) {
                if (codeArr.indexOf(i) == -1) {
                    unAddNodes.push(i);
                }
            }
            for (var i in unAddNodes) {
                if (!!self.quickBtnConfig[unAddNodes[i]]) {
                    unAddArr.push(self.quickBtnConfig[unAddNodes[i]]);
                }
            }
            // 获取任务分配的状态
            obj = self.allotBtnNum(btnAry);
            $('.js_footH').html(self.frame_quickBtnPopTpl({data: btnAry, obj: obj}));
            $('.js_footE').html(self.frame_quickUnaddBtnTpl({data: unAddArr}));
            self.addPage.removeClass('dn');
        },
        /**
         * 取消
         */
        cancelBtn: function () {
            this.addPage.addClass('dn');
        },
        /**
         * 确认
         */
        confirmBtn: function () {
            var self = this,
                code = null,
                nodeStr = null,
                nodeCodes = [],
                data = [];
            $('.js_footH li').each(function () {
                code = $(this).find('span').data('code');
                if (!!code) {
                    nodeCodes.push(code);
                }
            });
            // 保存设置
            nodeStr = nodeCodes.join('|');
            C.Native.saveData(self.obj.userId, nodeStr);
            for (var i in nodeCodes) {
                if (!!self.quickBtnConfig[nodeCodes[i]]) {
                    data.push(self.quickBtnConfig[nodeCodes[i]]);
                }
            }
            $('.js_fotter').html(self.frame_quickBtn({data: data}));
            // 根据用户角色，任务分配按钮隐藏或者显示
            // 角色 R_PA017_PAPC_MC 外勤抵押专员，isRc == '1？联络人:专员   外勤抵押副理，R_PA017_PAPC_MC 外勤抵押专员
            self.obj.role ? $('.js_allot').parent().hide() : $('.js_allot').parent().show();
            self.isRo ? $('#order_list').show():$('#order_list').hide(); // ro角色显示任务清单按钮，否则隐藏
            // 对底部的每个图标调用事件
            self.forwardPage();
            self.addPage.addClass('dn');
        },
        /**
         * 公共数据取值判断
         */
        commJudge: function ($el, type, nodesAry, addBtn) {
            var self = this,
                code = null,
                commObj = {},
                btnAry = [],
                codeArr = [],
                topNodes = [],
                bottomNodes = [];
            nodesAry = type == 'H' ? topNodes : (type == 'E' ? bottomNodes : btnAry);
            $el.each(function () {
                code = $(this).find('span').data('code');
                if (!!code) {
                    for (var i in self.quickBtnConfig) {
                        if (self.quickBtnConfig[i]['eventCode'] == code) {
                            if (addBtn) {
                                codeArr.push(code);
                                nodesAry.push(self.quickBtnConfig[i]);
                            }else{
                                nodesAry.push(code);
                            }
                        }
                    }
                }
            });
            // 获取上层和下层的icon
            commObj.nodesAry = nodesAry;
            commObj.codeArr = codeArr ||  '';
            return commObj;
        },
        /**
         * 公共获取数组
         */
        commGet: function (nodeBtn, nodesAry, type) {
            var self = this,
                code = null,
                topBtn = [],
                bottomBtn = [];
            nodeBtn = type == 'H' ? topBtn : bottomBtn;
            for (var i in nodesAry) {
                code = nodesAry[i];
                if (!!code) {
                    for (var i in self.quickBtnConfig) {
                        if (self.quickBtnConfig[i]['eventCode'] == code) {
                            nodeBtn.push(self.quickBtnConfig[i]);
                        }
                    }
                }
            }
            // 点击删除后获取上层和下层的icon
            return nodeBtn;
        },
        /**
         * 浮层获取上下框的数据
         */
        topAndBottom: function (activeNode, type) {
            var self = this,
                index = null,
                obj = null,
                code = null,
                topNodes = [],
                topBtn = [],
                bottomBtn = [],
                bottomNodes = [];
            topNodes = (self.commJudge($('.js_footH li'), 'H', topNodes)).nodesAry;
            bottomNodes = (self.commJudge($('.js_footE li'), 'E', bottomNodes)).nodesAry;
            if (type == 'top') {
                index = topNodes.indexOf(activeNode);
                if (index > -1) {
                    topNodes.splice(index, 1);
                }
                bottomNodes.push(activeNode);
            } else {
                index = bottomNodes.indexOf(activeNode);
                if (index > -1) {
                    bottomNodes.splice(index, 1);
                }
                topNodes.push(activeNode);
            }
            // 重置浮层顶部icon
            topBtn = self.commGet(topBtn, topNodes, 'H');
            // 重置浮层底部icon
            bottomBtn = self.commGet(bottomBtn, bottomNodes, 'E');
            // 获取任务分配的状态
            obj = self.allotBtnNum(topBtn);
            $('.js_footH').html(self.frame_quickBtnPopTpl({data: topBtn, obj: obj}));
            $('.js_footE').html(self.frame_quickUnaddBtnTpl({data: bottomBtn}));
        },
        /**
         * 删除首页的显示的框
         */
        btnDel: function (e) {
            var activeNode = $(e.currentTarget).parent().data('code');
            this.topAndBottom(activeNode, 'top');
        },
        /**
         * 删除下方的全部功能
         */
        delBel: function (e) {
            var activeNode = $(e.currentTarget).children('span').data('code');
            this.topAndBottom(activeNode, 'bottom');
        },
        getTaskList: function () {
            var self = this;
            if (this.isPost) return;
            this.isPost = true;
            C.UI.loading();
            $.ajax({
                url: C.Api('RO_ATTENDANCE_STATE_ZHAI'),
                type: 'get',
                success: function (res) {
                    self.isPost = false;
                    if (res.flag == C.Flag.SUCCESS) {
                        C.UI.stopLoading();
                        // 已经打卡
                        if (res.data.signed == 1) {
                            C.Native.forward({
                                url: 'task_list.html',
                                data: {
                                    hdId: res.data.hdId
                                }
                            });
                        } else {
                            C.Native.tip('您尚未打卡,请先选择房管局打卡');
                        }
                    }
                }
            })
        }
    }));

    $(function () {
        var page = new Page({
            el: $('body')[0]
        });
        $$.EventListener.getNum = page.getNum;
        $$.EventListener.onBack = function () {
            location.reload();
        }
    })
});
