define([
    "zepto",
    "C"
    ],function(
        $,
        C
    ){
    var pafcode;
    var userData = C.Utils.data(C.Constant.DataKey.USER_LOGIN_INFO) || {},
        platform=userData.platform,
        paftoken = userData.paPayToken,
        cardNo = userData.Id,
        customerName = userData.custName,
        pafcode = decodeURIComponent(C.Utils.getParameter("code"));

    var header = {
        "Authorization": C.Constant.PAPAY_AUTH,
        "Content-Type": "application/x-www-form-urlencoded"
    };

    var _instant = {
        /* 刷新平安付token*/
        refreshToken:function(paftoken, callback) {
            var self = this;
            var exchange_token_param = {
                //access_token
                access_token: paftoken
            };
            // return;
            C.Native.request({
                url: C.Api.EXCHANGE_PATOKEN,
                type: "post",
                headers: header,
                data: $.param(exchange_token_param),
                success:function(data) {
                    C.Native.tip(data);
                    if (data.status == "200") {
                        var rspdata = JSON.parse(data.responseText);
                        paftoken = rspdata.access_token;
                        callback && callback(rspdata.access_token)
                    }
                }
            });
        },
        saveToken:function(pafcode,paftoken,callback){
            var pafparam = {
                // 平安付CODE
                code: pafcode,
                //平安付token
                paPayToken: C.rsaEncrypt(paftoken),
                ACCOUNT_VER:C.Constant.ACCOUNT_VER,
                os:platform
            };
            $.ajax({
                url: C.Api.SAVE_PAFTOKEN,
                type: "POST",
                data: pafparam,
                success: function(res) {
                    C.Native.tip(res);
                    if (res.flag == "1") {
                        callback && callback(res);
                    }
                }
            })
        },
        /**
         * 如有paPayToken,就用旧的Token换取新的Token
         * token/exchange
         post参数“access_token”:token

         header:
         stg1:”Authorization":”900000001493  33c6e8446a6c43a5adcf224e7e7a8d6f”
         prd：”Authorization":"900000004158 2c147337721348908d69fbf4145dd50d"
         */
        codeToToken: function(callback) {
            var self = this;
            var code_token_param = {
                code:pafcode,
                client_id: C.Constant.PAPAY_APP_ID,
                client_secret: C.Constant.PAPAY_SECRET,
                grant_type: "Bearer"

            };
            C.Native.request({
                url: C.Api.CODE_PATOKEN,
                type: "post",
                headers:header,
                body: $.param(code_token_param),
                success:function(data) {
                    C.Native.tip(data);
                    if (data.status == "200") {
                        console.log(data.responseText);
                        var rspdata = JSON.parse(data.responseText);
                        paftoken = rspdata.access_token;
                        callback && callback(paftoken);
                        //获取PafToken后保存到SS后台
                        self.saveToken(pafcode,paftoken);
                    }
                }
            });
        }
    }
    var papay = {
        bindcard:function(callback,error){
            var self = this;
            var doBind = function(paftoken){
                C.Native.bindBankCard(paftoken,
                    function(res) {
                        C.Native.tip(JSON.stringify(data));
                        // {"data":{"bankName":"中国光大银行","phoneNum":"13798528428","bankMark":"CEB","bankCardId":"8580064","bankCardType":"D","bankCardNo":"6214918888884555","userId":"1000010002594486"},"code":"1"}
                        if (res.code == C.Flag.SUCCESS) {
                            var data = res.data;
                            callback && callback(data);
                        }else{
                            error && error(res);
                        }
                    }
                );
            }
                if (paftoken == "") {
                    /**
                     * 需要手工绑定地址,返回地址得到CODE参数
                     https://test-www.stg.1qianbao.com/auth?response_type=code&client_id=900000001493&redirect_uri=http://success&mustLogout=1&scope=user:balance placeorder headlesspayment&constraints={
                          "name" : "平安",
                          "idNumber" : "440104198909235012"
                        }
                     用code换取token
                     stg1： client_id ：900000001493  clientSecret ：33c6e8446a6c43a5adcf224e7e7a8d6f
                     prd：client_id ：900000004158  clientSecret ：2c147337721348908d69fbf4145dd50d"

                     test-www.stg.1qianbao.com:7443/token
                     参数：
                     “code”:code,
                     “client_id": client_id
                     “client_secret":clientSecret
                     “grant_type”:"Bearer"
                     */
                    if (pafcode == "") {
                        //手工绑定地址,返回地址得到CODE参数
                        // var redirect_URL = C.Api.ILOAN_HOME + "/card_binding.html";
                        var redirect_URL = location.href;
                        var constraints = "{\"name\":\"" + customerName + "\",\"idNumber\":\"" + cardNo + "\"}";
                        var yiqianbaoUrl = C.Api.YIQIANBAO + "/auth?response_type=code&client_id="+C.Constant.PAPAY_APP_ID+"&redirect_uri=" + redirect_URL + "&mustLogout=1&scope=user:balance placeorder headlesspayment&constraints=" + constraints;
                        httpurl = decodeURIComponent(yiqianbaoUrl);
                        C.UI.dialog({
                            content:"您的壹钱包账户尚未激活，快去激活吧",
                            okText:"马上激活",
                            ok:function(){
                                C.Native.forward({
                                    url:httpurl
                                });
                            }
                        })
                        return;
                    }
                    //code换取access_token
                    _instant.codeToToken(function(paftoken){
                        doBind(paftoken);
                    });
                } else {
                    // {"data":{"bankName":"中国光大银行","phoneNum":"13798528428","bankMark":"CEB","bankCardId":"8580064","bankCardType":"D","bankCardNo":"6214918888884555","userId":"1000010002594486"},"code":"1"}
                    _instant.refreshToken(paftoken, function(newToken) {
                        paftoken = newToken;
                        //调用平安付SDK
                        doBind(paftoken);
                    });
                }
        }
    }
    return papay;
})
