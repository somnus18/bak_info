/**
 * @Author : zhangjunli001@pingan.com.cn
 * @Date   : 2016-04-08
 * @Time   : 11:20:32
 *
 * @Description: 配置信息
 */
/* global define: false */

define([], function () {

    'use strict';

    return {
        // 类型
        '1_1': {
            '1': '宅e贷',
            '2': '按揭',
            '3': '二手房'
        },
        '1_2': {
            '1': '新任务',
            '2': '时间待定',
            '3': '拉产调',
            '4': '办押',
            '5': '他证',
            '6': '未完成',
            '7': '已完成'
        },
        // 任务详情更多信息展示字段
        detailMoreMaps: {
            ershoufang: {
                sell: {
                    title: '出售方',
                    code: '序号',
                    sellName: '出售方姓名',
                    sellIdCard: '出售方证件号码',
                    sellAddress: '证件地址'
                },
                buy: {
                    title: '买售方',
                    code: '序号',
                    buyName: '卖方姓名',
                    buyIdCard: '卖方证件号码',
                    buyAddress: '卖方证件地址'
                },
                sellAgent: {
                    title: '卖方经纪人',
                    sellAgentName: '卖方经纪人姓名',
                    sellAgentCardId: '卖方经纪人号码'
                },
                buyAgent: {
                    title: '买方经纪人',
                    buyAgentName: '买方经纪人姓名',
                    buyAgentCardId: '买方经纪人证件号码'
                },
                buyAgentCard: {
                    title: '房屋价格信息',
                    buyAgentCardId: '房屋售价',
                    houseArea: '房屋面积',
                    ratePatmentType: '税费承担',
                    brokeragePatmentType: '佣金承担方'
                },
                downPayFigure: {
                    title: '支付方式',
                    downPayFigure: '定金金额',
                    frontPayFigure: '首付付款',
                    secondPayFigure: '二期房款',
                    finalPayFigure: '尾款'
                },
                totalBroke: {
                    title: '佣金',
                    totalBrokerage: '佣金金额'
                },
                houseCard: {
                    title: '房屋信息',
                    houseCardId: '房屋证件号码',
                    address: '房屋地址',
                    province: '地区 省',
                    city: '市',
                    region: '区',
                    neighbourhood: '小区名称',
                    floorNo: '楼栋号',
                    houseNo: '室号',
                    houseType: '房屋类型',
                    houseTypeOther: '其他房屋描述',
                    pledgeStatus: '抵押情况',
                    pledgeFigure: '抵押金额',
                    hireStatus: '是否出租',
                    creditor: '权利人信息'
                }
            }
        }
    }
});